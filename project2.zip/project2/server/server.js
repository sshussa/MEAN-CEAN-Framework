//Dependencies

var express    = require('express');        // call express
var app        = express();                 // define our app using express
var bodyParser = require('body-parser');
var Viewall     = require('./app/models/viewall');
var mongoose   = require('mongoose');
var path= require('path');
var methodOverride = require('method-override');

//socket code
var http=require('http').Server(app);
var io=require('socket.io')(http);

//API response caching

// var apicache= require('apicache');
// var cache= apicache.middleware;
// app.use(cache('5 minutes'));

//connect to the database
mongoose.connect('mongodb://localhost/viewtest1');

// configure app to use bodyParser()
// this will let us get the data from a POST

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../client')));
app.use(bodyParser.json({type: 'application/vnd.api+json'})); // parse application/vnd.api+json as json
app.use(methodOverride('X-HTTP-Method-Override')); // override with the X-HTTP-Method-Override header in the request

//linking style for error handling
app.use(express.static(__dirname + '/public'));
app.set('view engine', 'ejs');


//set our port
var port = process.env.PORT || 8080;

// ROUTES FOR OUR API

var router = express.Router();              // get an instance of the express Router

// middleware to use for all requests
router.use(function(req, res, next) {
    // do logging
    console.log('Middleware is at work');
    next(); // make sure we go to the next routes and don't stop here
});

router.route('/viewalls')

// get all viewall response (accessed at GET http://localhost:8080/#/viewalls)

    .get(function(req, res) {
        Viewall.find(function(err, viewalls) {
            if (err)
                res.send(err);

            res.json(viewalls);
            //console.log(viewalls);
        });
    });

// all of our routes will be prefixed with /api

app.use('/api', router);

var users=[];
io.on('connection',function(socket){
    var username='';
    console.log('A user has connected!!');
    socket.on('request-users',function(){
    socket.emit('users',{users:users});});
    socket.on('message',function(data){
        io.emit('message',
            {username:username, message:data.message});
    });

    socket.on('add-user',function(data){
        if(users.indexOf(data.username)==-1){
            io.emit('add-user',
                {
            username:data.username
                });
            username=data.username;
            users.push(data.username);
        }
        else{
          socket.emit('prompt-username',{
              message:'User Already Exists!'
          })
        }
            });
    socket.on('disconnect',function(){
        console.log(username+'has disconnected!!');
        users.splice(users.indexOf(username),1);
        io.emit('remove-user', {username:username});
    })
});

//Error Message
app.get('*', function(req, res, next) {
    var err = new Error();
    err.status = 404;
    next(err);
});

app.use(function(err, req, res, next) {
    if(err.status !== 404) {
        return next();
    }
    res.status(404);
    // res.send(err.message || '<div class="errorMessage">** Error: Oops, it happens: Landed on a incorrect Page **</div>');
    res.render('errorMessage.ejs');
});

// START THE SERVER
http.listen(port);
console.log('Awesome, magic happens on port ' + port);