var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var ViewallSchema   = new Schema({
    terms: String,
    offerContent: String,
    offerLabel:String,
    annualFeeContent: String,
    applyLink: String,
    learnMoreLink: String,
    ratingLink: String,
    ratingValue: String,
    rating: String,
    offer: String,
    title: String,
    fileName: String,
    pmc: String,
    Products:[],
    id:Number
});

module.exports = mongoose.model('Viewall', ViewallSchema);