angular.module('App').controller('viewaboutController',['$scope','viewallService', function($scope,viewallService){
	viewallService.list(function(viewallService){
	$scope.viewallService=viewallService["0"];
         console.log(viewallService);
	});
}]);

//angular.module('App')
//    .controller('viewaboutController', ['$scope','$http','ViewallService', function($scope, $http, ViewallService) {
//
//        ViewallService.get()
//            .success(function(data) {
//                $scope.viewallService = data;
//                console.log("Data::"+data);
//
//            });
//    }]);