/**
 * Created by syedhus on 11/12/16.
 */
exports.config = {
    seleniumAddress: 'http://localhost:4444/wd/hub',
    specs: ['tests/protractor.js']
};