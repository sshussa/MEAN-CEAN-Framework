/**
 * Created by syedhus on 11/8/16.
 */


    describe("mycontrollertest", function () {

        var myScope;

        beforeEach(function () {
            module('App');
        });

        beforeEach(inject(function ($rootScope, $controller) {
            myScope = $rootScope.$new();
            $controller('myController', {
                $scope: myScope});
        }));

        beforeEach(inject(function (_$httpBackend_) {
            $httpBackend = _$httpBackend_;
        }));

        it("Test hint", function () {
            expect(myScope.hint).toEqual("<p>Start with a web server such as <strong>node server.js</strong> to retrieve JSON from Server</p>");
        });

        it("loadJson should be defined", function () {
            expect(myScope.loadJson).toBeDefined();
        });

        it('has a dummy spec to test 2 + 2', function() {
            // An intentionally failing test. No code within expect() will never equal 4.
            expect(2+2).toEqual(4);
        });

        //it("retrieveQuotes should return array of quotes", inject(function ($httpBackend) {
        //    $httpBackend.whenGET("data.json").respond(200);
        //    $httpBackend.expectGET("data.json");
        //    myScope.loadJson();
        //    $httpBackend.flush();
        //}));

        //it('Test load json name', function () {
        //    $httpBackend.whenGET('data.json').respond(200);
        //    $httpBackend.expectGET('data.json');
        //    $httpBackend.flush();
        //    //expect(myScope.data.name).toEqual("NPC01");
        //});
    });

//describe('Users factory', function() {
//    it('has a dummy spec to test 2 + 2', function() {
//        // An intentionally failing test. No code within expect() will never equal 4.
//        expect(2+2).toEqual(4);
//    });
//});