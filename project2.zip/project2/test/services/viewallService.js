angular.module('App').factory('viewallService', function($http){
	return{
	list:function(callback){
	$http.get("/api/viewalls").success(callback);
	}
	}
});

//angular.module('App')
//    .factory('ViewallService', ['$http',function($http) {
//        return {
//            get : function() {
//                return $http.get('/api/viewalls');
//            }
//        }
//    }]);