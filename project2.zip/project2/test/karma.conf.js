var webpackConfig = require('./webpack.config.js');
webpackConfig.entry = {};

module.exports = function(config) {
    config.set({
        basePath: '',
        frameworks: ['jasmine','mocha','chai'],

        reporters: ['mocha','progress'],
        port: 9876,
        colors: true,
        logLevel: config.LOG_INFO,
        autoWatch: true,
        browsers: ['Chrome'],
        singleRun: false,
        autoWatchBatchDelay: 300,

        files: [
            './vendors/jquery.min.js',
            './vendor.bundle.js',
            './app.bundle.js',
            './node_modules/angular-mocks/angular-mocks.js',
            './template/**.html',
            './tests/*.spec.js'],

        preprocessors: {
            '../app.bundle.js': ['webpack'],
            '../tests/*.spec.js': ['webpack'],
            '../template/**.html': ['ng-html2js']
        },
        ngHtml2JsPreprocessor: {
           moduleName:'template'
        },

        webpack: webpackConfig,

        webpackMiddleware: {
            noInfo: true
        },
        plugins: [
            require('karma-webpack'),
            'karma-chai',
            'karma-mocha',
            'karma-jasmine',
            'karma-chrome-launcher',
            'karma-ng-html2js-preprocessor',
            'karma-mocha-reporter'
        ]
    });
};