require('./stylesheet/style.scss');

var App = angular.module('App', ['ui.router', 'ui.bootstrap','ngResource','btford.socket-io','ngSanitize']);
App.config(function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/cards');
    $stateProvider
    //home state and nested views=======
        .state('cards', {
            url: '/cards',
            templateUrl: 'template/partial-home.html'
        })

        //nested views with custom controller

        .state('cards.spotlight', {
            url: '/spotlight',
            templateUrl: 'template/partial-home-spotlight.html',
            controller: function ($scope) {
                $scope.modules = ['Spotlight', 'Viewall', 'Compare', 'Quiz', 'Findoffer'];
            }
        })

        //viewall page and multiple named views=========

        .state('viewabout', {
            url:'/viewabout',
            views:{
                //the main template will be placed here(relative name)======
                '': {
                    templateUrl:'template/partial-about.html',
                    controller:'viewaboutController'
                },

                //the child will be defined here (absolute name)=======
                'columnOne@viewabout':{
                    templateUrl:'template/partial-about-footer.html',
                    controller:'ModalDemoCtrl'
                },
                'columnTwo@viewabout':{
                    templateUrl:'template/partial-c2c.html',
                    controller:'chatController'
                }
            }
        });
});
//factories
//
// App.factory('viewallService', function($http){
//     return{
//         list:function(callback){
//             $http.get("viewall_PZN.json").success(callback);
// //            .then(function(response){
// //              $scope.content=response.data;
// //              $scope.statuscode=response.status;
// //              $scope.statustext=response.statusText;
// //            });
//         }
//     }
// });

//controller
// App.controller('viewaboutController',function($scope, viewallService){
//     viewallService.list(function(viewallService){
//         $scope.viewallService=viewallService;
//     });
// });

angular.module('App').directive('myModal', function() {
    return {
        restrict: 'E',
        templateUrl: 'myModalContent.html',
        controller: function ($scope) {
            $scope.selected = {
                item: $scope.items[0]
            };
        }
    };
});

angular.module('App').directive('w3TestDirective',function(){
    return{
        restrict: 'E',
        template:'<a href="#" class="quick-look-link" title="Quick Look"><span class="magnify-icon"></span></a>'
    };
});

angular.module('App').controller('ModalDemoCtrl', function ($scope, $modal, $log) {

    $scope.items = ['Payment Types', 'Rewards', 'Benefits'];

    $scope.open = function (size) {
        var modalInstance;
        var modalScope = $scope.$new();
        modalScope.ok = function () {
            modalInstance.close(modalScope.selected);
        };
        modalScope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        modalInstance = $modal.open({
                template: '<my-modal></my-modal>',
                size: size,
                scope: modalScope
            }
        );

        modalInstance.result.then(function (selectedItem) {
            $scope.selected = selectedItem;
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };
});
require('./controllers/myController');
require('./controllers/viewaboutController');
require('./services/viewallService');
require('./controllers/chatController');
require('./services/socketFactory');


