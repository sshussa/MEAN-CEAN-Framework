/**
 * Created by syedhus on 11/13/16.
 */
angular.module('App').factory('Socket',['socketFactory', function (socketFactory) {
    return socketFactory();
}]);