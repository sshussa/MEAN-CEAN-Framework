// angular.module('App').factory('viewallService', function($http){
// 	return{
// 	list:function(callback){
// 	$http.get("/api/viewalls").success(callback);
// 	}
// 	}
// });


angular.module('App').factory('viewallService',function ($resource) {
	return $resource("/api/viewalls");
});