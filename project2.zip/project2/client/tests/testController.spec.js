/**
 * Created by shuss22 on 11/25/2016.
 */
describe("view all controller test", function () {

    var myScope;

    beforeEach(function () {
        module('App');
    });
    var myScope;
    beforeEach(inject(function ($rootScope, $controller) {
        myScope = $rootScope.$new();
        $controller('viewaboutController', {
            $scope: myScope});
    }));

    beforeEach(inject(function (_$httpBackend_) {
        $httpBackend = _$httpBackend_;
    }));

    it("Test hint", function () {
        expect(myScope.hint).toEqual("<p>Start with a web server such as <strong>node server.js</strong> to retrieve JSON from Server</p>");
    });

    it("viewallServiceResponse should be defined", function () {
        expect(myScope.viewallServiceResonse).toBeDefined();
    });

    it('has a dummy spec to test 2 + 2', function() {
        expect(2+2).toEqual(4);
    });

});