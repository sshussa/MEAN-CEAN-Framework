// describe('User', function () {
//     var mockUserResource, $httpBackend;
//     beforeEach(angular.mock.module('myApp'));
//
//     beforeEach(function () {
//         angular.mock.inject(function ($injector) {
//             $httpBackend = $injector.get('$httpBackend');
//             mockUserResource = $injector.get('/api/viewalls');
//         })
//     });
//
//     describe('getUser', function () {
//         it('should call getUser with username', inject(function (User) {
//             $httpBackend.expectGET('/api/index.php/users/test')
//                 .respond([{
//                     username: 'test'
//                 }]);
//
//             var result = mockUserResource.getUser('test');
//
//             $httpBackend.flush();
//
//             expect(result[0].username).toEqual('test');
//         }));
//
//     });
// });





describe('ProjectResource', function(){
    beforeEach(module('App'));

    afterEach(inject(function($httpBackend){
        //These two calls will make sure that at the end of the test, all expected http calls were made
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    }));

    it('mock http call', inject(function($httpBackend, viewallService) {
        jasmine.getJSONFixtures().fixturesPath='client/tests/apiMocks';
        var resource = new viewallService(getJSONFixture('viewall_PZN.json'));
        //Create an expectation for the correct url, and respond with a mock object
        $httpBackend.whenGET("template/partial-home.html").respond(200);
        $httpBackend.expectGET('/api/viewalls').respond(200);

        //Make the query
        resource.$query();
        console.log(resource);
        //Because we're mocking an async action, ngMock provides a method for us to explicitly flush the request
        $httpBackend.flush();

        //Now the resource should behave as expected
        // expect(resource).toBeDefined();
        expect(resource).toBeDefined();
    }));
});





// describe('ProjectResource', function(){
//     beforeEach(module('App'));
//
//     afterEach(inject(function($httpBackend){
//         //These two calls will make sure that at the end of the test, all expected http calls were made
//         $httpBackend.verifyNoOutstandingExpectation();
//         $httpBackend.verifyNoOutstandingRequest();
//     }));
//
//     it('mock http call', inject(function($httpBackend, viewallService) {
//         var resource = new viewallService();
//         //Create an expectation for the correct url, and respond with a mock object
//         $httpBackend.whenGET("template/partial-home.html").respond(200);
//         $httpBackend.expectGET('/api/viewalls').respond(200);
//
//         //Make the query
//         resource.$query();
//         console.log(resource);
//         //Because we're mocking an async action, ngMock provides a method for us to explicitly flush the request
//         $httpBackend.flush();
//
//         //Now the resource should behave as expected
//         // expect(resource).toBeDefined();
//         expect(resource).toBeDefined();
//     }));
// });






// /**
//  * Created by shuss22 on 11/25/2016.
//  */
// describe("MyService", function () {
//
//     beforeEach(module('App'));
//
//     var vs;
//
//     beforeEach(inject(function (viewallService) {
//         vs = viewallService;
//         $httpBackend.whenGET("template/partial-home.html").passThrough();
//     }));
//
//     it("viewall Service should be defined", function () {
//         expect(vs).toBeDefined();
//     });
//
//     it("retrieveQuotes should return array of quotes", inject(function ($httpBackend,viewallService) {
//         $httpBackend.expectGET("/api/viewalls").respond(200);
//         var result= viewallService.viewallServiceResonse;
//         console.log(result);
//         $httpBackend.flush();
//         expect(result[0].Products.length).toEqual(11);
//     }));
//
//     // it('should call viewall service response and test array length ', inject(function (viewallService) {
//     //     $httpBackend.expectGET('/api/viewalls')
//     //         .respond(200);
//     //     $httpBackend.flush();
//     //     expect(mockUserResource).toBeDefined();
//     // }));
// });