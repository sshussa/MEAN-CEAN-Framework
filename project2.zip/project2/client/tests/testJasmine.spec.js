// /**
//  * Created by syedhus on 11/8/16.
//  */
//
// describe("mycontrollertest", function () {
//
//         var myScope;
//
//         beforeEach(function () {
//             module('App');
//         });
//     var myScope;
//         beforeEach(inject(function ($rootScope, $controller) {
//             myScope = $rootScope.$new();
//             $controller('viewaboutController', {
//                 $scope: myScope});
//         }));
//
//         beforeEach(inject(function (_$httpBackend_) {
//             $httpBackend = _$httpBackend_;
//         }));
//
//         it("Test hint", function () {
//             expect(myScope.hint).toEqual("<p>Start with a web server such as <strong>node server.js</strong> to retrieve JSON from Server</p>");
//         });
//
//         it("loadJson should be defined", function () {
//             expect(myScope.viewallServiceResonse).toBeDefined();
//         });
//
//     it('has a dummy spec to test 2 + 2', function() {
//         // An intentionally failing test. No code within expect() will never equal 4.
//         expect(2+2).toEqual(4);
//     });
//
//         //it("retrieveQuotes should return array of quotes", inject(function ($httpBackend) {
//         //    $httpBackend.whenGET("data.json").respond(200);
//         //    $httpBackend.expectGET("data.json");
//         //    myScope.loadJson();
//         //    $httpBackend.flush();
//         //}));
//
//         //it('Test load json name', function () {
//         //    $httpBackend.whenGET('data.json').respond(200);
//         //    $httpBackend.expectGET('data.json');
//         //    $httpBackend.flush();
//         //    //expect(myScope.data.name).toEqual("NPC01");
//         //});
//     });
//
// // describe('Users factory', function() {
// //    it('has a dummy spec to test 2 + 2', function() {
// //        // An intentionally failing test. No code within expect() will never equal 4.
// //        expect(2+2).toEqual(4);
// //    });
// // });
//
// // describe('Testing viewall Service Response ', function () {
// //     var mockUserResource, $httpBackend;
// //     beforeEach(angular.mock.module('App'));
// //     beforeEach(function () {
// //         angular.mock.inject(function ($injector) {
// //             $httpBackend = $injector.get('$httpBackend');
// //             mockUserResource = $injector.get('viewallService');
// //         })
// //     });
// //
// //     describe('view all Service Response', function () {
// //         it('should call viewall service response and test array length ', inject(function (viewallService) {
// //             $httpBackend.expectGET('/api/viewalls')
// //                 .respond(200);
// //             var result = mockUserResource.viewallServiceResonse;
// //             $httpBackend.flush();
// //             expect(result).toBe(true);
// //         }));
// //
// //         it("Test hint", function () {
// //              expect(myScope.hint).toEqual("<p>Start with a web server such as <strong>node server.js</strong> to retrieve JSON from Server</p>");
// //          });
// //
// //     });
// // });
//
//
// describe("MyService", function () {
//
//     beforeEach(module('App'));
//
//     var vs;
//
//     beforeEach(inject(function (viewallService) {
//         vs = viewallService;
//     }));
//
//     it("viewall Service should be defined", function () {
//         expect(vs).toBeDefined();
//     });
//
//     // it("retrieveQuotes should return array of quotes", inject(function ($httpBackend) {
//     //
//     //     $httpBackend.whenGET("/api/viewalls").respond(200);
//     //
//     //     //expect a get request to "internalapi/quotes"
//     //     $httpBackend.expectGET("/api/viewalls");
//     //
//     //     vs.viewallServiceResonse;
//     //     $httpBackend.flush();
//     // }));
//
//     it('should call viewall service response and test array length ', inject(function (viewallService) {
//             $httpBackend.expectGET('/api/viewalls')
//                 .respond(200);
//             $httpBackend.flush();
//             expect(mockUserResource).toBeDefined();
//         }));
// });