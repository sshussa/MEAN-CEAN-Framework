/**
 * Created by shuss22 on 11/27/2016.
 */
angular.module('App').filter('to_trusted', ['$sce', function($sce){
    return function(text) {
        return $sce.trustAsHtml(text);
    };
}]);