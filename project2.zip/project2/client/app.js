var App = angular.module('App', ['ui.router', 'ui.bootstrap','ngResource','btford.socket-io','ngSanitize','ngAnimate']);
App.config(function ($stateProvider, $urlRouterProvider, $locationProvider) {
    $urlRouterProvider.otherwise('/home-page');
    $stateProvider

    //home state and nested views=======

            .state('cards', {
                url: '/home-page',
                templateUrl: 'template/partial-home.html'
            })

            //nested views with custom controller

            .state('cards.spotlight', {
                url: '/spotlight',
                templateUrl: 'template/partial-home-spotlight.html',
                controller: 'spotCarouselController'
            })

//viewall page and multiple named views=========

    .state('viewabout', {
        url:'/viewall-cards-page',
        views:{
            //the main template will be placed here(relative name)======
            '': {
                templateUrl:'template/partial-about.html',
                controller:'viewaboutController'
           },

            //the child will be defined here (absolute name)=======
            'columnOne@viewabout':{
                templateUrl:'template/partial-filterModal.html',
                controller:'ModalDemoCtrl'
                    },
            'columnTwo@viewabout':{
                templateUrl:'template/partial-c2c.html',
                controller:'chatController'
            }
        }
    });
    /*$locationProvider.html5Mode(true);*/
});

//Loading Modules
require('./stylesheet/style.scss');
require('./controllers/myController');
require('./controllers/viewaboutController');
require('./services/viewallService');
require('./controllers/chatController');
require('./services/socketFactory');
require('./directives/quicklookDir');
require('./directives/modalDir');
require('./controllers/spotCarouselController');
require('./directives/offerContentDir');
require('./controllers/modalController');
require('./filters/offerContentFiltr');
