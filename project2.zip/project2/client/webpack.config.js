var webpack =require('webpack');

module.exports={
	context: __dirname,
	entry:{
		app:'./app.js',
        vendor:'./vendor.js'
	},
	output:{
		path:__dirname,
		filename:'app.bundle.js'
	},
	module:{
		loaders:[
{
	test:/\.scss$/,
	loader:'style!css!sass'
}
		]
	},
    plugins: [
        new webpack.optimize.CommonsChunkPlugin('vendor', 'vendor.bundle.js', Infinity)
    ]
};