require('./vendors/angular.min.js');
require('./vendors/angular-ui-router.min.js');
require('./vendors/angular-resource.min.js');
require('./vendors/angular-sanitize.js');
require('./vendors/angular-animate.min.js');
// require('./node_modules/angular-socket-io/socket.js');
// require('./vendors/jquery.min.js');
// require('./vendors/tether.min.js');
// require('./vendors/bootstrap.min.js');
// require('./vendors/ui-bootstrap-tpls.js');



