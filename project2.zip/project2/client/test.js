/**
 * Created by shuss22 on 12/19/2016.
 */



var str = "SYED";

var revStr= str.reverse();

console.log(revStr);