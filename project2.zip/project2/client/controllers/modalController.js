/**
 * Created by shuss22 on 11/27/2016.
 */
angular.module('App').controller('ModalDemoCtrl', function ($scope, $modal, $log) {

    $scope.items = ['Payment Types', 'Rewards', 'Benefits'];

    $scope.open = function (size) {
        var modalInstance;
        var modalScope = $scope.$new();
        modalScope.ok = function () {
            modalInstance.close(modalScope.selected);
        };
        modalScope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        modalInstance = $modal.open({
                template: '<my-modal></my-modal>',
                size: size,
                scope: modalScope
            }
        );

        modalInstance.result.then(function (selectedItem) {
            $scope.selected = selectedItem;
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };
});