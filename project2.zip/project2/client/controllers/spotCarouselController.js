/**
 * Created by shuss22 on 11/24/2016.
 */
angular.module('App').controller('spotCarouselController', function ($scope) {
    $scope.myInterval = 5000;
    var slides = $scope.slides = [];
    $scope.addSlide = function() {
        var newWidth = ['flat-cardart-474.png','flat-cardart-79.png','flat-cardart-111.png','flat-cardart-89.png'];
        slides.push({
            image: 'http://localhost:63342/Project/client/assets/cardarts/' + newWidth[i],
            text: ['SPG','Blue','BGR','Green'][slides.length % 4] + ' ' +
            ['Card', 'Card', 'Card', 'Card'][slides.length % 4]
        });
    };
    for (var i=0; i<4; i++) {
        $scope.addSlide();
    }
});
