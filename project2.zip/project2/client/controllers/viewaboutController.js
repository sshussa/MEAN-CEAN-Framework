angular.module('App').controller('viewaboutController',function($scope,viewallService){
	var viewallServiceArray=viewallService.query(function () {
		console.log(viewallServiceArray[0].Products);
	});
	$scope.viewallServiceResonse=viewallServiceArray;
	$scope.hint = "<p>Start with a web server such as <strong>node server.js</strong> to retrieve JSON from Server</p>";

	$scope.alerts = [];
	$scope.addAlert = function() {
		$scope.alerts.push( { type: 'success', msg: 'Well done! You successfully applied.' });
	};

	$scope.closeAlert = function(index) {
		$scope.alerts.splice(index, 1);
	};
	$scope.teleValue='6786676885';
});


// angular.module('App').controller('viewaboutController',['$scope','viewallService', function($scope,viewallService){
// 	viewallService.list(function(viewallService){
// 	$scope.viewallService=viewallService["0"];
//          console.log(viewallService);
// 	});
// }]);

//angular.module('App')
//    .controller('viewaboutController', ['$scope','$http','ViewallService', function($scope, $http, ViewallService) {
//
//        ViewallService.get()
//            .success(function(data) {
//                $scope.viewallService = data;
//                console.log("Data::"+data);
//
//            });
//    }]);