/**
 * Created by shuss22 on 11/23/2016.
 */
angular.module('App').directive('quickLookDirective',function(){
    return{
        restrict: 'E',
        template:'<a href="#" class="quick-look-link" title="Quick Look"><span class="magnify-icon"></span></a>'
    };
});