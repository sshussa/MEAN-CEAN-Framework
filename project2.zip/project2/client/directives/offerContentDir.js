/**
 * Created by shuss22 on 11/27/2016.
 */

angular.module('App').directive("myWidget", function() {
    return {
        restrict: "E",
        transclude: true,
        template: '<div ng-transclude></div>'
    };
});