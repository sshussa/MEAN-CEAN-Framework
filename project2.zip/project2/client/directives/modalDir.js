/**
 * Created by shuss22 on 11/23/2016.
 */
angular.module('App').directive('myModal', function() {
    return {
        restrict: 'E',
        templateUrl: 'myModalContent.html',
        controller: function ($scope) {
            $scope.selected = {
                item: $scope.items[0]
            };
        }
    };
});