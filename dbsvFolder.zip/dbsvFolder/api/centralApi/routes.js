require("./models.js");

const appRouter = function(app){

app.post("/dowork", function(req,res){
	const payload=req.body;
	const assetIdXName=payload.assetIdXName;
	const assetIdX = `${assetIdXName}`;
	console.log('assetIdX ', assetIdX);
	callConsumerAPIGET(assetIdX);
});
	
}

module.exports=appRouter;