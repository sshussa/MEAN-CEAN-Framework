/**
 *
 * (C) Copyright 2017 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 */
const querystring = require('querystring');
const https = require('https');
 
const appCentralRouter = function(app){

var host = 'car-e1.aexp.com';
 
let  performRequest = (requestObject, success)=> {
    var dataString = JSON.stringify(requestObject.data);

    if (requestObject.method == 'GET') {
        //endpoint += '?' + querystring.stringify(data);
    }

    let headers = {
        'Content-Type': 'application/json',
        'token': requestObject.token 
    };
	
    var options = {
        host: requestObject.host,
        path: requestObject.endpoint,
        method: requestObject.method,
        headers: headers,
        port : requestObject.port
    };

    var req = requestObject.requestType.request(options, function (res) {
        res.setEncoding('utf-8');

        var responseString = '';

        res.on('data', function (data) {
            responseString += data;
        });

        res.on('end', function () {
            var responseObject = JSON.parse(responseString);
            success(responseObject);
        });
    });
    //req.write(dataString);
    if (requestObject.method !== 'GET') {
        req.write(dataString);
    }
    req.end();
}

class requestClass {
    constructor(host,endpoint,method,data,port,requestType,token){
        this.host = host;
        this.endpoint = endpoint;
        this.method = method;
        this.data = data;
        this.port = port;
        this.requestType = requestType;
        this.token = token;
    }
}

callConsumerAPIGET = function(assetIdX, callback){
			
	const requestObject = new requestClass(host,`/central/api/v1/asset/data/consumer?assetId=${assetIdX}`,
        "GET",{},443, https ,"5bf6ecc0-f7b1-11e6-9e64-67e893d9f3bf");
			
		performRequest(requestObject,function(assets){
					callback(assets);
					//process.exit(0);
				});
}


//GET Calls

app.post("/getCentralAPIusingAimId", function(req,res){
	const payload=req.body;
	const assetIdXName=payload.assetIdXName;
	const assetIdX = `${assetIdXName}`;
	console.log('assetIdX ', assetIdX);
	callConsumerAPIGET(assetIdX, function(assets){
				res.send(assets);
				//process.exit(0);
		}); 
});

}
module.exports=appCentralRouter;

