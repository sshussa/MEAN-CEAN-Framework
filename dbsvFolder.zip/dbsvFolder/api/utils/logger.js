/**
 * Created by rkunkal on 2/1/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */

'use strict';

const winston = require('winston');

const logger = new (winston.Logger)({
    transports: [
        new (winston.transports.Console)
        ({
            colorize: 'all',
            timestamp: true//,prettyPrint: myPrettyPrint
        }),
        new (winston.transports.File)({
            name: 'api-info',
            filename: './winstonlgs/dsv-api-info.log',
            timestamp: true,
            level: 'info',
            colorize: 'all',
            maxsize: 50000000, // 50 MB
            maxFiles: 10,
            json: false,
            tail: true

        }),
        new (winston.transports.File)({
            name: 'api-debug',
            filename: './winstonlgs/dsv-api-debug.log',
            timestamp: true,
            level: 'debug',
            colorize: '',
            maxsize: 50000000, // 50 MB
            maxFiles: 10,
            json: false,
            tail: true

        }),
        new (winston.transports.File)({
            name: 'api-error',
            filename: './winstonlgs/dsv-api-error.log',
            timestamp: true,
            level: 'error',
            colorize: 'all',
            maxsize: 50000000, // 50 MB
            maxFiles: 10,
            json: false,
            tail: true

        })
    ],
    exceptionHandlers: [
        new winston.transports.File({
            filename: './winstonlgs/dsv-api-exceptions.log', // this path needs to be absolute
            colorize: true,
            timestamp: true,
            maxsize: 50000000, // 50 MB
            maxFiles: 10
        })

    ]
});

module.exports = logger;