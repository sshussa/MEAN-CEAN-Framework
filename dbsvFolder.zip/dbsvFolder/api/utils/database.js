'use strict';

const co = require('co');
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

const database = {};

database.getDBConnecctionObj = function (server, dbName, username, password) {
    return co(function*() {

        // Build connection string
        const connectionUrl = `mongodb://${username}:${password}@${server}/${dbName}?authSource=admin`;

        // Use configuration
        const configuration = {
            native_parser: true,
            autoReconnect: true,
            poolSize: 10
        };
        console.log('connectionUrl',connectionUrl);
        // create db connection
        const db = yield MongoClient.connect(connectionUrl, configuration);
        return Promise.resolve(db);
    });
};


database.getDocuments = function (db, collectionName) {
    return co(function*() {
        const docs = yield db.collection(collectionName)
            .find({})
            .limit(3)
            .toArray();
        return Promise.resolve(docs);
    });
};

database.getAllCollections = function (db) {
    return co(function*() {
        const collections = yield db.listCollections().toArray();
        const collectionNames = [];
        for(var i=0;i<collections.length;i++){
            collectionNames.push(collections[i].name)
        }
        return Promise.resolve(collectionNames);
    });
};


database.stop = (db)=> {
    db.close()
};

database.getAllData = function (db) {

    return co(function*() {

        // Get list of collections
        const collections = yield database.getAllCollections(db);

        // Prepare the list of promises
        if (collections !== null && collections.length > 0) {

            const promiseObj = {};

            for (var i = 0; i < collections.length; i++) {
                const collectionName = collections[i];
                promiseObj[collectionName] = database.getDocuments(db, collectionName);
            }

            // Now resolve all the promise
            const resolvedPromise = yield promiseObj;

            return Promise.resolve(resolvedPromise);

        }
        return Promise.resolve([]);
    });
};

module.exports = database;