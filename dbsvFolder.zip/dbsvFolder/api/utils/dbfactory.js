/**
 * Created by rkunkal on 2/2/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
'use strict';

const mongoose = require('mongoose');
const assert = require('assert-plus');
const log = require('../utils/logger');

let db, DatabaseProfile, Database, Rule, User;

module.exports = {
    connect: function (url, options, cb) {
        if (!db) {
            mongoose.connect(url, options);
            db = mongoose.connection;
            db.on('error', function (error) {
                console.log('DB Error' + JSON.stringify(error));
                mongoose.disconnect();
            });
            db.once('open', function () {
                let databaseProfileSchema = require('../models/databaseProfile');
                DatabaseProfile = mongoose.model('DatabaseProfile', databaseProfileSchema);

                let databaseSchema = require('../models/database');
                Database = mongoose.model('Database', databaseSchema);

                let ruleSchema = require('../models/rule');
                Rule = mongoose.model('Rule', ruleSchema);

                let userSchema = require('../models/user');
                Rule = mongoose.model('User', userSchema);

                if (cb) {
                    return cb();
                }
            });
        } else if (cb) {
            return cb();
        }
    },
    databaseProfileDomain: function () {
        if (DatabaseProfile) {
            return DatabaseProfile;
        } else {
            assert.fail('DB connection is not established. Connect to DB before doing any DB operations.');
        }
    },
    databaseDomain: function () {
        if (Database) {
            return Database;
        } else {
            assert.fail('DB connection is not established. Connect to DB before doing any DB operations.');
        }
    },
    ruleDomain: function () {
        if (Rule) {
            return Rule;
        } else {
            assert.fail('DB connection is not established. Connect to DB before doing any DB operations.');
        }
    },
    userDomain: function () {
        if (User) {
            return User;
        } else {
            assert.fail('DB connection is not established. Connect to DB before doing any DB operations.');
        }
    },
    closeConnections: function (callback) {
        mongoose.disconnect(function () {
            callback();
        });
    }

};
