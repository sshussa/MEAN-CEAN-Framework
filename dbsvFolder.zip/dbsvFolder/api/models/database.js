/**
 * Created by rkunkal on 1/28/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
'use strict';

const mongoose = require('mongoose');
const user = require('./user');

const Database = new mongoose.Schema({

    databaseType: String,
    databaseName: String,
    serverName: String,
    port: String,
    registeredBy: typeof user,
    registrationDate: Date,
    lastUpdatedBy: typeof user,
    lastUpdatedTimeStamp: Date
}, {
    collection: 'database',
    strict: false
});

module.exports = Database;
