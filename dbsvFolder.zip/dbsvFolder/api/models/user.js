/**
 * Created by rkunkal on 2/2/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */

'use strict';

const mongoose = require('mongoose');

const User = new mongoose.Schema({
    fullName: String,
    emailAddress: String

}, {
    collection: 'user',
    strict: true,
    autoIndex: false
});

module.exports = User;
