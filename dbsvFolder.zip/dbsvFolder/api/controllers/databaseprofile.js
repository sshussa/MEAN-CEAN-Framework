/**
 * Created by rkunkal on 2/2/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */

'use strict';

const db = require('../utils/dbfactory');
const log = require('../utils/logger');
const _ = require('lodash');
const promise = require('bluebird');

module.exports = {

    /**
     * Create a new database profile
     * Add new new database details
     * @param req
     * @param res
     */
    createDatabaseProfile: function (req, res) {
        console.log('Enter to createDatabaseProfile :', ' ' + req.swagger.operationPath[1]);
        console.log('database profile user payload', ' ' + JSON.stringify(req.swagger.params.profile.value.profile));
        let userDatabaseDetails = req.swagger.params.profile.value.profile.database;
        let userCentralId = req.swagger.params.profile.value.profile.assetId;
        let DatabaseProfile = db.databaseProfileDomain();
        let databaseProfileNew = new DatabaseProfile(req.swagger.params.profile.value.profile);
        if (_.isEmpty(userDatabaseDetails)) {
            res.status(400);
            res.json({
                message: 'Database details are empty'
            }).end();
        } else {
            DatabaseProfile.findOne({'assetId': _.trim(userCentralId)}, function (err, databaseProfile) {
                if (err) {
                    console.log('Not able to insert the database profile details');
                    console.log(err);
                    res.status(500).json({
                        'message': 'Application error. Please check the response or logs for error details'
                    }).end();
                } else if (_.isEmpty(databaseProfile)) {
                    databaseProfileNew.save(function (err) {
                        if (err) {
                            console.log('Not able to insert the database profile details');
                            errorResponseHandler(err, res);
                        } else {
                            console.log('New database profile created successfully', JSON.stringify(databaseProfileNew));
                            successResponseHandler(databaseProfileNew, res);
                        }
                    });
                } else {
                    promise.each(userDatabaseDetails, function (databaseObj) {
                        if (_.get(databaseObj, 'databaseName')) {
                            if (_.find(databaseProfile.database, {
                                    'databaseName': databaseObj.databaseName
                                })) {
                                res.status(201);
                                res.json({'message': 'database Name already exists'}).end();
                            } else if (_.find(databaseProfile.database, {
                                    'databaseType': databaseObj.databaseType
                                })) {
                                res.status(201);
                                res.json({'message': 'database Type already exists'}).end();
                            } else {
                                DatabaseProfile.findOne({
                                    'database.databaseName': databaseObj.databaseName,
                                    'database.databaseType': databaseObj.databaseType
                                }, function (err, existingDatabaseDetails) {
                                    if (err) {
                                        console.log('Not able to insert the database profile details');
                                        console.log(err);
                                        errorResponseHandler(err, res);
                                    } else if (_.isEmpty(existingDatabaseDetails)) {
                                        DatabaseProfile.findOneAndUpdate({'assetId': _.trim(req.swagger.params.profile.value.profile.assetId)},
                                            {$addToSet: {database: databaseObj}}, {
                                                upsert: false,
                                                'new': true
                                            }, function (err, newDatabaseServer) {
                                                if (err) {
                                                    console.log('Not able to insert the database profile details');
                                                    console.log(err);
                                                    errorResponseHandler(err, res);
                                                } else {
                                                    console.log('No details found and new database profile added successfully', JSON.stringify(newDatabaseServer));
                                                    successResponseHandler(newDatabaseServer, res);
                                                }
                                            });
                                    } else {
                                        console.log('database profile already exists');
                                        res.status(201);
                                        res.json({
                                            'message': 'database profile already exists'
                                        }).end();
                                    }
                                });
                            }
                        } else {
                            console.log('Database Name :' + _.map(userDatabaseDetails, 'databaseName') + ' or '
                                + 'Database Type:' + _.map(userDatabaseDetails, 'databaseType'));
                            res.status(404);
                            res.json({
                                'message': 'Database Name or Database Type missing'
                            }).end();
                        }
                    }).catch(function (error) {
                        errorResponseHandler(error, res)
                    });
                }
            });
        }
    },
    /**
     * returns the database profile details by passing central Id
     * @param req
     * @param res
     */
    getDBProfilesByCentralId: function (req, res) {
        console.log('Enter to getDBProfilesByCentralId :' + ' ' + req.swagger.operationPath[1]);
        console.log('user input params', req.swagger.params.assetId.value);
        let DatabaseProfile = db.databaseProfileDomain();
        let assetId = (_.get(req, 'swagger.params.assetId.value'));
        if (assetId) {
            DatabaseProfile.findOne({'assetId': req.swagger.params.assetId.value}, function (err, databaseProfiles) {
                if (err) {
                    console.log(err);
                    errorResponseHandler(err, res);
                }
                else if (databaseProfiles) {
                    console.log('Successfully returned databaseProfiles ', JSON.stringify(databaseProfiles));
                    successResponseHandler(databaseProfiles, res);
                } else {
                    console.log('No records found in Database Schema Validator');
                    errorResponseHandler(err, res);
                }
            }).lean();
        } else {
            console.log('Central Id mizzzing');
            /* res.status(404); */
         /*   DatabaseProfile.find(function (err, databaseProfiles) {
                if (err) {
                    console.log(err);
                    errorResponseHandler(err, res);
                } else {
                    console.log('Successfully returned databaseProfiles ', JSON.stringify(databaseProfiles));
                    successResponseHandler(databaseProfiles, res);
                }
            }) */
			DatabaseProfile.aggregate([ { $sample: { size: 2 } }], function (err, databaseProfiles) {
                if (err) {
                    console.log(err);
                    errorResponseHandler(err, res);
                } else {
                    console.log('Successfully returned databaseProfiles ', JSON.stringify(databaseProfiles));
                    successResponseHandler(databaseProfiles, res);
                }
            })
        }
    },
    /**
     * Update the database profile by passing the central Id and database name
     * @param req - databaseName : dsv
     * @param res
     */
    updateDatabaseProfile: function (req, res) {
        console.log('Enter to updateDatabaseProfile :', ' ' + req.swagger.operationPath[1]);
        let userObj = req.swagger.params.profile.value.profile;
        //var userCentralId = req.swagger.params.centralId.value;
        let DatabaseProfile = db.databaseProfileDomain();
        if (_.isEmpty(userObj)) {
            res.status(400);
            res.json({
                message: 'Database details missing'
            }).end();
        } else {
            promise.each(userObj.database, function (databaseObj) {
                if (databaseObj.databaseName) {
                    console.log('database name', databaseObj.databaseName);
                    DatabaseProfile.findOneAndUpdate({
                            'assetId': userObj.assetId,
                            'database.databaseName': _.trim(databaseObj.databaseName)
                        },
                        {
                            $set: {'database.$': databaseObj}
                        }, {
                            upsert: false,
                            'new': true
                        }, function (err, newDatabaseServer) {
                            if (err) {
                                errorResponseHandler(err, res);
                            } else {
                                console.log('New database profile created successfully', JSON.stringify(newDatabaseServer));
                                res.status(200);
                                res.json({
                                    profile: newDatabaseServer
                                }).end();
                            }
                        });
                } else {
                    res.status(400);
                    res.json({
                        message: 'Database Name missing'
                    }).end();
                }
            }).catch(function (error) {
                console.log(error); // printing the error
                res.status(500).json({
                    'message': 'Application error. Please check the response or logs for error details'
                }).end();
            });
        }
    },
    /**
     * Delete the database from existing profile
     * @param req assetId , databaseName
     * @param res
     */
    deleteDatabaseProfile: function (req, res) {
        let uiCentralId = req.swagger.params.assetId.value;
        console.log('input param assetId:', uiCentralId);
        let uiDatabaseName = req.swagger.params.databaseName.value;
        console.log('input param databaseName', uiDatabaseName);
        let DatabaseProfile = new db.databaseProfileDomain();
        DatabaseProfile.findOneAndUpdate({'assetId': uiCentralId, 'database.databaseName': uiDatabaseName},
            {$pull: {'database': {'databaseName': uiDatabaseName}}}).lean()
            .then(function (databaseProfile) {
                if (_.isEmpty(databaseProfile)) {
                    console.log('No records found to delete in Database Schema Validator', uiDatabaseName);
                    res.status(404).json({
                        'message': 'No record found to delete in Database Schema Validator'
                    }).end();
                } else {
                    console.log('Deleted database record' + uiDatabaseName + 'successfully');
                    res.status(200).json({'message': 'Deleted database record' + uiDatabaseName + 'successfully'}).end();
                }
            }).catch(function (err) {
            errorResponseHandler(err, res);
        })
    }
};
/**
 * returns the success response
 * @param objectResult
 * @param res
 */
function successResponseHandler(objectResult, res) {
    if (res) {
        res.status(200);
        res.json({profile: objectResult}).end();
    }
}
/**
 * returns if database profile already exist
 * @param objectResult
 * @param res
 */
function alreadyExistsResponseHandler(objectResult, res) {
    if (res) {
        res.status(201);
        res.json({'message': 'database profile already exists'}).end();
    }
}
/**
 * returns the error response
 * @param err
 * @param res
 */
function errorResponseHandler(err, res) {
    if (res) {
        if (err) {
            console.log('error', err);
            res.status(500).json({'message': 'Application error. Please check the response or logs for error details'}).end();
        } else {
            res.status(404).json({'message': 'No  records found in Database Schema Validator'}).end();
        }
    }
}