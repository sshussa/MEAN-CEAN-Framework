/**
 * Created by rkunkal on 1/24/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
'use strict';

module.exports = {
    application: {
        apiUrl: {
            host: 'localhost',
            port: '8080'
        },
        mongo: {
            db: 'dsv',
            auth: {
                user: '',
                pass: ''
            },
            instances: [{
                //use localhost host, if you have Mongo installed in your local
                host: 'PHXPC02DYPF.ads.aexp.com',
                port: '27017'
            }]
        }

    }
};
