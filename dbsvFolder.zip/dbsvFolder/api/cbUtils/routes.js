const GetCbConnectionAllDocsModel = require("./models").GetCbConnectionAllDocsModel;

const appRouter = function(app){

app.post("/getalldocsfrombucket", function(req,res){
		const payload = req.body;
        const serverName = payload.serverName;
		const bucketName=payload.bucketName;
        const server = `${serverName}`;
		const bucketInfo=`${bucketName}`
        console.log('server ', server);
		GetCbConnectionAllDocsModel.getAll(server, bucketInfo, function(error,result){
		if(error){
			return res.status(400).send(error);
			}
				res.send(result);
				//process.exit(0);
		}); 
    });
	
}

module.exports=appRouter;