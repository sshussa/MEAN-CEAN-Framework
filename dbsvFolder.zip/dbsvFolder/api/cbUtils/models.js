const uuid = require("uuid");
const couchbase = require("couchbase");
const N1qlQuery=require("couchbase").N1qlQuery;

function GetCbConnectionAllDocsModel(){}

GetCbConnectionAllDocsModel.getAll=function(server, bucketInfo, callback){
			
			const bucket=new couchbase.Cluster(`couchbase://${server}`).openBucket(`${bucketInfo}`,"Amex1234");
			const queryBucket=`${bucketInfo}`;
			/*const query = N1qlQuery.fromString('SELECT * FROM '+queryBucket);*/
			const query = N1qlQuery.fromString('INFER '+queryBucket);
			bucket.query(query,function(error,result){
					if(error){
					console.log(error);
						return callback(error,null);
					}
					callback(null,result);
					//process.exit(0);
				});
}

module.exports.GetCbConnectionAllDocsModel = GetCbConnectionAllDocsModel;

