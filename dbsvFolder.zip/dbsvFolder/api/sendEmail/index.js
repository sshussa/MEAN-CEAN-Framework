'use strict';
const nodemailer = require('nodemailer');
const smtpTransport=require('nodemailer-smtp-transport');

// create reusable transporter object using the default SMTP transport
var transporter = nodemailer.createTransport(smtpTransport({
    host: 'tenant-proxy-e1.aexp.com',
	port: 25
}));

// setup email data with unicode symbols
const appRouter = function(app){

app.post('/sendEmail', function(req,res){

var data= req.body;

let mailOptions = {
    from: 'dsv-support@aexp.com', // sender address
    to: data.to, // list of receivers
    subject: data.subject, // Subject line
    //text: data.text, // plain text body
    html: `<p>Hello,</p>
    <p>Thanks for using the Database Schema Validator (DSV)!</p>
    <p>The validation report for your database is attached with this email.</p>
    <p>Please contact dsv-support for further assistance.</p>
    <p>Thanks,<br />
    <b>DSV Support</b>
    </p>
    <p>AXP Internal</p>
`, // html body
	//attachments:[{path: '/Users/shuss22/Downloads/'+ data.attachment}]
	attachments:[{
	filename:"validationReports.csv",
	content:data.attachment
	}]
};

// send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        return console.log(error);
    }
    console.log('Message %s sent: %s', info.messageId, info.response);
	});
})

}

module.exports=appRouter;