angular.module('databaseProfileController').directive('exportToCsv', function(){
	return {
	restrict:'A',
	link:function(scope,element,attrs){
	var el=element[0];
	element.bind('click', function(e){
	e.preventDefault();
	var table=document.getElementById('attributeTable');
	var id = document.getElementById('assetId').innerHTML;
	var dbName = document.getElementById('dbName').innerHTML;
	var dirName = document.getElementById('dirName').innerHTML;
	var csvString= id+dbName+dirName + "\n";
	for(var i=0;i<table.rows.length;i++){
	var rowData=table.rows[i].cells;
	for(var j=0;j<rowData.length;j++){
		csvString=csvString+rowData[j].innerHTML+",";
	}
	csvString=csvString.substring(0,csvString.length-1);
	csvString=csvString+"\n";
	}
	console.log('20',table.rows)
	csvString=csvString.substring(0,csvString.length-1);
	var a=$('<a/>',{
		style:'display:none',
		href:'data:application/octet-stream;base64,'+btoa(csvString),
		download:'validationReports.csv'
	}).appendTo('body')
	a[0].click()
	a.remove();
	});
	}
	}
	});

angular.module('databaseProfileController').controller('RuleViolationController', function ($scope,$uibModal, $timeout, Upload, $http, $rootScope, $window) {
    $scope.model = {}
    $scope.model.missingAttributes = $rootScope.missingAttributes;
	$scope.model.dbDetails=$rootScope.selectedDataBase;
    console.log('Compared Attributes Data::', $rootScope);
	$scope.sendEmailReport=function(e){
		e.preventDefault(); 
		var modalInstance=$uibModal.open({
			templateUrl:'myModalContent.html',
			controller:'ModalInstanceCtrl',
			controllerAs:'$ctrl'
	});
	
	var table=document.getElementById('attributeTable');
	var id = document.getElementById('assetId').innerHTML;
	var dbName = document.getElementById('dbName').innerHTML;
	var dirName = document.getElementById('dirName').innerHTML;
	var csvString= id+dbName+dirName + "\n";
	/* var csvString= id+"\n"; */
	for(var i=0;i<table.rows.length;i++){
	var rowData=table.rows[i].cells;
	for(var j=0;j<rowData.length;j++){
		csvString=csvString+rowData[j].innerHTML+",";
	}
	csvString=csvString.substring(0,csvString.length-1);
	csvString=csvString+"\n";
	}
	console.log('20',table.rows)
	csvString=csvString.substring(0,csvString.length-1);
	
	modalInstance.result.then(function(data){
	var req={
		method:'POST',
		url:'/sendEmail',
	headers:{
		'Content-Type':'application/json'
	},
	data:{
		to:data.email,
		subject:"Validation Report",
		//text:data.text,
		//file:data.file.csvString,
		attachment: csvString
		}
	};
	
	$http(req).then(function(resp){
		console.log('sent',resp);
	},function(err){
	console.log('err',err);
	})
	});
	}
	});
	angular.module('databaseProfileController').controller('ModalInstanceCtrl',function($uibModalInstance,$scope, $rootScope, Upload){
		$scope.mail={email:'',desc:''};
		$scope.mail.file=$rootScope.uploadFile;
		Upload.upload({
			url:'/upload', //webAPI exposed to upload the file
			data:{file:$rootScope.uploadFile}
	}).then(function(resp){
		console.log('uploaded', resp);
	});
	$scope.send=function(form){
		if(form.$valid){
			$uibModalInstance.close($scope.mail);
		}
	}
	});
	
	
	


