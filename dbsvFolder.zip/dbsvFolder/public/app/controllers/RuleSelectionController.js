angular.module('databaseProfileController').controller('RuleSelectionController', function ($scope, Upload, $http, $rootScope, $window, $location) {
    $scope.model = {};

//$scope.rules=[
    /* {"value":"camelCase","ruleName":"Camel Case", "ruledescription":"Starting letter should be lower case"},
     {"value":"compareAttribute","ruleName":"Compare Attributes", "ruledescription":"Compare each data elements exist in Databse and Data dictionary"},
     {"value":"dataTypeCheck","ruleName":"Data type check", "ruledescription":"Check the attribute data type defined correctly or not"}] */

    $scope.rules = [
        {
            "value": "compareAttribute",
            "ruleName": "Compare Attributes",
            "ruledescription": "Compare each data elements exist in Database and Data Dictionary"
        }
    ]

$scope.gobtns = function ( path ) {
  $location.path( path );
};

//console.log('missingAttributes from RuleSelectionController', $rootScope.missingAttributes);
    $scope.model.missingAttributes = $rootScope.missingAttributes;
	$scope.model.dbDetails=$rootScope.selectedDatabase;
    $scope.isRuleSelected = true;
    $scope.validate = function () {
        isvalid = false;
        console.log('rules::', $scope.rules);
        angular.forEach($scope.rules, function (rule, key) {
            if (rule.checked) {
                isvalid = true;
            }
        })
        if (isvalid) {
            $scope.isRuleSelected = true;
			$http({
            url: '/api/comparisondatas',
            method: "POST",
            data: {attributes: $rootScope.missingAttributes}
			})
            .then(function (response) {
                    // success
                    console.log("Success", response);
                },
                function (err) { // optional
                    // failed
                    console.log("Error", err);
                });
				
            $location.path('/ruleviolation');
        } else {
            $scope.isRuleSelected = false;
        }

    }
});