angular.module('databaseProfileController').directive('exportToCsv', function(){
return {
restrict:'A',
link:function(scope,element,attrs){
var el=element[0];
element.bind('click', function(e){
e.preventDefault();
var table=document.getElementById('attributeTable')
var csvString='';
for(var i=0;i<table.rows.length;i++){
var rowData=table.rows[i].cells;
for(var j=0;j<rowData.length;j++){
csvString=csvString+rowData[j].innerHTML+",";
}
csvString=csvString.substring(0,csvString.length-1);
csvString=csvString+"\n";
}
console.log('20',table.rows)
csvString=csvString.substring(0,csvString.length-1);
var a=$('<a/>',{
style:'display:none',
href:'data:application/octet-stream;base64,'+btoa(csvString),
download:'emailStatistics.csv'
}).appendTo('body')
a[0].click()
a.remove();
});
}
}
});

angular.module('databaseProfileController').controller('RuleViolationController', function ($scope,$uibModal, $timeout, Upload, $http, $rootScope, $window) {
    $scope.model = {}
    $scope.model.missingAttributes = $rootScope.missingAttributes;
    console.log('Compared Attributes Data::', $scope.model.missingAttributes);
	
	$scope.sendEmailReport=function(e){
	e.preventDefault(); 
	var modalInstance=$uibModal.open({
	templateUrl:'myModalContent.html',
	controller:'ModalInstanceCtrl',
	controllerAs:'$ctrl'
	});
	modalInstance.result.then(function(data){
	var req={
	method:'POST',
	url:'/sendEmail',
	headers:{
	'Content-Type':'application/json'
	},
	data:{
	to:data.email,
	subject:"Report",
	text:data.desc,
	file:data.file
	}
	};
	
	$http(req).then(function(resp){
	console.log('58',resp);
	})
	},function(){
	});
	}
	});
	angular.module('databaseProfileController').controller('ModalInstanceCtrl',function($uibModalInstance,$scope){
	
	$scope.mail={email:'',desc:''};
	$scope.send=function(form){
	if(form.$valid){
	$uibModalInstance.close($scope.mail);
		}
	}
	});
	
	
	


