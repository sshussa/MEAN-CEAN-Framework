angular.module('databaseProfileController').controller('ValidationController', function ($scope, Upload, $http, $rootScope, $window, $location,DatabaseProfile,$timeout) {
    $scope.model = {};
    var vm = $scope.model;
    $scope.model.selectedDatabase = $rootScope.selectedDataBase;
    vm.database = {
        id: '',
        password: ''
    }
	$scope.authenticationFailed=false;
    $scope.next = function () {//function to call on form submit
        //check if form is valid
        console.log('13', $scope.model);
		if($scope.model.selectedDatabase.databaseType!=='Couchbase'){
        $scope.formValid = true;
		}
        if((($scope.model.database.id && $scope.model.database.password)|| $scope.model.selectedDatabase.databaseType=='Couchbase') && $scope.model.file) {
            $scope.upload($scope.model.file); //call upload function
			$rootScope.uploadFile=$scope.model.file;
		} else {
            console.log('here');
        }
    }
    $rootScope.missingAttributes = [];
    $scope.compareAttribute = function (src, dest, flag) {
        console.log('Performing comparison of keys operations...', src, dest);
        for (var i = 0; i < src.length; i++) {
            if (dest.indexOf(src[i]) > -1) {
            } else {
                var obj = {
                    attribute: src[i],
                    flag: flag,
					
                }
                $rootScope.missingAttributes.push(obj);
            }
        }
    }
    $scope.upload = function (file) {
        Upload.upload({
            url: '/upload',  //webAPI exposed to upload the file
            data: {file: $scope.model.file} //pass file as data, should be user ng-model
        }).then(function (resp) { //upload function returns a promise
            if (resp.data.error_code === 0) {//validate success
                
				var uploadJSONData = resp.data.data;
				var uploadedJSONData=[];
					angular.forEach(uploadJSONData,function(obj,i){
					 if (uploadedJSONData.indexOf(obj) > -1 == false) {
						uploadedJSONData.push(obj['abbreviated name']);
					}
				});
				
				
                //var uploadedJSONData = uploadJSONData;
                console.log('Gotcha --> Coverted Spreadsheet Data to JSON Data::', uploadedJSONData);
                
			/* 	var keyJSONDatafromUpload = [];
                $rootScope.externalAttributes = [];
                for (var k in uploadedJSONData) {
                    angular.forEach(k.split('/'), function (v, i) {
                        if (keyJSONDatafromUpload.indexOf(v) > -1 == false) {
                            keyJSONDatafromUpload.push(v);
                        }
                    })
                } */
				
				var keyJSONDatafromUpload = [];
                $rootScope.externalAttributes = [];
               
                angular.forEach(uploadedJSONData, function (v, i) {
                        if (keyJSONDatafromUpload.indexOf(v) > -1 == false) {
                            keyJSONDatafromUpload.push(v);
                        }
                    })
         
				
				
				
                console.log('Extracted Keys from uploaded Data-Dictionary JSON Data::', keyJSONDatafromUpload);
                //if(vm.database.id){
				var dataPayload, databaseUrl;
				if($scope.model.selectedDatabase.databaseType=='Couchbase'){
					dataPayload={
					"serverName": $scope.model.selectedDatabase.serverName+":"+$scope.model.selectedDatabase.port,
					"bucketName": $scope.model.selectedDatabase.databaseName
					}
					databaseUrl='/getalldocsfrombucket';
				}
				else{
				var dataPayload={
				"serverName":$scope.model.selectedDatabase.serverName,
				"port":$scope.model.selectedDatabase.port,
				"databaseName":$scope.model.selectedDatabase.databaseName,
				"username":$scope.model.database.id,
				"password":$scope.model.database.password
				}
                databaseUrl = '/get-db-details';
				}
   
				$scope.checkpromiseFail=true;
				var promise=DatabaseProfile.dbUpdate(databaseUrl,dataPayload);
					promise.then(function(response) {
					$scope.checkpromiseFail=false;
					var JSONDatafromDB = response.data.docs;
                    console.log('Gotcha, fetched random documents from a collection in DB::', response.data.docs);
					if($scope.model.selectedDatabase.databaseType=='Couchbase'){
					JSONDatafromDB = response.data;
					}else{
					JSONDatafromDB = response.data.docs;
					}
                    var keyJSONDatafromDB = [];
                    $rootScope.databseAttributes = [];
                    function pushTheKeys(key) {
                        //console.log('at the push');
                        if (keyJSONDatafromDB.indexOf(key) < 0&&key!==''&&key!=='_id') {
                            keyJSONDatafromDB.push(key)
                        }
                    }

                    angular.forEach(JSONDatafromDB, function (data) {
                        console.log('Documents Data::', data);
                        for (var key in data) {
                            pushTheKeys(key);
                            if (typeof data[key] == 'object') {
                                for (var j in data[key]) {
                                    pushTheKeys(j);
                                    if (typeof data[key][j] == 'object') {
                                        for (var k in data[key][j]) {
                                            pushTheKeys(k);
                                        }
                                    }
                                }
                            }
                        }
                    });
					
                    //console.log('Extracted Keys from DB', keyJSONDatafromDB);
					var newkeyJSONDatafromDB=keyJSONDatafromDB.filter(function(ele){return isNaN(ele)});
					console.log('Extracted new Keys from DB', newkeyJSONDatafromDB);
                    $scope.compareAttribute(newkeyJSONDatafromDB, keyJSONDatafromUpload, 'database');
                    $scope.compareAttribute(keyJSONDatafromUpload, newkeyJSONDatafromDB, 'external');
                    //console.log('mizzzing attributes::::', $rootScope.missingAttributes);
                    $location.path('/ruleselection');
                }).catch(function (err) {
                    console.log("error", err);
					$scope.authenticationFailed=true;
                });
            } else {
                $window.alert('an error occured');
            }
        }, function (resp) {//catch error
            console.log('Error status: ' + resp.status);
            $window.alert('Error status: ' + resp.status);
        }, function (evt) {
            //console.log(evt);
            var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
            console.log('Uploading, Storing, Renaming, Reading Spreadsheet Data Operations...: ' + progressPercentage + '% ' + evt.config.data.file.name);
            vm.progress = 'progress: ' + progressPercentage + '% ';//capture upload progress

        });
			$timeout(function(){
				console.log("aha");
				$scope.authenticationFailed=true;
		},2500);
    };
	/* $('input,document').keypress(function(event){
		if(event.keyCode==13) event.preventDefault();
	}) */
});