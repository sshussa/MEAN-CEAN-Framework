/**
 * Created on 2/6/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */

angular.module('databaseProfileController', [])
    .controller('regDatabaseCtrl', function ($scope) {
        console.log('hello from database profile controller');
        $scope.newProfile = {};
        $scope.clickedProfile = {};
        $scope.message = "";
        $scope.profiles = [{
            "assetId": "200000000",
            "name": "Sample1",
            "databaseType": "Mongo",
            "databaseName": "ads",
            "serverName": "apdwa679.phx.aexp.com",
            "port": "27017"
        }];
        $scope.saveProfile = function () {
            console.log($scope.newProfile);
            $scope.profiles.push($scope.newProfile);
            $scope.newProfile = {};
            $scope.message = "New Database Profile Added Successfully !";
        };

        // Select db profile for edit & then update
        $scope.selectProfile = function (profile) {
            console.log('selected profile', profile);
            $scope.clickedProfile = profile;
        };
        $scope.updateProfile = function () {
            $scope.message = "Database Profile Details Updated Successfully !"
        };
        $scope.deleteProfile = function () {
            $scope.profiles.splice($scope.profiles.indexOf($scope.clickedProfile), 1);
            $scope.message = "Database Profile Deleted Successfully !"
        };
        $scope.clearMessage = function () {
            $scope.message = "";
        };

    });
