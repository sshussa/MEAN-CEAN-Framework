var app = angular.module('allContentJSONModule',[]);

app.controller('aboutDsvController',function($scope, $location, $rootScope, $http, $window){

/* function aboutDsv(){
 $location.path('/about'); 
 $http.get('/allContent').then(
		function(response) { $scope.allContent = response.data;},
		function (err) {console.log(err)}
		);
} */

$scope.redirectToNGDM = function () {
   $window.open('https://teams.aexp.com/sites/edmsprojectnotification/Lists/Engagement%20Requests/ERequestCreateForm.aspx?Source=https://teams.aexp.com/sites/edmsprojectnotification/Lists/Engagement%2520Requests/AllItems.aspx&RootFolder="', '_blank');
};

$scope.go = function ( path ) {
  $location.path( path );
};

});