var app = angular.module('databasesearchControllerApp',[]);

app.controller('SearchController',function($scope, $location, DatabaseProfile, $rootScope, $http, $window){

    $scope.model={};
    $scope.submitFlag=false;
    $scope.model.errorFlag=false;
    $scope.validateSearch=validateSearch;
	/* $scope.allContent={}; */
	
	/* $http.get('/allContent').then(
		function(response) { $scope.allContent = response.data;},
		function (err) {console.log(err)}
		); */
		
		
   /*  $scope.redirectToNGDM = function () {
        $window.open('https://teams.aexp.com/sites/edmsprojectnotification/Lists/Engagement%20Requests/ERequestCreateForm.aspx?Source=https://teams.aexp.com/sites/edmsprojectnotification/Lists/Engagement%2520Requests/AllItems.aspx&RootFolder="', '_blank');
    }; */
	
	function validateSearch(valid){
        $scope.submitFlag=true;
        if(valid){
           console.log('Validated: Central Id or AIM Id!');
            var url='/api/profile?assetId=' +$scope.model.searchId;
            console.log('Making an async API call to DB.....');
            DatabaseProfile.getAll(url).then(function(data){
                console.log('Awesome, got the data from mongo DB::',data);
                $rootScope.profiles=data.profile;
                $location.path('/profile');
            },function(err){
			    console.log('No profile or asset found in Mongo DB::',err);
                console.log('Make an async API call to Central API Server....');
               /*  $http({
                    method: 'POST',
                    url: '/getCentralAPIusingAimId',
					data:{
					"assetIdXName": $scope.model.searchId
					}
                }) */
				var data = {
				"assetIdXName": $scope.model.searchId
				};
				$http.post('/getCentralAPIusingAimId', JSON.stringify(data)).then(function(data){
                    console.log('Gotcha, data from central api server::',data.data.asset);
                    $rootScope.profiles=data.data.asset;
                    $location.path('/profile');
                },function(err){
                    console.log('No profile or asset found in both Central and mongo DB::',err);
                    $scope.model.errorFlag=true;
                    setTimeout(function(){
                        $scope.model.errorFlag=false;
                    },3000);
                })
            });
        }
    }
});