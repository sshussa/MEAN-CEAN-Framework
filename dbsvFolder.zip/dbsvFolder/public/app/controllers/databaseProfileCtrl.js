/**
 * Created on 2/6/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */

angular.module('databaseProfileController', [])
    .controller('regDatabaseCtrl', function ($route, $scope, $http, DatabaseProfile, $routeParams, $rootScope, $location) {
        $scope.message = '';
        $scope.profile = {};
        $scope.profiles = {};
        $scope.newProfile = {};
       // console.log('17',$rootScope);
	   $scope.options = ['MongoDB', 'CouchBase', 'Cassandra', 'Neo4J',' Redis'];
/* 	   $scope.watch('newProfile', function(newval,oldval){
		console.log("dataType:::",newval);
	   }); */
        $scope.profiles = $rootScope.profiles;
        $scope.saveProfile = function (profile) {
            profile.assetId = $scope.profiles.assetId;
			profile.name = $scope.profiles.name;
			profile.lifeCycleStatus = $scope.profiles.lifeCycleStatus;
			profile.ownershipInfo = $scope.profiles.ownershipInfo;
			console.log("profile", profile);
            DatabaseProfile.create(profile)
                .then(function (data) {
                    if (data.profile) {
                        $scope.profiles = data.profile;
                        $scope.newProfile = {};
                        $scope.message = 'New database details added successfully !';
                    } else {
                        $scope.newProfile = {};
                        $scope.message = 'Database name or type already exists, please use edit option !';
                    }
                })
                .catch(function (data, status) {
                    $scope.message = 'Not able to Save the details, please try later !';
                });
        };
        $scope.getProfilesById = function () {
            //let assetId = 500001408;
            console.log('Root Scope Data::', $rootScope);
            $scope.profiles = $rootScope.profiles;
        };
        $scope.selectProfile = function (profile,i) {
            $scope.clickedProfile = profile;
			$scope.selectedIndex=i;
        };
        $scope.updateProfile = function (profile) {
            profile.assetId = $scope.profiles.assetId;
            DatabaseProfile.update(profile).then(function (data) {
                $scope.profiles = data.profile;
                $scope.message = 'Database details updated successfully !'
            })
        };
        $scope.deleteProfile = function (profile) {
            profile.assetId = $scope.profiles.assetId;
            DatabaseProfile.delete(profile).then(function (data) {
               // $scope.refersh = $scope.getProfilesById();
				$scope.refesh = $scope.getProfilesById();
                $scope.message = 'Removed the database details';
				console.log("deleted");
            });
			$scope.profiles.database.splice($scope.selectedIndex, 1);  
        };
        $scope.clearMessage = function () {
            $scope.message = '';
        };
        $scope.nextToValidate=function(profile){

            var dbObj={
                name: $scope.profiles.name,
                assetId : $scope.profiles.assetId,
				lifeCycleStatus : $scope.profiles.lifeCycleStatus,
				ownershipInfo : $scope.profiles.ownershipInfo,
                databaseType:profile.databaseType,
                serverName:profile.serverName,
                databaseName:profile.databaseName,
                port:profile.port
            };

            $rootScope.selectedDataBase=dbObj;
			$rootScope.profiles=$scope.profiles;
            $location.path('/validation');

        }
    });