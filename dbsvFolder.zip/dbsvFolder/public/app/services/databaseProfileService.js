/**
 * Created on 2/7/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
angular.module('databaseProfileService', [])
    .factory('DatabaseProfile', function ($http, $q) {
        let fac = {};
        fac.create = function (newProfile) {
            let defer = $q.defer();
			let database=[];
			if(newProfile.databaseType=='CouchBase'){
			 database= [{
                            databaseType: newProfile.databaseType,
                            databaseName: newProfile.databaseName,
                            serverName: newProfile.serverName,
                            port: newProfile.port
                        }]
						} else {
						 database= [{
                            databaseType: newProfile.databaseType,
                            databaseName: newProfile.databaseName,
                            serverName: newProfile.serverName,
                            port: newProfile.port
                        }]		
			}
            let req = {
                method: 'POST',
                url: '/api/profile',
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {
                    profile: {
                        assetId: newProfile.assetId,
                        name: newProfile.name,
						lifeCycleStatus: newProfile.lifeCycleStatus,
						ownershipInfo: newProfile.ownershipInfo,
                        database: database
                    }
                }
            };
            $http(req).then(function (response) {
                defer.resolve(response.data);
            }, function (error) {
                defer.reject(error)
            });
            return defer.promise;
        };
        fac.getAll = function (url) {
            let defer = $q.defer();
            let req = {
                method: 'GET',
                url: url,
                headers: {
                    'Content-Type': 'application/json'
                }
            };
            $http(req).then(function (response) {
                console.log('in success...',response.data);
                defer.resolve(response.data);
            }).catch(function(){
               console.log('in error!');
                defer.reject('error');
            });
            return defer.promise;
        };
        fac.update = function (profile) {
            let defer = $q.defer();
            let req = {
                method: 'PUT',
                url: '/api/profile?assetId=' + profile.assetId,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: {
                    profile: {
                        assetId: profile.assetId,
                        database: [{
                            databaseType: profile.databaseType,
                            databaseName: profile.databaseName,
                            serverName: profile.serverName,
                            port: profile.port
                        }]
                    }
                }
            };
            $http(req).then(function (response) {
                defer.resolve(response.data);
            });
            return defer.promise;
        };
        fac.delete = function (profile) {
            let defer = $q.defer();
            let req = {
                method: 'DELETE',
                url: '/api/profile?assetId=' + profile.assetId + '&databaseName=' + profile.databaseName,
                headers: {
                    'content-Type': 'application/json'
                }
            };
            $http(req).then(function (response) {
                if (response) {
                    defer.resolve(response.data);
                } else {
                    defer.reject(error);
                }
            });
            return defer.promise;
        };
		
		fac.dbUpdate=function(url, data){
		let defer=$q.defer();
		let req={
				method: 'POST',
                url: url,
                headers: {
                    'content-Type': 'application/json'
                },
				data:data
		
		};
		$http(req).then(function (response) {
                console.log('128');
                defer.resolve(response);
                }).catch(function(){
				console.log('131 error ***');
				defer.reject('error');
				});
                 return defer.promise;   
   
            };
        return fac
    });