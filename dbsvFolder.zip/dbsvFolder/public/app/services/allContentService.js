/**
 * Created on 2/7/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
 
/* angular.module('allContentJSONModule',[]).factory('AllContentService', function($http) {
 /*   var factory = {
    topAuthorsList: false,
    getList: function() {
      //returning promise
      return $http.get('allContent.json')
        .then(function(response) {
           var data = response.data;
           factory.topAuthorsList = data;
           //returning data to resolving promise
           return data;
        }, function(error) {
            return 'There was an error getting data';
        });
    }
  };
  return factory; */
/*   }); */ 
  
  
  