/**
 * Created on 2/6/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
angular.module('appRoutes', ['ngRoute'])
    .config(function ($routeProvider, $locationProvider) {
        $routeProvider
			.when('/about',{
				templateUrl: 'app/views/pages/aboutDsv.html',
				controller:'aboutDsvController'
			})
            .when('/search', {
                templateUrl: 'app/views/pages/search.html',
                controller:'SearchController'
            })
            .when('/profile', {
                templateUrl: 'app/views/pages/profile/databaseProfile.html',
                controller: 'regDatabaseCtrl'
            })
            .when('/validation',{
                templateUrl: 'app/views/pages/profile/validation.html',
                controller: 'ValidationController'
            })
			.when('/ruleviolation',{
                templateUrl: 'app/views/pages/ruleViolation.html',
                controller: 'RuleViolationController'
            })
			.when('/ruleselection',{
                templateUrl: 'app/views/pages/ruleSelection.html',
                controller: 'RuleSelectionController'
            })
            .otherwise({redirectTo: '/search'});

        $locationProvider.html5Mode({
            enabled: true,
            requiredBase: false
        });

    });