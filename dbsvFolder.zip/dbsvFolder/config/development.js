/**
 * Created by rkunkal on 1/24/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
'use strict';

module.exports = {
    application: {
        apiUrl: {
            host: 'localhost',
            port: '8443'
        },
        mongo: {
            db: 'dsv',
            auth: {
                //user: dsvuser && pass: dsv1234
                user: 'dsvuser',
                pass: 'dsv1234'
            },
            instances: [{
                // use host:PHXPC02DYPF.ads.aexp.com, instead of localhost. If you are connecting from local
                //lpdospdb00376.ads.aexp.com for e1-server database LPDOSPDB00376.phx.aexp.com
                host: 'LPDOSPDB00376.phx.aexp.com',
                port: '27017'
            }]
        }

    }
};
