#
# `Database Schema Validator`
#
ADSV objective is to execute the rules on the data elements exist in Database Vs data elements exist in Data Dictionary provided by application teams. The report shown on the tool  with an email and download  as an excel options.

