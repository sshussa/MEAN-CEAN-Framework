/**
 * Created on 2/2/2017.
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 */
'use strict';

const fs = require('fs');
const https = require('https'); 
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const SwaggerUi = require('swagger-tools/middleware/swagger-ui'); // for swagger-tools
const SwaggerExpress = require('swagger-express-mw');
const db = require('./api/utils/dbfactory');
const configuration = require('config');
const hostConfig = configuration.application.apiUrl;
const log = require('./api/utils/logger');
const path = require("path");
const bodyParser = require('body-parser');
const multer = require('multer');
const xlstojson = require("xls-to-json-lc");
const xlsxtojson = require("xlsx-to-json-lc");
const co = require('co');
const database = require('./api/utils/database');
//const couchbase=require("couchbase");
const allContent=require("./api/json/allContent");
const querystring = require('querystring');
//const nodemailer = require('nodemailer');
//const smtpTransport=require('nodemailer-smtp-transport');

//SSL certificate

/* const port = 8443;
const ip   = '0.0.0.0'; 
const privateKey = fs.readFileSync('/opt/epaas/certs/key');
const certificate = fs.readFileSync('/opt/epaas/certs/cert');
const ca = fs.readFileSync('/opt/epaas/certs/ca');
const pass = fs.readFileSync('/opt/epaas/certs/pass','ascii');  */


const port = 8443;
const ip   = '0.0.0.0'; 
const privateKey = fs.readFileSync('C:/certs/key.txt');
const certificate = fs.readFileSync('C:/certs/cert.txt');
const ca = fs.readFileSync('C:/certs/ca.txt');
const pass = fs.readFileSync('C:/certs/pass.txt','ascii');


let config = {
    appRoot: __dirname // required config
};

app.use(function (req, res, next) { //allow cross origin requests
    res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
    res.header("Access-Control-Allow-Origin", "http://localhost");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

//certificate options
const options = { 
    key: privateKey,
    cert: certificate,
    ca: ca,
    passphrase: pass,
    requestCert: true, 
    rejectUnauthorized: false 
};
options.agent = new https.Agent(options); 


//To parse the post data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));

//upload an excel file on our application to a particular path, read the file and convert it into json data
//Start: Setting up multer storage settings for the storage destination, upload file name and also the storage type as disk storage::

var storage = multer.diskStorage({ //multers disk storage settings
    destination: function (req, file, cb) {
        cb(null, './uploads/');
    },
    filename: function (req, file, cb) {
        var datetimestamp = Date.now();
        cb(null, file.originalname.split('.')[0] + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1]);
    }
});

var upload = multer({ //multer settings
    storage: storage
}).single('file');

/** API path that will upload the files */

app.post('/upload', function (req, res) {
    var exceltojson;
    upload(req, res, function (err) {
        if (err) {
            res.json({error_code: 1, err_desc: err});
            return;
        }
        /** Multer gives us file info in req.file object */
        if (!req.file) {
            res.json({error_code: 1, err_desc: "No file passed"});
            return;
        }
        /** Check the extension of the incoming file and
         *  use the appropriate module
         */
        if (req.file.originalname.split('.')[req.file.originalname.split('.').length - 1] === 'xlsx') {
            exceltojson = xlsxtojson;
        } else {
            exceltojson = xlstojson;
        }
        console.log(req.file.path);
        try {
            exceltojson({
                input: req.file.path,
                output: null, //since we don't need output.json
                lowerCaseHeaders: true
            }, function (err, result) {
                if (err) {
                    return res.json({error_code: 1, err_desc: err, data: null});
                }
                res.json({error_code: 0, err_desc: null, data: result});
            });
        } catch (e) {
            res.json({error_code: 1, err_desc: "Corrupted excel file"});
        }
    })
});

app.post('/get-db-details', function (req, res) {

    return co(function*() {

        const payload = req.body;
        const serverName = payload.serverName;
        const port = payload.port;
        const databaseName = payload.databaseName;
        const username = payload.username;
        const password = payload.password;
        const server = `${serverName}:${port}`;
        console.log('server ', server)
        const db = yield database.getDBConnecctionObj(server, databaseName, username, password);
        const docs = yield database.getAllData(db);
        database.stop(db);
        res.json({payload, docs});

    });
});


const ComparisonDataSchema = new mongoose.Schema({
        flag: String,
        attribute: String
    },
    {
        collection: 'comparedAttributes',
        strict: false,
        timestamps: true
    }
);
var ComparisonData = mongoose.model('ComparisonData', ComparisonDataSchema);
app.post('/api/comparisondatas', function (req, res) {
    var comparisondata = new ComparisonData(req.body);
    comparisondata.save(function (err) {
        if (err)
            console.log(err);
        else
            console.log(comparisondata);
    });
});


//save end
const routes=require("./api/cbUtils/routes.js")(app);
const centralApi=require('./api/centralApi/callConsumerAPI.js')(app);
const sendEmailApi=require('./api/sendEmail/index.js')(app);

let host;
SwaggerExpress.create(config, function (err, swaggerExpress) {
    if (err) {
        throw err;
    }
    // Add Swagger-UI
    app.use(SwaggerUi(swaggerExpress.runner.swagger));

    // install middleware
    swaggerExpress.register(app);
    app.use(express.static(__dirname + '/public'));

    app.get('*', function (req, res) {
        res.sendFile(path.join(__dirname + '/public/app/views/pages/index.html'))
    });

    if (typeof host === 'undefined' || this.host === '') {
        host = hostConfig.host + ':' + hostConfig.port;
    }
    console.log('DSV API : ' + host);
    let mongoAuth = '',
        mongoURL = '',
        dbConfig = configuration.application.mongo,
        hostString = '';

    if (dbConfig.auth.user && dbConfig.auth.pass) {
        mongoAuth = dbConfig.auth.user + ':' + dbConfig.auth.pass + '@';
    }
    for (let indx = 0; indx < dbConfig.instances.length; indx++) {
        if (indx > 0) {
            hostString += ',';
        }
        hostString += dbConfig.instances[indx].host + ':' + dbConfig.instances[indx].port;
    }
    mongoURL = 'mongodb://' + mongoAuth + hostString + '/' + configuration.application.mongo.db + '?' + 'authSource=admin';
    //mongoURL='mongodb://dsvuser:dsv1234@10.17.165.223:27017/dsv?authSource=admin'
    //mongoURL='mongodb://localhost:27017/dsv'
    
    mongoose.Promise = global.Promise;
    db.connect(mongoURL, function () {
     /*    app.listen(configuration.application.apiUrl.port, function () {
            log.info('App is listening on port: ' + configuration.application.apiUrl.port);
            log.info('The DB Server started at: ' + hostString + '/' + configuration.application.mongo.db);
            log.info('mongoURL: ', mongoURL);
        }) */
		https.createServer(options, app).listen(port, ip, function () {
           console.log('App is listening on port: ' + configuration.application.apiUrl.port);
           console.log('The DB Server started at: ' + hostString + '/' + configuration.application.mongo.db);
           console.log('mongoURL: ', mongoURL);
        })
    });
	
    process.on('SIGINT', function () {
        db.closeConnections(function () {
            process.exit(0);
        });
    });
    process.on('unhandledRejection', function (reason, p) {
        console.log('Unhandled Rejection at: Promise ', p, ' reason: ', reason);
    });

    process.on('uncaughtException', function (err) {
        console.log('uncaughtException', err);
    });
});

module.exports = app; // for testing
