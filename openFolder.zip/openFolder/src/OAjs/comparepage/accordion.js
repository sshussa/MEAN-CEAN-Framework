

OPEN.cmpaccrd={
   accordion: {		
        set: function() {
            if ($(window).width() < 660) {
                $(".module-1 ul" + OPEN.config.CLS._comprSec).show();
                $(".module-1" + $(OPEN.config.CLS._accHdr) + " .accordion_head p span").addClass("arrow-down").removeClass("arrow-right").parent().parent().addClass("active");
            }
           
            $(OPEN.config.CLS._accHdr).bind("click touch", function(b) { /* mar a */
                if ($(window).width() < 660) {
                    ($(this).parent().attr("id") == "details") ? ($(this).next().find(OPEN.config.CLS._comprSec).hide(), OPEN.config.CLS._comprSec = ">.compare-section") : (OPEN.config.CLS._comprSec = ".compare-section")
                    if ($(this).parent().find(OPEN.config.CLS._comprSec).is(":visible")) {
                        $(this).parent().find(OPEN.config.CLS._comprSec).hide("slow");
                        $(this).find("span.arrow-down").removeClass("arrow-down").addClass("arrow-right").parent().parent().removeClass("active");
						$(this).find("span.minus-icon").addClass("plus-icon").removeClass("minus-icon");
                        /*March A */
                        $(this).parent().find('.compare-section span.minus-icon').removeClass("minus-icon").addClass("plus-icon");
                    } else {
                        $(this).parent().find(OPEN.config.CLS._comprSec).show("slow");
                        $(this).find("span.arrow-right").addClass("arrow-down").removeClass("arrow-right").parent().parent().addClass("active");
						$(this).find("span.plus-icon").addClass("minus-icon").removeClass("plus-icon");
                    }
                    OPEN.config.CLS._comprSec = ".compare-section"
                }
                 
				 setTimeout(function(){
				 ($(window).scrollTop() + $(window).height() >= $(document).height() - 20)? $(".scroll-arrow").addClass('up'): $(".scroll-arrow").removeClass('up')
				 },800)
            })
        }
       
    },
    accr: function() {

        OPEN.cmpaccrd.accordion.set(this);
        $(".accordion_head p").each(function() {
            //$(this).parent().parent().hasClass("module-4") && $(this).find("strong").html("Card Type");    commenting out as the current markup dont have Strong tag
            var e = $(this).text();
            var t = e.replace("-", " ");
            /* march A */
            !$(this).parents('.accordion .accordion').html() ? $(this).html(t.replace(/\w\S*/g, function(e) {
                return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase()
            }) + "<span class='arrow-right'></span>") : $(this).html(e + "<span class='plus-icon'></span>");
        });
        $(".accordion_head p span:first").addClass("arrow-down").removeClass("arrow-right").parent().parent().addClass("active");

    }
	
}