if (!window.OPEN) {
    var OPEN = {};
}
(function($, window, document) {

    if (typeof jQuery == 'undefined') {
        throw new Error("JQuery library is not loaded which is mandatory to run the AMEX OPEN Application");
        return;
    }

    /*************************************************** Config Starts here ***********************************************/
    //Page level config details. but these are not Global variables.
    OPEN.config = {

            ID: {
                _filterPanel: "#filter-panel",
                _cmprCrds: "#compare-cards",
                _crdCnt: "#cards-content",
                _overlaybg: "#overlay-mask",
                _cardsLst: "#cards-list-overlay",
                curr_selitem: "#curr-selection li",               				
                _cardsListWrap: "#cards-list-overlay-wrap",
                _cmprHead: "#compare-cards .cards-header",
                mbl_lrn: "#mobile-learnmore",
                _mbiloverlaybg: "#mobile-list-overlay-wrap",
				crdOvly :'#cards-list-overlay'                

            },
            CLS: {
                _comprSec: ".compare-section",
                _cardBtns: ".cards-btns",
                _cls: ".close-icon-compare-tray ",
                _cardsList: "cards-list",
                _accHdr: ".accordion .accordion_head",
                scrl_arrow: $(".scroll-arrow"),
                MWWrapper:$(".page-wrapper").length==0?$('#compare-cards .content-wrapper'):$(".page-wrapper") ,
                modules:$(".accordion>ul,.accordion>div>ul").not(".module-terms").not(".earn-points"),
                scrollPadding:$("#compare-cards").height()-90
            },
                    glb_vrbs: {
                _cmpr_crdTry: [],
                avl_crdstry:[],
				crd_cntr:0,
				     tray_arr: [],
					cookie_arr: [], tray_arr_up: [],					
                ld_cke: 0,
                mbl_cmp:false,
                card_rdr: false,
				overlay_open: false,
                _crrCrd: null,
                bodyClass: null,
                _navFlag: false,
                mb_over_open: false,
                bfr_crd: "",
                ck_mb:false,
				res_change:'',
				cnt:0,
                pag_load_flg:false,
                set_json_flg:false,
                scrollng_flg:false,
                crd_tbrm:'',
                mbl_itr_cntr:0,
                ratings:{}
            },
            APP:{
                module_array: [],
                  fltr_selc: "",
                  add_ovly:false
            }



        }
        /*************************************************** Config ends here ***********************************************/

    //Page level implementation 

    OPEN.compare = function() {
        //Closur global variables.
        var cmpCards = {

            // --------- Private methods which are encapsulated inside the structure.

               
            // --------- Public methods which are exposed out-side the structure.
            public: {


                comp_pagecomponent: function() {
                    void 0 !== OPEN.cmpnavigate && (OPEN.cmpnavigate.navigate(this), OPEN.cmpnavigate.navigateSec(this));
              
			   
                },


                $crdContent: function() {
                    void 0 != OPEN.comp_pagecomponent && OPEN.comp_pagecomponent.crdContent(this);
                },

                filter: function() {
                    void 0 != OPEN.cmpfilter && OPEN.cmpfilter.filterCards(this)
                },

                /* All statments requred during document ready defined here */
                $ready_methods: function() {
                    
                    //void 0 !== OPEN.comp_pagecomponent && OPEN.comp_pagecomponent.newcompare_modorder();
                    void 0 != OPEN.docmt_method && OPEN.docmt_method.rdy_method(this).view_allnk();
                    
                     
                   
                },

                $accrr_load: function() {

                    void 0 != OPEN.cmpaccrd && OPEN.cmpaccrd.accr(this);

                },
				 $renderCardFilters: function () {
                    //Genarate filter items with specified Json Structure.
                    void 0 !== OPEN.overlayfilter  && OPEN.overlayfilter.filterData.renderCardFilters(this);
                },
                pg_load: function() {
                    void 0 != OPEN.cust_scroll && OPEN.cust_scroll.scrollBar();	
					void 0 != OPEN.mobile_overlay && OPEN.mobile_overlay.clone_tryasection();
                    void 0 != OPEN.mobile_overlay && OPEN.mobile_overlay.mobilescroll();
                    void 0 != OPEN.docmt_method && OPEN.docmt_method.pgld_method(this);
                   
					void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageReady(OPEN.config);
                   
					
				
                }
            }
        }
        for (var obj in this) cmpCards[obj] = this[obj];
        var _ = cmpCards;
        return cmpCards.public;
    }

//OPEN.testshowcard = function(){
//            if((parseInt($('#compare-cards').css('top'), 0))&&($(window).width() < 660)&& $("div#compare-cards:not(.scroll)")){
//           console.log("aha"); 
//         $(OPEN.config.ID. _cmprCrds).find("#curr-selection li a.card-art").hide();
//            }
//        
//};

    function INIT(init, inhr) {
        for (var obj in (OPEN.compare()))(init ? obj[0] == '$' : obj[0] != '$') && typeof(OPEN.compare()[obj]) == "function" && (OPEN.compare()[obj]).call(inhr);
    }

    $(document).ready(function(e) {


        //initialize the methods before HTML structure renders on web page.
        INIT(true, OPEN.config);
    });
    $(window).load(function(e) {
        //initialize the methods after all assets(HTML/CSS/JS) are loaded on web page.
        INIT(false, OPEN.config);
		
    });
    $(window).resize(function(e) {
        //initialize the methods after all assets(HTML/CSS/JS) are loaded on web page.
        
        OPEN.docmt_method.resz(this);
		
        void 0 !== OPEN.findOffers && OPEN.findOffers.pageResize();
        void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageResize(OPEN.config);                       
//        void 0 !== OPEN.testshowcard(OPEN.config);
    });  

      
	 $(window).on("scroll", function () {
         OPEN.config.glb_vrbs.scrollng_flg=true;
//         console.log("true::"+OPEN.config.glb_vrbs.scrollng_flg);
        void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageScroll(OPEN.config); 
//        void 0 !== OPEN.testshowcard(OPEN.config);
      
        OPEN.config.glb_vrbs.scrollng_flg=false;  
//        console.log("false::"+OPEN.config.glb_vrbs.scrollng_flg);
     });


    window.onpageshow = function(event) {
        //May B 
        ($("#compare-cards").css('top') == "auto" || $("#compare-cards").css('top') != 0) && $(window).width() > 660 && $(window).resize();
        if (event.persisted) {

            setTimeout(function() {
                $(window).width() < 660 ? $(OPEN.config.ID._crdCnt).css("padding-top", $("#compare-cards").outerHeight(true) + 5) : $(".server-error").size() ? $(OPEN.config.ID._crdCnt).css("padding-top", 272 + $(".server-error").height()) : $(OPEN.config.ID._crdCnt).css("padding-top", "265px"); /* May B */
            }, 3500);
        }
    };
})(window.jQuery, window, document);