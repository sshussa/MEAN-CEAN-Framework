
OPEN.cmpfilter={

    filterCards: function() {
        $(OPEN.config.ID._cardsLst).find(".cards-list li:last-child").after($(OPEN.config.ID._cardsLst).find(".close-icon").focus());
        $(OPEN.config.ID._cardsLst).find(".card-types input[type='radio']").on("click touch", function() {
                   if ($(this).is(":checked")) {
   OPEN.overlayfilter.filterData.ovrlay_FilterCards.call($(this));
                    var c = $(this).attr("title").split(" ").join("");                                       
              
                typeof $iTagTracker == "function" ? $iTagTracker("rmaction", "ShowCards_" + c) : null
            
            }
             OPEN.config.APP.fltr_selc=$(this).attr("id");
        })
    }
}