/********************************************** All events related document defined here **************************************/
OPEN.docmt_method = {
    rdy_method: function() {
     $("#ajnavwrapper").css("display")=="none"&&$("#ajnavwrapper").removeAttr("style").css("visibility","hidden");
        $("#curr-selection li:not(.pmc-hldr)").length==1 &&   $("#curr-selection li button.close-icon-compare-tray").hide();    
	 OPEN.universal.openNewTab(".module-terms");
        OPEN.config.glb_vrbs.bodyClass = $('body').attr('class');
        OPEN.config.glb_vrbs.res_change = $('body').attr("class").match(/res[\w-]*\b/).toString();
        (typeof(module_preselect) != "undefined") && $('#cards-content').addClass('off-txt');
        if (typeof(snrURL) !== "undefined") {
            if (window.history && window.history.pushState) {
                $(window).bind("popstate", function() {
                    var hashLocation = location.hash;
                    var hashSplit = hashLocation.split("#!/");
                    var hashName = hashSplit[1];
                    if (hashName !== "") {
                        var hash = window.location.hash;
                        if (hash === "") {
                            window.location = snrURL;
                            return false
                        }
                    }
                });
                window.history.pushState("forward", null, "")
            }
        }
        /* DTW EEP Decode flow scenario fix 11A*/
        if ($("#ajnav").length == 0) {
            $("#wrapper").addClass("decode-flow");
        }
        /* 11A end */
          OPEN.comp_pagecomponent.updatedratings();
        /* Compare Page redsign Logic Needs to be called in ready */

        void 0 != OPEN.cmp_reld && OPEN.cmp_reld.comp_rdg(this)
        OPEN.universal.isIphone();
        /* Aprila */
        if ($(window).width() < 831 && $(OPEN.config.ID.curr_selitem).not(".pmc-hldr").length == 2) {
            $("#curr-selection li:last").addClass("last-item");
            $(".cards-btns li:last").addClass("last-item")
        } else {
            if ($(window).width() < 831 && $(OPEN.config.ID.curr_selitem).not(".pmc-hldr").length == 3) {
                OPEN.cmp_reld.curr_selec(1);
            } else {
                OPEN.cmp_reld.curr_selec(0);
            }
        }
        ($("#curr-selection li.pmc-hldr").length == 2 && (('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch)) && ($("#curr-selection li.pmc-hldr").eq(0).find('a.card-art').addClass("halfcard-image"));
        var listitems = document.getElementById("benefits-and-terms").getElementsByTagName("li");
        var listindex = $("#benefits-and-terms li").length - 1; /* mar a */
        listitems[listindex].className = "last-item";
        $('#cards-content div[class*="module-"]').keyup(function(e) {
            if (e.keyCode == 9) {
                var t = OPEN.universal.formatTabName($(this).find("ul:eq(0)").attr("id"));
                typeof $iTagTracker == "function" ? $iTagTracker("layertrack", t) : null
            }
        })

        return this;

    },
    view_allnk: function() {
        $(".viewall_cardslink").bind("click", "touch", function() {
            OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec+ "li:visible").not(".pmc-hldr"));
            OPEN.cmp_components.cooke_creation();
        });
        return this;
    },

    pgld_method: function() {        
        $("#curr-selection.compare-section .card-art").on("click", function(e) {
            if (!$(this).parent().hasClass("pmc-hldr")) {
                e.preventDefault();
                window.location = $(this).attr("href");
            }
        });

       
        $("#newcmprtryftr").insertAfter('.custom-scrollbar .viewport');
        $(".pmc-hldr").hasClass("singlecard") ? $("#curr-selection .pmc-hldr .close-icon-compare-tray").removeAttr("style") : null;
        $(window).width() < 660 && OPEN.comp_pagecomponent.setApplyBtn(1);
        $(window).width() < 660 ?$(OPEN.config.ID._crdCnt).css("padding-top", $("#compare-cards").outerHeight(true) + 35) :($(".server-error").size() ? $(OPEN.config.ID._crdCnt).css("padding-top", 272 + $(".server-error").height()) : $(OPEN.config.ID._crdCnt).css("padding-top", "265px")), $('#ajnav').css('top') == "auto" && $(window).resize(); /* May B */
// $(window).width() < 660 ?$(OPEN.config.ID._cmprCrds).css("padding-top", $("#compare-cards").outerHeight(true) + 25) :($(".server-error").size() ? $(OPEN.config.ID._crdCnt).css("padding-top", 272 + $(".server-error").height()) : $(OPEN.config.ID._crdCnt).css("padding-top", "265px")), $('#ajnav').css('top') == "auto" && $(window).resize(); /* May B */

        /* Nov B 2015 Mobile Overlay */
        OPEN.comp_pagecomponent.mobile_ovlmths();




  

    },
    navigate_sec_resize: function(scp) {        
        /*$(window).width() > 830 ? $(a).css("padding-top", "250px") : $(a).css("padding-top", $("#compare-cards").height() + 12);
				$(window).width()<661?_crdCnt.css("padding-top", $("#compare-cards").outerHeight(true) + 5):_crdCnt.css("padding-top",0);*/




        $(window).width() < 660 ? $(OPEN.config.ID._crdCnt).css("padding-top", $("#compare-cards").outerHeight(true) + 35) : ($(".server-error").size() ? $(OPEN.config.ID._crdCnt).css("padding-top", 272 + $(".server-error").height()) : $(OPEN.config.ID._crdCnt).css("padding-top", "265px")); /*May B 	*/

        $(window).width() > 660 ? $(".server-error").css({
            position: 'relative',
            top: 60,
            "margin-bottom": '10px'
        }) : $(".server-error").css({
            position: 'relative',
            top: 10,
            "margin-bottom": '10px'
        });

    },

    resz: function() {
        
        if(OPEN.config.glb_vrbs.cnt==0){
            OPEN.config.glb_vrbs.cnt++;
       $(OPEN.config.ID.crdOvly).find('div').css('opacity',0);
       OPEN.component.overlay_filter_resz();
     
        }
        OPEN.mobile_overlay.update_overlaycrd_selction();
        OPEN.mobile_overlay.update_tootip();       

   
        if ($('body').attr("class").match(/res[\w-]*\b/).toString() != OPEN.config.glb_vrbs.res_change) {
            OPEN.config.glb_vrbs.res_change = $('body').attr("class").match(/res[\w-]*\b/).toString();
            OPEN.mobile_overlay.traycrds_update();
            $('#curr-selection li').not('.pmc-hldr').length == 2 && OPEN.comp_pagecomponent.doc_wdth() && $("#cards-list-overlay button.circle-close-icon").click();
        }
        OPEN.mobile_overlay.update_seccards();

        $(OPEN.config.ID._cardsListWrap).find(".close").click(function() {
                $(OPEN.config.ID._cardsListWrap).hide().removeClass("overlay-wrap showoverlay");
                $('body').removeClass('ovrly_open').addClass('ovrly_hidden');
            })
            /* September B 2015*/
        if ($(window).width() < 831 && $("#curr-selection li").not(".pmc-hldr").length == 2) {
            $("#curr-selection li:last").addClass("last-item");
            $(".cards-btns li:last").addClass("last-item");
            $('body').removeClass('ovrly_open').addClass('ovrly_hidden');
            if ($(OPEN.config.ID._cardsListWrap).hasClass("showoverlay")) {
                $(OPEN.config.ID._cardsListWrap).hide().removeClass("overlay-wrap showoverlay");
            }
        } else {
            if ($(window).width() < 831 && $("#curr-selection li").not(".pmc-hldr").length == 3) {
                OPEN.cmp_reld.curr_selec(1);
                if ($(OPEN.config.ID._cardsListWrap).hasClass("showoverlay")) {
                    $(OPEN.config.ID._cardsListWrap).addClass("overlay-wrap");
                }
            } else {
                OPEN.cmp_reld.curr_selec(0)
            }
        }
    if (($(window).width() > 831 && $("#curr-selection li").not(".pmc-hldr").length == 1) || ($(window).width() < 831 && $("#curr-selection li").not(".pmc-hldr").length == 1) || ($(window).width() > 831 && $("#curr-selection li").not(".pmc-hldr").length == 2) || ($(window).width() > 831 &&     $("#curr-selection li").not(".pmc-hldr").length == 3)) {
            if ($(OPEN.config.ID._cardsListWrap).hasClass("showoverlay")) {
                $(OPEN.config.ID._cardsListWrap).addClass("overlay-wrap");
            } else {
                OPEN.config.glb_vrbs.overlay_open == true && ($(OPEN.config.ID._cardsListWrap).show(), $(OPEN.config.ID._cardsListWrap).show().addClass("showoverlay"));
            }
        }
        OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr")); /* feb a Regression */

        $(window).width() > 660 && ($(OPEN.config.ID._mbiloverlaybg).hide(), OPEN.config.glb_vrbs.mb_over_open = false); /* October B */
        if ($(window).width() < 831 && $(OPEN.config.ID.curr_selitem).not(".pmc-hldr").length == 2) {
            $("#curr-selection li:last").addClass("last-item");
            $(".cards-btns li:last").addClass("last-item")
        } else {
            if ($(window).width() < 831 && $(OPEN.config.ID.curr_selitem).not(".pmc-hldr").length == 3) {
                OPEN.cmp_reld.curr_selec(1)
            } else {
                OPEN.cmp_reld.curr_selec(0)
            }
        }
        if ($(window).width() <= 660) {
            //var vp_height = $(window).height() - ($('#cards-list-overlay #newcmprtryftr').height() + $('.section').height());
            //$('.open.res_Small.newcomparetray .custom-scrollbar .viewport').height(vp_height);
            touch ? $("#cards-list-overlay-wrap .custom-scrollbar").addClass('touch-scrollbar') : $("#cards-list-overlay-wrap").openScrollber();
            this.rst_comptry();
            OPEN.comp_pagecomponent.setApplyBtn(1)

        } else {
            OPEN.config.glb_vrbs.mbl_cmp = false;
            OPEN.comp_pagecomponent.setApplyBtn(0)
        }

        if (navigator.userAgent.match(/Android/i) && navigator.userAgent.match(/Nexus/i) && $('body').hasClass('res_Small')) {
            setTimeout(function() {
                $('.module-1').find(OPEN.config.CLS._comprSec).show();
            }, 200);
        }
        var sett = setTimeout(function() {

                OPEN.config.glb_vrbs.bodyClass != $('body').attr('class') ? ($(window).resize(), OPEN.config.glb_vrbs.bodyClass = $('body').attr('class'), (!$('#cards-list-overlay-wrap').hasClass('showoverlay') && $('body').removeClass('ovrly_open'))) : clearTimeout(sett);
            }, 2000)
            /* compare page Redesign	*/
        $("#curr-selection li.pmc-hldr").length == 2 && OPEN.config.glb_vrbs.bodyClass.indexOf("res_Medium") != -1 ? $("#curr-selection li.pmc-hldr").eq(0).find('a.card-art').addClass("halfcard-image") : null

        OPEN.docmt_method.navigate_sec_resize(this);
        OPEN.config.glb_vrbs.cnt=0
        $(OPEN.config.ID.crdOvly).find('div').css('opacity',1);
        
    },
    rst_comptry: function() {
        var curr_sel = $("#curr-selection");
        OPEN.comp_pagecomponent.setApplyBtn(1);
        (!OPEN.config.glb_vrbs.mb_over_open) && $("body").css("overflow", "visible");
        if (curr_sel.find("li.pmc-hldr").length < 2) {
            $(OPEN.config.ID.mbl_lrn).find("li").css("display", "block")
        } else {
            if (curr_sel.find("li.pmc-hldr").length = 2) {
                $(OPEN.config.ID.mbl_lrn).find("li:eq(1)").css("display", "none");
                $(OPEN.config.ID.mbl_lrn).find("li:eq(0)").css("display", "block")
            }
        }
        $(OPEN.config.CLS._accHdr).live("click touch", function(a) {
                var d = $(this).find("span");
               
                d.hasClass("arrow-down") ? d.addClass("arrow-down") : d.removeClass("arrow-down")
            })
            /*$("#mobile-learnmore").find("li:eq(2)").html("");/*JAN PIV   feb a PIV */
    }

    //resize implementaion code is supposed to be placed in the following event block

}