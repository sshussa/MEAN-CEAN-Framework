/********************************************** All Page level Events Start here **************************************/
//Page level reusable components.
OPEN.cmp_components = {
    setJsondata: function(e, c, d, bfr_crd) {
         
        var p = c[d];
        OPEN.config.glb_vrbs.card_rdr == false ? $("#overview.compare-section").append(String(p.section.overview)) : $(String(p.section.overview)).insertBefore($('#overview.compare-section li.' + bfr_crd));
        /*  card_rdr!=false ? $("#overview.compare-section").append(String(p.section.overview)): $(String(p.section.overview)).insertBefore($("#overview.compare-section"));*/
        $(".compare-section.earn-points ." + e).remove();
        OPEN.config.glb_vrbs.card_rdr == false ? $(".compare-section.earn-points").append(p.section.offercontent) : $(String(p.section.offercontent)).insertBefore($('.compare-section.earn-points li.' + bfr_crd));

        $("#good-for.compare-section .aug" + e).remove();
        OPEN.config.glb_vrbs.card_rdr == false ? $("#good-for.compare-section").append(p.section.goodfor) : $(String(p.section.goodfor)).insertBefore($('#good-for.compare-section li.' + bfr_crd));
        $("#rewards.compare-section ." + e).remove();
        OPEN.config.glb_vrbs.card_rdr == false ? $("#rewards.compare-section").append(p.section.reward) : $(String(p.section.reward)).insertBefore($('#rewards.compare-section li.' + bfr_crd));
        OPEN.config.glb_vrbs.card_rdr == false ? $(".module-terms").append(p.section.benefits) : $(String(p.section.benefits)).insertBefore($('.module-terms li.' + bfr_crd));


        /* 9B 2015 */
	   var r = /<(\w+)[^>]*>.*<\/\1>/gi;
        $(OPEN.config.CLS._cardBtns).find("." + d.replace("_", "-")).find(".applybutton").html(p.ApplyNowURL);
        !OPEN.config.glb_vrbs.ld_cke && $(OPEN.config.CLS._cardBtns).find("." + d.replace("_", "-")).find(".learnmorebutton a").attr("title", "Learn More on " + $('#curr-selection').find("li." + d.replace("_", "-") + " h2 a").text().trim());  	/* 9B 2015 */
        $(OPEN.config.CLS._cardBtns).find("." + d.replace("_", "-")).find(".applybutton").html(p.ApplyNowURL);
        $(OPEN.config.CLS._cardBtns).find("." + d.replace("_", "-")).find(".learnmorebutton a").attr("href", p.LearnMoreURL);
        $("#curr-selection.compare-section ." + e).find(".card-art").attr("href", p.LearnMoreURL);
        $("#curr-selection.compare-section ." + e).find('h2 a').attr("href", p.LearnMoreURL);
           $("#curr-selection li."+e).find("h2").after($(p.section.ratings))
        /*Oct B 2015 production fix */
        $(".pmc-hldr a").parent().find("h2 a").attr("href", p.LearnMoreURL);
        var s = $("#details");
        var m = p.section.details;
        var n = [],
            prvMkp = false;
        for (obj in m) {
            var h = m[obj].tags;
            var o = m[obj];
            s.find(".details-row").size() != 0 && (prvMkp = true);
            var u = 0;
            var i;
            for (g in m[obj]) {
                if (g != "tags" && g != "title") {
                    (!prvMkp) && $("#details>li>ul").eq(u).append(h);
                    (g.indexOf("Access") == 0 || g.indexOf("Card Membership Benefits") == 0) ? (n.push(o[g])) : (i = o[g]);
                    OPEN.config.glb_vrbs.card_rdr == false ? $("#details #" + obj + " #" + g.split(" ").join("_")).find(".compare-section").append(i) : $(i).insertBefore($("#details #" + obj + " #" + g.split(" ").join("_")).find(".compare-section li." + bfr_crd));
                    u++
                }
            }
        }  
        var r = $("ul#details>li:eq(1)>ul .accordion>li.compare-section >ul> li.details-row ul.compare-section");
        for (s = 0; s < r.length; s++) {
            OPEN.config.glb_vrbs.card_rdr == false ? $(r[s]).append(n[s]) : $(n[s]).insertBefore($(r[s]).find("li." + bfr_crd))
        }
        $("#payment-type.compare-section ." + e).remove();
        OPEN.config.glb_vrbs.card_rdr == false ? $("#payment-type.compare-section").append(p.section.cardType) : $(String(p.section.cardType)).insertBefore($('#payment-type.compare-section li.' + bfr_crd));
        $("#annual-fee.compare-section ." + e).remove();
        OPEN.config.glb_vrbs.card_rdr == false ? $("#annual-fee.compare-section").append(p.section.annualFee) : $(String(p.section.annualFee)).insertBefore($('#annual-fee.compare-section li.' + bfr_crd));
        $("#curr-selection li."+e).find("h2").after($(p.section.ratings).find('div.viewallratings'))
        $("#details.compare-section ." + e).remove();
        var b = '<li class="' + e + '"></li>';
        $("#mobile-learnmore").append(b);
        /*Jan B */
        $("#mobile-learnmore li").show();
        /* 320 overlay */
	 ($(window).width() <= 660) && OPEN.docmt_method.rst_comptry();
        var mb_lm = $("#mobile-learnmore li").length;
        if (mb_lm >= $("#curr-selection li").not(".pmc-hldr").length) {
            for (mb_lm; mb_lm != ($("#curr-selection li").not(".pmc-hldr").length); mb_lm--) {              
                $($("#mobile-learnmore li")[mb_lm - 1]).remove()
            }
        }
        if (OPEN.config.glb_vrbs.mbl_cmp) {
            $("#compare-cards .cards-btns li").not('.pmc-hldr').each(function(i) {
                var a = $(this);
                var d = a.attr("class");
                $("#curr-selection").find("li." + d).find("span.applybutton").remove().end().append($(a).find(".applybutton").clone());
                (typeof($("ul#mobile-learnmore").find("li." + d).find("span.learnmorebutton")[0]) == "undefined") && $("ul#mobile-learnmore li").eq(i).remove().end().parent().append('<li class="' + d + '"></li>');
                $("ul#mobile-learnmore").find("li." + d).find("span.learnmorebutton").remove().end().append($(a).find(".learnmorebutton").clone());
            })
            $('.ajax-loding').remove();
            $('#wrapper, #ajnavwrapper,#responsiveWrapper_main').removeClass("loading");        
        }
        /* 10 B Flat card art updates */
        $('#curr-selection li').not('.pmc-hldr').find('a.card-art').each(function() {
            ($(this).attr('class').indexOf("flat-cardart-") != -1) && $(this).removeClass(function(index, css) {
                return (css.match(/\bflat-\S+/g) || []).join(' ');
            })
            $(this).addClass("flat-cardart-" + $(this).parent().attr('class').split("-")[1])
        })
        
        OPEN.config.glb_vrbs.set_json_flg=false;
        OPEN.config.glb_vrbs.mbl_itr_cntr++;  
        if(OPEN.config.glb_vrbs.mbl_itr_cntr==2){
        if($('body').hasClass('res_Small') &&    !OPEN.config.glb_vrbs.pag_load_flg){
         !$.isArray(OPEN.config.glb_vrbs.crd_tbrm, OPEN.config.glb_vrbs.avl_crdstry) && OPEN.cmp_components.closecardMet(this,OPEN.config.glb_vrbs.crd_tbrm,OPEN.config.glb_vrbs.ld_cke);
          
            }
            else{
            OPEN.config.glb_vrbs.mbl_itr_cntr=0;      
                
            }
        }
               if (OPEN.config.glb_vrbs.mbl_cmp && OPEN.config.glb_vrbs.avl_crdstry.length < 2) {
                OPEN.config.glb_vrbs.mbl_cmp = false;
            } else {
                OPEN.config.glb_vrbs.crd_cntr++;
                (OPEN.config.glb_vrbs.crd_cntr == 2) && (OPEN.config.glb_vrbs.mbl_cmp = false);
            }
            
             OPEN.comp_pagecomponent.updatedratings();
        

    },
    getJsonData: function(e, d, f) {
        $.ajax({
            dataType: "json",
            url: f,
            success: (function(json) {
                OPEN.cmp_components.setJsondata(e, json, d);
            })
        })
    },
    closecardMet: function(scp, crdName, ld_cke) {      
        var i = [];
        /* March B*/
        OPEN.universal.isPad() && (OPEN.config.glb_vrbs.ld_cke == 0 ? OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr")) : OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li").not(".pmc-hldr")));
        OPEN.config.glb_vrbs.mbl_cmp && OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li").not(".pmc-hldr"));
        $(window).width() < 831 && $.each($("#" + $($(OPEN.config.ID._crdCnt)).attr("id") + " " + OPEN.config.CLS._comprSec), function(a, b) { /* feb a Regression*/
            OPEN.config.glb_vrbs.ld_cke == 0 && !OPEN.config.glb_vrbs.mbl_cmp && $(b).children("li").eq(2).remove(); /*March B Deferred Defect 428*/
        });


        $("#" + $(OPEN.config.ID._crdCnt).attr("id") + " " + OPEN.config.CLS._comprSec + " li." + crdName).remove();
        $("ul#mobile-learnmore li").each(function (a) {
            currentid = $(this).attr("class");
            if (currentid == crdName) {
                $("ul#mobile-learnmore li." + crdName).remove() /* feb a PIV */
            }
        });
        OPEN.comp_pagecomponent.doc_wdth() && $(this).parent().parent().parent().children(":visible").not(".pmc-hldr").size() == 1 && $(this).parent().parent().index() == 0 ? window.location = "../OAhtml/viewall-cards.html" : null;
        for (j in OPEN.config.glb_vrbs._cmpr_crdTry) {
            OPEN.config.glb_vrbs._cmpr_crdTry[j].pmc != crdName && i.push(OPEN.config.glb_vrbs._cmpr_crdTry[j])
        }
        OPEN.config.glb_vrbs._cmpr_crdTry = i;
        OPEN.comp_pagecomponent.renderCrds();
        OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr"));
        var h;
        OPEN.cmp_components.cooke_creation();
        $(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr")
        OPEN.comp_pagecomponent.setApplyBtn();
            $('#compare-cards .cards-header h2,#compare-cards .cards-header p').hide();
            $('#compare-cards .cards-header h1').html("Compare Cards");
        /* 10 B Flat card art updates */
        $('#curr-selection li').find('a.card-art').each(function() {           
            ($(this).attr('class').indexOf("flat-cardart-") != -1) && $(this).removeClass(function(index, css) {
                return (css.match(/\bflat-\S+/g) || []).join(' ');
            })
                  if ($(this).parent().attr('class') != "pmc-hldr") {
                $(this).addClass("flat-cardart-" + $(this).parent().attr('class').split("-")[1]);                
            }
        })
           },
    cardClose: function() {
        $(OPEN.config.ID._cmprCrds).on("click touch", "button.close-icon-compare-tray", function(e) {
            OPEN.config.glb_vrbs.pag_load_flg=false;
              if(OPEN.config.glb_vrbs.set_json_flg) {
                   return false;
                   }
              else
              {  
            /* compare page redesign */          
            e.preventDefault();
            window.location.hash = "#loadfromcookie=true"
            $(this).parent().siblings("a").attr("title", "Add a Card");
            $(this).parent().siblings("span.learnmorebutton").hide();
            !(navigator.platform.indexOf("iPad") == -1 && navigator.userAgent.toLowerCase().indexOf("android") == -1 && navigator.userAgent.toLowerCase().indexOf("blackberry") == -1) ? $(".card-art").addClass("halfcard-image"): $(".card-art").removeClass("halfcard-image");
            (navigator.userAgent.toLowerCase().indexOf("iPhone") == -1) ? $(".card-art").addClass("halfcard-image"): $(".card-art").removeClass("halfcard-image");
            /* OCT B - to update flatcard-arts clases */
            $(this).parent().siblings('a.card-art').removeClass(function (index, css) {
                return (css.match(/\bflat-\S+/g) || []).join(' ');
            });
            crdName = $(this).parent().parent().attr("class");
            OPEN.cmp_components.closecardMet(this, crdName, OPEN.config.glb_vrbs.ld_cke); /* March B*/
            $(this).parent().next().addClass("halfcard-image");
            $(window).width() < 660 ? $(OPEN.config.ID._crdCnt).css("padding-top", $("#compare-cards").outerHeight(true) + 35) : ($(".server-error").size() ? $(OPEN.config.ID._crdCnt).css("padding-top", 272 + $(".server-error").height()) : $(OPEN.config.ID._crdCnt).css("padding-top", "265px")); /* May B */
            return false;
              }
        })
      
    },
    cooke_creation: function() {
        var jsonString = OPEN.universal.stringify(OPEN.config.glb_vrbs._cmpr_crdTry, false);
        OPEN.universal.createCookie("cardInfo", jsonString, 10);
    },
    select_card: function(t) {
        OPEN.config.glb_vrbs.set_json_flg=true;
        OPEN.config.glb_vrbs._crrCrd = $($("#curr-selection li.pmc-hldr")[0]);        
        var n = t.target.nodeName == "SPAN" ? $(this).parent() : $(this).parent().parent(), curr_sel = $("#curr-selection");
        OPEN.config.glb_vrbs.mbl_cmp && n.removeClass('disabled');
        if (!$(OPEN.config.ID._cmprCrds).find("li").hasClass("pmc-" + Number(n.attr("class").split("-")[1])) && !n.hasClass("disabled")) {
            if (OPEN.config.glb_vrbs._crrCrd != null) {
                var r = "pmc-" + n.attr("class").split("-")[1];
                $(OPEN.config.glb_vrbs._crrCrd).attr("id", r + "-card");                
                var s = OPEN.config.glb_vrbs._crrCrd.removeClass().addClass(r).css("visibility", "visible").find("h2").html(n.find("a").html()).clone();
                OPEN.config.glb_vrbs._crrCrd.removeClass().addClass(r).css("visibility", "visible").find("h2").html("<a class='viewcomparelink' href=''>" + s.html() + "</a>");
                var i = n.find("a").attr("title");
                $(OPEN.config.glb_vrbs._crrCrd).find("a.card-art").attr("title", i);
                $(OPEN.config.CLS._cardBtns).find(".pmc-hldr:first").removeClass().addClass(r).css("visibility", "visible");
                $(OPEN.config.ID._cmprCrds).find(".pmc-hldr").removeAttr("style").parent().find(OPEN.config.CLS._cls).first().removeAttr("style");
                $(OPEN.config.ID._cmprCrds).find('.' + r + ' .card-art ').addClass("flat-cardart-" + r.split("-")[1])
                OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr"));
            }
        }
        var o = OPEN.universal.getProductName(n.attr("class").split("-sml")[0]);
        typeof $iTagTracker == "function" ? $iTagTracker("rmaction", "Select-" + o) : null;
        OPEN.cmp_components.cooke_creation();
        jsonCardObj = r.replace("-", "_");
        var u = window.location.href;
        if (u.indexOf("#") != -1) {
            var a = u.indexOf("#");
            u = u.substring(0, a)
        }
        var f;       
        //u="https://qwww.americanexpress.com/us/small-business/credit-cards/top-credit-cards/44279" 
        u.indexOf("?") != -1 ? f = u + "&addPMC=" + jsonCardObj.split("_")[1] : f = u + "?addPMC=" + jsonCardObj.split("_")[1];
        OPEN.cmp_components.getJsonData(r, jsonCardObj, f);
        $(OPEN.config.ID.mbl_lrn).find("li:eq(1)").attr("class", curr_sel.find("li:eq(1)").attr("class"));
        $(OPEN.config.ID.mbl_lrn).find("li:eq(0)").attr("class", curr_sel.find("li:eq(0)").attr("class"));
        $(OPEN.config.ID.mbl_lrn).find("li:eq(0)").find("a").attr("href", $(".cards-btns").find("li:eq(0)").find("a.learn-more").attr("href"));
        $(OPEN.config.ID.mbl_lrn).find("li:eq(1)").find("a").attr("href", $(".cards-btns").find("li:eq(1)").find("a.learn-more").attr("href"));
        $('#compare-cards .cards-header h2,#compare-cards .cards-header p').hide();
        $('#compare-cards .cards-header h1').html("Compare Cards");
        
   
    }
}

