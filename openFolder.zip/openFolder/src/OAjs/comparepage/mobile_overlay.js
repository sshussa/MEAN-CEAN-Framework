/********************************************** Reusable Components Start here **************************************/
OPEN.mobile_overlay = {
    clear_comparetray: function() {
        $('.section li').removeClass().addClass('pmc-hldr').find('h2').html('');
        $('.section li button.close-icon-compare-tray').live('click', function() {
            $(OPEN.config.ID._cardsListWrap).removeClass('anim_stp');
            $('.cards-list li.' + $(this).parent().parent().attr('class') + '-sml').removeClass('disabled');
            $(this).parent().parent().removeClass().addClass('pmc-hldr').find('a').removeAttr('title').end().find('h2').html('').end().find('button.close-icon-compare-tray').hide();
            OPEN.mobile_overlay.update_tootip();
            var tmp_pmchldr = $('.section li.pmc-hldr')[0],
                tmp_dvr = $('.section span.section-divider');
            (!$($('.section li')[1]).hasClass('pmc-hldr') && $('.section li.pmc-hldr').length == 1) && (tmp_dvr.remove(), $($('.section li.pmc-hldr')[0]).remove(), $('.section').append(tmp_dvr).append(tmp_pmchldr));
            $('#cards-list-overlay ul.section li').not('.pmc-hldr').length < 2 && $("#cards-list-overlay-wrap .compare_cards").addClass('disable').parents('.cards-list').removeClass('disabled');
        })
        $('body').removeClass('ovrly_open').css({
            overflow: "visible"
        });
    },
    update_overlaycrd_selction: function() {
        $(OPEN.config.ID._cardsLst).find('.cards-list ul li').removeClass("disabled");
        var selc_var;
        OPEN.comp_pagecomponent.doc_wdth() ? selc_var = $(OPEN.config.glb_vrbs.avl_crdstry) : selc_var = $(OPEN.config.ID.curr_selitem).not('.pmc-hldr');
        selc_var.each(function(i, j) {
            var clss_name = OPEN.comp_pagecomponent.doc_wdth() ? j : this.className;
            $(OPEN.config.ID._cardsLst).find('.cards-list ul li.' + clss_name + "-sml").addClass("disabled")
        })
        $(OPEN.config.ID.crdOvly).find(".section li.pmc-hldr:eq(0)").length != 0 && $('.cards-list').removeClass('disabled')

    },
    clone_tryasection: function() {
        section_li = $('.compare-tray-placeholder.hide').find('li');
        section = $('.compare-tray-placeholder.hide').clone().removeClass().addClass('section').append(section_li);
        $('.section-holder').append(section);

    },
    update_tootip: function() {
        var card_wdth = $('.section li:eq(0) a.card-art img').width();
        var pmchldr_cnt = $(OPEN.config.ID.crdOvly).find(".section li.pmc-hldr").length;
        var crd_pos = (pmchldr_cnt == 0) ? $(OPEN.config.ID.crdOvly).find(".section li:eq(1) a.card-art").offset().left + (card_wdth / 2 - 10) : ($(OPEN.config.ID.crdOvly).find(".section li.pmc-hldr a.card-art").offset().left + (card_wdth / 2 - 10));
        $(OPEN.config.ID.crdOvly).find(".divider-line-arrow-down").css({
            left: crd_pos
        });
        pmchldr_cnt == 0 ? $(OPEN.config.ID.crdOvly).find(".divider-line-arrow-down").hide() : $(OPEN.config.ID.crdOvly).find(".divider-line-arrow-down").show();
    },
    traycrds_update: function() {
        if ($(window).width() < 661) {
            $('.section li').removeClass().addClass('pmc-hldr').find('button.close-icon-compare-tray').hide();

            $("#curr-selection li").not('.pmc-hldr').each(function(i) {
                $('.section li').eq(i).removeClass().addClass($(this).attr("class")).find('button.close-icon-compare-tray').show();
            })
        }
    },
    update_seccards: function() {
        OPEN.config.glb_vrbs.avl_crdstry = [];
        $('#cards-list-overlay ul.section li').each(function() {
            OPEN.config.glb_vrbs.avl_crdstry.push(this.className)
        })

    },
    mobilescroll: function() {

        $('#newcmprtryftr').live('touchmove', function(e) {
            e.stopPropagation();
            return false;
        })
        var lastScrollTop = 0;
        var inht = window.innerHeight;

        var scrollTimeout = null;
        var scrollendDelay = 150; // ms

        $(window).scroll(function() {
            if (scrollTimeout === null) {} else {
                clearTimeout(scrollTimeout);
            }
            scrollTimeout = setTimeout(scrollendHandler, scrollendDelay);
        });


        function scrollendHandler() {         
            // this code executes on "scrollend"
            var st = window.innerHeight;
            var ht = window.innerHeight - ($('.section-holder').height() + $('#newcmprtryftr').height());
            if (touch && $("body").hasClass("res_Small")) {
                if (st != lastScrollTop) {
                    ($(window).width() == 320 || $(window).width() == 375) && ht < $(window).height() - 50 && (ht = window.innerHeight - ($('.section-holder').height() + $('#newcmprtryftr').height()));
                    $(window).width() == 480 || $(window).width() == 568 && (ht = window.innerHeight - ($('.section-holder').height() + $('#newcmprtryftr').height()));
                    $("#cards-list-overlay-wrap").css("height", ht);
                    $("#cards-list-overlay .custom-scrollbar").css("height", ht);
                    $("#cards-list-overlay .viewport").css("height", ht);
                }
                if (st > lastScrollTop) {
                    st = window.lastScrollTop;
                    var inc = st - lastScrollTop;
                    $("#cards-list-overlay .viewport").css("height", ht + inc);

                }

            }
            lastScrollTop = st;
            scrollTimeout = null;
        }




    }


}