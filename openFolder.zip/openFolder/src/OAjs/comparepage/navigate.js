OPEN.cmpnavigate={
    navigate: function() {
        $("#ajnav .aj-inpage .in-page").on("click touch","a",function(i) { /* Personalization */ /* Junec */
            var flk = true;
            i.preventDefault();
            var e = OPEN.universal.formatTabName($(this).text());
            typeof $iTagTracker == "function" ? $iTagTracker("rmaction", e + "_LeftNav") : null;
            var h = 0;
            var f = !!window.devicePixelRatio ? window.devicePixelRatio : 1;
            if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/iPad/i)) {
                h = 2
            }
            $(this).text().toLowerCase() == "overview" && f >= 1 ? $("html, body").animate({
                scrollTop: iNavHeight + h
            }) :  OPEN.comp_pagecomponent.scrollSec($(this).text());
            /*personalization*/
            /*Compare page redesign*/
            (typeof(module_preselect) == "undefined" || module_preselect == "overview") ? OPEN.config.glb_vrbs._navFlag = true: !flk && (OPEN.config.glb_vrbs._navFlag = true);
            flk = false;
            $("#ajnav .aj-inpage .in-page a").parent().removeClass("active"); /* junec */
            /* Personalization */

            $(this).parent().addClass("active")
        }).focus(function(b) {
            $("#ajnav .aj-inpage .in-page a").parent().removeClass("active"); /* junec */
            $(this).parent().addClass("active")
        });

        OPEN.cmp_components.cardClose(this);
        $(OPEN.config.ID._cmprCrds).find("a.terms").live("click touch", function() {
            $("#ajnav .aj-inpage .in-page a").parent().removeClass("active"); /* junec */
            OPEN.config.glb_vrbs._navFlag = true;
            OPEN.comp_pagecomponent.scrollSec($(this).text());
            return false
        })
    },



    navigateSec: function() {
        var e = "",comp_mod=true;
            _goodForSec = "good-for";
        var t = $("." + _goodForSec).parent().hasClass("active");
        var o = $("#" + _goodForSec + " li ul li");
        var v = $("#good-for li div  ul li div");
        !t ? o.find("div").removeClass("list-overlay") : null;
        o.live("click touch", function() {
		               clearInterval(e);
            $("#good-for ul li").find("div").removeClass("list-overlay");
            $(this).find("div").addClass("list-overlay");
            e = setTimeout(function() {
                $(".list-overlay").removeClass("list-overlay")
            }, 7000);
            $(this).find("div").addClass("list-overlay").find('.close-icon').live("click touch", function() {
                $(this).parent().removeClass("list-overlay");
                return false
            });
            var c = $(this).parent().parent().attr("class");
            var b = $("#curr-selection li." + c).find("h2").text().split("From")[0] + ":" + $(this).find("a").text();
            typeof $iTagTracker == "function" ? $iTagTracker("rmaction", "HoverView_" + b) : null;
            return false;
			
        });
        $("body").live("click touch", function() {
            $(".list-overlay").removeClass("list-overlay")
        });
        var s = OPEN.config.CLS.modules;
       // s.push($("#details"));
        var n = $(window).scrollTop();
        var i = 0;
        var u = $("#wrapper").find("#cards-content");
        $(window).scroll(function(b) {
            var c = $(window).scrollTop();
            n < c ? i = 0 : i = 70;
            n = c;
            $(u).bind("touchstart", function() {
                OPEN.config.glb_vrbs._navFlag = false
            });
            if (!OPEN.config.glb_vrbs._navFlag) {
                s.each(function(index, element) {
                   
                    
                        /* April A implementation*/
                        /* @param secPos gives module position
				   @param inpageOffset gives inpage navigation position
				   @param moduleId gives id of a module or a sub module
				   @param currentnav gives respective module's in page navigation link index
				   @param currentnavtop gives postion of the present module's inpage nav link w.r.t to navigation
				 */    
                 //var navliHt = OPEN.universal.navPanelPosIndexed(); 
                        var secPos = $(element).offset().top - $(document).scrollTop() - 
                        ($("body").hasClass("newcompare")?$("#compare-cards-clone").outerHeight(true):$(OPEN.config.ID._cmprCrds).outerHeight(true)), moduleId = $(element).attr('id'),                           
                            currentnavtop =  i ;
                        $("#ajnav .aj-inpage .in-page").is(":visible") && (OPEN.config.glb_vrbs._navFlag = false);
                        

                        if (secPos <= currentnavtop) {
                            
                            if (typeof moduleId != "undefined") {
                               
                                if (typeof(module_preselect) == "undefined" || module_preselect == "overview") {
                                    $("#ajnav .aj-inpage .in-page a").parent().removeClass("active"); 
                                    $("#ajnav .aj-inpage .in-page a." + moduleId + "").parent()[0].classList.add("active");
                                }
                                 else {
                                     if (typeof(module_preselect) != "undefined" && comp_mod) {
                                         comp_mod = false;
                                         OPEN.config.glb_vrbs._navFlag = false;
                                        $('#ajnav .aj-inpage .in-page li').find('a.' + module_preselect).click()
                                    } else {
                                        if (typeof(module_preselect) != "undefined" && !comp_mod) {
                                             $("#ajnav .aj-inpage .in-page a").parent().removeClass("active") && $("#ajnav .aj-inpage .in-page a." + moduleId + "").parent()[0].classList.add("active");
                                         }
                                     }
                                 }
                                $('#ajnav .aj-inpage .in-page li:last-child')[0].classList.add('last-nav');
                            }
                        }
                         $("#ajnav .aj-inpage .in-page li.ignore-ele.active").length>0 &&   $("#ajnav .aj-inpage .in-page li.ignore-ele.active").removeClass("active").next()[0].classList.add("active");        

                        /* Personalization */
                        /*compare page error fix*/
                         $(window).width() > 660 ?  $(".server-error").css({
                                position: 'relative',
                                top: 60,
                                "margin-bottom": '10px'
                            }) : $(".server-error").css({
                                position: 'relative',
                                top: 10,
                                "margin-bottom": '10px'
                            });
                       
                   
                
                })
             }
        });
        var a = "#overview",
            r = ".mask-layer";
        /*compare page error message fix*/
        /*$(window).width()<661&& _crdCnt.css("padding-top", $("#compare-cards").outerHeight(true) + 5);
                 $(a).css("padding-top", $("#compare-cards").height() + 5);*/

        $(window).resize(function() {
            OPEN.docmt_method.resz();
			$('#cards-list-overlay-wrap').hasClass('showoverlay')? $(window).width() < 660 ? $('body').addClass('ovrly_open'):$('body').removeClass('ovrly_open'): $('body').removeClass('ovrly_open');
           
        });
  
        $(window).width() < 660 ? $(OPEN.config.ID._crdCnt).css("padding-top", $("#compare-cards").outerHeight(true) + 5) : ($(".server-error").size() ? $(OPEN.config.ID._crdCnt).css("padding-top", 272 + $(".server-error").height()) : $(OPEN.config.ID._crdCnt).css("padding-top", "265px")); /* May B */
    }}