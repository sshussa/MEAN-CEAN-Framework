/********************************************** Reusable Components Start here **************************************/
OPEN.comp_pagecomponent = {
    crdContent: function() {
        var _addCard = $(".pmc-hldr a"),
            _cardsListWrap = $("#cards-list-overlay-wrap");
           _cardsLst = $("#cards-list-overlay");
        _addCard.live("click touch", function(e) {
            OPEN.config.APP.add_ovly=true;
            OPEN.config.glb_vrbs.pag_load_flg = false;
            e.stopPropagation();
            /* compare page redesign */
            $(window).width() > 660 ? window.location.hash = "#loadfromcookie=true" : null;
            $("#see-all-cards").click();
            (typeof($iTagTracker) == "function") ? $iTagTracker("layertrack", "ShowCardsByFeature"): null;
            $(window).width() < 831 ? ($(OPEN.config.ID.curr_selitem).eq(2).addClass("last-item"), $(".cards-btns li").eq(2).addClass("last-item")) : null;
            if (jQuery.browser.msie) {
                OPEN.universal.isDesktop ? $("body,html").css({
                    overflow: "hidden"
                }) : null
            } else {
                OPEN.universal.isDesktop ? $("body").css({
                    overflow: "hidden"
                }) : null
            }
            /* Nov B 2015*/
            OPEN.mobile_overlay.clear_comparetray();
            var selcd_card = "pmc-" + $($('#curr-selection li')[0]).attr('class').split(' ')[0].split('-')[1];
            var crd_title = $($('#curr-selection li')[0]).find('a.card-art').attr('title')
            $("#cards-list-overlay-wrap .compare_cards").addClass('disable');
            $($(OPEN.config.ID._cardsListWrap).find('.section li.pmc-hldr')[0]).removeClass().addClass(selcd_card).find('.close-icon-compare-tray').show().end().find('a.card-art').attr('title', crd_title);
            $('.cards-list li.' + selcd_card + "-sml").addClass('disabled');
            OPEN.config.glb_vrbs.overlay_open = true;
            $(OPEN.config.ID._overlaybg).css("display", "block");
            OPEN.config.glb_vrbs._crrCrd = $(this).parent();
            $(OPEN.config.ID._cardsLst).find("ul li input:radio").siblings("span").hasClass("radio-checked") == false ? ($(OPEN.config.ID._cardsLst).find("ul li:first input:radio").attr("checked", "checked").siblings("span").addClass("radio-checked")) : null;
            $(OPEN.config.ID._cardsLst).find("ul li:first input:radio").trigger("click"); //octb production fix
            $("." + OPEN.config.CLS._cardsList).find("li").removeClass("disabled").css("opacity", 1);
            $.each($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr"), function(d, c) {
                $(OPEN.config.ID._cardsLst).find("." + OPEN.config.CLS._cardsList + " li[class='pmc-" + $(c).attr("class").split(" ")[0].split("-")[1] + "-sml']").addClass("disabled").find("a").attr("tabIndex", "-1")
            });
            _cardsListWrap.show().addClass("showoverlay").addClass('anim_stp');
            _cardsListWrap.find(".cards-list li").show();
            OPEN.comp_pagecomponent.doc_wdth() && $('body').addClass('ovrly_open');
            OPEN.mobile_overlay.update_tootip();
            !touch && _cardsListWrap.find('input[type="radio"]:checked').focus(); /* Aprila pavan*/
            $(window).keyup(function(e) {
                if (e.keyCode == 9) {
                    var d = $(document.activeElement),
                        f = "";
                    if ($(d).parent().prev().attr("class") == "small-card") {
                        f = "cards-list"
                    } else {
                        if ($(d).attr("type") == "radio") {
                            f = "ShowCardsByFeatureLayer"
                        } else {
                            if ($(d).attr("class") == "circle-close-icon") {
                                f = "close"
                            }
                        }
                    }
                }
            });
            _cardsListWrap.find(".circle-close-icon").live("keypress", function(b) {
                if (b.keyCode == 9) {
                    $(OPEN.config.ID._cardsLst).find('input[type="radio"]:checked').focus();
                    return false
                } else {
                    if (b.keyCode == 13) {
                        _cardsListWrap.hide().removeClass("showoverlay overlay-wrap");
                        $(OPEN.config.ID._overlaybg).hide();
                        $('body').removeClass('ovrly_open').addClass('ovrly_hidden');
                        $("#wrapper").find(".pmc-hldr a").focus();
                        return false
                    }
                }
            })
            navigator.userAgent.match(/Android/i) && $(OPEN.config.ID._cardsLst).css("top", 20);
            var vp_height = $(window).height() - ($('#newcmprtryftr').height() + $('.section').height());
            $('.open.res_Small.newcomparetray .custom-scrollbar .viewport').height(vp_height);
            touch ? $("#cards-list-overlay-wrap .custom-scrollbar").addClass('touch-scrollbar') : $("#cards-list-overlay-wrap").openScrollber();
            //OPEN.universal.alignAnchors(); /*March B Deferred Defect 424*/
            return false;
        });
        $("#cards-list-overlay-wrap").find("button.circle-close-icon, ." + OPEN.config.CLS._cardsList + " li a, ." + OPEN.config.CLS._cardsList + " li span, button.circle-plus-blue-btn").click(function(d) {
            /* Nov B 2015*/
            d.stopPropagation();
            if ($('body').hasClass('res_Small')) {
                if (this.nodeName == "A" && ($(this).parents('li').hasClass('disabled') || $('.cards-list').hasClass('disabled'))) {
                    return false;
                }
                this.nodeName == "A" && $(this).parents('li').addClass("disabled");
            }
            if ($('body').hasClass('res_Small') && !OPEN.config.glb_vrbs.mbl_cmp) {
                if ($(this).attr('class') == "circle-close-icon") {
                    $(OPEN.config.ID._overlaybg).css("display", "none");
                    OPEN.config.glb_vrbs.overlay_open = false;
                    var c = d.target.nodeName == "SPAN" ? $(this).parent() : $(this).parent().parent();
                    !c.hasClass("disabled") ? _cardsListWrap.hide().removeClass("overlay-wrap showoverlay") : $("#overlay-mask").show();
                } else if ($(this).attr('class') == "circle-plus-blue-btn" || $(this).parents('li').attr('class').indexOf($('.section li:eq(0)').attr('class').split('-')[1].toString()) == -1)
                 {
                    if ($(this.parentElement).hasClass('disabled')) {
                        $('.section li.' + $(this.parentElement).attr('class').split(' ')[0].replace('-sml', '') + ' .close-icon-compare-tray').click();
                        return false;
                    }
                    if (OPEN.comp_pagecomponent.doc_wdth()) {
                        if ($('.section li.pmc-hldr').length == 0) {
                            return false;
                        }
                    }
                    _cardsListWrap.removeClass('anim_stp');
                    var selcd_card = "pmc-" + $(this).parents('li').attr('class').split('-')[1];
                    var temp = $('ul.section li:eq(0) a.card-art').clone().addClass('temp').addClass(selcd_card),
                        pmc_top = $('.section li.pmc-hldr a').offset().top - $('.section').offset().top,
                        pmc_left = $('.section li.pmc-hldr a').offset().left;
                    var crd_title = $(this).parents('li').find('a').text().trim()
                    $('ul.section').prepend(temp.css({
                        opacity: 0.3,
                        'position': 'relative',
                        'display': 'inline-block',
                        top: pmc_top + 20,
                        left: pmc_left,
                        width: 72,
                        height: 43
                    }).animate({
                        opacity: 0.8,
                        'position': 'relative',
                        'display': 'inline-block',
                        'top': pmc_top + 5,
                        'margin': 0,
                        'left': pmc_left,
                        width: 72,
                        height: 43
                    }, 'easein', function() {
                        $(this).remove();
                        $($(OPEN.config.ID._cardsListWrap).find('.section li.pmc-hldr')[0]).removeClass().addClass(selcd_card).find('.close-icon-compare-tray').show().end().find('a').attr('title', crd_title);
                        //$(OPEN.config.ID._cardsListWrap).find('.section li.' + selcd_card).find('.card-art').removeClass('emtycard').end().find('.close-icon-compare-tray').show();
                        $('#cards-list-overlay ul.section li').not('.pmc-hldr').length == 2 && $("#cards-list-overlay-wrap .compare_cards").removeClass("disable").parents('.cards-list').addClass('disabled');
                        OPEN.mobile_overlay.update_tootip();
                    }));
                    $(this).parents('li').addClass('disabled');
                    card = $(OPEN.config.ID.crdOvly).find("li.pmc-hldr");
                }
                return false
            } else {
                $('.cards-list').removeClass('disabled');
                $(OPEN.config.ID._overlaybg).css("display", "none");
                OPEN.config.glb_vrbs.overlay_open = false;
                var c = d.target.nodeName == "SPAN" ? $(this).parent() : $(this).parent().parent();
                !c.hasClass("disabled") ? _cardsListWrap.hide().removeClass("overlay-wrap showoverlay") : $("#overlay-mask").show();
				/* Omniture Tracking code*/
				if($(this).attr("class") != "undefined" && $(this).attr("class") == "circle-close-icon") {
					(typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'compareCards_CloseAddCard') : null;}
				/* ended Omniture tracking code */
                if (jQuery.browser.msie) {
                    OPEN.universal.isDesktop ? $("body,html").css({
                        overflow: "auto",
                        "margin-right": 0
                    }) : null
                } else {
                    OPEN.universal.isDesktop ? $("body").css({
                        overflow: "auto",
                        "margin-right": 0
                    }) : null
                }
                /*Jan B */
                /*if(navigator.appVersion.indexOf("iPad")!=-1 && navigator.appVersion.indexOf("8_0")!=-1){*/
                var anc = $(window).scrollTop();
                $(window).scrollTop(anc - 1);
                /*}*/
                return false
            }
        });
        $(OPEN.config.ID._overlaybg).click(function() {
            $(OPEN.config.ID._overlaybg).css("display", "none");
            OPEN.config.glb_vrbs.overlay_open = false;
            _cardsListWrap.hide().removeClass("showoverlay overlay-wrap");
            $('body').removeClass('ovrly_open').addClass('ovrly_hidden');
            if (jQuery.browser.msie) {
                OPEN.universal.isDesktop ? $("body,html").css({
                    overflow: "auto",
                    "margin-right": 0
                }) : null
            } else {
                OPEN.universal.isDesktop ? $("body").css({
                    overflow: "auto",
                    "margin-right": 0
                }) : null
            }
            return false
        });
        OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.ID.curr_selitem + ":visible").not(".pmc-hldr"));
        $(OPEN.config.ID._cardsLst).find("." + OPEN.config.CLS._cardsList + " li a, ." + OPEN.config.CLS._cardsList + " li span, button.circle-plus-blue-btn").on("click", function(t) {
            if (!$('body').hasClass('res_Small')) {
                if (!$(this).parents('li').hasClass("disabled")) {
                    OPEN.cmp_components.select_card.call(this, t);
                    $("body").removeClass("ovrly_open").addClass('ovrly_hidden');
                } else {
                    return false;
                }
            } else {
                OPEN.config.glb_vrbs.mbl_cmp && ($('#wrapper, #ajnavwrapper,#responsiveWrapper_main').addClass("loading"), ($('.ajax-loding').length == 0 && $('body').prepend('<div class="ajax-loding"><span></span></div>')), OPEN.cmp_components.select_card.call(this, t))
            }
        });
        OPEN.comp_pagecomponent.cardsToCampare($(OPEN.config.CLS._cardBtns).children("li").size())
    },
    renderCrds: function() {
        var e = $(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li");
        var k = true;
        var h;
        var cmp_tray_sz = Number(e.size());
        //OPEN.config.glb_vrbs.mbl_cmp  && (OPEN.config.glb_vrbs._cmpr_crdTry = OPEN.config.glb_vrbs.avl_crdstry);
        if (OPEN.config.glb_vrbs._cmpr_crdTry.length) {
            for (var l = 0; l < cmp_tray_sz; l++) {
                h = OPEN.config.glb_vrbs._cmpr_crdTry[l];
                e.is(".pmc-hldr") && e.eq(2).hide();
                if (h) {
                    e.eq(l).find(".card-art").attr("href", e.parent().find("." + h.pmc + " .card-art").attr("href")).attr("title", e.parent().find("." + h.pmc + " .card-art").attr("title"));
                    e.eq(l).find('.viewallratings').remove();                    
                    e.eq(l).removeClass().addClass(h.pmc).find("h2").html(h.title).parent().parent().find(".card-art").parent().attr("id", h.pmc + "-card");
                    e.eq(l).find('h2').after(OPEN.config.glb_vrbs.ratings[h.pmc]);
                    e.eq(l).find("h2 a").attr("href", $(OPEN.config.CLS._cardBtns).find("li." + h.pmc + " .learn-more").attr("href"));
                    $(OPEN.config.CLS._cardBtns).find("li").eq(l).html($(OPEN.config.CLS._cardBtns).find("li." + h.pmc).html()).removeClass().addClass(h.pmc);                 
                    $('[id^="compare-cards-"]').find(".module-terms").each(function() {
                        $(this).find('li').eq(l).html($('#compare-cards-landing .module-terms').find('li.' + h.pmc).html()).removeClass().addClass(h.pmc)
                    })
                } else {
                    if ((OPEN.config.glb_vrbs.mbl_cmp && e.eq(l).attr('class') != $($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li")[l - 1]).attr('class') ? !$.isArray(e.eq(l).attr('class'), OPEN.config.glb_vrbs.avl_crdstry) : (OPEN.config.glb_vrbs.ld_cke && OPEN.config.glb_vrbs._cmpr_crdTry.length == 1 && $(e.eq(l)).attr('class') != $(e.eq(l - 1)).attr('class') && $.inArray($(e.eq(l)).attr('class'), OPEN.config.glb_vrbs.cookie_arr) != -1))) {
                        e.eq(l).show();
                    } else {                                                
                                $("#compare-cards [class^='cards-btns']").each(function() {
                                    $(this).find('li').eq(l).find("a").attr("title", " ").attr("href", " ");
                                    $(this).find('li').eq(l).find("button").attr("title", " ").removeAttr("onclick");
                                    $(this).find('li').eq(l).find("a").attr("title", " ").attr("href", " ").end().find("button").attr("title", " ").removeAttr("onclick");
                                    $(this).find('li').eq(l).removeClass().addClass("pmc-hldr");
                                })
                                $('#compare-cards ul[class^="module-terms"]').each(function() {
                                    $(this).find('li').eq(l).removeClass().addClass('pmc-hldr')
                                });
                              e.eq(l).find('.viewallratings').remove();
                            e.eq(l).removeClass().addClass("pmc-hldr").find(".card-art").attr("href", " ").attr("title", "Add a Card").parent().find("h2").html(" ");
                           e.eq(l).find(".card-art").attr("href", " ").attr("title", "Add a Card");
                                                        e.eq(l).removeClass().addClass("pmc-hldr");
                        
                    }
                }
            }
            var i = e.parent().children(":visible").not(".pmc-hldr").size();
            i == 1 && (e.parent().children(":visible").not(".pmc-hldr").find(".close-icon-compare-tray").hide());
            e.parent().find(".pmc-hldr:eq(0)").show()
        }
        },
    getAvlCrds: function(b) {
        if ($(window).width() < 768) {
            $("ul#mobile-learnmore li").eq(2).hide();
        }
		if ($('body').hasClass('res_Small')) {
            $("ul#mobile-learnmore li").eq(1).show();
        }
     
        OPEN.config.glb_vrbs._cmpr_crdTry = [];
        b.each(function(a, d) {
            OPEN.config.glb_vrbs._cmpr_crdTry[$(this).attr("class")] = {
                pmc: $(this).attr("class"),
                title: $(this).find("h2").html()
            }
        })
    },
    setApplyBtn: function(b) {
        $("#compare-cards .cards-btns li").each(function() {
            var a = $(this);
            var d = a.attr("class");
            if (d != "pmc-hldr" && d.indexOf('pmc-hldr') == -1) {
                if (b == 1) {
                    $("#curr-selection").find("li." + d).find(".applybutton").length <= 0 ? $("#curr-selection").find("li." + d).append(a.find(".applybutton").clone()) : null;
                    $("ul#mobile-learnmore").find("li." + d).find(".learnmorebutton").length <= 0 ? $("ul#mobile-learnmore").find("li." + d).append(a.find(".learnmorebutton").clone()) : null
                } else {
                    if (b == 0) {
                        $("#curr-selection").find("li." + d).find(".applybutton").remove();
                        $("#mobile-learnmore").find("li." + d).find(".learnmorebutton").remove()
                    } else if (OPEN.config.glb_vrbs.mb_over_open || b == undefined) {
                        $("#curr-selection").find("li." + d).find(".applybutton").remove().end().append(a.find(".applybutton").clone())
                        $("ul#mobile-learnmore").find("li." + d).find(".learnmorebutton").remove().end().append(a.find(".learnmorebutton").clone())
                    }
                }
            } else {
                $("#curr-selection").find("li." + d).find(".applybutton").remove();
                $("#mobile-learnmore").find("li." + d).find(".learnmorebutton").remove()
            }
        })
    },
    cardsToCampare: function() {
        Number($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr").size()) == 1 ? $(OPEN.config.ID._cmprCrds).find("li a" + OPEN.config.CLS._cls).hide() : $(OPEN.config.ID._cmprCrds).find("li a" + OPEN.config.CLS._cls).show();
    },
    scrollSec: function(d) {
        var c = $("#" + d.toLowerCase().split(" ").join("-"))[0].offsetTop - $(OPEN.config.ID._cmprCrds)[0].offsetHeight;
        $("html, body").animate({
            scrollTop: c
        }, function() {
            $(window).scroll();
            setTimeout(function() {
                OPEN.config.glb_vrbs._navFlag = false
            }, 600);
        })
    },
    /* Nov B 2015*/
    mobile_ovlmths: function() {
        $('.compare_cards').live('click', function(d) {
            OPEN.config.glb_vrbs.crd_cntr = 0;
            d.stopPropagation();
            $('.cards-list').removeClass('disabled');
            if ($('#cards-list-overlay ul.section li').not('.pmc-hldr').length < 2) {
                return false;
            } else {
                 OPEN.config.glb_vrbs.crd_tbrm=$(OPEN.config.ID.curr_selitem).attr('class');
                 OPEN.config.glb_vrbs.mbl_itr_cntr=0;
                $('#cards-list-overlay-wrap button.circle-close-icon').click();
                OPEN.config.glb_vrbs.mbl_cmp = true;
                d.preventDefault();
                OPEN.mobile_overlay.update_seccards();
                $(OPEN.config.glb_vrbs.avl_crdstry).each(function(i) {
                    OPEN.config.glb_vrbs.avl_crdstry[i] == $(OPEN.config.ID.curr_selitem).attr('class') && OPEN.config.glb_vrbs.avl_crdstry.splice(i, 1)
                })
                $('#cards-list-overlay-wrap button.circle-close-icon').click();
                $(OPEN.config.glb_vrbs.avl_crdstry).each(function(i) {
                    OPEN.config.glb_vrbs._crrCrd = $($("#curr-selection li.pmc-hldr")[0]);
                    $('.cards-list li' + "." + OPEN.config.glb_vrbs.avl_crdstry[i] + "-sml .small-card").click();                    
                })
                $(window).scrollTop() != 0 && $(window).scrollTop(0);
                OPEN.mobile_overlay.clear_comparetray();            }
        })
        $('.back-btn ').live('click', function(d) {
            d.preventDefault();
            $('.cards-list').removeClass('disabled');
            $('#cards-list-overlay-wrap button.circle-close-icon').click();
            $('.section li button.close-icon-compare-tray').hide();
            OPEN.mobile_overlay.clear_comparetray();
            return this;
        })
    },
    doc_wdth: function() {
        return document.body.clientWidth < 661;
    },
    
    updatedratings:function(){
        
      $('#curr-selection .viewallratings').each(function(){OPEN.config.glb_vrbs.ratings[$(this).parent().attr('class')]=$(this)})  
    }
	}