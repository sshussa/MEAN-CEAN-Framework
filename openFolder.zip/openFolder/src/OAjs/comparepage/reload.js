
OPEN.cmp_reld = {
comp_rdg: function() {

        if ((window.location.hash == "#loadfromcookie=true") && (document.cookie.indexOf("cardInfo") != -1) && $(eval("(" + OPEN.universal.readCookie("cardInfo") + ")").cards).length != 0) {
 $('[id^="landing-title"] li.pmc-hldr').length==0 && $('[id^="curr-selection"] li.pmc-hldr').length>0 && $('[id^="landing-title"]').append( $($('[id^="landing-title"] li')[0]).clone().removeClass().addClass('pmc-hldr').html('<h2></h2>').hide());            
            ($(eval("(" + OPEN.universal.readCookie("cardInfo") + ")").cards).each(function() {
                OPEN.config.glb_vrbs.cookie_arr.push(this.pmc)
            }), $("#container .compare-section#curr-selection li").not('li.pmc-hldr').each(function() {
                OPEN.config.glb_vrbs.tray_arr.push(this.className)
            }))
            OPEN.config.glb_vrbs.pag_load_flg=true;
            var tlen = OPEN.config.glb_vrbs.cookie_arr.length;
            var _htmltry = [];
            var _htmltry = $(OPEN.config.glb_vrbs.tray_arr).not(OPEN.config.glb_vrbs.cookie_arr).get();
            OPEN.config.glb_vrbs.ld_cke = 1; /* March B*/
            /* Difference in current html structure and Cookie is loaded in _htmltry and differed card is removed from tray. "closecardMet" is the new  resuable object created  */
            $.each(_htmltry, function(key, value) {

                OPEN.cmp_components.closecardMet(this, value, OPEN.config.glb_vrbs.ld_cke); /* March B*/                
            });

            OPEN.cmp_reld.upd_try(0);
            var cookie_arr_up = OPEN.config.glb_vrbs.cookie_arr.slice();
            var cki_dff = $(OPEN.config.glb_vrbs.cookie_arr).not(OPEN.config.glb_vrbs.tray_arr).get()
            $(cookie_arr_up).each(function(index) {
                cki_dff == cookie_arr_up[index] && cookie_arr_up.splice(index, 1)
            })
            var flg_shf = false;
            $(OPEN.config.glb_vrbs.tray_arr_up).each(function(indx1) {
                if (OPEN.config.glb_vrbs.tray_arr_up.length == 2) {
                    if (OPEN.config.glb_vrbs.tray_arr_up[indx1] != cookie_arr_up[indx1]) {
                         OPEN.cmp_reld.shuff_crd(cookie_arr_up[indx1], OPEN.config.glb_vrbs.tray_arr_up[indx1]);
                        OPEN.cmp_reld.upd_try(0);
                    }
                }

            })
            if (_htmltry.length == OPEN.config.glb_vrbs.tray_arr.length) {
                $(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:eq(0)").removeClass().addClass("pmc-hldr").find(".card-art").attr("href", " ").attr("title", "Add a Card").parent().parent().find("h2").html(" ");
                 $(OPEN.config.ID._cmprCrds).find('#curr-selection.compare-section li:eq(0)').removeClass().addClass("pmc-hldr").find(".card-art").attr("href", " ").attr("title", "Add a Card").parent().parent().find("h2").html(" ");
                 $(OPEN.config.ID._cmprCrds).find('#curr-selection.compare-section li:eq(0)').removeClass().addClass("pmc-hldr").find(".card-art").removeClass(function (index, css) {
                 return (css.match(/\bflat-\S+/g) || []).join(' ');
                 })
                $('.cards-btns li:eq(0)').attr("class", "").addClass("pmc-hldr");
                 $('#compare-cards .module-terms.compare-section').each(function(){$(this).find('li:eq(0)').attr("class", "").addClass("pmc-hldr")})
                
                
            }
            /* Enters into logic only when cookieCardData is filled, times we get it blank.*/                 
            if (typeof(cookieCardData) != "undefined") {
		
                if (cookieCardData != null  && Object.keys(cookieCardData).length != 0) {
                    /*For every card present in cookieCardDate varaible we are populating data on page. setJsondata is the new object created to populate value from ajax and json variable .*/                 
                      for (objc in cookieCardData) {
                        OPEN.config.glb_vrbs.card_rdr = false;
                        var pmc_obj = cookieCardData[objc].pmc;
                        
                        if ($("#curr-selection li").not('.pmc-hldr').length != 0) {
                            var curr_lst = $("#curr-selection li").not('.pmc-hldr');
                            var curr_pmcob, bfr_pmc, bfr_indx, bfr_pmctry = $('#curr-selection li:eq(' + curr_lst + ')').attr('class');

                            $.each(OPEN.config.glb_vrbs.cookie_arr, function(key, value) {
                                pmc_obj == value && (curr_pmcob = key);
                                bfr_pmctry = $("#curr-selection li").not('.pmc-hldr')[curr_pmcob];
                            });

                            if (curr_pmcob != 2 && curr_pmcob != curr_lst.length) {
                                curr_lst.attr("class").indexOf(OPEN.config.glb_vrbs.cookie_arr[curr_pmcob + 1]) != OPEN.config.glb_vrbs.cookie_arr.indexOf(OPEN.config.glb_vrbs.cookie_arr[curr_pmcob + 1]) && (OPEN.config.glb_vrbs.card_rdr = true, OPEN.config.glb_vrbs.bfr_crd = $($("#curr-selection li").not('.pmc-hldr')[curr_pmcob]).attr("class"))


                            }

                        }

                        var pmc_hldr = $('.compare-section#curr-selection li.pmc-hldr:eq(0)');
                        var r = "pmc-" + (cookieCardData[objc].pmc).split("-")[1];
						var i1 = $('.small-card').parent('li.' + (pmc_obj) + '-sml').find("a").attr("title");
                        pmc_hldr.find("a.card-art").attr("title", i1).attr('id','pmc-'+(cookieCardData[objc].pmc).split("-")[1]+"-card");
                     $('.compare-section#curr-selection li.pmc-hldr  .card-art').removeClass(function(index, css) {
		             	return (css.match(/\bflat-\S+/g) || []).join(' ');		});                         
                      $('.compare-section#curr-selection li.pmc-hldr:eq(0)  .card-art').addClass('flat-cardart-'+(cookieCardData[objc].pmc).split("-")[1]);
                      
                        var s=pmc_hldr.removeClass().addClass(r).css("visibility", "visible").find("h2").html($('.small-card').parent('li.' + (pmc_obj) + '-sml').find('a').html()).show();
                        pmc_hldr.removeClass().addClass(r).css("visibility", "visible").find("h2").html(s.html());
                    
                        $(OPEN.config.CLS._cardBtns).find(".pmc-hldr:first").removeClass().addClass(r).css("visibility", "visible");
                    
                        tlen != 1 && $(OPEN.config.ID._cmprCrds).find(".pmc-hldr").removeAttr("style").parent().find(OPEN.config.CLS._cls).first().removeAttr("style");
                        $('.compare-section#curr-selection li.' + pmc_obj + " .card-art").attr("href", cookieCardData[objc].LearnMoreURL);
						$(".cards-btns ." + pmc_obj + " .applybutton").html(cookieCardData[objc].ApplyNowURL);
                        $(".cards-btns ." + pmc_obj + " .learn-more").attr("href", cookieCardData[objc].LearnMoreURL).attr("title", "Lean More on " + i1);
                        $(".cards-btns ." + pmc_obj + " .learn-more span").html("on " + cookieCardData[objc].productname.replace(/"/g, ''));                        
                        if (OPEN.config.glb_vrbs.card_rdr != false) {
                            var cmp_trytmp = $('.compare-section#curr-selection li.' + pmc_obj);
                            $('.compare-section#curr-selection li.' + pmc_obj).remove();
                            $(cmp_trytmp).insertBefore($('#curr-selection li.' + OPEN.config.glb_vrbs.bfr_crd));
                            var cmp_btntmp = $(OPEN.config.CLS._cardBtns).find('li.' + pmc_obj);
                            $(OPEN.config.CLS._cardBtns).find('li.' + pmc_obj).remove();
                            $(cmp_btntmp).insertBefore($(OPEN.config.CLS._cardBtns).find('li.' + OPEN.config.glb_vrbs.bfr_crd));
                        }
                     
                        $(window).width() < 660 && OPEN.comp_pagecomponent.setApplyBtn(1);
                         OPEN.cmp_components.setJsondata(cookieCardData[objc].pmc, cookieCardData, cookieCardData[objc].pmc.replace("-", "_"),OPEN.config.glb_vrbs.bfr_crd);
                      
                    }

                } else { /*Shuffles card as per cookies order when all cards are related to current predefined bucket*/

                    if (Object.keys(cookieCardData).length == 0 && OPEN.config.glb_vrbs.cookie_arr.length != 1) {
                        for (i = 0; i < OPEN.config.glb_vrbs.tray_arr.length; i++) {
                            var flg_shf = false;
                            if (OPEN.config.glb_vrbs.tray_arr[i] != OPEN.config.glb_vrbs.cookie_arr[i]) {
                                if (OPEN.config.glb_vrbs.cookie_arr.length == 3) {
                                    $(OPEN.config.glb_vrbs.cookie_arr).each(function(indx) {
                                        (OPEN.config.glb_vrbs.cookie_arr[indx] == OPEN.config.glb_vrbs.tray_arr[i] && !flg_shf) && ( OPEN.cmp_reld.shuff_crd(OPEN.config.glb_vrbs.cookie_arr[indx - 1], OPEN.config.glb_vrbs.tray_arr[i]), flg_shf = true, OPEN.cmp_reld.upd_try(1), (OPEN.config.glb_vrbs.tray_arr[i] != OPEN.config.glb_vrbs.cookie_arr[i] && (i--)));
                                    })
                                } else if (OPEN.config.glb_vrbs.cookie_arr.length == 2) {
                                    $(OPEN.config.glb_vrbs.cookie_arr).each(function(indx_2) {

                                        (OPEN.config.glb_vrbs.cookie_arr[indx_2] != OPEN.config.glb_vrbs.tray_arr[indx_2]) && ( OPEN.cmp_reld.shuff_crd(OPEN.config.glb_vrbs.cookie_arr[0], OPEN.config.glb_vrbs.cookie_arr[1]), OPEN.cmp_reld.upd_try(1));
                                    })
                                }
                            }

                        }


                    }

                  OPEN.cmp_components.cooke_creation();                
                

                }
            }
            /* March B */
        
            $('#compare-cards .cards-header h2,#compare-cards .cards-header p').hide();
            $('#compare-cards .cards-header h1').html("Compare Cards");
        
            OPEN.comp_pagecomponent.getAvlCrds($(OPEN.config.ID._cmprCrds).find(OPEN.config.CLS._comprSec + " li:visible").not(".pmc-hldr"));
            OPEN.cmp_components.cooke_creation();
            $('#compare-cards #curr-selection li:visible').length == 2 && $('#compare-cards #curr-selection li:eq(0)').find('.close-icon-compare-tray').hide();


            $('#mobile-learnmore li').removeAttr("class");
            $('.cards-btns li').not('.pmc-hldr').find('.learnmorebutton a').each(function(key) {
                $($('#mobile-learnmore li')[key]).addClass($(this).parent().parent().parent().attr("Class")),
                    $($('#mobile-learnmore li')[key]).html(""), $($('#mobile-learnmore li')[key]).html($($('.cards-btns li span.learnmorebutton')[key]).clone())

            });
            $("#curr-selection li").not(".pmc-hldr").length > 1 && $("#curr-selection li:eq(0) .close-icon-compare-tray").show(); /*JAN B*/
            ($("#curr-selection li").not(".pmc-hldr").length == 2 && $(window).width() < 661) && $('#mobile-learnmore li:eq(1)').show(); /*March B*/
            $('#loading_msk').remove();
            OPEN.config.glb_vrbs.card_rdr = false;
            OPEN.config.glb_vrbs.ld_cke = 0; /* March B*/

        } else {            
         
            $('#loading_msk').remove();
        }
        
        $(".card-art").removeClass("halfcard-image");        
    },

		upd_try:function(ar1){
			      ar1==1? OPEN.config.glb_vrbs.tray_arr=[] :OPEN.config.glb_vrbs.tray_arr_up=[];
            $("#container .compare-section#curr-selection li").not('li.pmc-hldr').each(function() {
              ar1==1 ?(OPEN.config.glb_vrbs.tray_arr.push(this.className)):( OPEN.config.glb_vrbs.tray_arr_up.push(this.className))
            })
			},	
          shuff_crd:function(ck_bfr, try_pm){
			     var cry_shf = $('#curr-selection li.' + try_pm);
            var btn_shf = $('.cards-btns li.' + try_pm);
            var curr_sfh = $('#cards-content div[class*="module-"] .' + try_pm)
            cry_shf.remove();
            btn_shf.remove();
            curr_sfh.remove();
            cry_shf.insertAfter('#curr-selection li.' + ck_bfr);
            btn_shf.insertAfter('.cards-btns li.' + ck_bfr);
            curr_sfh.each(function(key, value) {
                $(curr_sfh[key]).insertAfter($('#cards-content div[class*=module] li[class*=' + ck_bfr + '] ')[key]);
            })
            flg_shf = false;
			  },
			     curr_selec: function(chk_flg) {
        $("#curr-selection li:last").addClass("last-item");
        $(".cards-btns li:last").addClass("last-item")
        if (chk_flg) {
            $("#curr-selection li:last").addClass("last-item");
            $(".cards-btns li:last").addClass("last-item");
            $('#cards-content ul li[class^="pmc-"]').each(function() {
                $(this).index() == 2 && $(this).css('display','none');
            })

        } else {
            $("#curr-selection li:last").removeClass("last-item");
            $(".cards-btns li:last").removeClass("last-item");
            $('#cards-content ul li[class^="pmc-"]').each(function() {
                $(this).index() == 2 && $(this).removeAttr('style');
            })
        }
    }
	}