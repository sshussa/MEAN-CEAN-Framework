OPEN.homePage.viewall = {
    crds: [],
    crdWidth: ".crd-slides",
    crdspc: "",
    crdsFlg: true,
    speedAct: true,
    mincrsl: '.module2 .min-nav',
    //modified as part of sept14 release.
    tme: 0,
    minWdt: 0,
    maxWdt: 0,
    pos_1: "",
    pos_2: "",
    pos_5: "",
    pos_3: "",
    pos_4: "",
    pos_6: "",
    isl: false,
    sec_mdlnav: $(".module2 .min-nav"),
    sec_mdlnavlk: $(".module2 .min-nav a"),
    isr: false,
    viewAllObj: null,
    viewAllOnce: true,
    slide_flg: false,
    def_arr: [".crd-1", ".crd-2", ".crd-3", ".crd-4"],
	cirArr: [],
	dspCrds:0,
    new_vacvar: '',
    minNavFlg: false,
	mvt_card:6,
    chargecardcount:3,
    creditcardcount:3,
    //added as part of sept14 release.
    mblFlg: false,
    genCrds: function(type, obj, cnt) {   
        cnt && $.ajax({
            type: 'GET',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            url: (typeof(ViewAllUrl) == 'undefined' ? (window.location.href.search("home_PZN.html") != -1 ? "../../json/viewall_PZN.json" : "../../json/viewall.json") : (ViewAllUrl)),
            cache: false,
            async: false,
            success: function(json) {
                allCrds = json;
            },
            error: function(e) {
                console.log("error to fetch JSON");
            }
        });
        if (typeof(allCrds) != 'undefined') {
		 var mvt_crdcnt=3;
                
                   if(typeof(this.chargecardcount) !="undefined" && type.split(' ').join("") =="chargecards" ){    
                      mvt_crdcnt=this.chargecardcount          
                  }else if( typeof(this.creditcardcount) !="undefined" && type.split(' ').join("") =="creditcards"  ){    
                      mvt_crdcnt=this.creditcardcount           
                  }
          
            var cndDsp = "", 
            crds_dsp = [],
			mvt_crds=allCrds.Products,
			arws = $("#hp-vac,.content-wrapper>.crd-details"),
			mvt = {newvac:"MVT",novactab:"allcard",init:"BAU"},
			cls = $("body").attr('class').match(/newvac|novactab/g) || ['init'];
			cndDsp = mvt[cls[0]];
			var crds = allCrds[(cndDsp == mvt.init?mvt.init:mvt.newvac) + "_order"][0][(cndDsp == mvt.novactab?cndDsp:type.split(' ').join("")) + "order"];			
			(cndDsp =="allcard") ? allCrds.MVT_order[0]["allcardcount"]!=null && typeof(allCrds.MVT_order[0]["allcardcount"]) !="undefined" && (crds=this.updatemvtarry(crds,allCrds.MVT_order[0]["allcardcount"])):(cndDsp=="MVT" && (crds=this.updatemvtarry(crds,mvt_crdcnt)))
			$(window).width() > 660 && crds.length == this.def_arr.length-1 && arws.hide();         
		for (var crd in allCrds.Products) {
                        var crdItm = crds.indexOf(parseInt(allCrds.Products[crd].pmc));
                        !!~crdItm && (crds_dsp[crdItm] = allCrds.Products[crd]);
				
                }

            var crdNum = 0,
                rating = '',
                rV = '',
                ratingLinkAnchor = '';
            $(".hp-view-all .crd-slides").html('');
			OPEN.homePage.viewall.dspCrds = crds_dsp.length;
            var newvac = this.new_vac;
			OPEN.homePage.viewall.cirArr = [];
            crds_dsp && $.each(crds_dsp, function() {
                var offer = newvac ? "<div class='offer-wrapper'><div class='custom-scrollbar'><div class='scrollbar'><div class='track'><div class='thumb'></div></div></div><div class='viewport'>" + this.offerContent + "</div></div></div>" : '';
                var img_src = $("body").hasClass("ieall") ?  this.fileName : (this.fileName).replace("/normal", "/retina"); /*JulyA*/
                img_src = newvac ? img_src.replace(new RegExp("angled", 'g'), "flat") : img_src;
                img_src = img_src + "#resource_version";
                crdNum = parseInt(crdNum) + 1;
                rating = (this.rating == 'rating-0') ? 'addreviewratings' : this.rating;
                rV = (this.ratingValue == '0') ? 'Add Review' : '(' + this.ratingValue + ')';
                ratingLinkAnchor = (this.ratingValue == '0') ? ("<a title='' href='" + this.ratingLink + "' target='_new'>") : ("<a title='' href='" + this.ratingLink + "'>")
                if (rating === '0') {
                    rating = 'rating-00';
                }
				OPEN.homePage.viewall.cirArr.push(".crd-"+parseInt(crdNum));
                $(".hp-view-all .crd-slides").append("<div class='card crd-" + (parseInt(crdNum)) + "'><a href='" + this.learnMoreLink + "' title='Apply For " + this.title.replace("<sup class='reg'>&#174;</sup>", "&reg;").replace('<br/>', '') + "' class='cardartclick'><div class='img-wrap'><img title='" + this.title.replace("<sup class='reg'>&#174;</sup>", "&reg;").replace('<br/>', '') + "' alt='" + this.title.replace("<sup class='reg'>&#174;</sup>", "&reg;").replace('<br/>', '') + "' src='" + img_src + "' /></div></a><div class='crd-name'>" + (newvac?this.title.replace('<br/>', ''):this.title) + "</div>" +
                    offer + "<div class='crd-details'><div class='viewallratings'>" + ratingLinkAnchor + "<span class='rating-holder " + rating + "' id='pmc-" + this.pmc + "-rating-review'></span></a><strong class='add-review splofr-addreview'>" + ratingLinkAnchor + "" + rV + "</a></strong> </div>" + (newvac && (!$("body").hasClass("novacapply")) ? "<div class='annual-fee-content'>" + this.annualFeeContent + "</div>" : "") +    
                    (newvac ? this.terms : "") + "<span class='list-views-btns button-holder'><a class='learnbutton btn primary' title='Click here to learn more about " + this.title.replace("<sup class='reg'>&#174;</sup>", "&reg;").replace('<br/>', '') + "' href='" + this.learnMoreLink + "'><span class='learn-btn btn blue-btn'>Learn More</span></a>" + (newvac && (!$("body").hasClass("novacapply")) ? '<button class="apply-button" value="Apply" title="Apply For '+ this.title.replace("<sup class='reg'>&#174;</sup>", "&reg;").replace('<br/>', '') +'" onclick="return applyForBusinessCard(' +"'"+ this.applyLink +"'" +','+"'pmc-"+this.pmc+"'"+','+"'"+(typeof(this.flow) !='undefined' ? this.flow.toUpperCase() : "")+"'"+')">Apply</button>' : "") + "</span>" +
                    "</div></div>");
            });

            this.viewAllCrds(obj);
            $("#cards-offer .card").length == 3 ? ($('#module-02').addClass('crdcln'),$("#cards-offer").append($("#cards-offer .card:eq(0)").clone().removeClass('crd-1 firstCard').addClass('crd-4').hide()), this.slide_flg = true) :($('#module-02').removeClass('crdcln'), this.slide_flg = false);
        }

        $(window).width() > 660 && ($('.offer-wrapper').addClass('enablescroll').removeClass('disablescroll'), touch ? $("#module-02 .offer-wrapper .custom-scrollbar").addClass('touch-scrollbar') : ($('#module-02 .offer-wrapper .scrollbar+ .viewport>div').addClass('overview'), $("#module-02 .offer-wrapper").openScrollber({
            wheelSpeed: 10,
            wheelLock: false
        })));
        $(window).width() > 660 ? ($(window).width() >= 831 && $('.offer-wrapper').addClass('highres')) : $('.offer-wrapper').removeClass('highres');
        OPEN.homePage.common.mdlfooter = $(".newvac .module2 .crd-details");
    },
    respCrds: function(width, init) {

        if (width < 831) {
            width <= 660 ? (this.responsive(1, 1, 0.84, init), $(this.mincrsl).hide(), $("#left,#right").show()) : (this.responsive(this.new_vac ? 0.291 : 0.38, this.new_vac ? 0.291 : 0.47, this.new_vac ? 0.89 : 0.87, init), $(this.mincrsl).show(), $(".module2 #left,.module2 #right").hide()); /*aprial a*/
        } else {
            this.responsive(this.new_vac ? 0.315 : 0.37, this.new_vac ? 0.315 : 0.43, this.new_vac ? 0.89 : 0.72, init);
            $(this.mincrsl).hide();
            $(".module2 #left,.module2 #right").show();
        }
        $(this.mincrsl).is(":hidden") ? ($(this.crds[0]).find('.crd-name').css('opacity', 1), $(this.crds[2]).find('.crd-name').css('opacity', 1)) : ($(this.crds[0]).find('.crd-name').css('opacity', 0), $(this.crds[2]).find('.crd-name').css('opacity', 0)); /* April A*/
        //if(this.isr) return false;
        this.middleCardalign();
        return this;
    },
    responsive: function(minW, maxW, cntW, init) {
        isMob = $("body").hasClass("res_Small");
        cntW = ($(".hp-view-all").parent().width()) * cntW;
        isMob && (cntW > 283 && (cntW = 283))
        $(".hp-view-all").width(cntW);
        this.minWdt = minW * cntW;
        this.maxWdt = maxW * cntW;
        imgRtShdw = 0.092;
        if ($(window).width() >= 831) {
            !this.new_vac && this.minWdt > 320 && (this.minWdt = 320);
            !this.new_vac && this.maxWdt > 380 && (this.maxWdt = 380);
            mdcardWdt = (this.maxWdt * 1.05) > 380 ? 380 : this.new_vac ? this.maxWdt : this.maxWdt * 1.05;
        } else if ($(window).width() > 660) {
            this.minWdt > 229 && (this.minWdt = 229);
            this.maxWdt > (this.new_vac ? 229 : 280) && (this.maxWdt = (this.new_vac ? 229 : 280));
            mdcardWdt = (this.maxWdt * 0.96) > 269 ? 269 : this.maxWdt * 0.96;
        }
        var crd1 = isMob ? -this.maxWdt : (this.new_vac ? -(this.minWdt * 0.160) : -7);
        var crd2 = isMob ? (cntW / 2) - (this.maxWdt / 2) : this.new_vac ? (this.minWdt) + ((this.minWdt * 0.1) - (this.minWdt * 0.160)) : (this.minWdt - (this.minWdt * imgRtShdw)) * (this.new_vac ? 0.98 : 0.84) + crd1 + 4;
        var crd3 = isMob ? cntW : this.new_vac ? (crd2 + mdcardWdt + ((this.minWdt * 0.1))) : (crd2+mdcardWdt-(mdcardWdt*imgRtShdw)+4-15);
        if ($(window).width() < 831 && $(window).width() > 660 && this.new_vac) {
            var crd1 = isMob ? -this.maxWdt : (this.new_vac ? 0 : -7);
            var crd2 = isMob ? (cntW / 2) - (this.maxWdt / 2) : this.new_vac ? (this.minWdt) + ((this.minWdt * 0.24) - (this.minWdt * 0.02)) : (this.minWdt - (this.minWdt * imgRtShdw)) * (this.new_vac ? 0.98 : 0.84) + crd1 + 4;
            var crd3 = isMob ? cntW : this.new_vac ? (crd2 + mdcardWdt + (this.minWdt * 0.28) - (this.minWdt * 0.02)) : (crd2 + mdcardWdt - ((mdcardWdt * imgRtShdw) + (this.new_vac ? 0 : 4 - 15)));
        }
        var crdT = isMob ? 0 : this.new_vac ? 0 : -25;
        this.pos_6 = crdT;
        $(this.crds[0]).css({
            width: this.minWdt,
            left: crd1
        });
        this.pos_4 = crd1
        $(this.crds[1]).css({
            width: this.maxWdt,
            left: crd2,
            top: crdT
        });
        this.pos_3 = crd2;
        $(this.crds[2]).css({
            width: this.minWdt,
            left: crd3
        });
        this.pos_2 = crd3;
        this.pos_5 = cntW;
        this.pos_1 = -this.minWdt;
        $(".crd-slides .card").not(".firstCard,.middleCard,.lastCard").css({
            width: this.minWdt,
            left: cntW
        });
        !isMob ? (mdLtShdw = (0.2 * mdcardWdt) - 16) : (mdLtShdw = 0);
        !this.new_vac && ($(window).width() >= 831 ? $(".middleCard .crd-name,.middleCard .crd-details").css({
            "margin-left": mdLtShdw
        }) : $(".middleCard .crd-name,.middleCard .crd-details").css({
            "margin-left": "auto"
        }));

			var crd1 = $(".firstCard"),
            crd2 = $(".middleCard"),
            crd3 = $(".lastCard");
			if(this.new_vac)
			{
			
			crd2.css({
                'overflow': 'hidden',
                'z-index': $(window).width() >= 661?'2':'auto'
            });
            crd3.css({
                'z-index': $(window).width() >= 661?'3':'auto'
            });
            crd1.css({
                'z-index': $(window).width() >= 661?'1':'auto'
            });
			}

    },
    viewAllCrds: function(view) {
        var _this = this;
        this.crdspc = view;
        var images = $(this.crdWidth + " div.card");
        this.sec_mdlnav.html('');

        for (var g = 1; g <= $(this.crdWidth + " div.card").size(); g++) {
            var sctr = this.mincrsl;
            $(sctr).append("<a class='nav-" + g + "' href='#'>" + g + "</a>");
            $(sctr + " a").removeClass("active");
        }
        _this.new_vac ? $(sctr + " a:first").addClass("active") : $(sctr + " a:first").next().addClass("active");
        this.crdsFlg && $(".module2 .min-nav a").live("click", function(e) {
            //added in order to manipulate the order at mobile break point as part of sept14 release.
            _this.tme = 500;
            if (_this.speedAct) {
                var prvInd = parseInt($(".min-nav a.active").index()) + 1;
                var crrInd = parseInt($(this).index() + 1);
                $(".module2 .min-nav a").removeClass("active");
                var cnt = Math.abs(crrInd - prvInd);

                cnt > 1 ? (OPEN.homePage.viewall.minNavFlg = true) : (OPEN.homePage.viewall.minNavFlg = false);

                if (prvInd < crrInd) {
                    var num = crrInd - prvInd;
                    for (var i = 0; i < num; i++) {
                        _this.speedAct = true;
                        $(".module2 #right").delay(_this.tme).queue(function(next) {
                            $(this).trigger('click');
                            next();
                        });
                    }
                } else {
                    if (prvInd != crrInd) {
                        var num = prvInd - crrInd;
                        for (var i = 0; i < num; i++) {
                            _this.speedAct = true;
                            $(".module2 #left").delay(_this.tme).queue(function(prev) {
                                $(this).trigger('click');
                                prev();
                            });
                        }
                    }
                }
                $(this).addClass("active");
            }
            return false;
        });
        images.width(this.minWdt);
        !new_vacvar && $(".crd-slides .crd-details").css('opacity', 0).hide();
        $(".crd-slides .crd-name").css('opacity', $(this.mincrsl).is(":hidden") ? 1 : 0);
        var cnt = 3;
        $(this.crdspc).data("crds", cnt);
        $(".module2 .crd-1").css({
            left: this.pos_4,
            width: this.minWdt,
            top: 0
        });
        this.crds[0] = ".crd-1";
        $(".module2 .crd-2").css({
            left: this.pos_3,
            width: this.maxWdt,
            top: this.pos_6
        }).find(".crd-details").css('opacity', 1).show(); /*JuneA*/
        $(this.mincrsl).is(":visible") && $(".module2 .crd-2").find(".crd-name").css('opacity', 1);
        this.crds[1] = ".crd-2";
        $(".module2 .crd-3").css({
            left: this.pos_2,
            width: this.minWdt,
            top: 0
        });
        this.crds[2] = ".crd-3";
        var lfNav = false;
        $(this.crdspc).data("flag", lfNav);
        $(this.crds[0]).addClass('firstCard');
        $(this.crds[1]).addClass('middleCard');
        $(this.crds[2]).addClass('lastCard');

        _this.middleCardalign();

        this.crdsFlg && $(".module2 #left").click(function(e, mblPop) {
            //added in order to manipulate the order at mobile break point as part of sept14 release.
            mblPop ? (_this.tme = 0) : (_this.tme = 500);
            $(window).width() >= 660 && (OPEN.homePage.viewall.minNavFlg = false);
            _this.isl = false;
            if (_this.isr) return false;
            _this.isr = true;
            setTimeout(function() {
                _this.isr = false
            }, _this.tme);
            //var leftCarousel=$(this).text();								
            (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'left_hpvacCarousel'): null; // FEB release						
            $('.crd-slides ' + _this.crds[0]).find(".crd-details").show();
            $(".middleCard").css({
                'overflow': 'hidden'
            });
            images = $(_this.crdWidth + " div.card");
            if (_this.speedAct) {
                $(".module2 .min-nav").is(":hidden") && (_this.speedAct = false);
                cnt = parseInt($(_this.crdspc).data("crds"));
                lfNav = $(_this.crdspc).data("flag");
                cnt == 0 && (cnt = images.size());
                lfNav && (cnt = parseInt(cnt) - 1);
                if (!lfNav) {
                    cnt <= 3 ? (cnt = images.size() - (3 - cnt)) : cnt = parseInt(cnt) - 3;
                }
                if (_this.slide_flg) {
                    var slid_chg = parseInt($(_this.def_arr).not(OPEN.homePage.viewall.crds)[0].split("-")[1]);
                    var nxt_sld = parseInt(slid_chg) - 1;
                    slid_chg == 1 && (nxt_sld = images.size());
                    $("#cards-offer .card.crd-" + slid_chg).html($("#cards-offer .card.crd-" + nxt_sld).html());
                    !new_vacvar && $("#cards-offer .card.crd-" + slid_chg).find('.crd-details').hide();
                }
                _this.navigation.rvrsLeft(".crd-" + cnt);
                cnt == 1 && (cnt = images.size() + 1);
                lfNav = true;
                $(_this.crdspc).data("crds", cnt);
                $(_this.crdspc).data("flag", lfNav);
            }
            setTimeout(function() {
                _this.avoidRating()
            }, 0);
			var nms = OPEN.homePage.viewall; 
                  var mincrs_notab=OPEN.homePage.viewall.cirArr.slice();
    		nms.cirArr.unshift(nms.cirArr.pop());  
            var tmr= _this.page_resize?1000:0;        
			var minCnt = nms.dspCrds == nms.cirArr.length?nms.cirArr:_this.crds;
            //added condition in order to manipulate the order at mobile break point as part of sept14 release.
                !OPEN.homePage.viewall.minNavFlg && $(".module2 .min-nav a").removeClass("active");                
                if( $("body").hasClass("newvac") && $("body").hasClass("novactab")){
                       setTimeout(function(){  
                 if($('body').hasClass('res_Small'))
                   {
                 !OPEN.homePage.viewall.minNavFlg && $(".module2 .min-nav a.nav-" +  mincrs_notab[0].split('-')[1]).addClass("active");
                   }
                   else{
                  !OPEN.homePage.viewall.minNavFlg  && $(".module2 .min-nav a.nav-" + minCnt[0].split('-')[1]).addClass("active");
                   }
                       },tmr);
                }
                else{
                 !OPEN.homePage.viewall.minNavFlg && $(".module2 .min-nav a.nav-" + minCnt[1].split('-')[1]).addClass("active");
                }
            //_this.middleCardalign().respCrds($(window).width(),true);
			
            _this.middleCardalign();

            return false;
        });

        this.crdsFlg && $(".module2 #right").click(function(e,mblPop) {
            mblPop ? (_this.tme = 0) : (_this.tme = 500);
            $(window).width() >= 660 && (OPEN.homePage.viewall.minNavFlg = false);
            _this.isl = false;
            if (_this.isr) return false;
            _this.isr = true;
            setTimeout(function() {
                _this.isr = false
            }, _this.tme);
            //var rightCarousel=$(this).text();					
            (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'right_hpvacCarousel'): null; // FEB release					

            $('.crd-slides ' + _this.crds[2]).find(".crd-details").show();
            images = $(_this.crdWidth + " div.card");
            if (_this.speedAct) {
                $(".module2 .min-nav").is(":hidden") && (_this.speedAct = false);
                cnt = parseInt($(_this.crdspc).data("crds"));
                lfNav = $(_this.crdspc).data("flag");

                if (lfNav) {
                    if (cnt >= images.size() - 3) {
                        cnt = (cnt + 3) - images.size();
                        cnt == 0 && (cnt = images.size());
                    } else {
                        cnt = (parseInt(_this.crds[2].split('-')[1]) + 1);
                    }
                } else {
                    cnt = parseInt(cnt) + 1;

                }


                if (_this.slide_flg) {
                    var slid_chg = parseInt($(_this.def_arr).not(OPEN.homePage.viewall.crds)[0].split("-")[1]);
                    var nxt_sld = parseInt(slid_chg) + 1;
                    slid_chg == 4 && (nxt_sld = 1);
                    

                    $("#cards-offer .card.crd-" + slid_chg).html($("#cards-offer .card.crd-" + nxt_sld).html()).find('.crd-details').hide()
                }
                _this.navigation.right(".crd-" + parseInt(cnt));
                cnt == images.size() && (cnt = 0);
                lfNav = false;
                $(_this.crdspc).data("flag", lfNav);
                $(_this.crdspc).data("crds", cnt);
            }

            setTimeout(function() {
                _this.avoidRating()
            }, _this.tme + 250);
			var nms = OPEN.homePage.viewall;
    		nms.cirArr.push(nms.cirArr.shift());
			 //added condition in order to manipulate the order at mobile break point as part of sept14 release.
			var minCnt = nms.dspCrds==nms.cirArr.length?nms.cirArr:_this.crds;
            var tmr= _this.page_resize?1000:0;
           !OPEN.homePage.viewall.minNavFlg && $(".module2 .min-nav a").removeClass("active");
                 if( $("body").hasClass("newvac") && $("body").hasClass("novactab")){ 
                 setTimeout(function(){                       
                   if($('body').hasClass('res_Small'))
                   {
               !OPEN.homePage.viewall.minNavFlg && $(".module2 .min-nav a.nav-" + minCnt[1].split('-')[1]).addClass("active");
                   }
                   else{                       
                 !OPEN.homePage.viewall.minNavFlg  && $(".module2 .min-nav a.nav-" + minCnt[0].split('-')[1]).addClass("active")                       
                   }
                
                },tmr);
                 }
                else{            
             !OPEN.homePage.viewall.minNavFlg &&  $(".module2 .min-nav a.nav-" +  minCnt[1].split('-')[1]).addClass("active");
                      }
                 //_this.middleCardalign().respCrds($(window).width(),true);	
			
            _this.middleCardalign();
            return false;
        });
        this.crdsFlg = false;

    },

    avoidRating: function() {
        !new_vacvar && $('.crd-slides ' + this.crds[0] + ',.crd-slides ' + this.crds[2]).find(".crd-details").hide();
        $('.crd-slides ' + this.crds[1]).find(".crd-details").show();
    },
    navigation: {
        right: function(crd1) {
            var _this = OPEN.homePage.viewall;
            this.left();
            $(crd1).css({
                width: _this.minWdt,
                left: _this.pos_5,
                display: 'block'
            }).animate({
                width: _this.minWdt,
                left: _this.pos_2
            }, _this.tme, "linear", function() {
                _this.speedAct = true;
            }); /*JuneA*/
            $(".min-nav").is(":visible") && crd1 ? $(crd1).find('.crd-name').animate({
                opacity: 0
            }, _this.tme) : $(crd1).find('.crd-name').css('opacity', 1); /* April A */
            _this.crds[2] = crd1;
            $(_this.crds[2]).addClass('lastCard');

        },
        left: function() {
            var _this = OPEN.homePage.viewall;
            $('.lastCard').removeClass('lastCard');
            $('.middleCard').removeClass('middleCard');
            $('.firstCard').removeClass('firstCard');
            _this.crds[0] && $(_this.crds[0]).animate({
                left: _this.pos_1,
                width: _this.minWdt,
                top: 0
            }, _this.tme, "linear", function() {
                $(this).css({
                    left: _this.pos_5
                });
            }); /*JuneA*/
            _this.crds[0] = null;
            _this.crds[1] && $(_this.crds[1]).animate({
                left: _this.pos_4,
                width: _this.minWdt,
                top: 0
            }, _this.tme, "linear"); /*JuneA*/
            !new_vacvar && _this.crds[1] && $(_this.crds[1]).find(".crd-details").animate({
                opacity: 0
            }, _this.tme);
            $(".min-nav").is(":visible") && _this.crds[1] && $(_this.crds[1]).find('.crd-name').animate({
                opacity: 0
            }, _this.tme);
            _this.crds[0] = _this.crds[1];
            $(_this.crds[0]).addClass('firstCard');
            _this.crds[2] && $(_this.crds[2]).animate({
                left: _this.pos_3,
                width: _this.maxWdt,
                top: _this.pos_6
            }, _this.tme, "linear").find(".crd-details").animate({
                opacity: 1
            }, _this.tme); /*JuneA*/
            $(".min-nav").is(":visible") && _this.crds[2] ? $(_this.crds[2]).find('.crd-name').animate({
                opacity: 1
            }, _this.tme) : $(_this.crds[2]).find('.crd-name').css('opacity', 1);
            _this.crds[1] = _this.crds[2];
            $(_this.crds[1]).addClass('middleCard');
            _this.crds[2] = null;


        },
        rvrsRight: function() {
            _this = OPEN.homePage.viewall;
            $('.lastCard').removeClass('lastCard');
            $('.middleCard').removeClass('middleCard');
            $('.firstCard').removeClass('firstCard');
            _this.crds[0] && $(_this.crds[0]).animate({
                left: _this.pos_3,
                width: _this.maxWdt,
                top: _this.pos_6
            }, _this.tme, "linear").find(".crd-details").animate({
                opacity: 1
            }, _this.tme); /*JuneA*/
            $(".min-nav").is(":visible") && _this.crds[0] ? $(_this.crds[0]).find('.crd-name').animate({
                opacity: 1
            }, _this.tme) : $(_this.crds[0]).find('.crd-name').css('opacity', 1);;
            _this.crds[1] && $(_this.crds[1]).animate({
                left: _this.pos_2,
                width: _this.minWdt,
                top: 0
            }, _this.tme, "linear") /*JuneA*/
			!new_vacvar && _this.crds[1] && $(_this.crds[1]).find(".crd-details").animate({
                opacity: 0
            }, _this.tme);
            $(".min-nav").is(":visible") && _this.crds[1] && $(_this.crds[1]).find('.crd-name').animate({
                opacity: 0
            }, _this.tme);
            _this.crds[2] && $(_this.crds[2]).animate({
                left: _this.pos_5,
                width: _this.minWdt,
                top: 0
            }, _this.tme - 100, "linear"); /*JuneA*/
            _this.crds[2] = _this.crds[1];
            _this.crds[1] = _this.crds[0];
            _this.crds[0] = null;
            $(_this.crds[2]).addClass('lastCard');
            $(_this.crds[1]).addClass('middleCard');

        },
        rvrsLeft: function(crd1) {
            _this = OPEN.homePage.viewall;
            this.rvrsRight();
            _this.slide_flg && $(crd1).show();
            $(crd1).css({
                width: _this.minWdt,
                left: _this.pos_1
            }).animate({
                left: _this.pos_4
            }, _this.tme, "linear", function() {
                _this.speedAct = true;
            }); /*JuneA*/
            $(".min-nav").is(":visible") && crd1 ? $(crd1).find('.crd-name').animate({
                opacity: 0
            }, _this.tme) : $(crd1).find('.crd-name').css('opacity', 1); /* April A */
            _this.crds[0] = crd1;
            $(_this.crds[0]).addClass('firstCard');
        }
    },
    middleCardalign: function() {
        var middleImg = $(".middleCard a.cardartclick img"),
            crd1 = $(".firstCard"),
            crd2 = $(".middleCard"),
            crd3 = $(".lastCard"),
            img1n3 = $(".firstCard a.cardartclick img,.lastCard a.cardartclick img");
        if (typeof mdcardWdt != "undefined") {
            if (!this.isl) {
                $(window).width() < 831 ? ($(window).width() > 660 ? middleImg.animate({
                    'width': this.new_vac ? '100%' : mdcardWdt,
                    'margin-left': this.new_vac ? '0px' : '-16px'
                }, this.tme, 'linear') : middleImg.animate({
                    'width': '100%',
                    'margin-left': '0%'
                }, this.tme, 'linear')) : middleImg.animate({
                    'width': this.new_vac ? '100%' : mdcardWdt,
                    'margin-left': this.new_vac ? 0 : '-15px'
                }, this.tme, 'linear'); /*JuneA*/
            } else {
                $(window).width() < 831 ? ($(window).width() > 660 ? middleImg.css({
                    'width': this.new_vac ? '100%' : mdcardWdt,
                    'margin-left': this.new_vac ? '0px' : '-16px'
                }) : middleImg.css({
                    'width': '100%',
                    'margin-left': '0%'
                })) : middleImg.css({
                    'width': this.new_vac ? '100%' : mdcardWdt,
                    'margin-left': this.new_vac ? 0 : '-15px'
                }); /*JuneA*/
            }
			if($(window).width() > 661)
			{
				crd2.css({
					'overflow': 'hidden',
					'z-index': '2'
				});
				crd3.css({
					'z-index': '3'
				});
				crd1.css({
					'z-index': '1'
				});
			}
            !this.isl && img1n3.animate({
                'width': '100%',
                'margin-left': '0%'
            }, this.tme, 'linear');

        }
        return this;
    },
    selvac: function() {
        if (typeof(pymnttyp) == 'undefined' || pymnttyp == null || pymnttyp == '') {
            this.genCrds("charge cards", ".chrg", true)
        } else if (pymnttyp == "charge") {
            ($('.crd-cnt').show(), $('.cdt-cnt').hide(), this.genCrds("charge cards", ".chrg", true)), $('.module2 .cards-type a.chrg').addClass('active'), $('.module2 .cards-type a.cdt').removeClass('active')
        } else if (pymnttyp == "credit") {
 
            ($('.crd-cnt').hide(), $('.cdt-cnt').show(), this.genCrds("credit cards", ".cdt", true)), $('.module2 .cards-type a.cdt').addClass('active'), $('.module2 .cards-type a.chrg').removeClass('active')
        } /** personalization **/
        return this;
    },
    activeCtgry: function() {
        $(".bgn-this.crds .link-txt").live("click", function(e) {
            $(".bgn-this.crds").addClass('active');
            $(".bgn-this.crds .link-txt").css("color", "white");
        })
    },
    vacLHeight: function() {
        $('.cards-type .link-txt').each(function() {
            if ($(window).width() <= 660) {
                $(this).height() >= 23 ? $(this).css('padding-top', '8px') : $(this).css('padding-top', '14px')
            } else $('.cards-type .link-txt').css('padding-top', '0px');
        })

    },
    move: function(e) {
        _this = OPEN.homePage.viewall;
		
		if($('#module-02').hasClass('crdcln')){
		if(($('#cards-offer .card').length-1)<=3 &&( $('body').hasClass('res_Medium')||$('body').hasClass('res_Large'))) {$(document)[0].addEventListener('touchmove', _this.move, true); return false;}
		}
        //!$("body").hasClass("newvac") && (_this.viewAllObj.tagName == 'SPAN' || _this.viewAllObj.tagName == 'A' || _this.viewAllObj.tagName == 'IMG' ? "" : e.preventDefault());
		
        if (!_this.viewAllObj.className.match(/heading|link-txt|cards-type|vac-navbar|chrg active|cdt|bgn-crds|crd-cnt/g) && !_this.viewAllObj.id.match(/cnt1|cnt2|cnt3|cnt4/g) && compD == true) {
			 var curr = e.touches[0].pageX - comp_pos;
                if (Math.abs(curr) >= 30) {
					if (_this.viewAllOnce) {
						e.preventDefault();
						OPEN.homePage.viewall.minNavFlg = false;
						e.touches[0].pageX < comp_pos && $("#right").trigger('click');
						e.touches[0].pageX > comp_pos && $("#left").trigger('click');
                	}
                _this.viewAllOnce = false;
            }

        }
    },
    touchUp: function(e) {
        _this = OPEN.homePage.viewall;
        !$("body").hasClass("newvac") && ( _this.viewAllObj.tagName == 'SPAN' || _this.viewAllObj.tagName == 'A' || _this.viewAllObj.tagName == 'IMG' ? "" : e.preventDefault()); /*October B*/
        comp_pos = 0;
        compD = false;
        compH = 0;
        _this.viewAllOnce = true;
        OPEN.config.CLS.crd_slds[0].removeEventListener('touchmove', _this.move, false);
		 OPEN.config.CLS.crd_slds[0].removeEventListener('touchend', _this.touchUp, false);
        _this.viewAllObj = null;


    },
    touchDown: function(e) {
        _this = OPEN.homePage.viewall;
        _this.viewAllObj = e.touches[0].target;
        comp_pos = e.touches[0].pageX;
        compD = true;
        OPEN.config.CLS.crd_slds[0].addEventListener('touchmove', _this.move, false);
		OPEN.config.CLS.crd_slds[0].addEventListener('touchend', _this.touchUp, false);
    },
    vacpageReady: function(o) {
        var _this = this;
        this.only_new_vac =false;
        this.new_vac = new_vacvar = $("body").hasClass("newvac");
        this.only_new_vac = $("body").hasClass("newvac") && !$("body").hasClass("novactab");

        $('.module2 .cards-type a').click(function(e) {
            //FEB release
            _this.isl = true;
            var linkText = $(this).find('.link-txt').html().toLowerCase().replace(/ /g, ""); //text with lowercase and without spaces
            if (linkText != 'allbusinesscards') {
                (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', linkText + '_menu'): null;
            }
            $('.module2 .cards-type a').removeClass('active');
            $(this).addClass('active');
            $(this).hasClass('cdt') ? ($('.crd-cnt').hide(), $('.cdt-cnt').show(), _this.genCrds($(this).find('.link-txt').html().toLowerCase(), $(this), false)) : ($(this).hasClass('chrg') ? ($('.cdt-cnt').hide(), $('.crd-cnt').show(), _this.genCrds($(this).find('.link-txt').html().toLowerCase(), $(this), false)) : null)
			var _nav = OPEN.homePage.common;
		if($("body").hasClass("newvac") && OPEN.universal.isMobile()){
		_nav.mdlfooter.removeClass("fixed");
        $(window).width() <= 661 && _this.new_vac && $(".module2 #left").trigger("click",true);
		_nav.stickyFooter.call({module:_nav.newVAC,footer:_nav.mdlfooter,class:"fixed",winH:$(window).height(),scrl:$(document).scrollTop(),start:_nav.ajnav,addition:_nav.mdlfooter.find(".min-nav").outerHeight()})
		}
        });
        _this.respCrds($(window).width(), true).selvac().vacLHeight();
        $("body").hasClass("res_Large") ? $(".middleCard .crd-name,.middleCard .crd-details").css({
            "margin-left": mdLtShdw
        }) : $(".middleCard .crd-name,.middleCard .crd-details").css({
            "margin-left": "auto"
        }); /*JuneA*/
        $(".module2 .slides li a").live('keydown', function(e) {
            var ele = $(this).parents(".hp-viewport").siblings('ul');
            if (e.shiftKey && e.keyCode == 9) {
                e.preventDefault();
                ele.find('a.hp-prev').hasClass('hp-disabled') ? $('.module2 a.primary').focus() : ele.find('a.hp-prev').click();
            } else if (e.keyCode == 9) {
                e.preventDefault();
                ele.find('a.hp-next').hasClass('hp-disabled') ? $('#rewards-type1 a.carousel_item').focus() : ele.find('a.hp-next').click();
            }
        });

        if (o.CLS.crd_slds.length) {
            o.CLS.crd_slds[0].addEventListener('touchstart', this.touchDown, false);
        }

     $(".module2 .min-nav a").removeClass('active');
          $(".module2 .min-nav a:first").addClass('active');
    },
    vacpageResize: function() {
        this.isl = true;
         this.page_resize = true;
        
		var dots = $(".content-wrapper>.crd-details");
		
        this.respCrds($(window).width(), true).vacLHeight();
        $("body").hasClass("res_Large") ? $(".middleCard .crd-name,.middleCard .crd-details").css({
            "margin-left": mdLtShdw
        }) : $(".middleCard .crd-name,.middleCard .crd-details").css({
            "margin-left": "auto"
        }); /*JuneA*/

        //added in order to manipulate the order at mobile break point as part of sept14 release.
        var crslL = $(".module2 #left");
        var crslR = $(".module2 #right");
        var minCrls = $(".module2 .min-nav");
        if (this.new_vac && $(window).width() <= 660 && !this.mblFlg) {
            crslL.trigger("click", true);
            $(".module2 .crd-slides .crd-details,.module2 .crd-slides .crd-details .crd-name").css("margin-left", "auto");
            if ($(".module2 .card").length - 1 == this.def_arr.length - 1) {
                minCrls.find("a").removeClass("active");
                minCrls.find("a:first").addClass("active");
            }
            this.mblFlg = true;
        } else if (this.new_vac && $(window).width() >= 661 && this.mblFlg) {
            if ($(".module2 .card").length - 1 > this.def_arr.length - 1) {
                crslR.trigger("click", true);
            }
            else {
                minCrls.find("a.active").index() == 0 && crslR.trigger("click", true);
                minCrls.find("a.active").index() == 2 && crslL.trigger("click", true);
            }
            this.mblFlg = false;
        } 
	var _nav = OPEN.homePage.common;
	OPEN.universal.isMobile() && !dots.is(":visible") && dots.show();
	if($("body").hasClass("newvac") && OPEN.universal.isMobile()){	
			_nav.stickyFooter.call({
			module:_nav.newVAC,
			footer:_nav.mdlfooter, 
			class:"fixed",
			winH:$(window).height(),
			scrl:$(document).scrollTop(),
			start:_nav.ajnav,
			addition:_nav.mdlfooter.find(".min-nav").outerHeight()
			})	
		}
		$(window).width() > 660 && OPEN.homePage.viewall.dspCrds == OPEN.homePage.viewall.def_arr.length-1 &&  $("#hp-vac,.content-wrapper>.crd-details").hide();
        $(window).width() > 660 ? ($('.offer-wrapper').addClass('enablescroll').removeClass('disablescroll'), touch ? $("#module-02 .offer-wrapper .custom-scrollbar").addClass('touch-scrollbar') : ($('#module-02 .offer-wrapper .scrollbar+ .viewport>div').addClass('overview'), $("#module-02 .offer-wrapper").openScrollber({
            wheelSpeed: 10,
            wheelLock: false
        }))) : $('.offer-wrapper').removeClass('enablescroll').addClass('disablescroll');
        $(window).width() > 660 ? $(window).width() >= 831 && $('.offer-wrapper').addClass('highres') : $('.offer-wrapper').removeClass('highres');
     this.page_resize = false;
    },
	updatemvtarry:function(arry,cnt)
	{
	return arry.slice(0,cnt);
	}
};