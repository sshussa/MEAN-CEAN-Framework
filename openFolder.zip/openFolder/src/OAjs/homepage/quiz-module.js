OPEN.homePage.quiz = {
	touch_dev:("ontouchstart" in window) || window.DocumentTouch && document instanceof DocumentTouch,
	errmsg_cnt:0,
    email_lead: function () {
        return ('<div id="email-cntr"><div id="email-lk"><a href="#" tabindex="29" title="Get more Card info" >Get more Card info<span class="arrow"></span></a> </div><div id="email-sec"><form action="#" id="email-submit" class="email-submit" method="post" autocomplete="off"><div class="email-content"><p class="error_msg" for="quiz-email">Your email address is required</p> <ul><li class="txt-field"><label class="label-mask" for="quiz-email">Email Address</label><input type="text" name="quizmail" title="Email Address" alt="Email Address" id="quiz-email" maxlength="50" /></li><li class="submit-section"> <span class="learnbutton"><label for="submit-btn-find"></label><input type="submit" value="Submit" id="quiz-submit" title="Click to Submit" class="learn-btn btn blue-btn" /></span> </li></ul><div class="secured-tooltip"><p class="tooltip-cnt">By providing your email address, you agree to receive follow-up communications from American Express OPEN about our products & services. For information on how we protect your privacy please visit us online at <a href="http://americanexpress.com/privacy?linknav=us-acq-open-aj-youroffers-privacyStatement" title="click here to read our privacy statement" target="_new">Privacy Statement</a>. </p> </div> </div>     </form>   </div>  </div>')
    },
    start: function () {
        var email_lead_flg = true, mailflag, rsd_selc = "input[type='radio']",  tb_cnt = 20, ml_sbt = 0, quiz_version, flg_errmsg = false, flg_mbles = true, _this=this;
        $.getScript(contentPath + "/ngaosbn/OAjs/quiz.js")
		//$.getScript("../../OAjs/quiz.js")
                .done(function (script, textStatus) {
                    var qz_emailsec = $(".module5 #email-sec");
                    var qo = Quiz;
                    
                    (email_lead_flg) ? $("#get-card-advice").append(OPEN.homePage.quiz.email_lead()) : null;
                    email_lead_flg = false;
                    var ques_obj = {};
                    ques_obj.ACQ_Recommended_Card = "";
                    var email_txtfld = ("#module-05 #email-submit li.txt-field");
                    var email_error = ("#module-05  #email-submit .error_msg");
                    var email_lkmodule = $("#module-05 #email-lk");
                    $(".q-slides").on("click", "#module-05 label.label-mask", function (e) {
                        $('#module-05 #email-submit input[type="text"]').focus()
                    });
                    $('#module-05 #email-submit input[type="text"]').live("blur", "focusout", function (e) {
                        if (document.activeElement == document.body && _this.touch_dev && brwsr_type.match(/Android/i)) {
                            e.preventDefault();
                            setTimeout(function () {
                                $('#module-05 #email-submit input[type="text"]').focus()
                            }, 10);
                            (_this.errmsg_cnt <= 2) && $(email_txtfld).removeClass("fieldErrors"), $(email_error).css("cssText", "visibility:hidden !important");
                            flg_mbles = false
                            flg_mbles = false
                        }
                    });
                    $(document).keypress(function (e) {
                        if (e.which == 13) {
                            if (document.activeElement.id == "quiz-email") {
                                e.preventDefault();
                                OPEN.Validate.BusinessForm.validateField(document.getElementById("quiz-email"));
                                (!$(email_txtfld).hasClass("fieldErrors")) ? $("#quiz-submit").trigger("click") : $(email_error).css("cssText", "visibility:visible !important"), $("#validateTipWrapper").css("cssText", "display:none !important")
                            }
                        }
                    });
                    $(email_txtfld).find("#quiz-email").live("blur", function (e) {
                        e.preventDefault();
                        (!_this.touch_dev && !brwsr_type.match(/Android/i)) && blnkmmail(e);
                        setTimeout(function () {
                            _this.errmsg_cnt++
                        }, 200);
                        if (_this.errmsg_cnt > 2) {
                            blnkmmail(e)
                        }
                        $(email_txtfld).hasClass("fieldErrors") ? ($(email_error).css("cssText", "visibility:visible !important")) : ($(email_error).css("cssText", "visibility:hidden !important"), $(email_txtfld).removeClass("fieldErrors"))
                    }).live("keyup", function (e) {
                        $(email_txtfld).find("label.label-mask").hide()
                    });
                    $(".q-slides").on("click", "#quiz-submit", function (e) {


                        e.preventDefault();
                        (brwsr_type.match(/Android/i)) && (_this.errmsg_cnt = 2);
                        OPEN.Validate.BusinessForm.validateField(document.getElementById("quiz-email"));
                        $(email_txtfld).hasClass("fieldErrors") && $("#validateTipWrapper").css("cssText", "display:none !important");
                        $(email_txtfld).hasClass("fieldErrors") ? (e.preventDefault(), $(email_error).css("cssText", "visibility:visible !important"), $(email_error).css("visibilty", "visible")) : (e.preventDefault(), $(email_error).css("visibilty", "hidden"), email_lkmodule.removeClass("down-arrow"), ($('.module5 #email-sec').animate({
                            height: "toggle"
                        }, 500, function () {
                            $(this).removeClass("show-mail")
                        })), submt_mail(), $(email_txtfld).find("#quiz-email").val(""));
                        _this.errmsg_cnt = 0

                    });

                    $(document).on("click", function (e) {
                        var curr_ele = $(e.target).parent().parent().attr("id");
                        var cur_tag = $(e.target);
                        $(".module5 #email-sec").hasClass("show-mail") ? (!(curr_ele == "email-cntr" || $(e.target).hasClass("submit-section") || cur_tag.hasClass("show-mail") || cur_tag.hasClass("email-content") || curr_ele == "email-sec" || curr_ele == "email-submit" || cur_tag.hasClass("tooltip-cnt")) ? (email_lkmodule.toggleClass("down-arrow"), $(".module5 #email-sec").hide(), $(".module5 #email-sec").toggleClass("show-mail")) : null) : null
                    });

                    email_lkmodule.find("a").click(function (e) {
                        var email_sec = $(".module5 #email-sec");
                        e.preventDefault();
                        (!$(email_txtfld).hasClass("fieldErrors") && $(email_txtfld).find("#quiz-email").val().length == 0) && ($("#module-05 #email-sec .label-mask").show(), $(email_error).css("cssText", "visibility:hidden !important"), $(email_txtfld).removeClass("fieldErrors"));
                        email_sec.toggleClass("show-mail");
                        email_lkmodule.toggleClass("down-arrow");
                        (email_sec.hasClass("show-mail")) ? (email_sec.show(), (!$(email_txtfld).hasClass("fieldErrors") && $(email_txtfld).find("#quiz-email").val().length == 0) ? $(email_txtfld).find("#quiz-email").val("") : null) : $(".module5 #email-sec").hide();
                        ($(".module5 #email-sec").hasClass("show-mail") && (flg_errmsg) && mailobj.ACQ_Quiz_Synccall == "Second_SyncLeadCall") && (($(email_txtfld).removeClass("fieldErrors"), $(email_error).css("cssText", "visibility:hidden !important"), flg_errmsg = false));
                        $(email_txtfld).hasClass("fieldErrors") ? $(email_error).css("cssText", "visibility:visible !important") : $(email_error).css("cssText", "visibility:hidden !important");
                        emlk_flg = false
                    });
                    var w = $("#module-05 .view").width(),
                            sc = $(".q-slides"),
                            qs = $(".q-start"),
                            qn = $(".q-next .next a"),
                            qb = $(".q-next .prev a"),
                            tree = [],
                            count = 1,
                            cs = getcs(),
                            nslide = "",
                            csinpchgd = false,
                            objp = "qo",
                            ols = false,
                            isSlideAnimating = false;
                    ls = false;
                    $(".q-slides>li").css("width", w);
                    qs.click(function (e) {
                        $("body .quiz_module").addClass("device-fix");
                        e.preventDefault();
                        count++;
                        $.each(qo.section, function (i, v) {
                            nslide += '<li><input type="radio" name="options" id="option' + (i + 1) + '" ><label for="option' + (i + 1) + '">' + qo.section[i].option + '</label><span class="radio-quiz-normal"></span></li>'
                        });
                        nslide = '<li class="slide2"><h2 class="heading">' + qo.header + "</h2><ul>" + nslide + '</ul><div class="q-nav"><ul class="q-next"><li class="next disabled"><a href="#">Next question</a></li><li class="prev"><a href="#" >Go back</a></li></ul></div></li>';
						isSlideAnimating = true;
                        sc.append(nslide).width(($(".q-slides>li").length) * w).animate({
                            marginLeft: -w
                        }, 400, function () {
                            qs.hide();
							isSlideAnimating = false;
                            $("ul.q-next, ul.q-next .next").show();
                            cs = getcs();
                            $("body .quiz_module").removeClass("device-fix")
                        });
                        $(".q-slides>li").css("width", w)
                    });
                    $(".q-slides").on("click", "a", function (e) {
                        if ($(this).text() == "Compare Cards ") {
                            var cArr = eval("(" + OPEN.universal.readCookie("cardInfo") + ")");
                            var strng = OPEN.universal.stringify(cArr[0].cards, true);
                            OPEN.universal.createCookie("cardInfo", strng, 10)
                        }
                        var linkHeadTxt = $(this).closest(".q-nav").parent("li").find("h2").text();
                        var QuizlinkTxt = {
                            "Finding a Card is quick and easy": "GetStarted",
                            "How do you typically pay your Card bill?": "HowDoYouPay",
                            "What's better for your business? Rewards or cash back?": "RewardOrCashBac",
                            "Are premium Card benefits important to your business?": "PremiumBenefits",
                            "Which of these rewards is the best choice for your business?": "BestChoice"
                        };
                        if ($(this).text() == "Get started") {
                            (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", "click_CardAdvice:GetStarted") : null
                        } else {
                            if ($(this).text() == "Start Over") {
                                $("#get-card-advice").append($("#email-cntr"));
                                (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", "click_CardAdvice:StartAgain") : null
                            } else {
                            	//rmaction for next button. No need of rmaction for compare and learn more button as these two button is already have linknav query string.
                                if (!$(this).parent().hasClass("disabled") && $(this).parent().hasClass("next") && (QuizlinkTxt[linkHeadTxt] !== "")) {
                                    (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", "click_CardAdvice:" + QuizlinkTxt[linkHeadTxt]) : null
                                }
                            }
                        }
                        if (!$(this).parent().hasClass("disabled") && $(this).parent().hasClass("next")) {
                            $("body .quiz_module").addClass("device-fix");
                            e.preventDefault();
                            cs = getcs();
                            var chid = getchid(cs);
                            getchkdinfo(cs) ? qn.parent().removeClass("disabled") : $(this).parent().addClass("disabled");
                            cs.index() < 1 ? $(".prev").hide() : $(".prev").show();
                            cs.index() == ($(".q-slides>li").length - 1) ? csinpchgd = true : null;
                            tree.push(chid);
                            ques_obj.ACQ_Quiz_Synccall = "First_SyncLeadCall";
                            var quiz_version = "OpenQuizV1";
                            switch (UBA.getQueryString("opt")) {
                                case "1":
                                    quiz_version = "OPENQUIZ_2014v1a";
                                    break;
                                case "2":
                                    quiz_version = "OPENQUIZ_2014v1b";
                                    break;
                                case "3":
                                    quiz_version = "OPENQUIZ_2014v1c";
                                    break;
                                default:
                                    quiz_version = "OPENQUIZ_2014v1a"
                            }
                            ques_obj.ACQ_Quiz_Version = quiz_version;
                            var sn = getreqobj(tree);
                            var hdr = sn.header;
                            Object.prototype.toString.call(sn) === "[object Array]" ? (sn = sn) : (typeof (sn.section) != "undefined" ? sn = sn.section : (sn = sn, ols = true));
                            if (!ols && csinpchgd) {
                                nslide = "";
                                count++;
                                $.each(sn, function (i, v) {
                                    nslide += '<li><input type="radio" name="level' + (tree.length - 1) + '" id="level' + (tree.length - 1) + "section" + (i + 1) + '" ><label for="level' + (tree.length - 1) + "section" + (i + 1) + '">' + sn[i].title + '</label><span class="radio-quiz-normal"></span></li>'
                                });
                                nslide = '<li class="slide' + count + '"><h2 class="heading">' + hdr + "</h2><ul>" + nslide + '</ul><div class="q-nav"><ul class="q-next"><li class="next disabled"><a href="#">Next question</a></li><li class="prev"><a href="#" >Go back</a></li></ul></div></li>';
                                sc.append(nslide)
                            } else {
                                if (csinpchgd) {
                                    count++;
                                    nslide = "";
                                    (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", "click_CardAdvice:Recommendation") : null;
                                    nslide = updateLastSection(sn.cards, sn, count);
                                    sc.append(nslide);
                                    (mailflag == "TRUE") && (setemaillead(quiz_version))
                                }
                            }
                            isSlideAnimating = true;
                            sc.width(($(".q-slides>li").length) * w).animate({
                                marginLeft: parseInt(sc.css("margin-left")) - w
                            }, 400, function () {
                                qs.hide();
                                $("ul.q-next").show();
                                cs = getcs();
                                if ($(window).width() < 661) {
                                    var hhh = cs.find("h2").outerHeight(true) + (cs.find("ul:first").outerHeight(true)) + cs.find(".q-nav").outerHeight(true);
                                    $(window).height() < 600 && $("html,body").animate({
                                        scrollTop: $(".quiz_module").offset().top - $(".ajnav").height()
                                    }, 800)
                                }
                                isSlideAnimating = false;
                                $("body .quiz_module").removeClass("device-fix");
                            });
                            cs.index() < 1 ? $(".prev").hide() : $(".prev").show();
                            getchkdinfo(cs.next()) ? qn.parent().removeClass("disabled") : $(this).parent().addClass("disabled");
                            ls && ($(".q-next,.q-next>li").hide(), $(".q-compare").show());
                            objp = "qo";
                            $(".q-slides>li").css("width", w);
                            return false
                        } else {
                            if ($(this).parent().hasClass("disabled") && $(this).parent().hasClass("next")) {
                                e.preventDefault()
                            }
                        }
                    });
                    $(".q-slides").on("click", "a", function (e) {
                        if ($(this).parent().hasClass("compare")) {
                            return true
                        } else {
                            if ($(this).parent().hasClass("prev") && !$(this).parent().parent().hasClass("q-compare")) {
                                $("body .quiz_module").addClass("device-fix");
                                l = parseInt(sc.css("margin-left"));
                                sc.animate({
                                    marginLeft: l + w
                                }, 400, function () {
                                    cs = getcs();
                                    $("body .quiz_module").removeClass("device-fix")
                                });
                                tree.pop();
                                csinpchgd = false;
                                cs.index() <= 2 ? $(".prev").hide() : $(".prev").show();
                                getchkdinfo(cs.prev()) ? cs.prev().find(".q-next .next").removeClass("disabled") : cs.prev().find(".q-next .next").parent().addClass("disabled");
                                return false
                            } else {
                                if (!$(this).parent().hasClass("compare") && $(this).parent().parent().hasClass("q-compare")) {
                                    ques_obj = {};
                                    ques_obj.ACQ_Recommended_Card = "";
                                    email_lkmodule.css("visibility", "hidden").removeClass("down-arrow");
                                    $(".module5 #email-sec").removeClass("show-mail");
                                    $("body .quiz_module").addClass("device-fix");
                                    isSlideAnimating = true;
                                    sc.animate({
                                        marginLeft: -($(".q-slides>li").width())
                                    }, 400, function () {
                                        $(".q-slides>li:gt(1)").remove();
                                        isSlideAnimating = false;
                                        $("body .quiz_module").removeClass("device-fix")
                                    });
                                    var qz_slideso = $(".q-slides>li:eq(1)");
                                    qz_slideso.find(".next").show().addClass("disabled");
                                    qz_slideso.find(rsd_selc).attr("checked", "false");
                                    qz_slideso.find(".radio-quiz-normal").removeClass("active").parent().removeClass("active");
                                    tree = [], count = 1, cs = getcs(), nslide = "", csinpchgd = false, ls = false, ols = false;
                                    qz_emailsec.hide();
                                    qz_emailsec.removeClass("show-mail");
                                    $("#email-lk").removeClass("down-arrow");
                                    $(email_txtfld).find("#quiz-email").val("");
                                    $(email_txtfld).removeClass("fieldErrors");
                                    return false
                                }
                            }
                        }
                    });
                    $(".q-slides").on("click", cs, function (e) {
                        if (!isSlideAnimating) {
                            if ($(e.target).hasClass("radio-quiz-normal")) {
                                $(e.target).siblings().click();
                                return false
                            } else {
                                if (e.target.tagName.toUpperCase() === "INPUT" || e.target.tagName.toUpperCase() === "LABEL" || e.target.tagName.toUpperCase() === "SPAN") {
                                    var ele = e.target.tagName.toUpperCase() === "SPAN" ? $(e.target).parent() : $(e.target);
                                    qn.parent().removeClass("disabled");
                                    csinpchgd = true;
                                    ols = false;
                                    cs = getcs();
                                    cs.nextAll().remove();
                                    cs.find(".next").removeClass("disabled");
                                    count = $(".q-slides>li").length;
                                    ele.parent().siblings().removeClass("active").find(".radio-quiz-normal").removeClass("active");
                                    ele.parent().addClass("active").find(".radio-quiz-normal").addClass("active");
                                    ele.parent().siblings().find(rsd_selc).attr("checked", "false");
                                    ele.parent().find(rsd_selc).attr("checked", "checked");
                                    return false
                                }
                            }
                        }
                    });

                    function blnkmmail(e) {
                        $(email_txtfld).find("#quiz-email").val() == null || $(email_txtfld).find("#quiz-email").val() == "" ? (e.preventDefault(), $(email_txtfld).addClass("fieldErrors"), $(email_error).css("visibility", "visible"), $(email_txtfld).find("label.label-mask").show()) : null
                    }

                    function getchkdinfo(cs) {
                        var ch = cs.find(rsd_selc);
                        if (ch.filter(":checked").length > 0) {
                            return true
                        } else {
                            return false
                        }
                    }

                    function getchid(cs) {
                        var chk = cs.find(rsd_selc);
                        return chk.filter(":checked").parent().index()
                    }

                    function getcs() {
                        return $(".q-slides>li").eq(Math.abs(parseInt(sc.css("margin-left")) / w))
                    }

                    function track_choice(hdr, choic, i) {
                        var patt1 = /<\s*sup[^>]*>(.*?)<\s*\/\s*sup>/g;
                        quest = "ACQ_Q" + i + "_Question";
                        ans = "ACQ_Q" + i + "_Answer";
                        hdr.match(patt1) != null ? ques_obj[quest] = hdr.replace(patt1, '') : ques_obj[quest] = hdr;
                        choic.match(patt1) != null && (choic = choic.replace(patt1, ""));
                        choic = $("<sup />").html(choic).text();
                        choic = $("<span />").html(choic).text();
                        ques_obj[ans] = choic.replace("&#39;", "");
                    }

                    function submt_mail() {
                        mailobj = {};
                        mailobj.Email = $(email_txtfld).find("#quiz-email").val();
                        $.each(ques_obj, function (i, v) {
                            mailobj[i] = ques_obj[i];
                            flg_errmsg = true;
                            _this.errmsg_cnt = 0
                        });
                        mailobj.ACQ_Quiz_Synccall = "Second_SyncLeadCall";
                        $.ajax({
                            type: "POST",
                            url: (typeof (quizLeadUrl) == "undefined" ? "/submitlead" : (quizLeadUrl)),
                            data: JSON.stringify(mailobj),
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            crossDomain: true
                        })
                    }

                    function getreqobj(tree) {
                        $.each(tree, function (i, v) {
                            i == 0 ? (objp += ".section[" + tree[i] + "].section", objp1 = qo.section[tree[i]].option, hdr = qo.header) : (hdr = eval(objp).header, objp += ".section[" + tree[i] + "]", objp1 = eval(objp).title)
                        });
                        track_choice(hdr, objp1, (tree.length));
                        return eval(objp)
                    }
                    $(window).resize(function () {
                        if (brwsr_type.match(/Android/i)) {
                            $("body .quiz_module").addClass("device-fix")
                        }
                        cs = getcs();
                        (mailflag == "TRUE") && setemaillead(quiz_version);
                        w = $("#module-05 .view").width();
                        $(".q-slides>li").css("width", w);
                        typeof cs.attr("class") != "undefined" ? sc.width(($(".q-slides>li").length) * w).css("margin-left", (-(cs.index()) * w)) : null
                    });

                    function setquizEEP(url) {
                        var EEP;
                        typeof (quizEEP) != "undefined" ? (EEP = quizEEP) : (EEP = 44343);
                        var url_EEP = url == null ? window.location.href.substr(window.location.href.indexOf("#get-card-advice/")).match(/[0-9]{5}/g) : (url.match(/[0-9]{5}/g) == null && window.location.href.substr(window.location.href.indexOf("#get-card-advice/")).match(/[0-9]{5}/g));
                        $(url_EEP).length ? EEP = url_EEP[0] : typeof (quiz_EEP) != "undefined" && (EEP = quiz_EEP);
                        return EEP
                    }

                    function setemaillead() {
                        var isiPad = brwsr_type.match(/iPad/i) != null;
                        if ($(window).width() > 830) {
                            $("#lastSlide .q-nav").append($("#email-cntr"))
                        } else {
                            $("#email-cntr").insertAfter("#lastSlide h2");
                        }
                    }

                    function updateLastSection(pmccodes, sn, count) {
                        setTimeout(function () {
                            email_lkmodule.css("visibility", "visible")
                        }, 400);
                        ques_obj.ACQ_Recommended_Card = pmccodes;
                        var moduleContent = [];
                        $.ajax({
                            type: "GET",
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            url: (typeof (quizUrl) == "undefined" ? "../../json/cards.json" : (quizUrl + "?quiz_pmc=" + pmccodes)),
                            cache: false,
                            async: false,
                            success: function (json) {
                                mailflag = json.EmailIdSwitchFlag;
                                var comp_lnk;
                                var itag_products;
                                if (pmccodes.length > 1) {
                                    tb_cnt = 20;
                                    itag_products = "";
                                    $.each(pmccodes, function (entryIndex, entry) {
                                        itag_products += ";US:OPEN:" + entry + ",";
                                        $.each(json, function (index, value) {
                                            if (entry == index) {
                                                nslide += "<li><a tabindex=" + tb_cnt + " href='" + this.moreLink.replace("$EEP", setquizEEP(this.moreLink)) + "' class='card-art card-art-container flat-cardart-" + entry + "' title='" + this.title.replace("<sup class='reg'>&#174;</sup>", "&reg;").replace("<br/>", "") + "'></a><h5>" + this.title + "</h5><a  tabindex=" + (eval(tb_cnt + 1)) + " href=" + this.moreLink.replace("$EEP", setquizEEP(this.moreLink)) + " class='learn-more-link'>" + this.more + "</a>";
                                                tb_cnt = tb_cnt + 2
                                            }
                                        })
                                    });
                                    /*july A */   nslide = '<li class="slide' + count + '" id="lastSlide"><h2 class="heading">' + sn.header + "</h2><ul>" + nslide + '</ul><div class="q-nav"><ul class="q-compare"><li class="compare mult"><a tabindex=' + (tb_cnt + 10) + ' href="' + window.location.protocol + "//" + window.location.hostname + "/us/small-business/credit-cards/business-card-compare/" + setquizEEP(null) + "?fromPage=quiz-compare&pmccodes=" + pmccodes + '&linknav=us-open-aj-hp-getcardadvice-compare" title="Compare the recommended Cards">Compare Cards </a></li><li class="prev"><a  tabindex=' + (tb_cnt + 11) + ' href="#" ><span class="start-over-btn">Start Over<span class="start-over"></span></span></a></li></ul></div></li>';
                                    itag_products = itag_products.slice(0, -1)
                                } else {
                                    itag_products = ";US:OPEN:" + pmccodes;
                                    var mr = "",
                                            ml;
                                    tb_cnt = 20;
                                    $.each(pmccodes, function (entryIndex, entry) {
                                        $.each(json, function (index, value) {
                                            if (entry == index) {
                                                nslide += "<li><a  tabindex=" + tb_cnt + " href='" + this.moreLink.replace("$EEP", setquizEEP(this.moreLink)) + "' class='card-art card-art-container flat-cardart-" + entry + "' title='" + this.title.replace("<sup class='reg'>&#174;</sup>", "&reg;").replace("<br/>", "") + "'></a><h5>" + this.title + "</h5>";
                                                mr = this.more;
                                                ml = this.moreLink.replace("$EEP", setquizEEP(this.moreLink));
                                                tb_cnt++
                                            }
                                        })
                                    });
                                    nslide = '<li class="slide' + count + '" id="lastSlide"><h2 class="heading">' + sn.header + "</h2><ul>" + nslide + '</ul><div class="q-nav"><ul class="q-compare"><li class="compare"><a  tabindex=' + (tb_cnt + 10) + " href=" + ml + ">" + mr + '</a></li><li class="prev"><a  tabindex=' + (tb_cnt + 11) + ' href="#" ><span class="start-over-btn">Start Over<span class="start-over"></span></span></a></li></ul></div></li>'
                                }
                                ls = true
                            },
                            error: function () {
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: (typeof (quizLeadUrl) == "undefined" ? "/submitlead" : (quizLeadUrl)),
                            contentType: "application/json",
                            data: JSON.stringify(ques_obj),
                            dataType: "json"
                        });
                        return nslide
                    }
                }).fail(function (jqxhr, settings, exception) {

            try {
                if (jqxhr.status == 404)
                    throw "Supporting file for quiz module not found/loaded";
            }
            catch (err) {
                console.log("*****************************************" + err + "*****************************************");
            }

        })
		$("#module-05 .q-slides").on('click',"#lastSlide .compare a",function(e){/*OctB*/
			var cArr = eval("(" + OPEN.universal.readCookie("cardInfo") + ")");
			var strng = OPEN.universal.stringify(cArr.cards,true);
			OPEN.universal.createCookie("cardInfo",strng,10);
			e.preventDefault();
			window.location=$(this).attr("href");
		})
    }

}
