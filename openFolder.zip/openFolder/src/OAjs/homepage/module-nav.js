OPEN.homePage.moduleNav = {
    //navigation to the next module by arrow functionality
    moduleScroller: {
        modules: $(".module").length>0?$(".module"):($(".isNav").length>0?$(".isNav"):$(".accordion").length>0&&$(".accordion")),
        isClickedScrollArrow: false,
        fixedNavHeight: $('#product-footer-m').height(),
        winHeight: $(window).height() / 2,
        scrollArrow: $('.open.res_Large .scroll-arrow'),
        moduleResize: function (o) { //functionality on resolution change
            var _this = this;
            _this.scrollArrowRightPos(o);
            if (($(document).scrollTop() >= $('#iNavHdWrap').height() && $('#iNMbWrap').css('display') == 'none') || ($('#iNavHdWrap').css('display') == 'none' && $(document).scrollTop() >= $('#iNMbWrap').height())) {
                _this.scrollArrowPos(o);
            }
            _this.modules.each(function (index, element) {
                var secPos = null;
                secPos = $(element).offset().top - $(document).scrollTop();
                if (secPos < _this.winHeight) {
                    if ($(element).hasClass('last-module')) {
                        o.CLS.scrl_arrow.addClass('up');
                    } else {
                        o.CLS.scrl_arrow.removeClass('up');
                    }
                    if (!_this.isClickedScrollArrow) {
                        _this.modules.removeClass('scroll-active');
                        $(element).addClass('scroll-active');
                    }
                }
            });

        },
        scrollArrowPos: function (o) { //vertical position of arrow
            var _this = this;
            if ($(window).scrollTop() + window.innerHeight >= $("#iNavNGI_FooterMain").offset().top) {
                var scrollPos1 = parseInt($(window).scrollTop() + window.innerHeight - $('#iNavNGI_FooterMain').offset().top);
                o.CLS.scrl_arrow.css('margin-bottom', scrollPos1 + "px");
            } else {
                o.CLS.scrl_arrow.css('margin-bottom', 0);
            }
        },
        scrollArrowRightPos: function (o) { //horizoantal position of arrow
            var _this = this;
            var arrowRightPos = $(window).width()<1440 && $(window).width()>660?$("#wrapper .view-holder").offset().left+15:$("#wrapper .view-holder").offset().left;
            o.CLS.scrl_arrow.css('right', arrowRightPos);
        },
        main: function (o) {
            var _this = this;
            _this.scrollArrowPos(o);
            _this.scrollArrowRightPos(o);
            o.CLS.scrl_arrow.css('bottom', '25px');
            var offset = null;
            var nextMod = null;
            var body_html = $('html, body');
            o.CLS.scrl_arrow.click(function (e) {
                if (touch) {
                }
                if ($('.scroll-active').hasClass('last-module')) {
                    offset = $('.first-module').offset().top;
                    $('div.module').removeClass('scroll-active');
                    $('.first-module').addClass('scroll-active');
                    body_html.animate({
                        scrollTop: offset
                    }, 400, function () {
                    });
                    if (touch) {
                        o.CLS.scrl_arrow.removeClass('up');
                    }
                } else {
                    _this.modules.each(function (index, element) {
                        if ($(element).hasClass('scroll-active')) {
                            nextMod = null;
                            $('.module').removeClass('scroll-active');
                            nextMod = $('.module').eq(index + 1);
                        }
                    });
                    var navh = nextMod.offset().top
                    offset = navh;
                    $(window).width() > 830 ?
                            body_html.stop().animate({
                        scrollTop: offset
                    }, 400, function () {
                        nextMod.addClass('scroll-active');

                    }) : body_html.stop().animate({
                        scrollTop: offset - $("#ajnav").height()
                    }, 400, function () {
                        nextMod.addClass('scroll-active');

                    })
                }

            });

        }
    },
    moduleNavPageReady: function (o) {
        this.moduleScroller.main(o);
        $(".module").each(function () {
            if (!$(this).hasClass("isNav")) {
                $(this).addClass("isNav");
            }
            o.APP.module_array.push($(this)[0]);
        });
        if (o.APP.module_array.length >= 2) {
            $(o.APP.module_array[0]).addClass('first-module scroll-active');
            $(o.APP.module_array[o.APP.module_array.length - 1]).addClass('last-module');
            var spotlightEnd = $('.first-module').offset().top + $('.first-module').height();
            var lpos = $(".first-module").offset().left;
        } else {
            $(o.APP.module_array[0]).addClass("onlyModule");
            var spotlightEnd = only_mdle.offset().top;
            var lpos = only_mdle.offset().left;
            only_mdle.css("bottom", "0px !important");
            only_mdle.length && scrl_arrow.css('height', 0);
        }
        (o.APP.module_array.length == 2 || o.APP.module_array.length == 1) && $("#find-offers .view").addClass("bg");
        if ('ontouchstart' in document.documentElement) { /*arrow for all touch devices **/
            $('.scroll-arrow').addClass('touch-arrow');
        }
        !(touch) && $(".scroll-arrow").mouseenter(function () {
            $(this).addClass("mouseovr");
        }).mouseleave(function () {
            $(this).removeClass("mouseovr")
        });
    },
    moduleNavPageResize: function (o) {
        this.moduleScroller.moduleResize(o);
    },
    moduleNavPageScroll: function (o) {
        this.moduleScroller.moduleResize(o);
        $(".scroll-active").hasClass('first-module') && o.CLS.scrl_arrow.css('margin-bottom', 0);/*personalization**/
    }
};