
OPEN.homePage.common = {
	newVAC: $(".newvac .module2"),
	ajnav: $("#ajnav").outerHeight(),
	mdlfooter: $(".newvac .module2 .crd-details"),
    deeplinkTarget: (function () {
        var navMdl, isAnim = false,hashValue=window.location.hash;

        (hashValue.indexOf("find-offers") != -1 && $('.module').hasClass("module4")) ? navMdl = "find-offers" : null;
        (hashValue.indexOf("get-card-advice") != -1 && $('.module').hasClass("module5")) ? navMdl = "get-card-advice" : null;

        var isFirstMod = $("#" + navMdl).parent().hasClass("first-module") ? true : false, isScroll = false, st = 0, t = "";

        if (!($.browser.msie && parseInt($.browser.version) <= 8)) {
            var windowHeight = $(window).height();
            var moduleHeight = Math.round((0.8) * windowHeight);

            $(".module").each(function () {
                $(this).height(moduleHeight);
            });
        }
        if (hashValue.indexOf(navMdl) != -1) {

            var urlNew = window.location.href;
            var cal_ght;
            $.browser.msie && (window.location.href = urlNew);
            if (isTab) {
                _loading = false;
            }

            var h = iNavHeight;
                 h=0;
            gp = $("#" + navMdl).offset();
            cal_ght = h;

            navFlag = false;

        }

        return function () {
            if (hashValue.indexOf(navMdl) == -1) {
                return false;
            }
            return {
                reachTarget: function (t, cal_hgt, tm_ut) {
				/* Inav animation Hiding implementation 2016 */ 	cal_hgt=0;
                    gp = $("#" + navMdl).offset();
                    if (!isFirstMod) {/*JulyB*/
                        //$("body").addClass("inav-control");
                        $("#main").css("margin-top", (h==0?-7:h) + "px");
                    }
                    typeof evnt != "undefined" && evnt.preventDefualt;
                    $("html,body").animate({scrollTop: (gp.top - (h + (isFirstMod ? 0 : $("#ajnav").height()))) + 7}, t, function () {
                        st = gp.top + 10;
                        t = setTimeout(function () {
                            if (!isScroll) {
	/* Inav animation Hiding implementation 2016 */
                                //_iNavHead.animate({top: -(h + 7)}, 400);
                                $("#ajnav").animate({marginTop: 0}, 400);

                                $("html,body").animate({scrollTop: $(window).scrollTop() + (cal_hgt)}, 400, function () {
                                  	/* Inav animation Hiding implementation 2016 */
				    //$("body").removeClass("inav-control");
                                    $("#main").css("margin-top", -7 + "px");

                                });
                                clearTimeout(t);
                                isScroll = true;

                            }
                        }, tm_ut);

                    })

                },
                releaseElem: function () {
                    if (hashValue.indexOf(navMdl) == -1) {
                        return false;
                    }
                    var h = iNavHeight, gp = $("#" + navMdl).offset();
                    ;
                    $(window).scrollTop() <= h && _iNavHead.removeAttr("style").removeClass('scroll mbl-scroll');
                    st = st - 1;
                    if (st > 0 && st < gp.top && !isScroll) {
	/* Inav animation Hiding implementation 2016 */
                 /*       _iNavHead.animate({top: -h}, 400, function () {
                            if (parseInt($("#" + navMdl).css("margin-top")) > 0) {
                                _iNavHead.removeAttr("style").removeClass('scroll');
                                $("#" + navMdl).css("margin-top", "0px");
                            }
                        });*/
                        $("#ajnav").css({"margin-top": 0});
                        $("body").removeClass("inav-control"); /*julyB*/
                        $("#main").css("margin-top", -7 + "px");
                        isScroll = true;
                        clearTimeout(t);
                        isAnim = true;
                    }
					/* Inav animation Hiding implementation 2016 */	$("#iNavNGI_Header").css("cssText", "opacity:1 !important");

                }
            }
        }

        /*********************/
    })(),
    spotLightBtnsTnT: function () {
        /* start of query string code */
        if (UBA.getQueryString("applynow") === "true")
        {
            $('body').addClass("show-applynow");
        }
        $('body').removeClass('hidden');
    },
    setItagSliders: function (m, pName, dir) {
        switch (m) {
            case "spotlight":
                if (dir)
                    (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Featured_NextInCarousel:' + pName) : null;
                else
                    (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Featured_BackInCarousel:' + pName) : null;
                break;
            case "all-cards":
                if (dir)
                    (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'AllCards_NextInCarousel:' + pName) : null;
                else
                    (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'AllCards_BackInCarousel:' + pName) : null;
                break;
            case "compare-cards":
                if (dir)
                    (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'CardsByType_NextInCarousel') : null;
                else
                    (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'CardsByType_BackInCarousel') : null;
                break;
        }
    },
    chkLargeDevice: function () {
        var feart_viw = $("#featured .view");
        if ($(window).height() > 900)
        {
            feart_viw.find(".cardart").addClass("tablet-device");
            feart_viw.find(".details").addClass("tablet-device");
            feart_viw.find(".offer").addClass("tablet-device");
        }
        else
        {
            feart_viw.find(".cardart").removeClass("tablet-device");
            feart_viw.find(".details").removeClass("tablet-device");
            feart_viw.find(".offer").removeClass("tablet-device");
        }
    },
    commonPageReady: function (o) {
        this.spotLightBtnsTnT();
		OPEN.universal.openNewTab(".terms-limits");
		OPEN.universal.openNewTab(".hp-view-all");
        UBA.init();
        o.APP.bodyClass = $('body').attr('class');
        touch && $('#module-05').addClass('dev');
        this.chkLargeDevice();
        $('#hp-prev,#hp-next,#left,#right').html('');/*marchb*/
        var ftrdDivs = $('#featured .slides>div');
        $.each(ftrdDivs, function (i, v) {
            i <= 1 ? (!$(v).hasClass('bg') ? $(v).addClass('bg') : null) : null;
        })

        $(window).width() >= 661 ? $('#ultimate-apply-view1 .special-offers li a').attr('title', '').removeAttr('title') : null; /* June A*/
        if (brwsr_type.indexOf("Safari") > -1 && brwsr_type.indexOf('Chrome') == -1) {
            $("#wrapper").addClass("safari-wrap");
        }
	
	this.newVAC = $(".newvac .module2");
	this.mdlfooter = $(".newvac .module2 .crd-details");
	this.ajnav = $("#ajnav").outerHeight();
		

    },
	
    commonPageResize: function (o) {
        this.chkLargeDevice();

        if (!o.CLS.only_mdle.length) {
            var showFlag = false;
            lpos = $(".first-module").offset().left;/*april*/
            if (o.CLS.isTT && $(window).width() >= 1280) {
                o.ID.ttNav.css("display") == "none" && o.ID.ttNav.show();

                var ttpos = spotlightEnd - $(document).scrollTop();
                if (ttpos <= $(window).height() / 2) {
                    var crntpos = $(window).height() / 4;
                    var ttOpac = (ttpos / crntpos) - 1;
                    ttOpac = parseFloat(ttOpac).toFixed(2);
                    if (ttOpac < 0) {
                        o.ID.ttNav.hide();
                        showFlag = true
                    } else {
                        o.ID.ttNav.show();
                        showFlag = false
                    }

                }
                else {
                    $('#spotlight-nav').css("opacity", 1);
                    $('#spotlight-nav *').removeAttr("style");
                }


            }

            $(window).width() < 1280 ? (o.ID.ttNav.hide(), o.CLS.scrl_arrow.show()) : null;
            $(window).width() <= 660 ? o.CLS.scrl_arrow.hide() : !o.CLS.isTT ? o.CLS.scrl_arrow.show() : showFlag ? o.CLS.scrl_arrow.show() : $(window).width() >= 1300 ? o.CLS.scrl_arrow.hide() : o.CLS.scrl_arrow.show();/* June A*/
        }			/* personalization*/

        if (!($.browser.msie && parseInt($.browser.version) <= 8) && !((navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/iPhone/i)))) {
            var windowHeight = $(window).height();
            var moduleHeight;

            moduleHeight = Math.round((0.8) * windowHeight);// june release

            $(".module").each(function () {
                $(this).height(moduleHeight);	/*11-08*/
            });
        }
        var sett = setTimeout(function () {
            o.CLS.bodyClass != $('body').attr('class') ? ($(window).resize(), o.CLS.bodyClass = $('body').attr('class')) : clearTimeout(sett);
        }, 100);
		
		
    },
    commonPageScroll: function () {
		
        if ($("#viewallcards-item").parent().hasClass("active")) {
            $("#cards-offer img").each(function () {
                var img = $(this);
                img.attr("src", img.attr("data-src"));
            });
        }
        typeof this.deeplinkTarget().releaseElem == "function" && this.deeplinkTarget().releaseElem();        
        activeSlide = $("#ajnav ul.in-page li.active a").attr('class');
        (activeSlide == "get-card-advice") ? qz_section = true : qz_section = false;
		OPEN.homePage.viewall.viewAllOnce = true;
		var nav = OPEN.homePage.common;
		
		if($("body").hasClass("newvac") && OPEN.universal.isMobile())
		{	
			nav.stickyFooter.call({
			module:nav.newVAC,
			footer:nav.mdlfooter,
			class:"fixed",
			winH:$(window).height(),
			scrl:$(document).scrollTop(),
			start:nav.ajnav,
			addition:nav.mdlfooter.find(".min-nav").outerHeight()
			})	
		}
							

    },
    commonPageLoad: function (o) {
        var t = $(document).scrollTop();
        $(document).scrollTop(t + 1);
        /* Personalization */

        if (!o.CLS.only_mdle.length) {
            o.CLS.isTT ? $(".module2 h1").addClass("mov") : (o.CLS.scrl_arrow.css('display', 'block'));
        }

        $("#find-offers,#get-card-advice").css({"display": "block"});
        $(window).resize();
        typeof this.deeplinkTarget().reachTarget == "function" && this.deeplinkTarget().reachTarget(600, iNavHeight, 3000);
        document.body.addEventListener('touchstart', function (e) {
            OPEN.moduleNav.moduleScroller.isClickedScrollArrow = false;
        }, false)
    },
    commonPageOrientation: function (o) {
        if (brwsr_type.match(/iPad/i) || brwsr_type.match(/Android/i)) {
            void 0 != OPEN.homePage.viewall && OPEN.homePage.viewall.vacpageResize();

            var windowHeight = $(window).height();/*ios7 start*/
            if ($(window).height() < $(window).width()) {
                var portraitWindowHeight = $(window).width();
            }
            var moduleHeight;
            moduleHeight = Math.round((0.8) * windowHeight);
            if (isFocus) {
                var keyBoardHeight = portraitWindowHeight - $(window).height();
                moduleHeight = moduleHeight + keyBoardHeight;
                moduleHeight = Math.round((0.82) * moduleHeight);
            }
            $(".module").each(function () {
                $(this).height(moduleHeight);
            });/*iosend*/
        }

    },
	stickyFooter:function(obj)
	{
		var mdlPos = this.module.offset().top;
		var endPos = (this.module.outerHeight()+mdlPos)-(this.scrl);
        var secPos = mdlPos - this.scrl;
		var footer = $(".newvac .module2 .crd-details");
		if(secPos <= this.start ){
			!footer.hasClass(this.class) && footer.addClass(this.class);
			(endPos) <= this.winH+(!!~navigator.userAgent.indexOf("iPhone")?68:0) && rmvCls(footer,this.class);
			}else{rmvCls(footer,this.class);}
		function rmvCls(ftr,fixedClass){ftr.hasClass(fixedClass) && ftr.removeClass(fixedClass);}
	}
};

