
(function ($, window, document) {

    if (typeof jQuery == 'undefined') {
        throw new Error("JQuery library is not loaded which is mandatory to run the AMEX OPEN Application");
        return;
    }

    /*************************************************** Config Starts here ***********************************************/
    //Page level config details. but these are not Global variables.
    OPEN.config = {
        ID: {
            ttNav: $("#spotlight-nav")
        },
        CLS: {
            scrl_arrow: $(".scroll-arrow"),
            crd_slds: $("#view-all-cards .content-wrapper"),
            only_mdle: $(".onlyModule"),
            isTT: $("#spotlight-nav").css("display") == "block" ? true : false,
            MWWrapper:$(".page-wrapper"),
            modules:$("div[class*='module']"),
            scrollPadding:0,
            lastscrollPadding:0
        },
        APP: {
            isAndroid: brwsr_type.toLowerCase().indexOf("android") > -1,
            navFlag: false,
            module_array: [],
            bodyClass: "",
            nav_p: 0
        }
    }

    /*************************************************** Config ends here ***********************************************/
    //Page level implementation 
    OPEN.hp = function () {

        //Closur global variables.
    	
        var homePage = {
            // --------- Private methods which are encapsulated inside the structure.            
            wwidth: $(window).width(),
            triggerResizeEnd: function () {
                var sett = setTimeout(function () {
                    OPEN.config.APP.bodyClass != $('body').attr('class') && $('body').hasClass('nexus') ? ($(window).resize(), OPEN.config.APP.bodyClass = $('body').attr('class')) : clearTimeout(sett);
                }, 2000)
                if (this.resizeTO)
                    clearTimeout(this.resizeTO);
                this.resizeTO = setTimeout(function () {
                    $(this).trigger('resizeEnd');
                }, 400);
            },
            // --------- Public methods which are exposed out-side the structure.
            public: {
                $docReady: function () {
				    void 0 != OPEN.cust_scroll && OPEN.cust_scroll.scrollBar();	 
                    void 0 !== OPEN.homePage.spotlight && OPEN.homePage.spotlight.pageReady(OPEN.config);
                    void 0 !== OPEN.homePage.viewall && OPEN.homePage.viewall.vacpageReady(OPEN.config);
                    void 0 !== OPEN.homePage.compare && OPEN.homePage.compare.comparePageReady(OPEN.config);
                    void 0 !== OPEN.homePage.quiz && OPEN.homePage.quiz.start(OPEN.config);
                    void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageReady(OPEN.config);
                    void 0 !== OPEN.homePage.common && OPEN.homePage.common.commonPageReady(OPEN.config);
                    void 0 != OPEN.homePage.common && OPEN.homePage.common.commonPageLoad(OPEN.config);
                    void 0 !== OPEN.homePage.viewall && OPEN.homePage.viewall.vacpageResize();
					
                   
                },
                docLoad: function () {
                    void 0 != OPEN.homePage.common && OPEN.homePage.common.commonPageLoad(OPEN.config);
                },
                //event handlers
                eventDelegates: function () {
                    //resize implementaion code is supposed to be placed in the following event block
                    $(window).resize(function (event) {
                        //this.triggerResizeEnd();
                        void 0 !== OPEN.homePage.viewall && OPEN.homePage.viewall.vacpageResize();
                        void 0 !== OPEN.homePage.compare && OPEN.homePage.compare.comparePageResize();
                        void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageResize(OPEN.config);
                        void 0 !== OPEN.homePage.common && OPEN.homePage.common.commonPageResize(OPEN.config);
						void 0 !== OPEN.findOffers && OPEN.findOffers.pageResize();
						
                                                
                                                
                    });
                    $(window).on('resizeEnd', function () {
                      if($('body').hasClass('newvac') && ($(window).width() < 831) )                      
                      {
                       $(".crd-name,.middleCard .crd-details").css({
                        "margin-left": "auto"
                       })   
                      }                                      
                    });
                    $(window).on("scroll", function () {
                        void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageScroll(OPEN.config);
                        void 0 !== OPEN.homePage.common && OPEN.homePage.common.commonPageScroll(OPEN.config);
                    });
                    $(window).on("orientationchange", function () {
                        void 0 !== OPEN.homePage.common && OPEN.homePage.common.commonPageOrientation(OPEN.config);

                    });


                }
            }

        }
        for (var obj in this)
            homePage[obj] = this[obj];
        var _ = homePage;
        return homePage.public;
    }

    function INIT(init, inhr) {
        for (var obj in (OPEN.hp()))
            (init ? obj[0] == '$' : obj[0] != '$') && typeof (OPEN.hp()[obj]) == "function" && (OPEN.hp()[obj]).call(inhr);
    }
    OPEN.bgrPZN = function(){
        var param=UBA.getQueryString("bgrpzn");	
        if (param=="true"){
            $('body').addClass('bgrpzn')
        }         
    }

    $(document).ready(function (e) {
        //initialize the methods before HTML structure renders on web page.
        INIT(true, OPEN.config);
        OPEN.bgrPZN();
    });
    $(window).load(function (e) {
        //initialize the methods after all assets(HTML/CSS/JS) are loaded on web page.
        INIT(false, OPEN.config);
    });
})(window.jQuery, window, document);