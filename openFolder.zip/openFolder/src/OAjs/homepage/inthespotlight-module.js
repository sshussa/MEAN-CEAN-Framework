OPEN.homePage = OPEN.homePage || {};
OPEN.homePage.spotlight = {
    setCarousel: function () {
        $('.carousel-set1').Amex_HP_Slider({
            selector: ".slides > div",
            animation: "slide",
            animationLoop: true,
            itemMargin: 5,
            slideshowSpeed: 9000000000,
            start: function (slider)
            {
                $('body').removeClass('loading');
            },
            before: function (slider) {
                slider.find(".view:eq(" + slider.animatingTo + ")").addClass("bg");
            },
            after: function (slider) {
                $(slider).find(".hp-active-slide").addClass("bg");

                /* live person tagging implementation : start*/
                var viewId = slider.find(".view").eq(slider.currentSlide).attr("id");
                typeof (lpTag) != 'undefined' ? lpTag.vars.push([ {scope:"page",name:"carousel",value: viewId}]) : null;
                typeof(lpTag) =="object"  &&  typeof(lpTag.vars.send)=="function"  &&  lpTag.vars.send();
                /* live person implementation : end*/
                $(".list-content").addClass("device-fix")
            }
        });
        return this;
    },
    rmactions: function () {
        $(".module1 #hp-nav1 li a").live('click', function () {
            if ($(this).text() == "Previous") {
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'left_SpotlightCarousel') : null;
            }
            else {
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'right_SpotlightCarousel') : null;
            }
        });
        return this;
    },
    tabAccess: function () {
        $(".module1 a.primary").live('keydown', function (e) {
            var ele = $(this).parents(".hp-viewport").siblings('ul');
            if (e.shiftKey && e.keyCode == 9) {
                e.preventDefault();
                ele.find('a.hp-prev').hasClass('hp-disabled') ? $('#ajnav ul.in-page li:last a').focus() : ele.find('a.hp-prev').click();
            }
            else if (e.keyCode == 9) {
                e.preventDefault();
                ele.find('a.hp-next').hasClass('hp-disabled') ? $('.module2 a.primary').focus() : ele.find('a.hp-next').click();
            }
        });
        return this;
    },
    pageReady: function () {
        $('#ajnav ul.in-page li:eq(0)').addClass('active');
        $('#module-01 .offerapply span.off-txt').length > 0 && $('#module-01 .offerapply span.off-txt').parents('.offer').addClass('spl-offer'); 
        (OPEN.config.APP.isAndroid) && $('#module-01 #hero-offer10').addClass('andr');
        $('.module1 .offer *').each(function () {
            $.trim($(this).html()) == "" && $(this).css({'height': 0, 'padding': 0,'margin':0})
        });
        $("#featured div.details .learn-more").focusout(function (e) {
            $("#all-cards .cards-product .viewall-cards").focus();
        });
        $("#all-cards .cardart-carousel .offer-details a").focusout(function (e) {
            $("#all-cards .cardart-carousel #carousel-next").focus();
        });
        this.setCarousel().rmactions().tabAccess();
    }
};