OPEN.homePage.compare = { 
    "bkpt":"",
    prepareCarouselItems:function(maxItems,callback,eleinfo){
        var carslPrnt=$("#cards-type-view1 >div"),carsl=$('.carousel-set3'), slides=$('.carousel-set3 ul.slides'),slide=$('.carousel-set3 .slides>li').not(".clone"),slideContents=slide.children('div').clone(),totalslides=Math.round(slideContents.length/maxItems),inc=0,allcontent="",carouselcontent="";
        slide.html("");slides.html("");carslPrnt.find('.carousel-set3').remove();
        for(var i=0;i<totalslides;i++){

            for(var j=inc;j<maxItems;j++){
                if(typeof slideContents[j] != "undefined") {
                    typeof slide[i] == "undefined" && slide.push(document.createElement("li"));
                    slide[i].innerHTML += slideContents[j].outerHTML;                    
                }
                else {
                    break;
                }
            }
            allcontent += slide[i].outerHTML;
            inc=maxItems;maxItems+=maxItems;
        }
       slides[0].innerHTML=allcontent;carouselcontent=slides[0].outerHTML;
       carsl[0].innerHTML=carouselcontent;
       carslPrnt[0].innerHTML+=carsl[0].outerHTML;
        $('.carousel-set3').Amex_HP_Slider({
			selector: ".slides > li",
            animation: "slide",
            animationLoop: true,
            slideshowSpeed: 9000000000,
            startAt:typeof callback != "undefined" ? callback(eleinfo.prevEle,eleinfo.prevElecount):0,
            start: function (slider)
            {
                $('body').removeClass('loading');
                //typeof callback != "undefined" && callback(eleinfo.prevEle,eleinfo.prevElecount);
            },
            after: function (slider) {
                
                /* live person tagging implementation : start*/
                var viewId = slider.find(".view").eq(slider.currentSlide).attr("id");
                typeof (lpTag) != 'undefined' ? lpTag.vars.push([ {scope:"page",name:"carousel",value: viewId}]) : null;
                typeof(lpTag) =="object"  &&  typeof(lpTag.vars.send)=="function" &&  lpTag.vars.send();
                /* live person implementation : end*/
                
            }
        });
    },
    comparePageReady: function () {       
        _this=this;
        _this.bkpt=$(window).width() > 660 ? "L" : "S";
       _this.prepareCarouselItems($(window).width()>660?3:2);
        var comp_rgtclk = $(".module3 .carousel-set3 ul.slides>li");
        var comp_crdlkn = $("#compare-cards #compare-cards-content li a");
        comp_crdlkn.focus(function (e) {
            $(this).parent().find("p").show();
        })
        comp_crdlkn.focusout(function (e) {
            $(this).parent().find("p").hide();
        });
        var ss = false;
        $(".module3 .carousel-set3 li:nth-child(3n) a.carousel_item").live('keydown', function (e) {
            var ele = $(this).parents(".hp-viewport").siblings('ul');
            if (e.shiftKey && e.keyCode == 9) {
                e.preventDefault();
                $(this).parent().parent().prev().find('a').focus()
            }
            else if (e.keyCode == 9) {
                ele.find('a.hp-next').click();
                $(this).parent().parent().next().focus();
                //e.preventDefault(); 
                if ($(this).parent().parent().index() == 2) {
                    ss = true
                    e.preventDefault();
                    e.stopPropagation();
                    $('.module3 .carousel-set3').find('li').eq(3).find('a').focus();
                    return false;
                }
                else
                {
                    if (ss) {
                        e.preventDefault();
                    }
                }
            }

        });
        $(".module3 .carousel-set3 li:last-child a.carousel_item").live('keydown', function (e) {
            e.preventDefault();
            if (e.keyCode == 9) {
                $('#card-offers a').focus();
                e.preventDefault();
            }
        });
        if ($("body").hasClass("res_Medium")) {
            ($(".first-module").hasClass("module3")) && ($("#cards-type-heading").css("margin-top", "55px"));
        }
        if (touch)
        {
            $(window).width() > 660 ? $(".module3 .view-holder .view1 .offer .slides li p").show() : null;
        }
        else
        {
            var _width = $(window).width();

            var compareHover = function ()
            {
                $(document).on('mouseover', 'a.enable,a.carousel_item_heading', function (e)
                {
                    $(this).addClass('active');
                    $(this).siblings("p").addClass('active');
                    var self = this;
                    function mouseout()
                    {
                        $(document).off('mouseout', mouseout);
                        $(self).removeClass('active');
                        $(self).siblings("p").removeClass('active');
                    }
                    ;
                    $(document).on('mouseout', mouseout);
                });
            }

            var callDesk = function (w)
            {
                if (w > 830)
                {
                    $(".carousel_item").addClass('enable');
                    compareHover();
                } else
                {
                    $(".enable").removeClass("enable");
                }
            }

            $(window).resize(function (e)
            {
                _width = $(window).width();
                callDesk(_width);

            });

            callDesk(_width);
        }
    },
    comparePageResize: function () {
        winWidth=$(window).width(); 
        winWidth > 660 && touch ? $(".module3 .view-holder .view1 .offer .slides li p").show() : null;
        eleinfo={
             prevEle:$(".carousel-set3 .hp-control-nav .hp-active").parent().index(),
             prevElecount:$(".carousel-set3 .slides>li").not(".clone").size()
        }  
     if(this.bkpt=="L"){
        winWidth<661  && (this.prepareCarouselItems(2,this.triggerActiveElement,eleinfo),this.bkpt="S")
     }
     else{
        winWidth>=661 && (this.prepareCarouselItems(3,this.triggerActiveElement,eleinfo),this.bkpt="L")
        }
         
    },
    triggerActiveElement:function(prevEle,prevElecount){
     elecount=$(".carousel-set3 .slides>li").not(".clone").size();
     crrEleFlag=$(".carousel-set3 .slides>li").eq(prevEle).length>0?true:false;
     diff=elecount-prevElecount;
        if(prevEle!=0){
           //$(ele).eq(prevEle + diff).find("a").trigger("click");
           return crrEleFlag?prevEle:(prevEle + (diff));
        }
        else return 0;
    }
};

