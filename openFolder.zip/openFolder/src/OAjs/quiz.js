var Quiz = {
    header: "How do you typically pay your Card bill?",
    section: [{
        option: "I pay my balance in full each month.",
        section: {
            header: "What's better for your business? Rewards or cash back?",
            section: [{
                title: "Rewards points redeemable toward travel, hotel stays and more.",
                header: "Are premium Card benefits important to your business?",
                section: [{
                    title: "Yes, premium benefits are a must.",
                    header: "Here are the recommended Cards for your business:",
                    cards: [92, 111]
                }, {
                    title: "No thanks, standard benefits are fine.",
                    header: "Here are the recommended Cards for your business:",
                    cards: [111, 89]
                }]
            }, {
                title: "Cash back on eligible business purchases.",
                header: "Here is the recommended Card for your business:",
                cards: [499]
            }, {
                title: "I'm interested in rewards or cash back.",
                header: "Are premium Card benefits important to your business?",
                section: [{
                    title: "Yes, premium benefits are a must.",
                    header: "Here are the recommended Cards for your business:",
                    cards: [92, 499, 111]
                }, {
                    title: "No thanks, standard benefits are fine.",
                    header: "Here are the recommended Cards for your business:",
                    cards: [499, 111, 89]
                }]
            }]
        }
    }, {
        option: "I pay monthly, but like the option to carry a balance with interest.",
        section: {
            header: "What's better for your business? Rewards or cash back?",
            section: [{
                title: "Rewards points redeemable toward travel, hotel stays and more.",
                header: "Which of these rewards is the best choice for your business?",
                section: [{
                    title: "<span>Membership Rewards<sup>&reg;</sup> points</span><span class='small_txt'>I want to earn points that I can use toward travel, hotel stays, merchandise, gift cards and event tickets.</span>",
                    header: "Here is the recommended Card for your business:",
                    cards: [79]
                }, {
                    title: "<span>Delta Sky Miles<sup>&reg;</sup></span><span class='small_txt'>I want to earn miles that I can use on Delta.</span>",
                    header: "Are premium Card benefits important to your business?",
                    section: [{
                        title: "Yes, premium benefits are a must.",
                        header: "Here are the recommended Cards for your business:",
                        cards: [756, 141, 113]
                    }, {
                        title: "No thanks, standard benefits are fine.",
                        header: "Here is the recommended Card for your business:",
                        cards: [113]
                    }]
                }, {
                    title: "<span>Starwood Preferred Guest<sup>&reg;</sup></span><span class='small_txt'>I want to earn Starpoints<sup>&reg;</sup> for hotel award nights and free flights with SPG Flights.</span>",
                    header: "Here is the recommended Card for your business:",
                    cards: [474]
                }, {
                    title: "<span>Lowe's Business Rewards<sup>&reg;</sup></span><span class='small_txt'>I want to earn points to use for Lowe's gift and rewards cards.</span>",
                    header: "Here is the recommended Cards for your business:",
                    cards: [251]
                }]
            }, {
                title: "Cash back on eligible business purchases.",
                header: "Here is the recommended Card for your business:",
                cards: [1043]
            }, {
                title: "I'm interested in rewards or cash back.",
                header: "Are premium Card benefits important to your business?",
                section: [{
                    title: "Yes, premium benefits are a must.",
                    header: "Here is the recommended Card for your business:",
                    cards: [756]
                }, {
                    title: "No thanks, standard benefits are fine.",
                    header: "Here are the recommended Cards for your business:",
                    cards: [113, 474]
                }]
            }]
        }
    }, {
        option: "I prefer more than one way to pay.",
        section: {
            header: "Here is the recommended Card for your business:",
            cards: [499]
        }
    }, {
        option: "I'm flexible and interested in all payment options.",
        section: {
            header: "What's better for your business? Rewards or cash back?",
            section: [{
                title: "Rewards points redeemable toward travel, hotel stays and more",
                header: "Which of these rewards is the best choice for your business?",
                section: [{
                    title: "<span>Membership Rewards<sup>&reg;</sup> points</span><span class='small_txt'>I want to earn points that I can use toward travel, hotel stays, merchandise, gift cards and event tickets.</span>",
                    header: "Are premium Card benefits important to your business?",
                    section: [{
                        title: "Yes, premium benefits are a must.",
                        header: "Here are the recommended Cards for your business:",
                        cards: [92, 111]
                    }, {
                        title: "No thanks, standard benefits are fine.",
                        header: "Here are the recommended Cards for your business:",
                        cards: [111, 89]
                    }]
                }, {
                    title: "<span>Delta Sky Miles<sup>&reg;</sup></span><span class='small_txt'>I want to earn miles that I can use on Delta.</span>",
                    header: "Are premium Card benefits important to your business?",
                    section: [{
                        title: "Yes, premium benefits are a must.",
                        header: "Here are the recommended Cards for your business:",
                        cards: [756, 141, 113]
                    }, {
                        title: "No thanks, standard benefits are fine.",
                        header: "Here is the recommended Card for your business:",
                        cards: [113]
                    }]
                }, {
                    title: "<span>Starwood Preferred Guest<sup>&reg;</sup></span><span class='small_txt'>I want to earn Starpoints<sup>&reg;</sup> for hotel award nights and free flights with SPG Flights.</span>",
                    header: "Here is the recommended Card for your business:",
                    cards: [474]
                }, {
                    title: "<span>Lowe's Business Rewards<sup>&reg;</sup></span><span class='small_txt'>I want to earn points to use for Lowe's gift and rewards cards.</span>",
                    header: "Here is the recommended Card for your business:",
                    cards: [251]
                }]
            }, {
                title: "Cash back on eligible business purchases.",
                header: "Here are the recommended Cards for your business:",
                cards: [499, 1043]
            }, {
                title: "I'm interested in rewards or cash back.",
                header: "Are premium Card benefits important to your business?",
                section: [{
                    title: "Yes, premium benefits are a must.",
                    header: "Here are the recommended Cards for your business:",
                    cards: [92, 756]
                }, {
                    title: "No thanks, standard benefits are fine.",
                    header: "Here are the recommended Cards for your business:",
                    cards: [499, 111, 89]
                }]
            }]
        }
    }]
};