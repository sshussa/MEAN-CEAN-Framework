OPEN.moduleNav = {
    //navigation to the next module by arrow functionality
    moduleScroller: {
        modules:null,
        isClickedScrollArrow: false,
        winHeight: $(window).height()/2,
        scrollArrow: $('.open.res_Large .scroll-arrow'),
        navclickeditem:"",
        isnavclicked:false,
        moduleResize: function (o) { //functionality on resolution change
            var _this = this,secPos="";
            _this.scrollArrowRightPos(o);
            if (($(document).scrollTop() >= $('#iNavHdWrap').height() && $('#iNMbWrap').css('display') == 'none') || ($('#iNavHdWrap').css('display') == 'none' && $(document).scrollTop() >= $('#iNMbWrap').height())) {
                _this.scrollArrowPos(o);
            }
            !_this.isnavclicked   ?(($(".last-module").attr("id")==$("#ajnav .in-page li.active").find("a:not(.invisible)").not(".ignore-ele").attr("class") || $(".last-module").find(".view-holder").attr("id")==$("#ajnav .in-page li.active").find("a:not(.invisible)").not(".ignore-ele").attr("class") || ($(window).scrollTop() + $(window).height() >= $(document).height() - 20))?($(".last-module").length!=0 && o.CLS.scrl_arrow.addClass('up')):(o.CLS.scrl_arrow.removeClass('up'))):
            (($(".last-module").attr("id") == _this.navclickeditem.attr("class") || $(".last-module").find(".view-holder").attr("id") == _this.navclickeditem.attr("class")) || ($(window).scrollTop() + $(window).height() >= $(document).height() - 20) ?
            ( setTimeout(function(){
                        o.CLS.scrl_arrow.addClass('up');_this.navclickeditem="";
                    },600)
):				setTimeout(function(){
                        o.CLS.scrl_arrow.removeClass('up');_this.navclickeditem="";
                    },600)
                )
           _this.modules!=null && _this.modules.each(function (index, element) {
               
                    if (!_this.isClickedScrollArrow) {
                        _this.modules.removeClass('scroll-active');
                       
                    }
              //var s=setTimeout(function(){
                ($(element).attr("id")==$("#ajnav .in-page li.active").find("a:not(.invisible)").not(".ignore-ele").attr("class") || $(element).find(".view-holder").attr("id")==$("#ajnav .in-page li.active").find("a:not(.invisible)").not(".ignore-ele").attr("class")) &&
                        $(element).addClass('scroll-active');
                       // clearTimeout(s);
                //},500)
                        //console.log("on scroll"+$('.scroll-active').attr("id"));
                    typeof o.glb_vrbs != "undefined" && (OPEN.config.glb_vrbs._navFlag = false);
                    typeof _navFlag != "undefined" && (_navFlag = false);
            });

        },
        scrollArrowPos: function (o) { //vertical position of arrow
            var _this = this;
            if ($(window).scrollTop() + window.innerHeight >= $("#iNavNGI_FooterMain").offset().top) {
                var scrollPos1 = parseInt($(window).scrollTop() + window.innerHeight - $('#iNavNGI_FooterMain').offset().top);
                o.CLS.scrl_arrow.css('margin-bottom', scrollPos1 + "px");
            } else {
                o.CLS.scrl_arrow.css('margin-bottom', 0);
            }
        },
        scrollArrowRightPos: function (o) { //horizoantal position of arrow
            var _this = this;
            var arrowRightPos = $(window).width()<1440 && $(window).width()>660?o.CLS.MWWrapper.offset().left+15:o.CLS.MWWrapper.offset().left;
            o.CLS.scrl_arrow.css('right', arrowRightPos);
        },
        main: function (o) {
            var _this = this;
            _this.scrollArrowPos(o);
            _this.scrollArrowRightPos(o);
            o.CLS.scrl_arrow.css('bottom', '25px');
            var offset = null;
            var nextMod = null;
            var body_html = $('html, body');
            o.CLS.scrl_arrow.click(function (e) {
                if ($('.scroll-active').hasClass('last-module') || o.CLS.scrl_arrow.hasClass('up')) {
                    _this.modules.removeClass('scroll-active');
                     e.target=$("#ajnav .in-page li:eq(0)").hasClass("ignore-ele")?$("#ajnav .in-page li:eq(1)").find("a:not(.invisible)")[0]:$("#ajnav .in-page li:eq(0)").find("a:not(.invisible)")[0];                    
                    if(isCompare){
                        $("#ajnav .in-page").trigger(e);
                    }else{
                        $("#ajnav .in-page li:eq(0)").find("a:not(.invisible)").not(".ignore-ele").trigger("click");
                    }
                    if (touch) {
                        o.CLS.scrl_arrow.removeClass('up');
                    }
                } else {
                     _this.modules.removeClass('scroll-active');
                    e.target=$("#ajnav .in-page li.active").next().find("a:not(.invisible)").not(".ignore-ele")[0]; 
                    if(isCompare){
                        $("#ajnav .in-page").trigger(e);
                    }else{
                        $("#ajnav .in-page li.active").next().find("a:not(.invisible)").not().trigger("click");
                    }
                }

            });

        }
    },
    moduleNavPageReady: function (o) {
        var ms=this.moduleScroller;
        ms.modules=o.CLS.modules;
        ms.modules.each(function () {
           /*isNav dynamic addition is removed*/
            o.APP.module_array.push($(this)[0]);
            
        });
        if (o.APP.module_array.length >= 2) {            
            $(o.APP.module_array[0]).addClass('first-module scroll-active');
            $(o.APP.module_array[o.APP.module_array.length - 1]).addClass('last-module');
            var spotlightEnd = $('.first-module').offset().top + $('.first-module').height();
            var lpos = $(".first-module").offset().left;
        } else {
            $(o.APP.module_array[0]).addClass("onlyModule");
            var spotlightEnd = only_mdle.offset().top;
            var lpos = only_mdle.offset().left;
            only_mdle.css("bottom", "0px !important");
            only_mdle.length && scrl_arrow.css('height', 0);
        }
        (o.APP.module_array.length == 2 || o.APP.module_array.length == 1) && $("#find-offers .view").addClass("bg");
        if ('ontouchstart' in document.documentElement) { /*arrow for all touch devices **/
            $('.scroll-arrow').addClass('touch-arrow');
        }
        !(touch) && $(".scroll-arrow").mouseenter(function () {
            $(this).addClass("mouseovr");
        }).mouseleave(function () {
            $(this).removeClass("mouseovr")
        });
        ms.main(o);
        $("#ajnav .aj-inpage .in-page").on("click","a",function(){
                ms.navclickeditem=$(this);
               // ms.isnavclicked=true;
        })
    },
    moduleNavPageResize: function (o) {
        this.moduleScroller.moduleResize(o);
        this.moduleScroller.navclickeditem="";
    },
    moduleNavPageScroll: function (o) {
        this.moduleScroller.navclickeditem==""?(this.moduleScroller.isnavclicked=false):(this.moduleScroller.isnavclicked=true)
        this.moduleScroller.moduleResize(o);
        $(".scroll-active").hasClass('first-module') && o.CLS.scrl_arrow.css('margin-bottom', 0);/*personalization**/
    }
};