/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


OPEN.component = {
    /*
    @container[String Selector]: in which the video should be inserted.
    @src[String]: URL of the video to be played.
    @clsName[String](optional): class name when video frame need to be styled in specifc way.
    @isMask[Boolean](optional): transparent background mask. 
	@option(Object](optional): to get more options. Ex: {isOpen:false}
	@opened : (call back function for open)
	@closed : (call back function for close)
   */
    playYouTubeVideo : function(container,src,clsName,isMask,opened,closed) {
		var opnFlg = true;
	if($(container).length != 0 && src !=""){
            var frame = (isMask?'<div class="video-mask"></div>':'')+'<div id="video-container"><a class="close-icon" href="#"></a><iframe src="' + src + '&wmode=opaque"class="' + (clsName||'') + '"  frameborder="0" allowfullscreen width="100%" height="100%"></iframe></div>';
            var cntr = $("#video-container");
            setTimeout(function(){opnFlg = false;},500);
            cntr.length == 0 && $(container).prepend(frame).on("click touch","a.close-icon,.video-mask",function(e) {
				if(!opnFlg)
				{
                    e.preventDefault();
					$(container).off("click touch","a.close-icon,.video-mask");
                    $(container).find(".video-mask").remove();
                    $("#video-container").remove();
					setTimeout(function(){
						typeof closed != "undefined" && closed.call();
					},0);
				}
				opnFlg = false;
                return false;
            });
			setTimeout(function(){
				typeof opened != "undefined" && opened.call(cntr);
			},0);
	}
	return false;
    }
};