/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

OPEN.component = {
    alignCenter: function(obj, _addCard) {
        var ovrlypostn = ($(window).width() / 2) - obj.width() / 2 - 10;
        obj.css({
            top: $(_addCard)[0].parentNode.offsetTop + 40,
            left: ovrlypostn < 0 ? Math.abs(ovrlypostn) : ovrlypostn
        }).show();
        $(window).width() <= 660 ? (obj.css('display', 'none'), $("#overlay-mask").css('display', 'none')) : null;
        navigator.userAgent.match(/Android/i) && obj.css("top", 20);
    },
   overlay_filter_resz:function(){
       
               	if($(window).width() > 830)
        {
        OPEN.config.APP.add_ovly && OPEN.config.APP.fltr_selc &&$('.card-types ul li .radio-normal').siblings('input#'+OPEN.config.APP.fltr_selc).click();     
            
        }   
        else if($(window).width() <= 830 && $(window).width() >= 660){
            var temp_fltsec= OPEN.config.APP.fltr_selc;
            if( $itag.PageId==6958){
             var pmcVal = OPEN.overlayfilter.filterData.overlay_Filters.filterList["see_all_crds"].pmc;
             OPEN.overlayfilter.filterData.overly_cardsSelection(pmcVal, true);             
            OPEN.config.APP.fltr_selc=temp_fltsec;
           }
           else{
                $('.card-types ul li .radio-normal').siblings('input#see-all-crds').click();
           }
           OPEN.config.APP.fltr_selc=temp_fltsec;
            
        }
        
   } 
    
};