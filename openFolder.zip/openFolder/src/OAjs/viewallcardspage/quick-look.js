
/*********************************************** Quick Look Tray section code starts here *********************************************/
OPEN.quickLook = {
        //initialize Quick look overlay.
        _sldPmc: {},
		_wot:"",
        initialize: function() {
            var _wrapper = $("#quick-view-overlay"),_this=this;
            $("a.quick-look-link").live("click", function() {
                //Feb release
                pmc = $(this).closest('li[class^="pmc"]').attr('class').replace(" slide-cards","");/*slide-cards class is used in show hide Variation*/
                pmc == "pmc-499" && _wrapper.addClass("lto");
                pmc == "pmc-111" && $("#quick-view-overlay #ovrly-goodfor-col").addClass("pmc-111");
                OPEN.config.APP.itag_cardname = OPEN.universal.getProductName(pmc);
                (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', OPEN.config.APP.itag_cardname + '_QuickLook'): null; ////FEB release										

                /* Fix for Safari on Mac*/
                var initDocWidth = $(document).width();
                OPEN.components.scrollovrly_rst("hidden", 17);
                if (jQuery.browser.msie) {
                    OPEN.universal.isDesktop ? $('body,html').css({
                        'overflow': 'hidden'
                    }) : null;
                } else {
                    OPEN.universal.isDesktop ? $('body').css({
                        'overflow': 'hidden'
                    }) : null;
                }
                var docWidthDiff = initDocWidth - $(document).width();
                OPEN.universal.isDesktop ? $('body').css({
                    'margin-right': Math.abs(docWidthDiff)
                }) : null;
                var qick_CmrBtn = $(this).parent().find('.compare-btn');
                var parent = $(this).closest('li');
                OPEN.quickLook._sldPmc = {
                    pmc: parent.attr('class'),
                    isEnable: qick_CmrBtn.parent().attr('disabled') ? true : false,
                    compare: qick_CmrBtn.hasClass("remove-btn") ? true : false,
                    heading: parent.find(".heading span > a").html(),
                    titleattr: parent.find(".heading span > a").text(),
                    cardartimg: parent.find(".list-content-card a.card-art > img").attr('src'),
                    rating: parent.find('div[class*="rating"]').attr("class").split(" ")[1],                    
                    lo: parent.find(".limited-offer").length ? true : false,
                    limitedoffer: parent.find(".limited-offer").html(),
                    desc: parent.find(".list-content").html(),
                    count: $(this).parent().parent().find(".viewallratings").html(),
                    btns: parent.find('.button-holder').html(),
                    applyLnk: parent.find('.applybutton').attr('href'),
                    learnMoreLnk: parent.find(".learn-more-link").attr('href'),
                    goodfor_col: _this.getGoodFor(pmc,goodForJSONData),
                    rewardsheader: parent.find(".rewards").html(),
                    rewards: parent.find(".list-right-sidebar ul.points").clone().wrap('<ul>').parent().html(),
                    charge: parent.find(".payment-type").html(),
                    terms: parent.find(".term-conditions"),
                    annualfee : parent.find('.annual-fee').html(),
                    itempropcontent: parent.find('p[itemprop]').html()
                };
                OPEN.quickLook.show($(this));
                /*personalization*/
                $('#quick-view-overlay #quick-content-wrap .ovrly-rewards-col .earn-points-tile p span.off-txt').length > 0 && $('#quick-view-overlay').addClass('spl-offer');
                //hide earn-points-tile if child is benefit-only to for quick look
                $('#quick-view-overlay #quick-content-wrap .card-type .earn-points-tile .benefit-only').length > 0 &&  $('#quick-view-overlay #quick-content-wrap .card-type .earn-points-tile').hide();
                $('#quick-view-overlay #quick-content-wrap .card-type .earn-points-tile .plum-benefits').length > 0 &&  $('#quick-view-overlay #quick-content-wrap .card-type .earn-points-tile').hide();                
                OPEN.components.viewAll_touch ?$("#quick-view-overlay .custom-scrollbar").addClass("touch-scrollbar") : $("#quick-view-overlay .custom-scrollbar").openScrollber({wheelSpeed:10,wheelLock:false});
                /*OPEN.quickLook._wot=OPEN.components.ql_bodyscroll($(window).scrollTop());
				OPEN.quickLook._wot.set();*/
				$("#quick-view-overlay .viewport").scrollTop(0);
				return false;
            });

            _wrapper.find('button.circle-close-icon').live("click", function(e) {
                //Find out the card name for omniture
                OPEN.config.APP.itag_cardname = OPEN.universal.getProductName(_wrapper.find('#overlay-card').attr("class"));
                if (typeof OPEN.config.APP.itag_cardname !== 'undefined') {
                    (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', OPEN.config.APP.itag_cardname + '_CloseQuickLook'): null; //FEB omniture		`		
                }
                //Hide the quick look
                OPEN.quickLook.hide();
                //$(window).resize(); /*May B Defered Defect*/
                $("#quick-view-overlay #ovrly-goodfor-col").removeClass("pmc-111"); /* Auguat B */
                return false;
            });
            $("#overlay-mask").click(function() {
                $("#overlay-mask").hide();
                _wrapper.find('button.circle-close-icon').click();
                OPEN.components.scrollovrly_rst("auto", 0);
				//OPEN.quickLook._wot.release();
            });
			OPEN.components.viewAll_touch && this.stopPageScroll();
		return this;
        },
        //display Quick look overlay.
        show: function(ele) {
            $("#overlay-mask").show();
            var _wrapper = $("#quick-view-overlay");
            _wrapper.show();
            //this.alignoverlyCenter(_wrapper);
            //OPEN.universal.getJsonData('/ngaosbn/json/view-all-cards.json',"GET",function(){
            MXcards = this;
            this.quicklookovrly(_wrapper, OPEN.quickLook._sldPmc, ele);
            $(".loading").hide();
            //});
            // el=document.getElementById('quick-content-wrap');		
            scrollStartPos = 0;
            /*Personalization*/            

        },
        //hiding Quick look overlay.
        hide: function() {
            $("#quick-view-overlay .ovrly-rewards-col").find("#annual-fee").length ==0 && $("#quick-view-overlay .ovrly-rewards-col").prepend('<div id="annual-fee"></div>');
            /* May B */
            var _wrapper = $("#quick-view-overlay");
            _wrapper.hasClass("lto") && _wrapper.removeClass("lto");
            $("#ovrly-goodfor-col,.card-type,#rewards,#charge-card,#annual-fee").html("");
            $(".ovrly-rewards-col").find(".earn-points-tile").remove();
            $(".card-type").find(".limited-offer").remove();
            $("#overlay-mask").hide();
            
            $(".card-header .quicklook-title-container,.card-header .quicklook-buttons-container").html("");            
            
            _wrapper.hide(); /* April A*/
            _wrapper.hide();
            OPEN.components.scrollovrly_rst("auto", 0);
			//OPEN.quickLook._wot.release();
            OPEN.config.APP.quickL = false; /* feba pavan */
            OPEN.config.APP.qkovly = false; /*AprilA*/
            $("html,body").unbind('keydown');
            document.ontouchmove = function(e) {
                return true;
            }
        },
        quicklookovrly: function(ovrly, data, ele) {
            if (data) {
				/* Clearing all the existing card data*/
                $("#ovrly-goodfor-col,.card-type,#rewards,#charge-card,#annual-fee,.quicklook-title-container,.quicklook-buttons-container,.quicklook-card-container").html("");
                ovrly.find(".btm-links").remove();
				$("#overlay-card").removeAttr("class");
				/* Initializations */
                var ratinghldr = data.rating || "addreviewratings",cardTitle="", cardButtons="", cardContent="", cardArt="", pmcInt = data.pmc.split('-'),
				cardHeader= $(".card-header");
				
				var overlayCard= "<div id='overlay-card' class='"+ data.pmc + "'></div>";
				overlayCard=$(overlayCard).html(cardHeader.html());				
				!$(".card-header").find("#overlay-card").length ? cardHeader.html("").prepend(overlayCard):$("#overlay-card").addClass(data.pmc);
						
				
				/* populating card title and star ratings */
				cardTitle += '<p class="heading"><span class="crd-title" >' + data.heading + '</span>';
				cardTitle += '<span class="viewallratings ' + ratinghldr + '">' + data.count + '</span></p>'; 
				cardHeader.find(".quicklook-title-container").prepend(cardTitle);
				
				/* populating buttons*/
				cardButtons +='<span id="overlay-button-holder" class="button-holder">' + data.btns + '<span class="clrBoth"></span></span>';
				cardHeader.find(".quicklook-buttons-container").prepend(cardButtons).find(".quick-look-link").remove();
				
				/* populating card art*/
				cardArt +='<a itemprop="url" href="'+data.learnMoreLnk+'" class="card-art card-art-container flat-cardart-' + pmcInt[1] + '" title="' + data.titleattr + '"><img class="card-art-img" src="' + data.cardartimg + '" /></a>';
				cardHeader.find(".quicklook-card-container").prepend(cardArt);	
				
               /* welcome offer content as part of june08 start*/
                $(".card-type").prepend(data.desc).find(".sub-heading,ul.points, p[itemprop]").remove();
                var itemproplength = data.itempropcontent;
                var itemPropContent = '<p itemprop=description>' +data.itempropcontent+ '</p>';
                    if(itemproplength != null){
                    $("#quick-content-wrap .card-type").prepend(itemPropContent);
                    };
                $(".card-type").find(".earn-points-tile .offer-points").append($(".card-type").find(".earn-points-tile .offer-details"));
               // OPEN.quickLook._sldPmc.lo && $("body").hasClass("newgrid") && $(".card-type").find(".earn-points-tile").prepend("<span class='limited-offer'>"+OPEN.quickLook._sldPmc.limitedoffer+"</span>");
              
                /* welcome offer content as part of june08--End*/
                
                $("#charge-card").html(data.charge);
                $("#rewards").html(data.rewardsheader).append(data.rewards);  
                
                
                $("#rewards .limited-offer").remove();
                $("#ovrly-goodfor-col").html(data.goodfor_col);
                ovrly.append('<div class="btm-links">' + data.terms.html() + '</div>');
                
                $(".ovrly-rewards-col #annual-fee").html(data.annualfee);
                $('.card-type').find('.annual-fee').remove();
                $(".btm-links a").each(function() {
                        if (/Assurance Disclosures/g.test($(this).text())) {
                            $(this).prev().remove();
                            $(this).remove();
                        }
                    })
            }
        },
        alignoverlyCenter: function(obj) { 	
            var _wrapper = $("#quick-view-overlay");
            var quicklkovrlypostn = ($(window).width() / 2) - _wrapper.width() / 2 - 30;
            _wrapper.css({
                top: 40,
                left: quicklkovrlypostn < 10 ? quicklkovrlypostn + 12 : quicklkovrlypostn + 30
            }).show();
            navigator.userAgent.match(/Android/i) && _wrapper.css("top", 20);
        },
        quickLook_interaction: function() {           
            $("*").bind("click", function() {
                if ($(window).width() <= 830) {
                    OPEN.config.APP.quickL && (OPEN.config.APP.quickL = false);
                    OPEN.config.APP.qkovly && (OPEN.config.APP.qkovly = false); /*AprilA*/
                } else {                  
                    OPEN.config.APP.quickL = true;
                }
            });
        },
        quickLook_resizeEnd: function() {
            var _wrapper = $("#quick-view-overlay");
            var qk_lksec = $("#quick-view-overlay,#overlay-mask")
           // $(window).width() <= 830 && OPEN.config.APP.once && (OPEN.config.APP.qkovly = _wrapper.is(":visible"), OPEN.config.APP.once = false);
            //_wrapper.css("display") == "block" && this.alignoverlyCenter(_wrapper);
            if ($(window).width() >= 831) {
                OPEN.config.APP.once = true;
               // OPEN.config.APP.qkovly && (OPEN.config.APP.quickL ? (OPEN.components.scrollovrly_rst("hidden", 17), qk_lksec.show()) : null); /* May B*/
                $("#comparision").find(".section li").not(".pmc-hldr").length < 3 ? $(".compare-btn").not(".remove-btn").removeClass("disable").parent().css("opacity", 1).attr("title", "Click to add to compare tray").attr("disable") : null
            }
		OPEN.components.viewAll_touch ?$("#quick-view-overlay .custom-scrollbar").addClass("touch-scrollbar") : $("#quick-view-overlay .custom-scrollbar").openScrollber({wheelSpeed:10,wheelLock:false});
		//OPEN.components.ql_bodyscroll($(window).scrollTop());
		 _wrapper.is(":visible") ? (OPEN.components.scrollovrly_rst("hidden", 17), qk_lksec.show()) : null; 
        },
		getGoodFor:function(pmc, goodForJSONData){
			return (goodForJSONData?goodForJSONData.heading+goodForJSONData[pmc]:"");
		},
		stopPageScroll:function(){
			var el=$("#quick-view-overlay .viewport")[0],scrollStartPos=0,elP=$("#quick-view-overlay")[0],ovly=$("#overlay-mask")[0];
					el.addEventListener("touchstart", function(event) {
						scrollStartPos=this.scrollTop+event.touches[0].pageY;
						event.preventDefault();
					},false);
					el.addEventListener("touchmove", function(event) {
						this.scrollTop=scrollStartPos-event.touches[0].pageY;
						event.preventDefault();
					},false);
					elP.addEventListener("touchmove", function(event) {					
						event.preventDefault();
					},false);
					ovly.addEventListener("touchmove", function(event) {					
						event.preventDefault();
					},false);
		}
    }
    /*********************************************** Quick Look Tray section code ends here *********************************************/