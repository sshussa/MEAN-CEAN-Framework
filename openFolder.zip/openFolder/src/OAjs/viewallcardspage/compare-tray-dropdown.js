OPEN.newCompareTray = {
    bauCmr: true,
    isCompareClick: false,
    dblFlg : true,
	
	/* initializing the new compare tray functionality*/
    init: function () {
		/* initializing the closer variable */
        var comrLnk = $("#compare-cards-text"), crdOvly = $('#comparision');
        //$(window).width() >= 660 && (OPEN.config.ID._cmprCrds = "#comparision");
        ($(window).width() < 660) ? (OPEN.compareTray.bauCmr = true) : (OPEN.compareTray.bauCmr = false);
        var ovlH = 0,ovlOriH = 0,ovlCnt = 0,ovlOriCnt = 0;
		
		/* initializing the private functionality which is can be accessed out side of this object*/
        var private = {
            cmrFlg: true,
            cntrPs: 0,
			/* update the cards count in (0/3) text in all scenarios*/
            cardsCount: function (comrLnk, crdOvly) {
                var initscl = true;
                var cntrRw = crdOvly.find("div.viewport.custom-scrollbar ul > li");
                $(window).width() >= 830 ? (OPEN.compareTray._crdTry.length == 3 ? cntrRw.addClass("disabled") : cntrRw.removeClass("disabled")) : OPEN.compareTray._crdTry.length == 2 && cntrRw.addClass("disabled");
                this.cmr_Pos(comrLnk, crdOvly);
                crdOvly.is(":visible") && OPEN.newCompareTray.update_tooltip.apply(this, [crdOvly.find("li.pmc-hldr"), ($('#comparision').find(".divider-line-arrow-down")), false]);
                var cnt = OPEN.compareTray._crdTry.length;
                var cmrCnt = $(window).width() <= 830 ? (cnt == 3 ? 2 : cnt) : cnt;
				
                $("#compare-cards-text .card-count,#compare-cards-text-mob .card-count").html("(" + cmrCnt + "/" + ($(window).width() <= 830 ? 2 : 3) + ")");
                return this;
            },
			/* initializing the new compare tray with default values and interaction behaviour of it*/
            cmrTrayOvly: function (comrLnk, crdOvly) {
                var crd = 0;
                var wScl = 0;
                var crdH = crdOvly.outerHeight();
                crdOvly.find(".divider-line-arrow-down").after($("#cards-list-overlay .cards-list")[0].outerHTML)
                crdOvly.find(".cards-list").after($("#cards-list-overlay #newcmprtryftr")[0].outerHTML);
                $('a.compare_cards').css("opacity", 0.3).addClass('disabled').attr('onclick', 'return false');
                var self = this;
                $(window).bind('touchmove scroll', function (e) {
                    !OPEN.compareTray.bauCmr && crdOvly.is(":visible") && self.cmr_Pos(comrLnk, crdOvly);
                });
				
                comrLnk.click(function () {
                    crdOvly.find("ul.overview>li a").removeAttr("href","#");
					!crdOvly.find("ul.overview>li").last().is(":visible") && crdOvly.find("ul.overview>li").last().removeAttr("style");
                    crd = comrLnk.offset();
                    crdOvly.stop().fadeToggle("fast", "linear") && !OPEN.components.viewAll_touch && crdOvly.openScrollber({wheelSpeed:10});
                    if (ovlH == 0) {
                        var ovrlH = crdOvly.outerHeight(), ovrlCnt = crdOvly.find(".viewport").height();
                        ovlH = (ovrlH - iNavHeight), ovlOriH = ovrlH, ovlCnt = (ovrlCnt - iNavHeight), ovlOriCnt = ovrlCnt;
                    }
					
					var trayCrds = crdOvly.find("ul.section>li");
					for(var i=0;i<=trayCrds.not(".pmc-hldr").length-1;i++){
						
						
						trayCrds.eq(i).find(".close-icon-compare-tray").css("display") !="block" && (trayCrds.eq(i).find(".close-icon-compare-tray").show())
					}
					crdOvly.find("ul.section .card-art").attr('title','');
                    self.cmr_Pos(comrLnk, crdOvly);
                    OPEN.newCompareTray.update_tooltip.apply(this, [crdOvly.find("li.pmc-hldr"), (crdOvly.find(".divider-line-arrow-down")), false]);
                });
                $("html").on('click', function (event) {
                    if (!$(event.target).hasClass("compare-btn") && !$(event.target).closest(crdOvly).length && $(window).width()>660) {
                        !$(event.target).closest(comrLnk).length && crdOvly.hide();
                    }
                });
                $(".back-btn").click(function () {
                    crdOvly.hide();
                });
                return this;
            },
			/* adding a card to new compare tray with disable and enable state*/
            addCard: function (crdOvly) {
                var self = this;
                crdOvly.find('ul.overview> li,ul.overview> li a,ul.overview> li span,ul.overview> li button').live("click touch", function (e) {              
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    e.stopPropagation();
					
                    var cntr = this.nodeName != "LI" ? $(this).closest("li") : (this);
                    if ((!cntr.hasClass("disabled") && !cntr.hasClass("active")) || (this.nodeName == "BUTTON" && cntr.hasClass("active"))) {
                        var cntr = null;
                        cntr = this.nodeName != "LI" ? $(this).closest("li") : (this);
						OPEN.newCompareTray.dblFlg = true;
				
                        var eleCrd = cntr.attr('class').split(' ')[0],
                                card = crdOvly.find("li.pmc-hldr"),
                                tlp = crdOvly.find(".divider-line-arrow-down");
                        if ($('.list-view').find('li.pmc-' + eleCrd.split('-')[1] + ' .compare-btn').trigger("click", true), this.nodeName != "BUTTON" && cntr.addClass("active disabled"), card.size()) {
                            OPEN.newCompareTray.update_tooltip.apply(this, [card, tlp, true]);
							
                        }
                    } else {
                      typeof(tlp) !="undefined"  &&  tlp.hide()
                    }

                });
                return this;
            },
			/* re position & adjust the heigt of new compare tray on landing/resizing/scrolling */
            cmr_Pos: function (lnk, crdOvly) {
				if($(window).width() < 830 && $(window).width() > 660){
						!$("body").hasClass("res_Medium") && $("body").addClass("res_Medium");
				}
				
				($(window).width() < 660) ? (OPEN.compareTray.bauCmr = true,crdOvly.removeClass("scroll")) : (OPEN.compareTray.bauCmr = false);
                if (!OPEN.compareTray.bauCmr && $(window).width() > 660) {
                    var crdOvly = crdOvly,
                            Scr = brwsr_type.match(/iPhone/i) ? "mbl-scroll" : "scroll",
                            chtCntr = $(".chat-container").offset().left,
                            cmrlnk = lnk.offset().left, wndW = $(window).width(),
							hdrLt = $("#viewall-header").offset().left,
							wScl = $(window).scrollTop();
                   wndW <= 830 && (cmrlnk -= 80);wndW == 1024 && (cmrlnk -= 80);
					
                    crdOvly.css({
                        "left": (parseInt(cmrlnk) - lnk.width() / 2)-(wndW >= 830 ? ((wScl < iNavHeight)?hdrLt+45:45):0)
                    });
					if (ovlH <= 0) {
                        var ovrlH = crdOvly.outerHeight(), ovrlCnt = crdOvly.find(".viewport").height();
                        ovlH = (ovrlH - iNavHeight), ovlOriH = ovrlH, ovlCnt = (ovrlCnt - iNavHeight), ovlOriCnt = ovrlCnt;
                  }
                    this.cntrPs = parseInt(crdOvly.css("left")) + crdOvly.width()+((wScl < iNavHeight)?hdrLt:0);
                    (wndW >= 830 && this.cntrPs > chtCntr )? (this.cmrFlg = false):(this.cmrFlg = true);
                    if (wndW >= 830 && !this.cmrFlg && chtCntr !=0) {
                        
						!touch && crdOvly.css({
                            "left": chtCntr - (crdOvly.width() + ((wScl < iNavHeight)?hdrLt:0)+ 20)
                        });
                    }
                    wScl >= iNavHeight ? (crdOvly.removeClass(Scr).css({"top":wndW >= 830?125:112})) : (crdOvly.addClass(Scr));
                    ((parseInt(crdOvly.css("left")) + (crdOvly.width() / 2)+((wScl < iNavHeight)?hdrLt:0)) < (parseInt(cmrlnk) + (lnk.width() / 2 - (wndW <= 830 ? 0 : 20)))) ? (wndW <= 830? crdOvly.find(".arrow-up").css("right", "24.5%"):crdOvly.find(".arrow-up").css("right", "28%")) : crdOvly.find(".arrow-up").css("right", "47.5%");
                    (crdOvly.css("display") == 'block' && !(/AppleWebKit\/600/).test(navigator.userAgent)) && ((wScl < iNavHeight) ? ((crdOvly.outerHeight()-ovlH)!=2 && parseInt(crdOvly.outerHeight()) != ovlH) && (crdOvly.css("height", ovlH), crdOvly.find(".viewport").css("height", ovlCnt), crdOvly.css("display") == 'block' && !OPEN.components.viewAll_touch &&  crdOvly.openScrollber({wheelSpeed:10})) : ((crdOvly.outerHeight()-ovlOriH)!=2 && parseInt(crdOvly.outerHeight()) != ovlOriH) && (crdOvly.css("height", ovlOriH), crdOvly.find(".viewport").css("height", ovlOriCnt), crdOvly.css("display") == 'block' && !OPEN.components.viewAll_touch && crdOvly.openScrollber({wheelSpeed:10})));
						touch && (wndW == 1024) && crdOvly.find(".arrow-up").css("right", "27%");
					
                }
				else
				{
					crdOvly.is(":visible")?crdOvly.removeAttr("style").show():crdOvly.removeAttr("style");
					OPEN.compareTray._crdTry.length == 0  && crdOvly.hide();
				}
            },
			/* repopulate the required values on resizing */
            cmr_Resize: function (lnk, crdOvly) {
                var initscl = true;                
                var self = this,once=$(window).width() < 660?true:false;
                $(window).resize(function (event) {
                    self.cardsCount(lnk, crdOvly);
					var once=$(window).width() < 660?true:false;					
					($(window).width() < 660) ? (OPEN.compareTray.bauCmr = true,crdOvly.removeClass("scroll")) : (OPEN.compareTray.bauCmr = false);
					 setTimeout(function () {                            
                            self.cardsCount(lnk, crdOvly);
							once=true;
                        }, 1000);
						
                });
                return this;
            },
			/* intializing required private methods on page load*/
            init: function () {
                this.cmrTrayOvly(comrLnk, crdOvly).addCard(crdOvly).cardsCount(comrLnk, crdOvly).cmr_Resize(comrLnk, crdOvly);
				OPEN.components.viewAll_touch && crdOvly.find(".custom-scrollbar").addClass("touch-scrollbar")
            }

        }
        return private.init();
    },
	/* update the down arrow of new compare tray(tool tip) based on the empty card availability and this is a global method to be accessed outside */
    update_tooltip: function (card, tlp, add_ing) {
        var pmc_cnt = $('#comparision .section').find("li.pmc-hldr:visible");
        if (pmc_cnt.length) {
			tlp.show();
            var crd = pmc_cnt.eq(0),
                    crdPos = (crd !== void 0 && (crd.position().left) + crd.width() / 2)-(tlp.width()/2);
        } else {
            var crd = $('#comparision .section').find("li:visible").last(),
                    crdPos = (crd !== void 0 && (crd.position().left) + crd.width() / 2)-(tlp.width()/2);
					tlp.hide();
        }
        tlp.css({"left": crdPos});
    }
};