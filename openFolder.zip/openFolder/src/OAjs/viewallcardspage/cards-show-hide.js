/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* 
    Created on : Oct 8, 2015, 3:47:49 PM
    Author     : Janmejay
*/
/********************************************** Card show / hide code Starts here ****************************************************/

OPEN.newShowhide = {
	sliding:false,
    init: function() {
		var o=this;
        OPEN.newShowhide.getCardCount(); 
        $('.toggle-cards>span').on('click touch',function(){
                OPEN.newShowhide.toggleDisplay(o);

        });
    },
    getCardCount:function() {
        var _lstViewCrd = $('#list-view > li:visible');
        var _counter = 6;
        $("#list-view > li").removeClass("slide-cards");
        if(_counter < _lstViewCrd.length){
            for(i=_counter; i < _lstViewCrd.length;i++){
                $(_lstViewCrd[i]).addClass("slide-cards").hide(0);
            }
            $(".toggle-cards").show();
			var allCardsWrap=$("#cards-content"), toggleText=$(".toggle-text");
			if(allCardsWrap.hasClass("show-less")){
			  if(_counter < _lstViewCrd.length){
				for(i=_counter; i < _lstViewCrd.length;i++){
					$(_lstViewCrd[i]).addClass("slide-cards").show(0);
				}
			  }
			}
        }else{
            $(".toggle-cards").hide();
        }
		OPEN.config.APP._visibleCardsArr = $('#card-section [class^="pmc"]:visible')
    },
    toggleDisplay:function(o){
        var allCardsWrap=$("#cards-content"),
		toggleText=$(".toggle-text");
		if(!o.sliding){
			o.sliding=true;
			$("ul#list-view li.slide-cards").slideToggle(650,function(){o.sliding=false});		
			setTimeout(function(){
				if(allCardsWrap.hasClass("show-more")){
					allCardsWrap.removeClass("show-more");
					allCardsWrap.addClass("show-less");
				   toggleText.text("SHOW FEWER CARDS");
					OPEN.cardsView.grid_divider();
				}
				else {
						allCardsWrap.removeClass("show-less");
						allCardsWrap.addClass("show-more");
						toggleText.text("SHOW MORE CARDS");

					$("html,body").animate({
						scrollTop: OPEN.components.iNavHeight 
					}, 500, function(){
						
					});
				}
				$('.toggle-cards .arrow-down').toggleClass('arrow-up');
				$("body").hasClass("newgrid") && !OPEN.components.viewAll_touch && $(".open #cards-content ul.section>li").openScrollber({wheelSpeed:10,wheelLock:false});
				OPEN.config.APP._visibleCardsArr = $('#card-section [class^="pmc"]:visible');
			},660);
		}
    }
};

