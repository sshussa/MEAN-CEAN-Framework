
/********************************************** Filter code Start here ****************************************************/
//Page level Filter components.
OPEN.filter = {

        //purpose : Filter Json data.
        //params : null
	baufilter: true,	
        FArr : [],
        curSel:null,
        filterData: {
            payment_type: {
                header: "Payment Type",
                filterList: {
                    paym_tpe_all_crds: {
                        label: "All Cards",
                        title: "Check if you are interested in a all Cards.",
                        features: [],
                        pmc: [92, 111, 141, 89, 1043, 756, 113, 474, 499, 79, 251]
                    },
                    chg_cards: {
                        label: "Charge Cards",
                        title: "Check if you are interested in a Charge Cards.",
                        features: ["Pay in full every month", "Flexible spending limit that can adjust over time"],
                        overlay: true,
                        pmc: [111, 92, 499, 89]
                    },
                    credit_cards: {
                        label: "Credit Cards",
                        title: "Check if you are interested in a Credit Cards.",
                        features: ["Option to carry a balance with interest"],
                        overlay: true,
                        pmc: [113, 141, 756, 474, 251, 1043, 79]
                    }
                }
            },
            rewards: {
                header: "Rewards",
                filterList: {
                    cash_bk_rwds: {
                        label: "Cash Back",
                        title: "Check if you are interested in Cash back Rewards.",
                        features: [],
                        pmc: [499, 1043]
                    },
                    partner_rwds: {
                        label: "Partner Rewards",
                        title: "Check if you are interested in Partner Rewards.",
                        features: [],
                        pmc: [113, 141, 756, 474, 251]
                    },
                    membership_rwds: {
                        label: "Membership Rewards<sup>&reg;</sup> Program",
                        title: "Check if you are interested in Membership Rewards.",
                        features: [],
                        pmc: [111, 92, 89, 79]
                    },
                    travel_rwd: {
                        label: "Travel Rewards",
                        title: "Check if you are interested in Travel Rewards.",
                        features: [],
                        pmc: [113, 92, 141, 756, 474, 89, 111]
                    }

                }
            },
            benefits: {
                header: "Benefits",
                type: "checkbox",
                filterList: {
                    paym_flx: {
                        label: "Flexible Payment Options",
                        title: "Check if you want Payment flexibility.",
                        features: [],
                        pmc: [499]
                    },
                    airport_lounge: {
                        label: "Airport Lounge Access",
                        title: "Check if you want Airport lounge access.",
                        features: [],
                        pmc: [92, 756]
                    },
                    concierge_srv: {
                        label: "Concierge Services",
                        title: "Check if you want Concierge services.",
                        features: [],
                        pmc: [92, 756]
                    },
                    hotel_upgrades: {
                        label: "Travel Perks",
                        title: "Check if you want Travel Perks.",
                        features: [],
                        pmc: [92, 111, 113, 141, 756, 474]
                    },
                    baggage_insurance: {
                        label: "Car Rental Loss and Damage Insurance",
                        title: "Check if you want Car Insurance.",
                        features: [],
                        pmc: [92, 111, 141, 89, 1043, 756, 113, 474, 499, 79, 251]
                    },
                    roadSideAssist: {
                        label: "Roadside Assistance",
                        title: "Check if you want Roadside assistance.",
                        features: [],
                        pmc: [92, 111, 141, 89, 1043, 756, 113, 474, 499, 79, 251]
                    }
                }
            },
            overlay_Filters: {
                header: "SHOW CARDS BY FEATURE",
                overlay: true,
                filterList: {
                    see_all_crds: {
                        label: "See All Cards",
                        title: "Check if you want all Cards.",
                        features: [],
                        pmc: [92, 111, 141, 89, 1043, 756, 113, 474, 499, 79, 251]
                    },
                    charge_crds: {
                        label: "Charge Cards",
                        title: "Check if you wantCharge Cards.",
                        features: [],
                        pmc: [111, 89, 92, 499]
                    },
                    credit_crds: {
                        label: "Credit Cards",
                        title: "Check if you want Credit Cards.",
                        features: [],
                        pmc: [756, 141, 79, 113, 251, 1043, 474]
                    },
                    flexible_crds: {
                        label: "Flexible Payment Card",
                        title: "Check if you want Flexible Payment Card.",
                        features: [],
                        pmc: [499]
                    },
                    trl_rwds: {
                        label: "Travel Rewards",
                        title: "Check if you want Travel Rewards.",
                        features: [],
                        pmc: [756, 141, 113, 111, 92, 474, 89]
                    },
                    mbr_rwds: {
                        label: "Membership Rewards<sup>&reg;</sup> Program",
                        title: "Check if you want Membership Rewards.",
                        features: [],
                        pmc: [79, 111, 89, 92]
                    }
                }
            },
            availableCards: [92, 111, 141, 89, 1043, 756, 113, 474, 499, 79, 251]
        },
        renderCardFilters: function(cfg) {
            if($("body").hasClass("newfilter")){
                OPEN.filter.baufilter = false;
            }
            var section = "";
            var ovlyCnt = "";
            var mini_Filters = $("#cards-list-overlay").find('.card-types');
			var frag = document.createDocumentFragment();
			
            var data = this.filterData;
            data && (this.filterData = data);
            
            frag.appendChild($('<ul></ul>')[0]);
            $.each(data, function(header, element) {
                if (element.header && element.header != "") {
                    !element.overlay && (section = $('<li><a class="filter_section_header" title=' + element.header + '>' + element.header + '<span class="chevron"></span></a></li>'));
                    var ftrMkp;
                    if (element.filterList) {
                        ftrMkp = '<ul>';
                        $.each(element.filterList, function(index, items) {
                            var altTag = items.label.replace(/(<sup>|<\/sup>)/g, "");
                            var type = element.type == 'checkbox' ? 'checkbox' : 'radio';
                            ftrItm = "<li><input id='" + index.split("_").join("-") + "' type='" + type + "' name='" + header.split("_").join("-") + "' title='" + altTag + "' /><label for='" + index.split("_").join("-") + "'>" + altTag + "</label>";
                            !element.overlay ? ftrMkp = ftrMkp + ftrItm : ovlyCnt = ovlyCnt + ftrItm + "</li>";
                            var features = '';
                            if (items.features && $(items.features).length > 0) {
                                features = '<ul class="filter-cnt">';
                                $.each(items.features, function(index, feature) {
                                    features = features + "<li><span class='filter-cnt-wrap'>" + feature + "</span></li>";
                                });
                                features = features + "</ul>";
                            }
                            ftrMkp = ftrMkp + features + "</li>";
                        });
                    }
                    section.append(ftrMkp);
                }
                frag.firstChild.appendChild(section[0]);
            });
            //detail_Filters.append(frag);
			
			if( $itag.PageId!=="16944"){var detail_Filters = $(cfg.ID._filterPanel);
            detail_Filters[0].insertBefore(frag, detail_Filters[0].firstChild);         
            OPEN.components.customRadio.set(detail_Filters);
            OPEN.components.customCheckBox.set(detail_Filters);      
            detail_Filters.find("input:radio:first").attr('id') == 'paym-tpe-all-crds' ? detail_Filters.find("input:radio:first").attr('checked', 'checked').siblings('span').addClass("radio-checked") : $('#list-view > li').show();
            detail_Filters.find('ul li a').bind('click touch', function() {
                if(OPEN.filter.baufilter){
                    $(this).toggleClass('active');
                    $(this).next().slideToggle("slow");
		}
            }); ovlyCnt != "" && mini_Filters && $(mini_Filters).append($('<ul>' + ovlyCnt + '</ul>'));
            OPEN.components.customRadio.set(mini_Filters);
            OPEN.components.customCheckBox.set(mini_Filters);}
else{

		   ovlyCnt != "" && mini_Filters && $(mini_Filters).append($('<ul>' + ovlyCnt + '</ul>'));
            OPEN.comp_pagecomponent.customRadio.set(mini_Filters);
            OPEN.comp_pagecomponent.customCheckBox.set(mini_Filters);}
        },
        getFilterCards: function(cfg) {
            var cardArt = $("a.card-art");
            var crd_cnt = $("#cards-content");
            var flrPanel = $(cfg.ID._filterPanel);
            flrPanel.find("input[type='radio'],input[type='checkbox']").live('change', function(e) {
                e.stopPropagation();
                OPEN.filter.FArr.push($(this).attr('name'));
                var selectedCards;
                var pmcVal = OPEN.filter.filterData[$(this).attr('name').split('-').join('_')].filterList[$(this).attr('id').split('-').join('_')].pmc;
                var itag_option_1 = $(this).attr('title').split(' ').join('');
                var itag_option = itag_option_1.replace(/(<sup[\s\S]+?>|<\/sup>)/g, " "); //FEB omniture
                var option_name = $(this).attr('name').split('-').join('');
                if ($(this).attr('checked') == "checked") {
                    OPEN.filter.setItagAction(option_name, itag_option);
                } //FEB omniture
                $(this).is(':checked') ? (selectedCards = OPEN.filter.intersectCards(pmcVal, OPEN.filter.selectedCards("", flrPanel)), selectedCards != null && typeof selectedCards != 'undefined' ? OPEN.filter.renderCards(selectedCards, $(this), cfg) : null) : ($(this).is("input:checkbox") ? (selectedCards = OPEN.filter.selectedCards(this, flrPanel), selectedCards != null && typeof selectedCards != 'undefined' ? OPEN.filter.renderCards(selectedCards, $(this), cfg) : null) : null);

               !OPEN.config.APP.apply_fltr &&(selectedCards.length <= ($(document).width() < 768 ? 4 : 6) && $("html,body").animate({ /*ios7*/
                    scrollTop: OPEN.components.iNavHeight + 10
                }, 1000));
                OPEN.config.APP._visibleCardsArr = $('#card-section [class^="pmc"]:visible');
                crd_cnt.hasClass("list-view") && ($(OPEN.config.APP._visibleCardsArr).css("border-top", "2px solid #EEE"), $(OPEN.config.APP._visibleCardsArr[0]).css("border-top", "none"));
            });
            

            if (OPEN.components.viewAll_touch && $(window).width() >= 600) {
                cardArt.not(".pmc-hldr .card-art").click(function(e) {
                    cardArt.next().hide();
                })
                $('.learnmore-btnn').click(function() {
                    $(this).show();
                });
            } else {
                cardArt.hover(function(e) {
                    cardArt.next(".learnmore-btnn").hide();
                    $(this).next().not(".add-card").show();
                }, function() {
                    $(this).next().not(".add-card").hide();
                });
                $('.learnmore-btnn').hover(function() {
                    $(this).show();
                });
            }
                $(window).focus(function() {
                    $('.learnmore-btnn').hide();
                }).blur(function() {
                $('.learnmore-btnn').hide();
                });

            /*$('.learnmore-btnn').live('click touch',function(){window.location = '../OAhtml/productdetails.html';return false;});*/
            /*($(window).width() > 660 && $('#comparision').css("display") == "none") ? $("#list-view").parent().parent().css({
                paddingTop: 76
            }): null;*/
            return this;
        },
        setItagAction: function(name, opt) {
            switch (name) {
                case "paymenttype":
                    (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'paymenttype-' + opt + '_Filter'): null; //FEB release				
                    break;
                case "rewards":
                    (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'rewards-' + opt + '_Filter'): null; //FEB release				
                    break;
                case "benefits":
                    (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'benifits-' + opt + '_Filter'): null; //FEB release			
                    break;
            }
        },
        //intersect the filter selections.
        intersectCards: function(currItem, prevItems) {
            var selectedCrds = [];
            if (currItem.length == 0) {
                return prevItems
            } else {
                if (prevItems.length == 0) {
                    return currItem
                } else {
                    $(currItem).each(function(idx, val) {
                        $.inArray(val, prevItems) > -1 ? selectedCrds.push(val) : null;
                    })
                }
            }
            return selectedCrds;
        },
        //fetching pmc values corresponding selected cards.
        selectedCards: function(currItem, panel) {
            var prevSel = [];
            panel.find("input:checked").not(currItem).each(function() {
                var crrItem = OPEN.filter.filterData[$(this).attr('name').split('-').join('_')].filterList[$(this).attr('id').split('-').join('_')].pmc;
                prevSel.length == 0 ? prevSel = crrItem : prevSel = OPEN.filter.intersectCards(crrItem, prevSel);
            });
            return prevSel;
        },
        //disable the filter item that has no cards.
        _disableFilterItems: function(pmc, ele, cfg) {
            var prePmc = pmc;
            var eleName = "";
            var panel = $(cfg.ID._filterPanel);
            var _disable = 'disabled';
            var fltrItms = panel.find("input[type='radio']:checked,input[type='checkbox']:checked");
            $.each(panel.find("input[type='radio'],input[type='checkbox']").not(ele), function(indx, m) {
                var cards = 0;
                eleName = "";
                var crdItm = $(this).attr('name');
                if (!$(ele).is("input:checkbox")) {
                    var prevSel = [];
                    $.each(fltrItms, function(indx, m) {
                        var chk = $(this).is("input:checkbox") && $(this).is(':checked') && true;
                        if (crdItm != $(this).attr('name') || chk) {
                            eleName = "";
                            var crrItem = OPEN.filter.filterData[$(this).attr('name').split('-').join('_')].filterList[$(this).attr('id').split('-').join('_')].pmc;
                            prevSel.length == 0 ? prevSel = crrItem : prevSel = OPEN.filter.intersectCards(crrItem, prevSel);
                        }
                    });
                    pmc = prevSel;
                } else {
                    var prevSel = [];
                    $.each(fltrItms, function(indx, m) {
                        eleName = "";
                        var chk = !$(ele).is(':checked') ? crdItm != $(this).attr('name') : true;
                        if (!chk) {
                            chk = $(this).is("input:checkbox") && $(this).is(':checked') && true;
                        }
                        var chkfix = $(ele).attr("id") != "paym-flx" ? (crdItm != "payment-type") : true;
                        if (chk && chkfix) {
                            var crrItem = OPEN.filter.filterData[$(this).attr('name').split('-').join('_')].filterList[$(this).attr('id').split('-').join('_')].pmc;
                            prevSel.length == 0 ? prevSel = crrItem : prevSel = OPEN.filter.intersectCards(crrItem, prevSel);
                        }
                    });
                    pmc = prevSel;
                }
                var pmcVal = OPEN.filter.filterData[$(this).attr('name').split('-').join('_')].filterList[$(this).attr('id').split('-').join('_')].pmc;
                if (pmcVal.length > 0) {
                    cards = OPEN.filter.intersectCards(pmcVal, pmc);
                }
                eleName != $(this).attr('name') ? cards.length == 0 ? $(this).attr(_disable, true).prop('checked', false).parent().addClass(_disable).find("span").removeClass("radio-checked").removeClass("checkbox-checked") : $(this).removeAttr(_disable).parent().removeClass(_disable) : !$(this).is("input:checkbox") && $(this).removeAttr(_disable).parent().removeClass(_disable);

            });

        },
        //reset the filter items and set to default values.
        resetFilter: function(cfg, ele) {
            $('.reset-fltr').bind('click touch', function() {
                OPEN.filter.FArr = [];
                var panel = $(cfg.ID._filterPanel);
                var crd_cnt = $("#cards-content");
                var rdoChkd = "radio-checked";
                var chkd = "checkbox-checked";
                $(panel).find('span').removeClass(rdoChkd).removeClass(chkd);
				OPEN.components.removeHash("#charge-cards","#credit-cards");
                panel.find('input').removeAttr('disabled').parent().removeClass('disabled');
                panel.find("input:checkbox,input:radio").prop('checked', false);
				panel.find('input').removeClass("ftr-applied");
                if (panel.find("input:radio:first").attr('id') == 'paym-tpe-all-crds') {
                    panel.find("input:radio:first").attr('checked', 'checked').siblings('span').addClass(rdoChkd);
                    var dftVal = [];
                    dftVal = OPEN.filter.selectedCards("", panel);
                    dftVal != null && typeof dftVal != 'undefined' && OPEN.filter.renderCards(dftVal, null, cfg);
                } else $('#list-view > li').show();
                //reset gpc filter card 
                var _lstViewCrd = $('#list-view');
                  _lstViewCrd.find('li.pmc-gcp-card').css("display","block !important").show();
                  
                (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Filter_Reset'): null;
                !cfg.APP.apply_fltr && $("html,body").animate({
                    scrollTop: OPEN.components.iNavHeight + 10
                }, 1000);
                OPEN.config.APP._visibleCardsArr = $('#card-section [class^="pmc"]:visible');
                crd_cnt.hasClass("list-view") && ($(OPEN.config.APP._visibleCardsArr).css("border-top", "2px solid #EEE"), $(OPEN.config.APP._visibleCardsArr[0]).css("border-top", "none"));
				cfg.APP.apply_fltr && OPEN.NEW_FILTER.apply_Filter(false, $("body").hasClass("newfilter"));
                 $('#list-view > li').removeAttr('data-card');
				//cfg.APP.apply_fltr && $("#cards-content").removeAttr("style");
                return false;
            });
            return this;
        },
        //renders Cards according to filter logic.
        renderCards: function(pmc, ele, cfg) {
            var crrCrdPos = [];
            var selCard = [];
            var crds = pmc.length;
			var crrItem;
			this.curSel = {pmc:pmc,ele:ele};
			if (ele != null) {
                crrItem = this.filterData[$(ele).attr('name').split('-').join('_')].filterList[$(ele).attr('id').split('-').join('_')].pmc;
            if (crrItem.length != 13 || $(ele).attr('id') == "paym-tpe-all-crds") {
                ele != null && OPEN.filter._disableFilterItems(pmc, ele, cfg);
            }
			 }
			if(cfg.APP.apply_fltr && ele != null ){return false;}
            var _lstViewCrd = $('#list-view');
            _lstViewCrd.find('li').not('.points li,.list-content-card li, .list-right-sidebar li').hide().attr('data-card','no');		
            pmc ? $.each(pmc, function(idx, crdPmc) {
                _lstViewCrd.find('li.pmc-' + crdPmc).show().removeAttr('data-card');
            }) : null;
			
            //GPC Filter logic
          
            if(($(ele).attr('id') == "paym-tpe-all-crds" || $("#filter-panel").find("input:radio:checked").attr('id')== "paym-tpe-all-crds") && $("#filter-panel input:checked").length < 2){
      
                _lstViewCrd.find('li.pmc-gcp-card').css("display", "block !important").show();
			
            }
                        
            OPEN.cardsView.grid_divider();
            pmc.length == OPEN.filter.filterData.availableCards.length && _lstViewCrd.find('li.pmc-gcp-card').removeAttr("data-card");
            //$("body").hasClass("newshowhide") && OPEN.newShowhide.getCardCount();
            OPEN.config.APP._visibleCardsArr=$('#card-section [class^="pmc"]:visible');
			!OPEN.components.viewAll_touch && $('.open.newgrid #list-view .custom-scrollbar').openScrollber({wheelSpeed:10,wheelLock:false});
           
        },
		 //filter the available cards in the cards overlay.
    ovrlay_FilterCards: function() {
        var _cardsLst = $("#cards-list-overlay");
        _cardsLst.find(".cards-list li:last-child").after(_cardsLst.find(".close-icon").focus());
        _cardsLst.find(".card-types input[type='radio']").live('change', function() {
            var pmcVal = OPEN.filter.filterData[$(this).attr('name').split('-').join('_')].filterList[$(this).attr('id').split('-').join('_')].pmc;
            $(this).is(':checked') ? (pmcVal != null && typeof pmcVal != 'undefined' ?  OPEN.filter.overly_cardsSelection(pmcVal, true) : null) : null;
        });
    },
    overly_cardsSelection: function(pmc, tag) {
        var _cardsLst = $("#cards-list-overlay");
        _cardsLst.find(".cards-list li").hide();		
        tag ? $.each(pmc, function(k, crdPmc) {
            _cardsLst.find(".cards-list li[class='pmc-" + crdPmc + "-sml'],.cards-list li[class='pmc-" + crdPmc + "-sml disabled']").show();
        }) : null;

    },
        filter_Interaction: function() {
            $('.filter-cnt li').live('click touch', function() {
                $(this).parent().parent().find('input').click();
            });
        }

    }
    /*********************************************** Filter code ends here *********************************************/
