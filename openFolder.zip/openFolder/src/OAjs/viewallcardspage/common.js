
/********************************************** Reusable Components Start here **************************************/
//Page level reusable components.
OPEN.components = {

        //purpose : get the cards postions.
        //params : null
        getCrdPos: function(obj) {
            var curleft = curtop = 0;
            if (obj.offsetParent) {
                curleft = obj.offsetLeft;
                curtop = obj.offsetTop;
                while (obj = obj.offsetParent) {
                    curleft += obj.offsetLeft;
                    curtop += obj.offsetTop;
                }
            }
            return {
                left: curleft,
                top: curtop
            };
        },
        //change the default checkbox control to customized.
        customCheckBox: {
            set: function(ele) {
                var chk = "checkbox-normal";
                var chkd = "checkbox-checked";
                var chkb = ele.find('input:checkbox');
                chkb.css("opacity", "0").parent().append("<span class=" + chk + "></span>");
                //$(chkb + ":checked").siblings("span").addClass(chkd);
                chkb.live("click", function() {
                    $(this).siblings("span").toggleClass(chkd);
                })
            }
        },
        //change the default radio button control to customized.
        customRadio: {
            set: function(ele) {
                var rdo = ele.find('input:radio');
                var rdoChk = "radio-normal";
                var rdoChkd = "radio-checked";
                rdo.css("opacity", "0").parent().append("<span class=" + rdoChk + "></span>");
                $(rdo + ":checked").siblings("span").addClass(rdoChkd);
                rdo.live("click", function() {
                    $(this).parent().siblings("li").find(">span").removeClass(rdoChkd);
                    $(this).siblings("span").addClass(rdoChkd);
                    rdo = null;
                    OPEN.config.APP.fltr_selc=$('.card-types ul li .radio-normal.radio-checked').siblings('input').attr("id");
                })
            }
        },
        viewAll_touch: ("ontouchstart" in window && (/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/).test(navigator.userAgent)) || window.DocumentTouch && document instanceof DocumentTouch || (navigator.msMaxTouchPoints > 0),
        iNavHeight: $(window).width() > 660 ? $('#iNavHdWrap').outerHeight() : $('#iNMbWrap').outerHeight(),
        //purpose : to reuse a common Ajax method for all Ajax requests.
        ajax: function(url, type, dataType, callback) {
            $.ajax({
                url: url,
                type: type,
                dataType: dataType,
                beforeSend: function() {
                    onStartAjax();
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    callback.failure(XMLHttpRequest, textStatus, errorThrown);
                },
                success: function(data, textStatus) {
                    callback.success(data, textStatus);
                },
                complete: function(XMLHttpRequest, textStatus) {
                    onEndAjax();
                }
            });
        },
        scrollovrly_rst: function(val, num) {
            if (jQuery.browser.msie) {
                OPEN.universal.isDesktop ? $('body,html').css({
                    'overflow': val
                }) : null;
            } else {
                OPEN.universal.isDesktop ? $('body').css({
                    'overflow': val,
                    'margin-right': num
                }) : null;
            }
			
        },
		ql_bodyscroll:function(wo){
		var wot=wo;
		return {
			set:function(wo){
				$("#quick-view-overlay").is(":visible")?$('body').css("position","fixed"):($('body').css("position","static"),$(window).scrollTop(wot))
				},
			release:function(){				 
				$("#quick-view-overlay").is(":visible")?$('body').css("position","fixed"):($('body').css("position","static"),$(window).scrollTop(wot))
				}
			}
		},
		//reading # values of the current window URI.
        readHash:function(){
            var strUrl = window.location + "", hasQry = !!~strUrl.indexOf("?"), hashVle = strUrl.indexOf("#") > 0 ? strUrl.split("#")[1]||null:null;
            return hashVle && (hashVle.slice(0,hasQry?hashVle.lastIndexOf("?"):hashVle.length)||null);
        },
		//remove # values that specified as a function parameters.
		removeHash:function(rmvVle){
		var docUrl = window.location+"";
		var hashVle = [].slice.call(arguments);
			if(docUrl.match(hashVle.join("|")))
			{
				var docPos = $(document).scrollTop();
				window.location.href = docUrl.replace(new RegExp(hashVle.join("|"), 'g' ),"#");
				$('html,body').scrollTop(docPos);
			}
		}
		
		


    }
    /*********************************************** Reusable Components end here *********************************************/
