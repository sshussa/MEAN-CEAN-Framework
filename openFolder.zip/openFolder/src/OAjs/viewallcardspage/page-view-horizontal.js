
/*********************************************** New Filter Page view code starts here *********************************************/
OPEN.pageView = {
        initialize: function() {
            if($("body").hasClass("newfilter")){
                var bauPageView = $(".filter-section .page-view");
                bauPageView.find('a.grid').append("<span class='grid-icon'></span>");
                bauPageView.find('a.list').append("<span class='list-icon'></span>");
                $("#page-view-container").html(bauPageView.html());
            }
        }        
    };
/*********************************************** New Filter Page view code ends here *********************************************/