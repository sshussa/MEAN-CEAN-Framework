OPEN.gridView = {    
    initialize: function(){
        var hashVal = OPEN.components.readHash();
        var flrVal = hashVal && OPEN.universal.firstAllWords(hashVal.replace("-"," "));
        valElement = $("#filter-panel input[title='"+flrVal+"']");
        if(hashVal && valElement.attr('title') == flrVal){
        valElement.prop("checked", true).trigger("change").click();
        OPEN.NEW_FILTER.apply_Filter(true);
        OPEN.config.APP._visibleCardsArr = $('#card-section [class^="pmc"]:visible');
        }
       OPEN.universal.openNewTab(".term-conditions");
       OPEN.universal.openNewTab(".btm-links");
       
        if($("body").hasClass("newgrid")){
            var allBauCardsContent= $(".open #cards-content ul.section>li"); /*only gets BAU cards content*/
            allBauCardsContent.each(function(){
                var thisCardContent=$(this),
					offerContent = thisCardContent.find(".list-content .earn-points").html(),
					termsConditions = thisCardContent.find(".term-conditions").html(),
                                        offerBadge = thisCardContent.find(".list-content-card .pmc-card-details").html(),
                                        quicklink = thisCardContent.find(".list-view-btns").html();
                                       
                        
                //thisCardContent.find(".pmc-card-details").prepend(quicklink).find(".apply-button, .comparebutton, .learn-more-link, .devider").remove();
                
                //thisCardContent.find(".terms-and-condition-container").prepend(termsConditions).addClass('term-conditions');                
                //thisCardContent.find(".grid-offer-container").addClass("earn-points").html(offerContent).prepend(offerBadge).find(".viewallratings, .heading").remove().find(".offerapply").remove();
				/* For custom-scrollbar - start*/				
				thisCardContent.find(".list-content-card").children().not(".pmc-card-details,.terms-and-condition-container,.button-holder").wrapAll(("<div class='custom-scrollbar'><div class='viewport'><div class='overview'></div></div></div>")).parents(".custom-scrollbar").prepend('<div class="scrollbar"><div class="track"><div class="thumb"> </div></div></div>')
				 OPEN.components.viewAll_touch? thisCardContent.find(".custom-scrollbar").addClass("touch-scrollbar") : thisCardContent.find(".custom-scrollbar").openScrollber({wheelSpeed:10,wheelLock:false});
				/* For custom-scrollbar - end*/				
            });	
            $(".terms-and-condition-container a").each(function() {
                if (/Assurance Disclosures/g.test($(this).text())) {
                    $(this).prev().remove();
                    $(this).remove();
                }
            });
        }
    },
	setOnResize: function(){	
crds_cnter=($('.open.res_Medium #cards-content.grid-view .devider').length);	
$("body").hasClass("newgrid") && !$("body").hasClass("res_Small") && (OPEN.components.viewAll_touch ? $(".open #cards-content ul.section>li .custom-scrollbar").addClass("touch-scrollbar") : $(".open #cards-content ul.section>li .custom-scrollbar").openScrollber({wheelSpeed:10,wheelLock:false})) ;
$('.open.res_Medium #cards-content.grid-view .devider').show();
$('.open.res_Medium #cards-content.grid-view').find('.devider:eq('+(crds_cnter-1)+')').hide().end().find('.devider:eq('+(crds_cnter-2)+')').hide();	
		
	}
};