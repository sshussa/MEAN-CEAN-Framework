if (!window.OPEN) {
    var OPEN = {};
}

(function ($, window, document) {

    if (typeof jQuery == 'undefined') {
        throw new Error("JQuery library is not loaded which is mandatory to run the AMEX OPEN Application");
        return;
    }

    /*************************************************** Config Starts here ***********************************************/
    //Page level config details. but these are not Global variables.
    OPEN.config = {
        ID: {
            _filterPanel: "#filter-panel",
            _cmprCrds: "#comparision"
        },
        CLS: {
            _bodyClass: "",
            tray_section: ".section-holder .section li"
        },
        APP: {
            _visibleCardsArr: [],
            tgr_pop: false,
            qkovly: null,
            quickL: false,
            once: true,
            _iscookienable: true,
            itag_cardname: "",
            apply_fltr: false,
             fltr_selc: "",
             add_ovly:false,
             vac_cookie:false            
             
        }
    }

    /*************************************************** Config ends here ***********************************************/
    //Page level implementation 
    OPEN.cards = function () {

        //Closur global variables.

        var allCards = {
            // --------- Private methods which are encapsulated inside the structure.

            //fetching pmc values corresponding selected cards.
            ie11: function (currItem) {
                if (!!navigator.userAgent.match(/Trident.*rv\:11\./)) {
                    $("body").addClass("ie11");
                }
            },
            orientation_dom: function ()
            {
                window.addEventListener('orientationchange', function () {
                    if ($(window).width() < 600) {
                        $(".navheader li:first-child ul").addClass("no-call");
                        $(".no-call li").on('click', function () {
                            return false;
                        });
                    }
                });
            },
            MVT: function (val)
            {
                /*var qrV = void 0 !== val && val.split("-");
                
                var bdy = $("body");
                return {
                    newFilter: function ()
                    {
                        void 0 !== OPEN.NEW_FILTER && OPEN.NEW_FILTER.init();
                    },
                    newComparetray: function ()
                    {
                        void 0 !== OPEN.newCompareTray && OPEN.newCompareTray.init();
					},
                    newGrid: function ()
                    {
                    },
                    newShowhide: function ()
                    {
                        void 0 !== OPEN.newShowhide && OPEN.newShowhide.init();
                    },
                    init: function ()
                    {
                        var numV = qrV.length;                  
                        while (numV--)
                        {
                            var qval = qrV[numV].toLowerCase();
                            var jsV = 'new' + OPEN.universal.firstAllWords(qval.substring(3));
                            this[jsV] && bdy.addClass(qval) && this[jsV]();
                            bdy.addClass(qval);
                        }
                    }
                }*/
            },
            // --------- Public methods which are exposed out-side the structure.
            public: {
                //manipulate the data in card tray.
                compareTray: function (obj) {
                    //void 0 !== OPEN.compareTray && OPEN.compareTray.addCard(this).rmvCard(this,_).cmrTray_interaction(this);
                    void 0 !== OPEN.compareTray && OPEN.compareTray.crdsOverlay(this);
                },
                $browser: function () {
                    _.ie11();
                    OPEN.components.iNavHeight = $(window).width() > 660 ? $('#iNavHdWrap').outerHeight() : $('#iNMbWrap').outerHeight();
                    //var queryV = UBA.getQueryString("PARAM") || UBA.getQueryString("param");
                    
                    //typeof queryV != 'undefined' ? queryV : (typeof mvtParam != 'undefined' ? queryV = mvtParam : queryV );
                                        
                   // _.MVT(void 0 !== UBA && queryV).init();
				    void 0 !== OPEN.NEW_FILTER && OPEN.NEW_FILTER.init();
                },
                $compareTrayInit: function () {
					void 0 != OPEN.cust_scroll && OPEN.cust_scroll.scrollBar()
                    void 0 !== OPEN.compareTray && OPEN.compareTray.addCard(this).rmvCard(this, _).cmrTray_interaction(this);
                    void 0 !== OPEN.compareTray && OPEN.compareTray.cmrTray_Init(this);
                    

                },

                //filtering cards according to the filter logic.
                $filteredCards: function () {
                    void 0 !== OPEN.filter && OPEN.filter.getFilterCards(this).resetFilter(this).filter_Interaction()
                },
                //the function which has prefix('$') supposed to be executed bofore HTML structure renders on webpage.
                $renderCardFilters: function () {
                    //Genarate filter items with specified Json Structure.
                    void 0 !== OPEN.filter && OPEN.filter.renderCardFilters(this);
                },
                $quickLook: function () {
                    void 0 !== OPEN.quickLook && OPEN.quickLook.initialize().quickLook_interaction();
                },
//                grid_List: function () {
//                    void 0 !== OPEN.cardsView && OPEN.cardsView.setView().view_Interaction();
//                },
                $grid_List: function () {
                    void 0 !== OPEN.cardsView && OPEN.cardsView.setView().view_Interaction();
                    void 0 !== OPEN.cardsView && OPEN.cardsView.view_Init();
                },
                listview: function () {
                    void 0 !== OPEN.listview && OPEN.listview.initialize();
                },
                listviewBAU: function () {
                    void 0 !== OPEN.listviewBAU && OPEN.listviewBAU.initialize();
                },
                pageview : function(){
                    void 0 !== OPEN.pageView && OPEN.pageView.initialize();
                },
                grid_view:function(){
                    void 0 !== OPEN.gridView && OPEN.gridView.initialize();
                },
				
                //event handlers
                eventDelegates: function () {
                    //resize implementaion code is supposed to be placed in the following event block
                    $(window).resize(function (event) {
                        void 0 !== OPEN.compareTray && OPEN.compareTray.resize();
                        void 0 !== OPEN.findOffers && OPEN.findOffers.pageResize();
                    });

                    $(window).bind('resizeEnd', function () {
                        void 0 !== OPEN.compareTray && OPEN.compareTray.resizeEnd();
                        void 0 !== OPEN.quickLook && OPEN.quickLook.quickLook_resizeEnd();
                        void 0 !== OPEN.cardsView && OPEN.cardsView.view_resizeEnd();
						void 0 !== OPEN.gridView && OPEN.gridView.setOnResize();
                    });

                    //scrolling implementaion code is supposed to be placed in the following event block
                    $(window).scroll(function (event) {

                    });

                }
            }

        }
        for (var obj in this)
            allCards[obj] = this[obj];
        var _ = allCards;
        return allCards.public;
    }

    function INIT(init, inhr) {
        for (var obj in (OPEN.cards()))
            (init ? obj[0] == '$' : obj[0] != '$') && typeof (OPEN.cards()[obj]) == "function" && (OPEN.cards()[obj]).call(inhr);
    }

    $(document).ready(function (e) {
        //initialize the methods before HTML structure renders on web page.
        INIT(true, OPEN.config);
    });
    $(window).load(function (e) {
        //initialize the methods after all assets(HTML/CSS/JS) are loaded on web page.
        INIT(false, OPEN.config);
        //Call the resie method to run the resize logic on page load as well
        OPEN.compareTray.resize();
    });
})(window.jQuery, window, document);
