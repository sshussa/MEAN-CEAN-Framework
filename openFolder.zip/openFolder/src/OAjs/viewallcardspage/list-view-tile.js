
/*********************************************** List View section code starts here *********************************************/
OPEN.listview = {
    //initialize List View.
    initialize: function() {
		var allCardsContent= $(".open.newgrid #cards-content ul.section>li"); /*only gets newgrid cards content*/
		allCardsContent.each(function(){
			var thisCardContent=$(this),
				offerContent = thisCardContent.find(".list-content-card .earn-points").html(),
                                termsConditions = thisCardContent.find(".terms-and-condition-container").html();
                                
				//offerPoints = thisCardContent.find(".list-content .points").html(),
				//annualFee = thisCardContent.find(".list-content .annual-fee").html(),
				//offerBadge = thisCardContent.find(".list-content-card .pmc-card-details").html();
			//thisCardContent.find(".earn-points-tile").html(offerContent).prepend(offerBadge).find(".viewallratings, .heading").remove();
		thisCardContent.find(".list-content .earn-points-tile").html(offerContent).find(".viewallratings, .heading").remove();
                thisCardContent.find(".term-conditions").html(termsConditions)
				
                    //thisCardContent.find(".list-right-sidebar").html(offerPoints);
			//thisCardContent.find(".list-right-sidebar").append('<div class="annual-fee">' + annualFee + '</div>').find('.annual-fee-icon').remove();
		});
    }
};
/*********************************************** List View section code ends here *********************************************/