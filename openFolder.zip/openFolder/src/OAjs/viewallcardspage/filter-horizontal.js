OPEN.NEW_FILTER = {
	flrs:10,
	/* appling filter after selecting filter options under Payment/Rewards/Benifits section of new Filter panel */
	apply_Filter:function(rst, isNewReset)
	{
			
			OPEN.config.APP.apply_fltr = false;
            $('#list-view > li').removeAttr('data-card');
			OPEN.filter.curSel.pmc.length == 0 && (OPEN.filter.curSel.pmc = OPEN.filter.filterData.availableCards,$("#paym-tpe-all-crds").click().prop("checked",true)); 
			rst && void 0 !== OPEN.filter && OPEN.filter.renderCards(OPEN.filter.curSel.pmc,OPEN.filter.curSel.ele,OPEN.config);
			OPEN.config.APP.apply_fltr = true;
			$("#filter-panel input").removeClass("ftr-applied");
			var inputs = $("#filter-panel input:checked").not("#paym-tpe-all-crds");
			var ftr_opts = $("#filter-options");
			var  filterObj = $.map(inputs, function(n, i)
			{
				var filteredValues = {};
				filteredValues["name"] = n.id
				filteredValues["value"] = $(n).addClass("ftr-applied").siblings("label").text();
				return filteredValues;
			});
//			$(".fltr-icn>span:first").html(filterObj.length == 0?"":filterObj.length);
			ftr_opts.children().remove()
			for(var i=0;i<filterObj.length;i++)
			{
				var filterOptions='<div class="filter-option"><span class="'+filterObj[i].name +'">'+filterObj[i].value+'</span><a href="#" class="filter-close-btn"><span class="filter-close-icon">+</span></a></div>';		
				ftr_opts.append(filterOptions)
			}
			OPEN.NEW_FILTER.flrs == 10 && (OPEN.NEW_FILTER.flrs = ftr_opts.position().top);
			$(".fltr-icn>span:first").html(filterObj.length == 0?"":filterObj.length);
			$("#cards-content").css("padding-top",$("#viewall-header").outerHeight());
			(typeof(isNewReset)!=undefined && !isNewReset) && $("#filter-panel").hide();
			!OPEN.components.viewAll_touch && $('.open.newgrid #list-view .custom-scrollbar').openScrollber({wheelSpeed:10,wheelLock:false});
	},
	/* removing the selected options in new Filter panel and re render the cards accoordingly */
	filter_Close:function()
	{
		var closingfilterId="#"+$(this).prev("span").prop("class");
		$(this).parent().hide().remove();
		OPEN.components.removeHash("#charge-cards","#credit-cards");
		if($(closingfilterId).is("input[type=checkbox]"))
			$(closingfilterId).is(":checked") && $(closingfilterId).click();
		else
		{
			$(closingfilterId).click().prop("checked",false);
			$(closingfilterId).siblings("span").removeClass("radio-checked")
			OPEN.NEW_FILTER.apply_Filter(true);
		}
		var fltrOpts = $("#filter-options .filter-option").size();
		fltrOpts == 0 && $("#paym-tpe-all-crds").click().prop("checked",true)
		$(closingfilterId).removeClass("ftr-applied");
		$(".fltr-icn>span:first").html(fltrOpts == 0?"":fltrOpts);
		OPEN.config.APP.apply_fltr = false;
		OPEN.filter.curSel.pmc = OPEN.filter.selectedCards(this,$("#filter-panel")), void 0 !== OPEN.filter && OPEN.filter.renderCards(OPEN.filter.curSel.pmc,OPEN.filter.curSel.ele,OPEN.config);
		OPEN.config.APP.apply_fltr = true;
		var ftr_opts = $("#filter-options");
		var crdCnt = (OPEN.NEW_FILTER.flrs+ftr_opts.height()==0) && $("#viewall-header").height();
		$("#cards-content").css("padding-top",$("#viewall-header").height());
		!OPEN.components.viewAll_touch && $('.open.newgrid #list-view .custom-scrollbar').openScrollber({wheelSpeed:10,wheelLock:false});
	},
	/* revert the temporary filter selection and reset to the selection previously applied */
	revertSelection:function(panel)
	{
		panel.find('input').removeAttr('disabled').parent().removeClass('disabled');
		panel.find('span').removeClass("radio-checked").removeClass("checkbox-checked");
        panel.find("input:checkbox,input:radio").prop('checked', false);
		$("#paym-tpe-all-crds").click().prop("checked",true);
		panel.find("input.ftr-applied").click().prop("checked",true);
	},
	/* initializing the new Filter panel with default values and binding the event handlers */
	init:function()
	{
        OPEN.config.APP.apply_fltr = true;
		var fltrBtn = $("#viewall-header #filter-toggle");
		var filter  = $("#filter-panel");
		$('.apply-fltr').bind('click touch',function(){
			OPEN.NEW_FILTER.apply_Filter(true);
			OPEN.config.APP._visibleCardsArr = $('#card-section [class^="pmc"]:visible');
			OPEN.components.removeHash("#charge-cards","#credit-cards");
		});
		fltrBtn.bind("click touch",function(e){
			$(window).scrollTop($(window).scrollTop()+1);
			$(window).scrollTop($(window).scrollTop()-1);
                        if(!OPEN.compareTray.bauCmr){
                            $("#comparision").hide();
                        }
                    	filter.fadeToggle( "fast", "linear");
			e.stopImmediatePropagation();
			});
		$("html").on('click', function(event) {
		if (!$(event.target).is("#see-all-crds") && filter.is(":visible") && !$(event.target).closest(filter).length) {
			!$(event.target).closest(fltrBtn).length && filter.hide();

			OPEN.NEW_FILTER.revertSelection($("#filter-panel"));
		}
		});
		$("#filter-panel .close-icon-compare-tray").bind("click",function(){
			filter.fadeToggle( "fast", "linear");

			OPEN.NEW_FILTER.revertSelection($("#filter-panel"));
		});
		$('.filter-option .filter-close-btn').live("click",function(){
			OPEN.NEW_FILTER.filter_Close.call(this);
			return false;
		});
		function FltrPos()
		{
			$(this).scrollTop() >= iNavHeight ?$(".filter-section").removeClass(Scr).css("top",$(window).width()<830?119:127):$(".filter-section").addClass(Scr).removeAttr("style");
		}
		var Scr = brwsr_type.match(/iPhone/i) ? "mbl-scroll" : "scroll";
		$(window).bind('touchmove scroll', function (e) {
			FltrPos();
		});
		$(window).resize(function (event) {
			FltrPos();
		});
	}
}