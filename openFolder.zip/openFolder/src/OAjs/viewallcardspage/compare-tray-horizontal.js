
/*********************************************** Compare Tray code starts here *********************************************/

OPEN.compareTray = {
    _crdTry: [],
    _trayCards: [],
    isVisual: true,
    flag_close: true,
    addCardClick: false,
    rm_flg: false,
    bauCmr: true,
    cmrPd: 0,
    isCompareClick: false,
    adflg:false,
    rmflg:false,
    addCard: function (cfg) {
        var _cmprBtns = $(".cards-btns .compare-btn,.list-view-btns .compare-btn,#quick-view-overlay .compare-btn");
        var _rmvBrn = 'remove-btn';
        _cmprBtns.live("click", function (event, newCmr) { /*ios7*/
            /* May B */
			
            if (!OPEN.compareTray.rm_flg && !OPEN.compareTray.adflg) {			
                                OPEN.compareTray.adflg=true;
                
             if( OPEN.config.APP.vac_cookie ){
                    OPEN.compareTray.adflg=false     
             }
             else
             {
                setTimeout(function(){
                    OPEN.compareTray.adflg=false
                },1000)
                
             }                !$(this).parents(".list-view").length ? OPEN.compareTray.isVisual = false : OPEN.compareTray.isVisual = true;
                var pmc = OPEN.compareTray.isVisual ? $(this).closest('[class^="pmc"]').attr('class').split(' ')[0] : $(this).parents("#overlay-card").attr("class").split(' ')[0];
                if (!$(this).hasClass("disable")) {

                    /*FEBB VAC FIX*/
                    newCmr || $("#cards-list-overlay").hide();
                    if (!$(this).hasClass("remove-btn"))
                        OPEN.compareTray.isCompareClick = true;
                    $(".card-selected").length <= 2 && $(this).find('span:first').addClass("card-selected");
                    OPEN.config.APP.itag_cardname = OPEN.universal.getProductName(pmc);
                    if ($(this).hasClass(_rmvBrn)) {
                        (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', OPEN.config.APP.itag_cardname + '_Remove') : null; //FEB release
                        /*FEBB VAC FIX*/
                        !OPEN.compareTray.isCompareClick && $('.' + pmc).find('.card-art').css({
                            'opacity': '1',
                            'cursor': 'pointer'
                        });
                    } else {
                        if (!OPEN.compareTray.addCardClick) {
                            (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', OPEN.config.APP.itag_cardname + '_Compare') : null;
                        } //FEB omniture
                        OPEN.compareTray.addCardClick = false; //FEB omniture
                        $('.' + pmc).find('.card-art').css({
                            'opacity': '0.4',
                            'cursor': 'default'
                        });
                    }
                    var cmpTxt = $(this).html();
                    cmpTxt = cmpTxt.replace(/Compare/g, "Remove");
                    $('.' + pmc).find('.compare-btn').html(cmpTxt);
                    var _modsec = $(".section");
                    _modsec.css('display') != 'block' ? _modsec.css('display', 'block') : null;
                    var _cmprCrds = $(cfg.ID._cmprCrds);
                    var _lstViewCrd = $('#list-view');

                    if ($(window).width() <= 660) {
                        OPEN.compareTray._crdTry.length == 0 ? ($(".compare_cards").hide()) : $(".compare_cards").show();
                        //OPEN.compareTray._crdTry.length == 1 && _cmprCrds.find('ul.section').height('auto');
                        _modsec.css('display') == 'block' ? _lstViewCrd.parent().parent().animate({
                            paddingTop: $("#viewall-header").outerHeight() - 20
                        }) : null;

                    }
                    var mobileCmpSec = $(".compare-toggle");
                    mobileCmpSec.css('display') != 'block' ? mobileCmpSec.css('display', 'block') : null;
                    if ($(window).width() <= 660)
                    {
                        $("#compare-cards-text").css('display') != 'block' && $("#compare-cards-text").css('display', 'block');
                    }
                    var isCompare = true;
                    port = 0;
                    if ($(window).width() <= 830 && $(window).width() >= 660) {
                        port = 20;
                    } else if ($(window).width() > 830) {
                        port = 0;
                    } else if ($(window).width() <= 660) {
                        port = -20;
                    }
                    var _cmprCrds = $(cfg.ID._cmprCrds);					
 					(OPEN.compareTray.bauCmr || $(window).width() <= 660) && _cmprCrds.css('display') != 'block' ? (_cmprCrds.css({
                            display: 'block',
                            opacity: 1
                        }).animate({
                            opacity: 1
                        }, 'easein'),
                       $(window).width() >= 660 && _lstViewCrd.parent().parent().animate({
                            paddingTop: $(_cmprCrds)[0].offsetHeight + $(_cmprCrds)[0].offsetTop + port
                        }, 'easein')) : null;
						
                    OPEN.compareTray._crdTry.length <= 1 ? $(".cards-count").html(OPEN.compareTray._crdTry.length + 1) : null;
                    /* May B */
                    var _emtCrd = 'pmc-hldr';
                    var crds = OPEN.config.APP._iscookienable ? _cmprCrds.find('li.' + _emtCrd) : _cmprCrds.find('li:visible.' + _emtCrd);
                    var _wrapper = $("#quick-view-overlay");
                    !$(this).parents(".list-view").length ? OPEN.compareTray.isVisual = false : OPEN.compareTray.isVisual = true;
                    var crdPmc = OPEN.compareTray.isVisual ? $(this).closest('li') : $(this).parents("#overlay-card");

                    $(this).hasClass(_rmvBrn) && !OPEN.compareTray.rmflg ? ($('.' + crdPmc.attr('class').split(' ')[0]).find('.compare-btn'), isCompare = false, _cmprCrds.find('li.' + crdPmc.attr('class').split(' ')[0]).find('.close-icon-compare-tray').click(), newCmr || _wrapper.find('.circle-close-icon').click()) : null;
                    /* May B */
                    if (crds.size() <= Number(OPEN.config.APP._iscookienable ? _cmprCrds.find('li').size() : _cmprCrds.find('li:visible').size()) && !$(this).hasClass(_rmvBrn) && isCompare && Number(crds.size()) != 0) {
                        //_cmprBtns.parent().css({"opacity":"0.6","filter":""}).attr(_disable, true);
                        var crdInfo = _lstViewCrd.find('li.' + crdPmc.attr('class').split(' ')[0] + ' .list-content-card');
                        OPEN.compareTray._crdTry.length == 1 ? ($(".number-of-cards .cardscount").html("s"), $('#compare-now').focus()) : null;
                        OPEN.compareTray._crdTry.length == 2 ? ($('#compare-now').focus()) : null;
                        /* May B */
                        OPEN.compareTray._crdTry.length <= Number(OPEN.config.APP._iscookienable ? _cmprCrds.find('li').size() - 1 : _cmprCrds.find('li:visible').size() - 1) ? OPEN.compareTray._crdTry.push({
                            title: crdInfo.find('.heading').html(),
                            rating: crdInfo.find('.viewallratings').clone(),
                            pmc: crdPmc.attr('class').split(' ')[0]
                        }) : null;
                        var _cardimg = 'card-art';
                        var crd = OPEN.compareTray._crdTry[OPEN.compareTray._crdTry.length - 1];
						
                        var crdArt = OPEN.compareTray.isVisual ? crdPmc.find('.' + _cardimg) : $(".quicklook-card-container").find('.' + _cardimg);
                        var fromCookie = false;
                        var cmrovly = $("#cards-list-overlay");
                        OPEN.components.viewAll_touch ? $("#cards-list-overlay .custom-scrollbar").addClass("touch-scrollbar") : $("#cards-list-overlay  .custom-scrollbar").openScrollber({wheelSpeed:10,wheelLock:false});
                        var cnt = OPEN.compareTray._crdTry.length;
                        var cmrCnt = $(window).width() <= 830 ? (cnt == 3 ? 2 : cnt) : cnt;
                        $("#compare-cards-text .card-count,#compare-cards-text-mob .card-count").html("(" + cmrCnt + "/" + ($(window).width() <= 830 ? 2 : 3) + ")");	
						var crdP = (OPEN.compareTray.bauCmr && !newCmr)?OPEN.components.getCrdPos($(crdArt)[0]).top - $(document).scrollTop() > 0:true;
                        if (OPEN.compareTray.isVisual && crdP && $(this).parents(".list-view").length) {
                            var emtSlot = crds.first();
                            var cardArtPlaceholder = '<img class="card-art-img" src="../../OAimages/amex-open/cardarts/thumbnail/flat/retina/flat-card-art-placeholder-min.png#resource_version" />'
                            var cpy = crdInfo.find('.' + _cardimg).clone().addClass('card-mask').addClass(crdPmc.attr('class').split(' ')[0]);
                            crds.eq(0).removeClass(_emtCrd).addClass(crd.pmc).find('.' + _cardimg).addClass('emtycard');
                            if (!crds.eq(0).find(".card-art").children("img").hasClass("card-art-img")) {
                                crds.eq(0).find(".card-art").append(cardArtPlaceholder);
                            }
							//$(window).width() < 660 && crds.eq(0).find("h2").html(crd.title).css("visible","hidden");
                            $(window).width() < 660 ? crds.eq(0).find(".card-art").css({
                                                                                        "display":"block",
                                                                                        "margin-top":-50,
                                                                                        "position":"absolute",
                                                                                        opacity:0
                                                                                    }).animate({
                                                                                        marginTop:31,
                                                                                        opacity:1},'easein',function(){
                                                                                        $(this).removeAttr("style").css({"display": "block"});
                                                                                        $("html,body").scrollTop(OPEN.components.iNavHeight);
                                                                                        OPEN.compareTray.compareSpan();
                                                                                        crds.eq(0).find("h2").html(crd.title).show();
                                                                                        $(this).closest("li").find('.close-icon-compare-tray').css("display", 'block');
                                                                                        _modsec.css('display') == 'block' && _lstViewCrd.parent().parent().animate({
                                                                                            paddingTop: $("#viewall-header").outerHeight() - 20
                                                                                        }); }) : crds.eq(0).find(".card-art").show();
							
                            var _filterPanel = $(cfg.ID._filterPanel);
                            _filterPanel.parent().prepend(cpy.css({
                                opacity: 0,
                                'top': OPEN.components.getCrdPos($(crdArt)[0]).top - $(document).scrollTop(),
                                'left': OPEN.components.getCrdPos($(crdArt)[0]).left - ($(window).width() < 660 ? 15 : 0),
                                'width': newCmr ? $("#comparision a.card-art:first").width() : $(this).closest("li").find('.' + _cardimg).width(),
                                'height': newCmr ? $("#comparision a.card-art:first").height() : $(this).closest("li").find('.' + _cardimg).height(),
                            }).animate({
                                'top': OPEN.compareTray.bauCmr ? OPEN.components.getCrdPos($(emtSlot)[0]).top : OPEN.components.getCrdPos($("#compare-cards-text")[0]).top,
                                'left': OPEN.compareTray.bauCmr ? OPEN.components.getCrdPos($(emtSlot)[0]).left + parseInt($('.' + _cardimg).css("left")) - 1 : OPEN.components.getCrdPos($("#compare-cards-text")[0]).left + parseInt($("#compare-cards-text").width()) / 2,
                                'width': OPEN.compareTray.bauCmr ? crds.eq(0).width() : newCmr ? 'auto' : 0,
                                'height': OPEN.compareTray.bauCmr ? crds.eq(0).height() : newCmr ? 'auto' : 0,
                                opacity: newCmr ? 0 : 1
                            }, OPEN.compareTray.bauCmr ? 400 : newCmr ? 100 : 1000, function () {
                                $(this).remove();
                                emtSlot.prepend(cpy.css({
                                    'top': newCmr ? 75 : 0,
                                    'left': parseInt($('.' + _cardimg).css("left")) + 'px',
                                    height: $(this)[0].height,
                                    opacity: newCmr ? 0 : 1,
                                    'display': ($(window).width() > 660) ? 'block' : "none" /*ios7*/ /* May B */
                                }).animate({
                                    'top': newCmr ? 0 : parseInt($('.' + _cardimg).css("top")),
                                    opacity: newCmr ? 0.8 : 1
                                }, 'easein', function () {
                                    $(this).parent().find('.' + _cardimg).removeClass('emtycard');
                                    $(window).width() > 660 && crds.eq(0).find("h2").html(crd.title).show().parent().find('.close-icon-compare-tray').css({"opacity": 0, "display": 'block'}).animate({opacity: 1}).parent().parent().append(crd.rating).next('.' + _emtCrd).find($('.' + _cardimg + ',.mask-layer')).show();
                                    $(this).remove();
                                    _cmprBtns.removeAttr("disabled").parent().css({
                                        'opacity': 1,
                                        'cursor': 'pointer'
                                    }).removeAttr("disabled").attr("title", "Click to add to compare tray");
                                    /*  May B*/
                                    OPEN.compareTray._crdTry.length == Number(OPEN.config.APP._iscookienable ? _cmprCrds.find('ul.section>li').size() : _cmprCrds.find('ul.section>li:visible').size()) ? _cmprBtns.not('.' + _rmvBrn).parent().css({
                                        "opacity": "0.6",
                                        "filter": "",
                                        "cursor": "default"
                                    }).attr({
                                        "disabled": true,
                                        'onclick': 'return false'
                                    }).removeAttr("title", "Click to add to compare tray") : null; /*debugathon1*/
                                    /*FEBB VAC FIX*/
                                    OPEN.compareTray.isCompareClick = false;
                                    if ($(window).width() <= 830) {
                                        _cmprCrds.css("display") == "block" ? (_cmprCrds.find(".section li:visible").not('.pmc-hldr').length == 2 ? $(".compare-btn").not(".remove-btn").parent().css("opacity", 0.6) : null) : null;
                                    }
									
									
                                }));
                            }));
                        } else {
                            crds.eq(0).removeClass(_emtCrd).addClass(crd.pmc);
                            crds.eq(0).find("h2").html(crd.title).show().parent().find('.close-icon-compare-tray').show().parent().parent().append(crd.rating).next('.' + _emtCrd).find($('.' + _cardimg + ',.mask-layer')).show();
                            crds.eq(0).find(".card-art").attr("title", $("#list-view li." + crd.pmc).find(".card-art").attr("title"));
                            /*FEBB VAC FIX*/
                            OPEN.compareTray.isCompareClick = false;
                        }
                        // made card clickable with corresponding link as part of Sep A release.
                        var sldCrd = $('#list-view li.' + crd.pmc).find('.card-art');
                        crds.eq(0).find('.card-art').attr({ title: sldCrd.attr('title'), href: sldCrd.attr('href') });
                        
                        $(OPEN.config.ID._cmprCrds).find("ul.overview").find("li.pmc-" + crd.pmc.split(' ')[0].split('-')[1] + "-sml").addClass("active disabled");
                        !OPEN.compareTray.isVisual && crds.eq(0).find('.close-icon-compare-tray').css({"opacity": 1, "display": 'block'}).animate({opacity: 1}, 1000);
                        !OPEN.compareTray.isVisual ? _cmprBtns.parent().css({
                            'opacity': 1,
                            "cursor": "pointer"
                        }).removeAttr("disabled").attr("title", "Click to add to compare tray") : null;
                        $('.' + crdPmc.attr('class').split(' ')[0]).find('.compare-btn').addClass(_rmvBrn).attr('title', 'Click to remove card');
                        $(this).parent().parent().parent().parent() ? $(".selected-card").length < 2 && $(this).parent().parent().parent().parent().addClass("selected-card") : null;

                        _wrapper.hide();
                        $("#overlay-mask").hide();
                        OPEN.compareTray._crdTry.length == Number(_cmprCrds.find('ul.section>li:visible').size()) ? _cmprBtns.not('.' + _rmvBrn).parent().css({
                            'opacity': "0.6",
                            "cursor": "default",
                            "filter": ""
                        }).attr("disabled", true).removeAttr("title") : null;
							 

                        OPEN.compareTray.isVisual = true;
                    }
                    var a_compar = $('a.compare_cards');
                    var jsonString = OPEN.universal.stringify(OPEN.compareTray._crdTry, false);
                    OPEN.universal.createCookie("cardInfo", jsonString, 10);
                    OPEN.compareTray._crdTry.length >= 2 ? a_compar.css('opacity', '1').removeClass('disabled').removeAttr('onclick') : a_compar.css('opacity', '0.3').addClass('disabled').attr('onclick', 'return false');
                    if(OPEN.compareTray._crdTry.length >= 2){
                        a_compar.hover(function(){
                            a_compar.css('opacity', '0.9');
                        },function(){
                            a_compar.css('opacity', '1')
                        });
                    }
                }
                OPEN.compareTray._crdTry.length == 3 ? (_cmprBtns.not('.' + _rmvBrn).addClass("disable").removeAttr("title").parent().attr("disable", "true"), $(cfg.ID._cmprCrds).find("div.cards-list > div > div.viewport > ul > li").addClass("disabled")) : (_cmprBtns.not('.' + _rmvBrn).removeClass("disable").attr("title", "Click to add to compare tray").parent().removeAttr("disable"));
                OPEN.components.scrollovrly_rst("auto", 0);
                if ($(window).width() <= 830) { //FEB A 4
                    if (OPEN.compareTray._crdTry.length == 2) {
                        _cmprBtns.not('.' + _rmvBrn).addClass("disable").removeAttr("title").parent().attr("disable", "true");
                        _cmprBtns.not('.' + _rmvBrn).parent().css({
                            'opacity': "0.6",
                            "cursor": "default",
                            "filter": ""
                        }).attr("disable", true).removeAttr("title");
                        $(cfg.ID._cmprCrds).find("div.cards-list > div > div.viewport > ul > li").addClass("disabled");
                        $(window).width() >= 660 ? $(window).resize() : setTimeout(function () {
                            OPEN.compareTray.compareSpan()
                        }, 1500);
                    }

                }
				
                return false;
            }

        });
        OPEN.filter.resetFilter(cfg);
        /*april a start*/
        $('#comparision .compare_cards').on("click", function (e) {
            e.preventDefault();
            !$(this).hasClass("disabled") ? window.location = OPEN.compareTray.generateCompareUrl() : null; /*02-28-2013*/
        });
        $('#comparision .compare_cards').on("touchstart", function (e) {
            !$('#comparision .compare_cards').hasClass("disabled") ? $('#comparision .compare_cards').attr('href', OPEN.compareTray.generateCompareUrl()) : null;
        });
        /*april a end*/
        $('#comparision .compare_cards').on("click", function (e) {
            e.preventDefault();
            !$(this).hasClass("disabled") ? window.location = OPEN.compareTray.generateCompareUrl() : null; /*02-28-2013*/
        });
        $('#comparision .compare_cards').on("touchstart", function (e) {
            !$('#comparision .compare_cards').hasClass("disabled") ? $('#comparision .compare_cards').attr('href', OPEN.compareTray.generateCompareUrl()) : null;
        });
        return this;
    },
    generateCompareUrl: function () { /*april A*/
        var crrUrl = $('#comparision .compare_cards').attr('href');
        if (crrUrl.indexOf("#") != -1) {
            var crr = crrUrl.indexOf("#");
            crrUrl = crrUrl.substring(0, crr)
        }
        if (crrUrl.indexOf("pmccodes") != -1) { /* Compare page Redesign */
            var pmc_index = crrUrl.indexOf("pmccodes");
            crrUrl = crrUrl.substring(0, pmc_index - 1)
        }
        var pmcCrds = [];
        for (var crd in OPEN.compareTray._crdTry) {
            var pmc = OPEN.compareTray._crdTry[crd].pmc;
            pmcCrds.push(pmc.split('-')[1]);
        }
        var strUrl;
        crrUrl.indexOf("?") != -1 ? strUrl = crrUrl + "&pmccodes=" + pmcCrds : strUrl = crrUrl + "?pmccodes=" + pmcCrds;
        return strUrl;

    },
    //removing card in the Card Tray.
    rmvCard: function (cfg, obj) {
        var size_win = 0;
        var _cmprCrds = $(cfg.ID._cmprCrds);
        _cmprCrds.find('ul li .close-icon-compare-tray').live("click touch", function () {
            if(!OPEN.compareTray.rmflg  ) {
                OPEN.compareTray.rmflg=true;
             
             if(OPEN.config.APP.vac_cookie )
             {
                   OPEN.compareTray.rmflg=false       
             }
             else
             {
             setTimeout(function(){
                 OPEN.compareTray.rmflg=false                 
             },400)
             }
            /* May B */
            OPEN.compareTray.bauCmr && ((OPEN.compareTray._crdTry.length == 1 && ($(this).closest('[class^="pmc"]').attr('class').split(' ')[0] == $('#comparision ul li:first-child').attr("class").split(' ')[0])) && (OPEN.compareTray.rm_flg = true));
            /*FEBB VAC FIX*/
            /* May B */
            ($(window).width() <= 830 && $(this).closest("li").hasClass("pmc-hldr")) && (OPEN.compareTray.rm_flg = false);
            /* May B */
            if (OPEN.compareTray.isCompareClick == true || ($(window).width() <= 830 && $(this).closest("li").hasClass("pmc-hldr")))
                return false;
            OPEN.compareTray.bauCmr && $(this).siblings("a").attr("title", "Click to add a card");
            pmc = $(this).closest('[class^="pmc"]').attr('class').split(' ')[0];
            $('.' + pmc).find('.card-art').css('opacity', '1');
            if (OPEN.compareTray.flag_close) { //FEB omniture
                OPEN.config.APP.itag_cardname = OPEN.universal.getProductName($(this).closest("li").attr("class").split(' ')[0]);
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Click_Close') : null; //FEB omniture
                OPEN.compareTray.flag_close = true;
            }
            OPEN.compareTray._crdTry.length == 1 ? $(window).scrollTop(iNav.offsetHeight) : null;
            size_win = $(window).width();
            var comp = $("#viewall-header");
            crd_cnt = $("#cards-content");
            if ($(window).width() <= 660) {
                OPEN.compareTray._crdTry.length == 1 ? $(".compare_cards").hide() : $(".compare_cards").show(); /*ios7*/
                //   _crdTry.length == 1 ? $("#card-section").css('margin-top', 50) : null;
            }
			_cmprCrds.find("ul.overview> li").not(".active").removeClass("disabled");
			
            var mobcrd = $(this).closest("li").removeClass("open-compare-tray").attr("class").split(' ')[0];
            var crdSection = $('#card-section .' + mobcrd);
            var crdSecCmrbtn = $('#card-section .' + mobcrd + ' .compare-btn');
            crdSection.find(">:first-child").removeClass("selected-card");
            crdSection.removeClass("selected-card");
            _cmprCrds.parent().siblings().find('#card-section .' + mobcrd + ' .compare-btn span:first').removeClass();
            var cmpTxt = crdSecCmrbtn.html();
            cmpTxt = cmpTxt.replace(/Remove/g, "Compare");
            crdSecCmrbtn.html(cmpTxt);
            $(".cards-count").html(OPEN.compareTray._crdTry.length - 1);
            OPEN.compareTray._crdTry.length == 2 ? $(".number-of-cards .cardscount").html("") : null;
            var avlCrds = OPEN.compareTray._crdTry.length;
            for (var j = 0; j < avlCrds; j++) {
                var crdItem = OPEN.compareTray._crdTry[j];
                crdItem.pmc == $(this).closest("li").removeClass('card-mask').removeClass("open-compare-tray").attr("class").split(' ')[0] ? OPEN.compareTray._crdTry[j] = null : OPEN.compareTray._crdTry[j] != null || typeof OPEN.compareTray._crdTry[j] != 'undefined' ?
                        OPEN.compareTray._trayCards.push(OPEN.compareTray._crdTry[j]) : null;
            }
            var _rmvBrn = 'remove-btn';
            var _lstViewCrd = $('#list-view');
            _lstViewCrd.children('.' + $(this).closest("li").attr("class").split(' ')[0] + '').find('.' + _rmvBrn).removeClass().addClass("compare-btn btn grey-btn").attr('title', 'Click to add to compare tray');
            $(this).closest("li").find('.rating-holder').remove();
            $(this).closest("li").find('.add-review').remove();
            OPEN.compareTray._crdTry = OPEN.compareTray._trayCards;

            if ((OPEN.compareTray._trayCards.length == 0 && $(window).width() <= 660)) {
                $("#compare-cards-text").hide();
            }

            OPEN.compareTray._trayCards.length == 0 ? _cmprCrds.animate({
                opacity: (OPEN.compareTray.bauCmr || $(window).width() <= 660) ? 0 : 1
            }, 'easein', function () {
                (OPEN.compareTray.bauCmr || $(window).width() <= 660) && $(this).css('display', 'none');
                if (size_win > 660 && size_win < 1024) {
                    port1 = 5;
                } else if (size_win <= 660) {
                    port1 = -7;
                } else {
                    port1 = 0;
                }

                var crdTryH = jQuery.browser.msie && jQuery.browser.version == 7 ? 0 : $(_cmprCrds)[0].offsetTop;
                ($(window).width() < 830 && $(window).width() > 660) && ($("card-section").css("margin-top", "20px"));
                ($(window).width() <= 660) && _lstViewCrd.parent().parent().animate({
                    paddingTop: $(_cmprCrds)[0].offsetHeight + comp[0].offsetHeight + crdTryH
                }, 'easein');
				(OPEN.compareTray.bauCmr && $(window).width() >= 660) && _lstViewCrd.parent().parent().animate({
                    paddingTop: (OPEN.compareTray.bauCmr ? $(_cmprCrds)[0].offsetHeight:0) + comp[0].offsetHeight + (OPEN.compareTray.bauCmr ?$(_cmprCrds)[0].offsetTop:0)
                }, 'easein');
                OPEN.compareTray.rm_flg = false;
            }) : null; /* May B */
            OPEN.compareTray._trayCards.length == 0 ? $(".compare-toggle").css('display', 'none') : null;
            $("#compare-cards-text .card-count,#compare-cards-text-mob .card-count").html("(" + OPEN.compareTray._crdTry.length + "/" + ($(window).width() <= 830 ? 2 : 3) + ")");
            var _cmprBtns = $(".cards-btns .compare-btn,.list-view-btns .compare-btn,#quick-view-overlay .compare-btn");
            if ($(window).width() >= 831) {
                if ((OPEN.compareTray._trayCards.length <= 2)) {
                    _cmprBtns.parent().css({
                        'opacity': '1',
                        'cursor': 'pointer'
                    }).removeAttr("disable").attr("title", "Click to add to compare tray");
                }
            } else
                (OPEN.compareTray._trayCards.length <= 1) ? _cmprBtns.parent().css({
                    'opacity': '1',
                    'cursor': 'pointer'
                }).removeAttr("disable").attr("title", "Click to add to compare tray") : null;
            var a_compar = $('a.compare_cards');
            OPEN.compareTray._trayCards.length == 1 && a_compar.css('opacity', '0.3').addClass('disabled').attr('onclick', 'return false');
            OPEN.compareTray._trayCards = [];
            var fl;
            OPEN.compareTray._crdTry.length == 0 ? fl = true : fl = false;
			
			 var pmc = $(this).closest("li").attr('class').split(' ')[0];
			  $(this).closest("li").find('div.viewallratings').remove();			
                    _cmprCrds.find(".divider-line-arrow-down").show();
                    _cmprCrds.find("ul.overview").find("li.pmc-" + pmc.split('-')[1] + "-sml").removeClass("active disabled");
					!OPEN.compareTray.bauCmr && _cmprCrds.find("ul.section .card-art").attr('title','');					 
            OPEN.compareTray.filter_trayCards(cfg, $(this));
             $(".pmc-hldr div.viewallratings").remove();
			var jsonString = OPEN.universal.stringify(OPEN.compareTray._crdTry, fl);
            OPEN.universal.createCookie("cardInfo", jsonString, 10);
            ($(OPEN.config.ID._cmprCrds).find('ul.section').is(":visible") && !OPEN.compareTray.bauCmr) && OPEN.newCompareTray.update_tooltip.apply(this, [$(OPEN.config.ID._cmprCrds).find("li.pmc-hldr"), $(OPEN.config.ID._cmprCrds).find(".divider-line-arrow-down"), false]);
            for (var i = 0; i < (OPEN.compareTray._crdTry.length > 2 ? 2 : OPEN.compareTray._crdTry.length); i++) {
                $("#" + OPEN.compareTray._crdTry[i].pmc + "-card").addClass("selected-card");
            }
            OPEN.compareTray._crdTry.length == 3 ? _cmprBtns.not('.' + _rmvBrn).addClass("disable") : _cmprBtns.not('.' + _rmvBrn).removeClass("disable");
            if ($(window).width() <= 660) {
                setTimeout(function () {
                    OPEN.compareTray._crdTry.length == 1 && crd_cnt.animate({
                        paddingTop: $(comp).outerHeight() - 20
                    })
                }, 300);
            }
                
                /* Sep 14 code to update Card art links */
                $("#comparision .section li:not('.pmc-hldr')").each(function(){
                $(this).find('a.card-art').attr('href',$('#card-section .section li.'+$(this).attr('class')).find('.heading span.crd-title a').attr('href'))
                })
                $("#comparision .section li.pmc-hldr a").removeAttr('href');

            /* March B */
            if ($(window).width() <= 830 && !OPEN.config.APP.tgr_pop) {
                 OPEN.compareTray.rmflg=false;       
                _cmprCrds.find("ul").find("li:eq(1)").find("button.close-icon-compare-tray").click();
                _cmprCrds.find("ul").find('.pmc-hldr').show();
                /* May  B */
                _cmprCrds.find("ul").find('.pmc-hldr').length == 2 && _cmprCrds.find("ul").find('.pmc-hldr:eq(1)').hide()
            }			
			
            }
            return false;
        });        
    
        return this;
    },
    //manipulate the data in card tray from cards overlay.
    filter_trayCards: function (cfg, obj) {
        var _cmprCrds = $(cfg.ID._cmprCrds);
        var _emtCrds = true;
        var crrCrd;
        var tryCards = _cmprCrds.find('.section li');
        if (OPEN.compareTray._crdTry.length) {
            for (var i = 0; i < Number(tryCards.size()); i++) {
                OPEN.compareTray._crdTry[i] != null || typeof OPEN.compareTray._crdTry[i] != 'undefined' ? (crrCrd = OPEN.compareTray._crdTry[i], tryCards.eq(i).removeClass().addClass(crrCrd.pmc).find("h2").html(crrCrd.title).parent().append(crrCrd.rating), (OPEN.compareTray.bauCmr && tryCards.eq(i).find("a.card-art").attr("title", $("." + crrCrd.pmc).find(".crd-title").eq(0).text()))) : (_emtCrds ? (OPEN.compareTray.bauCmr && tryCards.eq(i).find("a.card-art").attr("title", "Click to add a card"), tryCards.eq(i).removeClass().addClass("pmc-hldr").find("h2").html("").parent().find(".rating-holder").remove(), tryCards.eq(i).find(".add-card").size() == 0 && tryCards.eq(i).append("<span class='add-card'>Add a Card</span>"), tryCards.eq(i).find(".close-icon-compare-tray").hide().removeAttr('style'), _emtCrds = false) : (tryCards.eq(i).removeClass().addClass("pmc-hldr").find(OPEN.compareTray.bauCmr ? ".card-art,.mask-layer,.close-icon-compare-tray,h2" : ".mask-layer,.close-icon-compare-tray,h2").hide().removeAttr('style'), _emtCrds = false));
            }
        } else {
            tryCards.eq(0).removeClass().addClass("pmc-hldr").find("h2").html("").parent().find(".rating-holder").remove();
            tryCards.eq(0).find(".close-icon-compare-tray").hide().removeAttr('style');
            $(obj).closest("li").next().find(OPEN.compareTray.bauCmr ? ".card-art,.mask-layer,.close-icon-compare-tray,h2" : ".mask-layer,.close-icon-compare-tray,h2").hide().removeAttr('style');
        }

    },
    compareSpan: function () {
        if (OPEN.compareTray._crdTry.length <= 3) { //sau feb A 5-prod
            var cmrHdrHt0 = $("#comparision .section li:eq(0) h2 span");
            var cmrHdrHt1 = $("#comparision .section li:eq(1) h2 span");
            cmrHdrHt0.height('auto'); //feb A 5-prod
            cmrHdrHt1.height('auto'); //feb A 5-prod             
            var span1 = cmrHdrHt0.height();
            var span2 = cmrHdrHt1.height();
            if (span1 > span2) {
                cmrHdrHt0.height(span1);
                cmrHdrHt1.height(span1);
            } else {
                cmrHdrHt0.height(span2);
                cmrHdrHt1.height(span2);
            }
        }
    },
    crdsOverlay: function (cfg) {
        var _cardsLst = $("#cards-list-overlay");
        var _cmprCrds = $(cfg.ID._cmprCrds);
        var _overlaybg = $("#overlay-mask");

        $('.pmc-hldr a.card-art').live("click", function () {
            OPEN.config.APP.add_ovly=true;
            if (OPEN.compareTray.bauCmr) {
                OPEN.components.scrollovrly_rst("hidden", 17);
                _overlaybg.css('display', 'block');
                crrCrd = $(this).parent().parent();
                //Feb release
                var showCard = $("#cards-list-overlay .card-types").find('h4').text().replace(/\s+/g, "");
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('layertrack', 'ShowCardsByFeature') : null; //FEB release							
                _cardsLst.find('li').removeClass("disabled").css("opacity", 1);
                _cmprCrds.find('li').not('.pmc-hldr').each(function (k, crdPmc) {
                    _cardsLst.find(".cards-list li[class='pmc-" + $(this).attr('class').split('-')[1] + "-sml']").addClass("disabled").find('a').attr('tabIndex', '-1')
                });
                OPEN.component.alignCenter(_cardsLst, $('.pmc-hldr a.card-art'));
                if ($.browser.msie) {
                    _overlaybg.css('display', 'block');
                }
                _cardsLst.find("ul li input:radio").siblings('span').hasClass('radio-checked') == false ? _cardsLst.find("ul li:first input:radio").attr('checked', 'checked').siblings('span').addClass(rdoChkd) : null;
                $(document).keydown(function (e) {
                    e.preventDefault();
                });

                !touch && _cardsLst.find('input[type="radio"]:checked').focus(); /* March A */
                _cardsLst.find(".close-icon").live('keypress', function (e) {
                    if (e.keyCode == 9) {
                        _cardsLst.find('input[type="radio"]:checked').focus();
                        return false;
                    } else if (e.keyCode == 13) {
                        _cardsLst.hide();
                        _overlaybg.hide();
                        $('#container').find('.pmc-hldr a').focus();
                        return false;
                    }
                });
                _cardsLst.find(".cards-list li").focus();
                _cardsLst.find("ul li:first input:radio").trigger("click"); /*octb production fix*/
  		
            }
            return false;
        });
        _cardsLst.find('button.circle-close-icon,.cards-list li a,.cards-list li span').bind('click touch', function (e) {
            if (OPEN.compareTray.bauCmr && !$(this).parent().hasClass("disabled"))
            {
                _overlaybg.hide();
                var thisEle = (e.target.nodeName == "SPAN") ? $(this).parent() : $(this).parent().parent();
                !thisEle.hasClass("disable") ? _cardsLst.hide() : null;
                OPEN.components.scrollovrly_rst("auto", 0);
                document.ontouchmove = function (e) {
                    return true;
                }
                $(document).unbind('keydown');
				
            }
            return false;
        });

        _overlaybg.bind('click touch', function () {
            _overlaybg.hide();
            _cardsLst.hide();
            return false;
        });
        _cardsLst.find('.cards-list li a,.cards-list li span').click(function (e) {
            if (OPEN.compareTray.bauCmr && !$(this).parent().hasClass("disabled"))
            {
                var thisEle = (e.target.nodeName == "SPAN") ? $(this).parent() : $(this).parent().parent();
                if (thisEle.hasClass("disable")) {
                    OPEN.components.scrollovrly_rst("hidden", 17);
                    _overlaybg.show();
                    return false;
                }
                OPEN.config.APP.itag_cardname = OPEN.universal.getProductName(thisEle.attr("class").split("-sml")[0]);
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', OPEN.config.APP.itag_cardname + '_AddCard') : null; //FEB release
                OPEN.compareTray.addCardClick = true; //FEB omniture			
                $('#list-view').find('li.pmc-' + thisEle.attr('class').split('-')[1] + ' .compare-btn').click();
            }
        });
        OPEN.filter.ovrlay_FilterCards();
    },
    cmrTray_interaction: function (cfg) {
        var cmp_sectry = $(cfg.ID._cmprCrds);
        var crd_cnt = $("#cards-content");
        var swipeFlag = false;
        $("#comparision .compare_cards.applybutton").on("contextmenu", function (e) {
            var curr_pmc = [];
            var val = "";
            $("#comparision .section li").not('.pmc-hldr').each(function () {
                curr_pmc.push(($(this).attr("class").split("-")[1]))
            })
            var new_href = $(this).attr("href").indexOf("pmccodes") == -1 ? $(this).attr("href") : $(this).attr("href").substring(0, $(this).attr("href").indexOf("?pmccodes"));
            for (var i = 0; i < curr_pmc.length; i++) {
                i == curr_pmc.length - 1 ? val = val + curr_pmc[i] : val = val + curr_pmc[i] + ",";
            }
            new_href += "?pmccodes=" + val;
            $(this).attr("href", new_href);

        });
        $('.card-type .compare-btn, .list-view-btns .remove-btn').live('click touch', function () {
            OPEN.compareTray.flag_close = false;
        });
        // added to make card clickable only for desktop as part of Sep A release.
        $("#comparision .card-art-container").on("click touch",function(e){
           if(!$(this).parents(".pmc-hldr").length && $(window).width() <= 830){ 
            e.preventDefault();
            return false;
           }
        });
	var hitFlg = true;
        $("#viewall-header .compare-toggle").on('touchstart', function (e) {
            e.preventDefault();
            e.stopPropagation();
            touchStartPos = e.originalEvent.changedTouches[0].pageY;
            var prevHt = parseInt($('#comparision').find('ul.section').height());
            var prevPadding = parseInt(crd_cnt.css("padding-top"));
            swipeFlag = true;
			
            $("#viewall-header .compare-toggle").on('touchmove', function (ev) {
                ev.stopPropagation();
                ev.preventDefault();
				hitFlg = false;
                var hgt = prevHt + (Math.abs(parseInt(ev.originalEvent.changedTouches[0].pageY)) - touchStartPos);
				
               $('#comparision').find('ul.section').css({
                    height: hgt > 60 ? (swipeFlag = true, hgt) : (swipeFlag = false, hgt)
                });
                var pdg = prevPadding + (Math.abs(parseInt(ev.originalEvent.changedTouches[0].pageY)) - touchStartPos);
                crd_cnt.css({
                    paddingTop: pdg < 240 ? pdg : 240
                })
            });
        }).on('touchend', function (e) {
            var _cmprCrds = $('#comparision');
            var crd_cnt = $("#cards-content");
			
			if(hitFlg)
			{
				if ($(window).width() <= 660) {
                _cmprCrds.find('ul.section').height() == 0 ? (_cmprCrds.find('ul.section').removeClass("tgl").show(), crd_cnt.animate({
                    "padding-top": $('#viewall-header').height()-20
                }, 300)) : (_cmprCrds.find('ul.section').addClass("tgl"), crd_cnt.animate({
                    "padding-top": "90px"
                }, 300));
				}
			}
			else
			{
            if ((_cmprCrds.find('ul.section').height() > 60 && swipeFlag)) {
                (crd_cnt.animate({
                    "padding-top": 220
                }, 300));
				_cmprCrds.find('ul.section').removeAttr("style").removeClass("tgl");
            } else {
                 (crd_cnt.animate({
                    "padding-top": 75
                }, 300));
				_cmprCrds.find('ul.section').removeAttr("style").addClass("tgl");
            }
			hitFlg = true;
			}

        });
		
		
        $(window).bind('touchmove scroll', function () {
			
            if (OPEN.compareTray.bauCmr) {
                $(window).width() <= 660 ? ($(this).scrollTop() >= OPEN.components.iNavHeight ? cmp_sectry.css("margin-top", "40px") : cmp_sectry.css("margin-top", "52px")) : (cmp_sectry.css("margin-top", "-1px"));
            } /*andsh*/
        });
		
        OPEN.config.CLS._bodyClass = $('body').attr('class');
        $(".compare-toggle").on("mouseup", function (e) { /*remove .tray-shadow selector from this context*/
            var _cmprCrds = $(cfg.ID._cmprCrds);
            e.preventDefault();
          if ($(window).width() <= 660) {
                _cmprCrds.find('ul.section').height() == 0 ? (_cmprCrds.find('ul.section').removeClass("tgl").show(), crd_cnt.animate({
                    "padding-top": $('#viewall-header').height()-20
                }, 300)) : (_cmprCrds.find('ul.section').addClass("tgl"), crd_cnt.animate({
                    "padding-top": "90px"
                }, 300));
            }
			
        });
        $(window).bind('touchmove scroll', function () {

            if (OPEN.compareTray.bauCmr) {
                $(window).width() <= 660 ? ($(this).scrollTop() >= OPEN.components.iNavHeight ? cmp_sectry.css("margin-top", "40px") : cmp_sectry.css("margin-top", "52px")) : (cmp_sectry.css("margin-top", "-1px"))
            }
            ;
        });

        $("#quick-view-overlay,#overlay-mask").hide();
    },
    cmrTray_Init: function (cfg) {
        var _cmprCrds = $(cfg.ID._cmprCrds);
        var _cmprBtns = $(".cards-btns .compare-btn,.list-view-btns .compare-btn,#quick-view-overlay .compare-btn");
        OPEN.compareTray.compareSpan();
        Number(_cmprCrds.find('li:visible').not('.pmc-hldr').size()) == 1 && $('a.compare_cards').css('opacity', '0.3').addClass('disabled').attr('onclick', 'return false');
        if ($(window).width() <= 660) {
            OPEN.compareTray._crdTry.length == 2 ? _cmprBtns.not('.remove-btn').addClass("disable") : _cmprBtns.not('.remove-btn').removeClass("disable");
        }

        $(window).width() <= 830 && _cmprCrds.find('ul.section').find('li:last').hide();

        $('#card-section .list-view-btns .compare-btn').not('.remove-btn').each(function () {
            $(this).parent().attr("disabled") == "disabled" && !$(this).hasClass('disable') && $(this).addClass('disable');
        });

		
		/(android)/i.test(navigator.userAgent)  && $('body').addClass("andriod");
    },
    resize: function (cfg) {
        var _cmprCrds = $(OPEN.config.ID._cmprCrds);
        if ($(window).width() <= 830 && _cmprCrds.find("ul.section").find("li").length == 3) { //feb A 4-prod
            _cmprCrds.find("ul.section").find("li:last").hide();
            var lastCard = _cmprCrds.find("ul.section").find("li:last").attr("class");
            var cmpTxt = $('#list-view').find('.' + lastCard).find('.comparebutton .compare-btn').html();
            //Dilip: change text from "Remove" to "Compare' for last selected card
            if (cmpTxt !== null) {
                cmpTxt = cmpTxt.replace(/Remove/g, "Compare");
            }
            $('#list-view').find('.' + lastCard).find('.card-art').css({
                'opacity': '1',
                'cursor': 'pointer'
            });
            $('#list-view').find('.' + lastCard).find('.comparebutton').attr('disabled', 'disabled').attr('onClick', 'return false').css({
                'opacity': '.6',
                'cursor': 'default'
            }).find('.compare-btn').removeClass('remove-btn').addClass('disable').html(cmpTxt).removeAttr("title").parent().removeAttr("title"); //sau
			$(OPEN.config.ID._cmprCrds).find("ul.overview").find("li.pmc-" + lastCard.split('-')[1] + "-sml").removeClass("active");            
        } else {
            $(window).width() >660 && _cmprCrds.find("ul.section").find("li:nth-child(2)").find(".card-art").css({
                'opacity': '1',
                'display': 'inline'
            });
            if ((_cmprCrds.find("ul.section").find("li:nth-child(2)").find(".card-art").attr('opacity', '1')) && (!_cmprCrds.find("ul.section").find("li:nth-child(2)").hasClass("pmc-hldr"))) {
                _cmprCrds.find("ul.section").find("li:nth-child(3)").find(".card-art").css({
                    'opacity': '1',
                    'display': 'inline'
                });
            }
			
            var lastCard = _cmprCrds.find("ul.section").find("li:last").attr("class");

            var cmpTxt = $('#list-view').find('.' + lastCard).find('.comparebutton .compare-btn').html();
            if (cmpTxt !== null) {
                cmpTxt = cmpTxt.replace(/Compare/g, "Remove");
            }
			_cmprCrds.find("ul.section").find("li").length == 3 && $(OPEN.config.ID._cmprCrds).find("ul.overview").find("li.pmc-" + lastCard.split('-')[1] + "-sml").addClass("active disabled"); 
            $('#list-view').find('.' + lastCard).find('.card-art').css({
                'opacity': '.4',
                'cursor': 'default'
            });

            $('#list-view').find('.' + lastCard).find('.comparebutton').removeAttr('disabled').attr('onClick', 'return true').css({
                'opacity': '1',
                'cursor': 'pointer'
            }).find('.compare-btn').addClass('remove-btn').removeClass('disable').html(cmpTxt).attr('title', 'Click to remove card'); //sau
			
              
        } //Feb A 4
		
		if($(window).width() >320 && $('#comparetray-cnt li').not('.pmc-hldr').find('.viewallratings span').length!= $('#comparetray-cnt li').not('.pmc-hldr').length){
		         $(OPEN.compareTray._crdTry).each(function(){			   
               $('#comparetray-cnt li.'+this.pmc).find('.viewallratings').remove();
               $('#comparetray-cnt li.'+this.pmc).append($("#list-view li."+this.pmc).find('.viewallratings').clone())
                    })
					}
        OPEN.compareTray.compareSpan(); //feb A 5-prod

        if (this.resizeTO)
            clearTimeout(this.resizeTO);
        this.resizeTO = setTimeout(function () {
            $(this).trigger('resizeEnd');
        }, 400);
        if (!OPEN.compareTray.bauCmr)
        {
            if ($(window).width() >= 660){
                (parseInt($("#cards-content").css("padding-top")) != 0) && (OPEN.compareTray.cmrPd = parseInt($("#cards-content").css("padding-top")))
            }else{
                $("#cards-content").css("padding-top", OPEN.compareTray.cmrPd);
            }

                  }

                OPEN.component.overlay_filter_resz();
    },
    resizeEnd: function () {

        var _cmprCrds = $(OPEN.config.ID._cmprCrds);
        var comp_crdssec = $(".compare_cards");
        var comp = $("#viewall-header");
        var qk_lksec = $("#quick-view-overlay,#overlay-mask");
		 if ($(window).width() > 660) {
			!OPEN.compareTray.bauCmr && _cmprCrds.find(".section").hasClass("tgl") && _cmprCrds.hide();
        }
        _cmprCrds.find("ul.section").find("li").not(".pmc-hldr").size() > 0 && $(window).width() <= 660 ? _cmprCrds.find('ul.section').show().find('li:first *, li:nth-of-type(2) *').not('.viewallratings,.add-card').show().filter(".card-art").css({"display": "block"}) : _cmprCrds.find("ul.section").find("li").not(".pmc-hldr").size() > 0 && _cmprCrds.find('ul.section').removeClass("tgl");
        $(window).width() <= 660 ? ($(this).scrollTop() >= OPEN.components.iNavHeight ? _cmprCrds.css("margin-top", "40px") : _cmprCrds.css("margin-top", "52px"), setTimeout(function () {
            ($(window).width() <= 660) && OPEN.compareTray.compareSpan()
        }, 1000)) : ($(this).scrollTop() >= OPEN.components.iNavHeight ? _cmprCrds.css("margin-top", "0px") : _cmprCrds.css("margin-top", "-1px"));

		if($(window).width() <= 660)
		{
			(_cmprCrds.css('display') == 'block' && parseInt(_cmprCrds.find(".section").css("height"))!=0) ? $('#cards-content').css("padding-top",$('#viewall-header').height()-20):OPEN.compareTray._crdTry.length>=1 && (_cmprCrds.show(),_cmprCrds.find(".section").addClass("tgl"),$('#cards-content').css("padding-top",$('#viewall-header').height()-20));
		}

		($(OPEN.config.ID._cmprCrds).find('ul.section').is(":visible") && !OPEN.compareTray.bauCmr) && OPEN.newCompareTray.update_tooltip.apply(this, [$(OPEN.config.ID._cmprCrds).find("li.pmc-hldr"), $(OPEN.config.ID._cmprCrds).find(".divider-line-arrow-down"), false]);				
        if ($(window).width() <= 830) {
            /* May B */
           OPEN.components.scrollovrly_rst('auto', 0);
            //OPEN.config.APP.qkovly && qk_lksec.hide(); /* April A */
            _cmprCrds.css("display") == "block" ? (_cmprCrds.find(".section li:visible").not('.pmc-hldr').length == 2 ? $(".compare-btn").not(".remove-btn").parent().css("opacity", 0.6) : null) : null;
			OPEN.compareTray._crdTry.length >=2 && $(OPEN.config.ID._cmprCrds).find("ul.overview li").addClass("disabled"); 
        }
		
		$(window).width() <= 830 && $(window).width() > 660 && _cmprCrds.find(".section li:visible").not('.pmc-hldr').length == 1 && _cmprCrds.find("ul").find('.pmc-hldr:visible .card-art').show();
		
		if ($(window).width() >= 830) {
			OPEN.compareTray._crdTry.length ==2 && $(OPEN.config.ID._cmprCrds).find("ul.overview li").not(".active").removeClass("disabled");
		}
        if ($(window).width() <= 830 && _cmprCrds.find("ul.section").find("li").length == 3) {
            _cmprCrds.find("ul.section").find("li:last").hide()
        } else {
            _cmprCrds.find("ul.section").find("li:last").show()
        }
        $(window).width() <= 830 && (_cmprCrds.find("ul.section").children("li").not(".pmc-hldr").size() == 2 ? $(".compare-btn").not(".remove-btn").addClass("disable").removeAttr("title").parent().css("opacity", 0.6).attr('onclick', 'return false').removeAttr("title") : null);

        $(".compare-section li:last-child").css("display", "none");
        if ($(window).width() > 660) {
            _cmprCrds.find(".section li").css("height", "").css("padding", "");
        }
        $(window).width() > 660 ? comp_crdssec.css("display", "block") : (OPEN.compareTray._crdTry.length == 1 ? comp_crdssec.css("display", "none") : comp_crdssec.css("display", "block"));

        var si = setTimeout(counter, 0);

        function counter() { /*ios7 start*/
            var _lstViewCrd = $('#list-view');
            if ($('body').attr('class').trim() != OPEN.config.CLS._bodyClass) {
                $(window).width() > 660 ? comp_crdssec.show() : (OPEN.compareTray._crdTry.length == 1 ? comp_crdssec.css("display", "none") : comp_crdssec.show());
                if ((!jQuery.browser.msie || jQuery.browser.version > 8)) {
                    $(window).width() > 660 ? (_cmprCrds.css("display") == "none" ? _lstViewCrd.parent().parent().css({
                        paddingTop: (OPEN.compareTray.bauCmr ? $(_cmprCrds)[0].offsetHeight:0) + comp[0].offsetHeight + (OPEN.compareTray.bauCmr ?$(_cmprCrds)[0].offsetTop:0)
                    }) : _lstViewCrd.parent().parent().css({
                        paddingTop: (OPEN.compareTray.bauCmr ? $(_cmprCrds)[0].offsetHeight:0) + (OPEN.compareTray.bauCmr ?$(_cmprCrds)[0].offsetTop:0)
                    })) : null;
                    $(window).width() <= 660 ? (_cmprCrds.css("display") == "none" ? _lstViewCrd.parent().parent().removeAttr("style") : _lstViewCrd.parent().parent().css({
                        paddingTop: $(comp).outerHeight() - 20
                    })) : null;
                }
                clearTimeout(si);
                OPEN.config.CLS._bodyClass = $('body').attr('class');
            } else {
                //si = setTimeout(counter, 0);
            }
            parseInt($("#cards-content").css("padding-top"))==0 && $("#cards-content").removeAttr("style");
            if($(window).width() > 660){
                $("#cards-content").css("padding-top",$("#viewall-header").outerHeight());
            }
            if($(window).width() <= 660){
                $("#cards-content").css("padding-top",$("#viewall-header").outerHeight()-20);
            }
        } /*ios7 end*/
        var crd_sec = $("#card-section");
        $(window).width() <= 830 && $(window).width() >= 660 ? crd_sec.css("margin-top", 20) : crd_sec.css("margin-top", "");
        $(window).width() <= 660 ? (_cmprCrds.css("display") == "none" ? crd_sec.css("margin-top", 45) : null) : null;
        if ($(window).width() > 300 && $(window).width() <= 660) {
            OPEN.compareTray._crdTry.length == 2 ? comp_crdssec.show() : comp_crdssec.hide();
            OPEN.compareTray._crdTry.length == 2 ? $(".cards-count").html(OPEN.compareTray._crdTry.length) : null;
            OPEN.compareTray._crdTry.length == 2 ? ($(".number-of-cards .cardscount").html("s"), $("#compare-now").focus()) : null
        }
			
	
			

    }

}
history.navigationMode = 'compatible';
$(window).bind("unload", function () {
});
window.onpopstate = function () {
    window.onpopstate = function () {
        var tray_arr1 = [],
                jstry1 = [],
                tray_arr2 = [];
        if (/(iPad|iPhone|iPod)/g.test(navigator.userAgent)) {
            var _cmprCrds = $('#comparision');
            if ($(window).width() <= 830 && _cmprCrds.find("ul").find("li").length == 3) {
                _cmprCrds.find("ul.section").find("li:last").hide();
                var lastCard = _cmprCrds.find("ul.section").find("li:last").attr("class");
                $('#list-view').find('.' + lastCard).find('.card-art').css({
                    'opacity': '1',
                    'cursor': 'pointer'
                });
                $('#list-view').find('.' + lastCard).find('.comparebutton').attr('disabled', 'disabled').attr('onClick', 'return false').css({
                    'opacity': '.6',
                    'cursor': 'default'
                }).find('.compare-btn').removeClass('remove-btn').addClass('disable').html('<span class=""></span> Compare'); //sau
            } else {
                _cmprCrds.find("ul.section").find("li:last").show();
                var lastCard = _cmprCrds.find("ul.section").find("li:last").attr("class");
                $('#list-view').find('.' + lastCard).find('.card-art').css({
                    'opacity': '.4',
                    'cursor': 'default'
                });
                $('#list-view').find('.' + lastCard).find('.comparebutton').removeAttr('disabled').attr('onClick', 'return true').css({
                    'opacity': '1',
                    'cursor': 'pointer'
                }).find('.compare-btn').addClass('remove-btn').removeClass('disable').text('Remove');
            }
            OPEN.allCards.compareSpan(); //feb A 5-prod
            if (this.resizeTO)
                clearTimeout(this.resizeTO);
            this.resizeTO = setTimeout(function () {
                $(this).trigger('resizeEnd');
            }, 400);

            OPEN.config.APP.tgr_pop = true;
            tray_arr1 = [], jstry1 = [], tray_arr2 = [];
            $(eval("(" + OPEN.universal.readCookie("cardInfo") + ")").cards).each(function () {
                tray_arr1.push(this.pmc);
            });
            $(tray_arr1).each(function (a, d) {
                var ln_mr = $('#card-section #list-view li.' + tray_arr1[a] + ' .list-view-btns a.learn-more-link').attr("href");
                var cr_tl = $('#' + tray_arr1[a] + '-card-details .heading a').html();
                jstry1[tray_arr1[a]] = {
                    pmc: tray_arr1[a],
                    title: '<a title="" class="viewcomparelink" href="' + ln_mr + '">' + cr_tl + '</a>'
                }
            });
            $("#comparision li").not('.pmc-hldr').each(function () {
                tray_arr2.push($(this).attr('class'));
            });

            /* March B */
            if ($(tray_arr2).not(tray_arr1).get().length != 0) {
                $(tray_arr2).each(function (key) {
                    $('.' + tray_arr2[key] + ' button.close-icon-compare-tray').click()
                })
                $(".cards-count").html(eval("(" + OPEN.universal.readCookie("cardInfo") + ")").cards.length);
                var jsonStr = OPEN.universal.stringify(jstry1, false);
                OPEN.universal.createCookie("cardInfo", jsonStr, 10);
                if (document.cookie.indexOf("cardInfo") != -1) {
                    if ($(eval("(" + OPEN.universal.readCookie("cardInfo") + ")").cards).length != 0) { /* feb A change */

                        $('body').css('opacity', '0');
                        var cArr = eval('(' + OPEN.universal.readCookie("cardInfo") + ')');
                        if (typeof (cArr.cards) != "undefined") {
                            _fromCookie = true;
                            for (var i = 0; i < cArr.cards.length; i++) {
                                var cis = $("#comparision ul.section>li[class^='pmc-']").eq(i);
                                var crdCls = cArr.cards[i].pmc;
                                var lis = $("ul#list-view>li");
								var thisclass;
                                if (i == 2) //FEB A 4
                                {
                                    $('#card-section').find('.' + crdCls).find('.compare-btn').removeClass('disable');
                                }
                                $.each(lis, function (i, v) {
                                  $(v).hasClass("slide-cards") ? thisclass=$(v).attr("class").split(" ")[0]:thisclass=$(v).attr("class");
						if (thisclass == crdCls) $(v).find(".compare-btn").not(".remove-btn").click()/*JAN*/
                                })
                                cis.find(".card-art").show().parent().find('.mask-layer').show();
                            }
                        }
                        _fromCookie = false;
                        /*febB*/
                        setTimeout(function () {
                            $("#comparision ").show().css('opacity', '1');
                            $('body').css('opacity', '1')
                        }, 1000);
                    }
                }
            }

        }
        OPEN.config.APP.tgr_pop = false;
    };
};

/*********************************************** Compare Tray code ends here *********************************************/