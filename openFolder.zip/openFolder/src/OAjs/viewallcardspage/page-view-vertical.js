
/*********************************************** Grid/List view section code ends here *********************************************/

OPEN.cardsView = {
    changeGridListView: function (viewClass){
       if (viewClass ===".list") { 
            if(!$('#cards-content').hasClass("list-view")) {
              $('#cards-content').addClass("list-view").removeClass("grid-view");
			  $('#cards-content .custom-scrollbar').find(".scrollbar").addClass("disable");   
            }                                                 
            OPEN.config.APP._visibleCardsArr = $('#card-section [class^="pmc"]:visible');
            $(OPEN.config.APP._visibleCardsArr).css("border-top", "2px solid #EEE");
            $(OPEN.config.APP._visibleCardsArr[0]).css("border-top", "none");
        } else {
            if(!$('#cards-content').hasClass("grid-view")) {
              $('#cards-content').addClass("grid-view").removeClass("list-view");     
            }
						
        }
        
	OPEN.cardsView.grid_seperator();		
		
        //Make view active
        $(".page-view a").removeClass("active").parent().find(viewClass).addClass("active"); 
		!OPEN.components.viewAll_touch && $('.open.newgrid #list-view .custom-scrollbar').openScrollber({wheelSpeed:10,wheelLock:false});
        var isTrayEmpty;
        OPEN.compareTray._crdTry.length == 0 ? isTrayEmpty = true : isTrayEmpty = false;
        var jsonString = OPEN.universal.stringify(OPEN.compareTray._crdTry, isTrayEmpty);
        OPEN.universal.createCookie("cardInfo", jsonString, 10);   
		
        return true;
    },
    setView: function() {
        $(".page-view a").live("click", function() {            
            if ($(this).hasClass("list")) {
                //Change the view
                OPEN.cardsView.changeGridListView(".list");
                //log omniture event                
                (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'List_PageView'): null; //FEB release					
            } else if ($(this).hasClass("grid")) {
                OPEN.cardsView.changeGridListView(".grid");                
                (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Grid_PageView'): null; //FEB release					
            }             
            return false;  
        });
        return this;
    },
    view_resizeEnd: function() {
        if ($(window).width() <= 660) { /*Start of OctB*/
            //if #cards-content is not having grid-view class then add it
            if(!$('#cards-content').hasClass("grid-view")) {
              $('#cards-content').addClass("grid-view").removeClass("list-view");  
            }            
        } else {
            var viewClass=".grid"; //default as grid view
            //Read the current state of cookie and set active for grid/list accordingly
            var cookieArr = eval("(" + OPEN.universal.readCookie("cardInfo") + ")");
            if(cookieArr !== null){
                if(cookieArr.gridview) { 
                   viewClass=".grid";
                } else {
                   viewClass=".list";   
                }   
            }                       
            //Change the view           
            OPEN.cardsView.changeGridListView(viewClass);
        } /*End of OctB*/
        OPEN.compareTray.bauCmr && $("#cards-list-overlay").css("display") == "block" && OPEN.component.alignCenter($("#cards-list-overlay"), $('.pmc-hldr a.card-art'));
        if ($(window).width() <= 660) {
            OPEN.config.APP.add_ovly=false;
            $('#card-section .list-view>li').show();
        } else {
            OPEN.config.APP._visibleCardsArr.length && $('#card-section .list-view>li').hide();
            for (var i = 0; i < OPEN.config.APP._visibleCardsArr.length; i++) {
                $(OPEN.config.APP._visibleCardsArr[i]).show();
            }
        }


    },
    view_Interaction: function() {
        (/(iPad|iPhone|iPod)/g.test(navigator.userAgent)) && $('body').attr("unload", "");
        isTab && $("body").addClass("s-Tab");
        if (navigator.userAgent.match(/iPhone/i) && $(window).width() < 660) {
            $("#special-offers input[type='text'],#special-offers select").on({
                focus: function() {
                    _viewHead.css({
                        "position": "absolute",
                        "top": "42px"
                    });
                },
                blur: function() {
                    $(window).scrollTop() >= OPEN.components.iNavHeight ? _viewHead.css({
                        "position": "fixed",
                        "top": "0px"
                    }) : _viewHead.css({
                        "position": "fixed",
                        "top": "42px"
                    });
                }
            })
        } /*Production miss 10B*/

        var epoints = $(".list-content .earn-points");
        $(".list-content .points").css({
            "width": "98%",
            "padding-right": "0%"
        }).find(".reward-count").css("width", "6%");
        epoints.length > 0 && epoints.prev().css({
            "width": "62%",
            "padding-right": "3%"
        }).find(".reward-count").css("width", "8%");
        $(".add-review").click(function() {
            OPEN.config.APP.itag_cardname = OPEN.universal.getProductName($(this).parent().parent().parent().attr("id").split("-card")[0]);
            (typeof($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'ReadReview_' + OPEN.config.APP.itag_cardname): null;
        });
        $(".points li span").each(function() {
            if ($(this).siblings().length <= 0 && $(this).parent().siblings().length >= 2) {
                if ($(this).parent().parent().parent().find(".earn-points").length > 0) $(this).css("width", "159%");
            }

        });

        OPEN.cardsView.grid_divider();
        $('#card-section .list-view-btns .compare-btn').not('.remove-btn').each(function() {
            $(window).width() < 660 && ($(this).hasClass('disable') && $(this).parent().css({
                opacity: "0.6",
                cursor: "default"
            }))
            if ($(this).hasClass('disable') && $(this).parent().attr("disabled") == undefined) {
                $(this).parent().attr("disabled", "disabled")
            } else {
                $(window).width() > 660 && !$(this).hasClass('disable') && ($(this).parent().removeAttr("disabled", "disabled"), $(this).parent().css({
                    opacity: "1",
                    cursor: "pointer"
                }))
            }

        });
    },
    view_Init: function() {
        
        $('.section li .earn-points span.off-txt').parents('.list-content').addClass('spl-offer');
        OPEN.cardsView.grid_divider();
        if (OPEN.config.APP._iscookienable) {
            OPEN.config.APP.vac_cookie = true;
            OPEN.universal.vacCookie(OPEN.compareTray._crdTry);
            OPEN.config.APP.vac_cookie = false;
        }
        /*($(window).width() > 660 && $('#comparision').css("display") == "none") ? $("#list-view").parent().parent().css({
            paddingTop: 76
        }): null;*/
    },
    grid_divider:function(){
        var _lstViewCrd = $('#list-view');
        var sldCrds = _lstViewCrd.find('li:visible').size();
        $(window).width() < 830 ? (Number(sldCrds) % 2) == 0 ? sldCrds = sldCrds - 2 : null : (Number(sldCrds) % 3) == 0 ? sldCrds = sldCrds - 3 : null;
        var numCrds = $(window).width() < 830 ? Math.floor(Number(sldCrds) / 2) * 2 : Math.floor(Number(sldCrds) / 3) * 3;
        _lstViewCrd.find('li:visible').each(function(index, element) {
            index + 1 <= numCrds ? $(this).find(".devider").show() : $(this).find(".devider").hide();
        });        
    },
	grid_seperator:function(){
            if($('#cards-content').hasClass("list-view")){
               
			   var tile = $('#list-view > li');
                for(var i=0; i < tile.length; i++){
					//$('.' + tile[i].className + ' .list-right-sidebar').css('height' ,'auto' );
				
                    var ht1 = $('.' + tile[i].className + ' .list-content-card').height();
                    var ht2 = $('.' + tile[i].className + ' .list-content').height();
                    var ht3 = $('.' + tile[i].className + ' .list-right-sidebar').height();
                    var m = Math.max(ht1, ht2, ht3);
                    m != ht3 && $('.' + tile[i].className + ' .list-right-sidebar').css('min-height' , m +'px' )
                
				}
				
            }
		
	}
};
/*********************************************** Grid/List view section code ends here *********************************************/