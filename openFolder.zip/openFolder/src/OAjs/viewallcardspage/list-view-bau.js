
/*********************************************** List View section code starts here *********************************************/
OPEN.listviewBAU = {
    //initialize List View.
    initialize: function() {
        if(!$("body").hasClass("newgrid")){
            var allBauCardsContent= $(".open #cards-content ul.section>li"); /*only gets BAU cards content*/
            allBauCardsContent.each(function(){
                var thisCardContent=$(this),
                        offerBadge = thisCardContent.find(".list-content-card .pmc-card-details").html();
                thisCardContent.find(".earn-points").prepend(offerBadge).find(".viewallratings, .heading").remove();               
            });
        }
    }
};
/*********************************************** List View section code ends here *********************************************/