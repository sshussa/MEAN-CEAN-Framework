OPEN.RRModules.Header = {
    // Loads selected card details on header
    rrLoadSingleCard: function (card) {
        var cardName = $(".card-filter .filter-card-item .active label").html();
        var cardTitle = $(".card-filter .filter-card-item .active label").text();
        var existingClasses = !!$(OPEN.config.ID.cnt_tp).attr("class") ? $(OPEN.config.ID.cnt_tp).attr("class").replace("pmc-card",""):"";
		$(OPEN.config.ID.cnt_tp).removeClass(existingClasses).addClass("pmc-card aj_card_" + card);	
        $("body").addClass("pmc-card");
		var type = 'normal';
        var pR = !! window.devicePixelRatio ? window.devicePixelRatio : 1; 
        pR>=2 && (type = 'retina'); 
		var cardArtImg=$("#content-top .card-art img"), cardArtSrcPath=(typeof contentPath !== "undefined") && contentPath+"/ngaosbn/OAimages/amex-open/cardarts/thumbnail/angled/"+type+"/angled-cardart-"+card+'.png#resource_version';
        cardArtImg.attr('src')!== cardArtSrcPath && cardArtImg.attr('src',cardArtSrcPath).css('opacity','0').load(function(){cardArtImg.css('opacity','1')}).attr("title", cardTitle);        
        $(".content-top-container h2.heading").html(cardName);		
		/*11B Change start */
		cardTitle = cardTitle.replace("The",""); 
		$(OPEN.config.CLS.apply_bt).attr("title", "Apply for the " + cardTitle);
        $(".content-top-container a.learn-more").attr("title", "Click here to learn more about the " + cardTitle);
		/*11B Change end */
    },
    // Loads rating details for selected card on header
    rrLoadSingleCardRatings: function () {
        if (OPEN.config.APP.rrSCApplyNow != undefined && OPEN.config.APP.rrSCApplyNow != "" && OPEN.config.APP.rrSCApplyNow != "null") {
			var flow="",card= OPEN.config.APP._filterVals.cards;                        
			if(typeof channel !== "undefined" && (channel === "RICHEROFFER" || channel === "UA")) {
                flow=channel;
			} else if ((typeof isPZNRequest !== "undefined" && isPZNRequest)) {
                flow="PZN"
            }  			
			$(OPEN.config.CLS.apply_bt).attr("onclick", "applyForBusinessCard('" + OPEN.config.APP.rrSCApplyNow + "','pmc-"+card+"','"+flow+"')");           
        }

        (OPEN.config.APP.rrSCLearnMore != undefined && OPEN.config.APP.rrSCLearnMore != "" && OPEN.config.APP.rrSCLearnMore != "null") && $(".headers a.learn-more").attr("href", OPEN.config.APP.rrSCLearnMore);

        if ((OPEN.config.APP.rrSCRating != undefined && OPEN.config.APP.rrSCRating != "" && OPEN.config.APP.rrSCRating != "null") || (OPEN.config.APP.rrCustomerServiceRating != undefined && OPEN.config.APP.rrCustomerServiceRating != "" && OPEN.config.APP.rrCustomerServiceRating != "null") || (OPEN.config.APP.rrCardBenefitsRating != undefined && OPEN.config.APP.rrCardBenefitsRating != "" && OPEN.config.APP.rrCardBenefitsRating != "null")) {

            (OPEN.config.APP.rrSCRating.toString().length == 3) && (OPEN.config.APP.rrSCRating = OPEN.config.APP.rrSCRating.toString().replace(".", ""));

            (OPEN.config.APP.rrCustomerServiceRating.toString().length == 3) && (OPEN.config.APP.rrCustomerServiceRating = OPEN.config.APP.rrCustomerServiceRating.toString().replace(".", ""));

            (OPEN.config.APP.rrCardBenefitsRating.toString().length == 3) && (OPEN.config.APP.rrCardBenefitsRating = OPEN.config.APP.rrCardBenefitsRating.toString().replace(".", ""));

            (OPEN.config.APP.rrSCRating.toString().length == 1) && (OPEN.config.APP.rrSCRating = OPEN.config.APP.rrSCRating.toString() + "0");

            (OPEN.config.APP.rrCustomerServiceRating.toString().length == 1) && (OPEN.config.APP.rrCustomerServiceRating = OPEN.config.APP.rrCustomerServiceRating.toString() + "0");

            (OPEN.config.APP.rrCardBenefitsRating.toString().length == 1) && (OPEN.config.APP.rrCardBenefitsRating = OPEN.config.APP.rrCardBenefitsRating.toString() + "0");

            $(".headers #overall-rating span").attr("class", "").addClass("rating-holder rating-" + OPEN.config.APP.rrSCRating);
            $(".headers #customer-service span").attr("class", "").addClass("rating-holder rating-" + OPEN.config.APP.rrCustomerServiceRating);
            $(".headers #card-benefits span").attr("class", "").addClass("rating-holder rating-" + OPEN.config.APP.rrCardBenefitsRating);
        }
        (OPEN.config.APP.rrSCRating == 0) && $(".headers #overall-rating span").attr("class", "").addClass("rating-holder rating-00");
        (OPEN.config.APP.rrCustomerServiceRating == 0) && $(".headers #customer-service span").attr("class", "").addClass("rating-holder rating-00");
        (OPEN.config.APP.rrCardBenefitsRating == 0) && $(".headers #card-benefits span").attr("class", "").addClass("rating-holder rating-00");
    }

};