OPEN.RRModules.ReviewFeedback = {
    onReviewClick: function () {
        $("#review-list").on("click", ".helpful-yes,.helpful-no,.flag", function (e) {
            e.preventDefault();
            if ($(this).attr("class") == "helpful-yes") {
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'click_WasThisReviewHelpfulYes') : null;
            } else if ($(this).attr("class") == "helpful-no") {
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'click_WasThisReviewHelpfulNo') : null;
            }
            var reviewmap = {
                "helpful-yes": "positive",
                "helpful-no": "negative",
                "flag": "inappropriate"
            };
            review = {
                reviewId: $(this).closest(".hreview").attr("id").match(/[0-9]+/g).toString(),
                action: reviewmap[$(this).attr("class")]
            };
            var _thisobj = $(this);
            if (!_thisobj.hasClass("disable")) {
                _thisobj.addClass("disable").siblings().addClass("disable");
                (_thisobj.hasClass("helpful-yes") || _thisobj.hasClass("helpful-no")) && _thisobj.removeAttr("title").siblings().removeAttr("title");
                _thisobj.parents(".rr-review-feedback").find(".thankyou-msg").show().delay(3000).fadeOut("slow");
                _thisobj.hasClass("flag") && _thisobj.html("<span class='ban-icon ban-icon-disabled'></span>Flagged as inappropriate").removeAttr("title");

                $.ajax({
                    type: "POST",
                    url: OPEN.RRModules.Common.rrAjaxNewURL() + "ratings-and-reviews-feedback",
                    data: review,
                    dataType: "html",
                    success: function (m) {
                    }
                });
            }
        });
        return this;
    },
    init: function () {
        this.onReviewClick();
    }
};