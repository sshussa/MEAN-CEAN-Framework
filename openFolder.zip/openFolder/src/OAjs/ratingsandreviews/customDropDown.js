OPEN.RRModules.CustomSelectBox = {
    onclick: function() {
        //for custom select box - to open and close
        $(OPEN.config.CLS._customBox).on("click", function() {
            $(OPEN.config.CLS._customBox).not($(this)).removeClass(OPEN.config.APP._active).next().removeClass(OPEN.config.APP._active);
			$(OPEN.config.CLS._customBox+" .cust-arrow-up").addClass("cust-arrow-down").removeClass("cust-arrow-up");			
            $(this).next().hasClass(OPEN.config.APP._active) ? ($(this).removeClass(OPEN.config.APP._active).next().removeClass(OPEN.config.APP._active),$(this).find(".cust-arrow-up").addClass("cust-arrow-down").removeClass("cust-arrow-up")) : ($(this).addClass(OPEN.config.APP._active).next().addClass(OPEN.config.APP._active),$(this).find(".cust-arrow-down").addClass("cust-arrow-up").removeClass("cust-arrow-down"),(!OPEN.RRModules.Common.touch ? $('.custom-scrollbar').openScrollber() : $(this).parent().find(".viewport").scrollTop(0)));
            if (!$("body").hasClass("res_Small")) {
                $(OPEN.config.CLS._customBox).not($(this)).next().removeClass(OPEN.config.APP._filtrShow);
                $(this).next().hasClass(OPEN.config.APP._filtrShow) ? $(this).next().removeClass(OPEN.config.APP._filtrShow) : $(this).next().addClass(OPEN.config.APP._filtrShow);
            }
        });
        return this;
    },
    onKeyPress: function() {
        $(".custom-check-box," + OPEN.config.CLS._customBox).on("keypress", function(e) {
            e.preventDefault();
            (e.which === 13 || e.which === 32) && $(this).trigger("click");
        });
        return this;
    },
    clickOutOfDropDown: function() {
        // to close the custom dorpdown by clicking anywhere else except drop down
        $(document).bind('touchstart click', function(e) {
            if (($(e.target).closest('.custom-dropdown>ul>li').length === 0 && $(e.target).closest(OPEN.config.CLS._customBox).length === 0) && $(OPEN.config.CLS._custDropDown).hasClass("active") && !$("body").hasClass("res_Small")) {
                $(OPEN.config.CLS._custDropDown).removeClass(OPEN.config.APP._active).removeClass(OPEN.config.APP._filtrShow);
				$(OPEN.config.CLS._customBox+" .cust-arrow-up").addClass("cust-arrow-down").removeClass("cust-arrow-up");
                $(OPEN.config.CLS._customBox).removeClass(OPEN.config.APP._active);
            }
        });
        return this;
    },
    init: function() {
        this.onclick().onKeyPress().clickOutOfDropDown();
    }
};