OPEN.RRModules.Filter = {
    mdl_cont: ".middle-container>.sorting",
    _checkboxChkd: ".filter-card-item input[type=checkbox]:checked",
    onFilterOptionClick: function () {
        // to change the checkbox class and add checked
        $(".filter-card-item").on("click", "li", function (e) {
            e.preventDefault();
            e.stopPropagation();
            var filterItem = $(this);
            var indiFilter = $(this).parents(".filter");
            var selectBoxVal = indiFilter.find(".custom-select-box label");
            if ($(e.target).closest(OPEN.config.CLS._custDropDown + ".sort-filter").length === 0) {
				
                filterItem.hasClass(OPEN.config.APP._active) ? (filterItem.removeClass(OPEN.config.APP._active), filterItem.find("input").removeAttr("checked"), filterItem.find(".checkbox-normal.checkbox-checked").removeClass("checkbox-checked")) : (filterItem.addClass(OPEN.config.APP._active), filterItem.find("input").attr("checked", "checked").next().addClass(""), filterItem.find(".checkbox-normal").addClass("checkbox-checked"));
                var temp = $.makeArray(indiFilter);
                OPEN.RRModules.Filter.countFilterSelections($(temp));
            } else {
                // to load reviews on changing sort by option
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Sortby_' + filterItem.find("a").text().replace(/[^a-z0-9]+/gi, '')) : null;
                indiFilter.find(".filter-card-item>li").removeClass(OPEN.config.APP._active).find("input").removeAttr("checked");
                filterItem.addClass(OPEN.config.APP._active);
                filterItem.find("input").attr("checked", "checked").siblings(".radio-normal").addClass("radio-checked").parent().siblings().find("span").removeClass("radio-checked");
                filterItem.parents(OPEN.config.CLS._custDropDown + ".active").removeClass(OPEN.config.APP._active).prev().removeClass(OPEN.config.APP._active).find(".cust-arrow-up").addClass("cust-arrow-down").removeClass("cust-arrow-up");
                OPEN.RRModules.Common.clearResponseInfo();
                !$("body").hasClass("res_Small") && (selectBoxVal.text(filterItem.find("a").addClass(OPEN.config.APP._active).text()), OPEN.RRModules.Common.rrAjaxRefresh(selectBoxVal.text(), "sorting"));
                if ($("body").hasClass("res_Small")) {
                    var val = filterItem.find("a").text();
                    $(OPEN.RRModules.Filter.mdl_cont).find(".sortby-controls .custom-select-box label").text($.trim(val));
                    $(OPEN.RRModules.Filter.mdl_cont).find(" .sortby-controls .filter-card-item li.active").removeClass("active");
                    $(OPEN.RRModules.Filter.mdl_cont).find(" .sort-filter .filter-card-item li a." + $.trim(val).toLowerCase().replace(" ", "-")).parent().addClass("active").parent().addClass("active");
                }

            }
        });
        return this;
    },
    onClearAllClick: function () {
        // to clear individual filters
        $(".indi-filter-clear").on("click", function (e) {
            e.preventDefault();
            var indiFilter = $(this).parents(".filter");
            indiFilter.find(OPEN.config.CLS._custDropDown + " input[type='checkbox']").removeAttr("checked").siblings(".checkbox-normal.checkbox-checked").removeClass("checkbox-checked").parent().removeClass(OPEN.config.APP._active);
            var temp = $.makeArray(indiFilter);
            OPEN.RRModules.Filter.countFilterSelections($(temp));
        });
        return this;
    },
    onSelectAllClick: function () {
        // to select all options in a filter
        $(".indi-filter-select").on("click", function (e) {
            e.preventDefault();
            var indiFilter = $(this).parents(".filter");
            indiFilter.find(OPEN.config.CLS._custDropDown + " input[type='checkbox']").attr("checked", "checked").siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass(OPEN.config.APP._active);
            var temp = $.makeArray(indiFilter);
            OPEN.RRModules.Filter.countFilterSelections($(temp));
        });
        return this;
    },
    onFilterClick: function () {
        // Filter Submit
        $(".filter-action-submit").on("click", function (e) {
            e.preventDefault();
            (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'FilterBy_' + $(this).parents(OPEN.config.CLS._custDropDown).find(".filter-heading").text().replace(/[^a-z0-9]+/gi, '')) : null;
            $(OPEN.config.ID._filterWrap).find(OPEN.config.CLS._customBox + ".selected").removeClass("selected");
            $(OPEN.config.ID._filterWrap).find(OPEN.config.CLS._custDropDown + ".active").removeClass(OPEN.config.APP._active).prev().removeClass(OPEN.config.APP._active).find(".cust-arrow-up").addClass("cust-arrow-down").removeClass("cust-arrow-up"); 
            OPEN.RRModules.Common.clearResponseInfo();
            OPEN.RRModules.Header.rrLoadSingleCardRatings();
            OPEN.RRModules.Common.rrApplyFilter(e);
            $("body").hasClass("res_Small") && ($(OPEN.config.ID._overlayMask).hide(), $("body").css("overflow", "visible"), $("#filter-wrapper,.filter-options .custom-dropdown").removeClass(OPEN.config.APP._filtrShow), OPEN.RRModules.MobileFilter.countFilterOptions());
            !OPEN.config.APP.isLoad && $(window).scrollTop(iNavHeight);
            OPEN.config.APP.isLoad = false;
        });
        return this;
    },
    onClearAllFiltersClick: function () {
        // Clear all filters
        $(".filter-action-clear").on("click", function (e) {
            var mob_bkp = $("body").hasClass("res_Small");
            e.preventDefault();
            if (mob_bkp && $("#filter-wrapper").hasClass("filter-show")) { /* feb a */
                OPEN.RRModules.Filter.rrResetSortBy();
                OPEN.RRModules.Filter.rrClearAllCheckboxes();
                OPEN.RRModules.MobileFilter.alignBackButton();
            } else {
                (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'click_ClearFilters') : null;
                $(".filter-options .filter-action-submit").parents(OPEN.config.CLS._custDropDown + ".active").removeClass(OPEN.config.APP._active).prev().removeClass(OPEN.config.APP._active).find(".cust-arrow-up").addClass("cust-arrow-down").removeClass("cust-arrow-up");
                OPEN.config.APP.isUrlParameters = false;
                OPEN.RRModules.Filter.rrResetSortBy();
                OPEN.RRModules.Filter.rrClearAllCheckboxes();
                OPEN.RRModules.Common.clearResponseInfo();
                OPEN.RRModules.Common.rrApplyFilter(e);
            }
            !OPEN.config.APP.isLoad && $(window).scrollTop(iNavHeight);
            OPEN.config.APP.isLoad = false;
        });
        return this;
    },
	onCustomCheckBoxChange: function(){
		$(".filter-card-item li > input[type='checkbox']").on("click",function(){		 
			if ($(this).is(":checked")) {                    
				$(this).siblings(".checkbox-normal").addClass("checkbox-checked");
			} else {
				$(this).siblings(".checkbox-normal").removeClass("checkbox-checked");                    
			}
		});
		return this;
	},
    countFilterSelections: function (filters) {
        // count number of selected filters
        filters.not(".filter-body>ul>li:last-child .filter").each(function () {
            var dis = $(this);
            var numChecked = dis.find("input:checked").length;
            var selectBoxVal = dis.find(".custom-select-box label");
            numChecked >= 1 ? selectBoxVal.html(dis.find(".filter-heading").text() + " (" + numChecked + ")") : selectBoxVal.html(dis.find(".filter-heading").text());
        });
        $(window).width() <= 660 && OPEN.RRModules.MobileFilter.alignBackButton();
    },
    rrClearAllCheckboxes: function () {
        // clears all the check box in all the available filters
        $(".filter-options .filter-card-item input[type=checkbox]").removeAttr("checked").siblings(".checkbox-normal.checkbox-checked").removeClass("checkbox-checked").parent().removeClass(OPEN.config.APP._active);
        $("#filter-wrapper .filter").each(function () {
            $(this).find(".custom-select-box label").html($(this).find(OPEN.config.CLS._custDropDown + " .filter-heading").text());
        });        

    },
    rrResetSortBy: function () {
        // Resets the sort by to Newest
        if ($(".sort-filter .filter-card-item li.active").index() != 0) { 
			/* Tablet and Desktop Sort-by */
			$(OPEN.config.CLS.srt_cntrl).find(".custom-select-box label").text("Newest");
			$(OPEN.config.CLS.srt_cntrl).find(".filter-card-item li.active").removeClass(OPEN.config.APP._active).find(".radio-normal").removeClass("radio-checked");			
			$(OPEN.config.CLS.srt_cntrl).find(".filter-card-item li:eq(0)").addClass("active").find(".radio-normal").addClass("radio-checked");
			/* Only mobile filter Sort-by*/
			$(".filter-options .sort-filter .filter-card-item li.active").removeClass(OPEN.config.APP._active).find(".radio-normal").removeClass("radio-checked"); /* feb a */
			$(".filter-options .sort-filter .filter-card-item li:eq(0)").addClass(OPEN.config.APP._active).find(".radio-normal").addClass("radio-checked");
        }
    },
    rrDeleteLastChar: function (str, charac) {
        (str.substring(str.length - 1) == charac) && (str = str.substring(0, str.length - 1));
        return str;
    },
    getSelectedCards: function () {
        // Get selected Cardart IDs
        var cards = "";
        $(".card-filter .filter-card-item input[type=checkbox]:checked").each(function () {
            var cardNo = $(this).attr("id");
            cards += cardNo.substring(cardNo.indexOf("_") + 1) + "^";
        });
        cards = this.rrDeleteLastChar(cards, "^");
        return cards;
    },
    getSelectedRatings: function () {
        // Get selected Ratings
        var ratings = "";
        $(".rating-filter").find(OPEN.RRModules.Filter._checkboxChkd).each(function () {
            var ratingId = $(this).attr("id");
            ratings += ratingId.substring(ratingId.indexOf("_") + 1) + "^";
        });
        ratings = this.rrDeleteLastChar(ratings, "^");
        return ratings;
    },
    rrGetSelectedIndustries: function () {
        // Get selected Industries
        var industries = "";
        $(".industries-filter").find(OPEN.RRModules.Filter._checkboxChkd).each(function () {
            var industryName = $(this).attr("name");
            industries += industryName + "^";
        });
        industries = this.rrDeleteLastChar(industries, "^");
        return industries;
    },
    rrGetSelectedRevenue: function () {
        // Get selected Revenue
        var revenue = "";
        $(".revenue-filter").find(OPEN.RRModules.Filter._checkboxChkd).each(function () {
            var revenueId = $(this).attr("id");
            revenue += revenueId + "^";
        });
        revenue = this.rrDeleteLastChar(revenue, "^");
        return revenue;
    },
    rrGetSelectedEmployees: function () {
        // Get selected no of Employees
        var employees = "";
        $(".employee-filter").find(OPEN.RRModules.Filter._checkboxChkd).each(function () {
            var employeesId = $(this).attr("id");
            employees += employeesId + "^";
        });
        employees = this.rrDeleteLastChar(employees, "^");
        return employees;
    },
    resetFilterOnResize: function () {
        if ($(window).width() > 660) {
            $(OPEN.config.ID._overlayMask).is(":visible") && $(OPEN.config.ID._overlayMask).hide();
            $("body").css("overflow") == "hidden" && $("body").css("overflow", "visible");
            $(OPEN.config.ID._filterWrap).removeClass(OPEN.config.APP._filtrShow).removeAttr("style");
            $(".filter-body,.viewport").removeAttr("style");
            !OPEN.RRModules.Common.touch && $('.custom-scrollbar').openScrollber();
        } else {
            $("#filter-wrapper .filter").each(function () {
                if ($(this).find(OPEN.config.CLS._custDropDown).hasClass(OPEN.config.APP._filtrShow)) {
                    /*mobFilter=$(this).find(".custom-select-box");*/
                    OPEN.RRModules.MobileFilter.showMobFilter();
                    $(this).find(".custom-select-box").trigger("click");
                    var fht = $(this).find(".filter-card-item").height();
                    var wht = $(OPEN.config.ID._filterWrap).height();
                    fht < wht ? ($(this).find(".viewport").css("height", fht), $(this).find(".scrollbar").hide()) : (!OPEN.RRModules.Common.touch && $(this).find('.custom-scrollbar').openScrollber(), $(this).find(".scrollbar").show());
                }
            });
        }
    },
    init: function () {
        this.onFilterOptionClick().onClearAllClick().onSelectAllClick().onFilterClick().onClearAllFiltersClick().onCustomCheckBoxChange();
    }
};