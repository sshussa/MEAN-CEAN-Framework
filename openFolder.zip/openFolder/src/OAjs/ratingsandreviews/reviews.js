OPEN.RRModules.Reviews = {
    onSeeMoreReviewsClick: function () {
        // See more reviews for specific card
        $("#review-list").on("click", "a.see-more-reviews", function (e) {
            e.preventDefault();
            (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'click_SeeMoreReviews') : null;
            var cardNo = $(this).attr("href");
            cardNo = cardNo.split("#")[1];
            var _cardFilter = $(".card-filter .filter-card-item input[type=checkbox]");
            _cardFilter.removeAttr("checked").siblings(".checkbox-normal.checkbox-checked").removeClass("checkbox-checked").parent().removeClass(OPEN.config.APP._active);
            _cardFilter.each(function () {
                ($(this).attr("id") == cardNo) && $(".card-filter .filter-card-item #" + cardNo).attr("checked", "checked").siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass("active");
            });
            OPEN.RRModules.Filter.countFilterSelections($(".filter-options .filter"));
            OPEN.RRModules.Common.clearResponseInfo();
			OPEN.config.APP.pageNo=1;
            OPEN.RRModules.Common.rrAjaxRefresh(OPEN.config.APP._filterVals.sortBy, "see-more-reviews")
            $(window).scrollTop(iNavHeight);
            OPEN.RRModules.MobileFilter.countFilterOptions();
        });
        return this;
    },
    onLoadMoreClick: function () {
        // On click Load more reviews in 320 break point
        $("#load-more-btn").click(function (e) {
            OPEN.config.APP.rrmorereviews = "yes";
            OPEN.config.APP.pageNo++;
            $("#review-list ul").append('<div class="ajax-loading" />');
            OPEN.RRModules.Common.rrAjaxRefresh(OPEN.config.APP._filterVals.sortBy, "load-more-reviews")
        });
        return this;
    },
    header_align: function () {
        if ($(window).width() > 660) {
            $("#review-list .hreview").each(function () {
                var summary = $(this).find(".review-container h2.summary");
                if (summary.hasClass("next-line")) {
                    summary.removeClass("next-line");
                }
                if ((summary.offset().left) == ($(this).find(".review-container .rr-rating-stars").offset().left)) {
                    summary.addClass("next-line");
                }
            });
        }
    },
    first_review: function (w) {
        //open the first review by default
        (w < 660) && ($("#review-list>ul li:first-child").addClass('rr-collapse').height('auto').find(".plus-icon").addClass("minus-icon").removeClass("plus-icon").end().find(".more-links").fadeIn('fast'));
    },
    card_name_height: function () {
        //dynamical height for collapsed review
        if ($(window).width() <= 660) {
            $("#review-list>ul>li").each(function () {
                var _dis = $(this);
                if (!_dis.hasClass('rr-collapse')) {
                    _dis.removeClass('rr-collapse');
                    var review_height;
                    review_height = _dis.find(".rating-detail").height() - $(this).find(".rating-detail .dtreviewed").height();
                    var liPaddindTop = parseInt(_dis.css("padding-top"));
                    var image_height = _dis.find(".rr-expand").outerHeight();
                    _dis.css('height', review_height + "px");
                    var accrd_top = (review_height - image_height - liPaddindTop) / 2;
                    _dis.find(".rr-expand").css('top', accrd_top + "px");
                    if (OPEN.config.APP.brwse_type.match(/Android/i)) { /* Fixed in 10B and Personalization*/
                        _dis.find(".summary").text().length == 0 && _dis.find(".rr-expand").css('top', "-10px");
                    }
                } else {
                    _dis.animate({
                        height: _dis.css('height', 'auto')
                    });
                }
            });
        }
    },
    init: function () {
        this.onSeeMoreReviewsClick().onLoadMoreClick();
    }
};