OPEN.RRModules.Common = {
    touch: ("ontouchstart" in window && (/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/).test(navigator.userAgent)) || window.DocumentTouch && document instanceof DocumentTouch || (navigator.msMaxTouchPoints > 0),
    readHashChange: function () {
        if (this.isAjaxRefresh == false) {
            this.readHash();
            OPEN.config.APP.isUrlParameters = window.location.hash === "";
        }
    },
    // Clear response information
    clearResponseInfo: function () {
        OPEN.config.APP.rrPageCount = 0;
        OPEN.config.APP.rrStartReview = 0;
        OPEN.config.APP.rrEndReview = 0;
        OPEN.config.APP.rrSCReviewsCount = 0;
        OPEN.config.APP.rrSCRating = 0;
        OPEN.config.APP.rrTotalReviews = 0;
        OPEN.config.APP.rrCustomerServiceRating = 0;
        OPEN.config.APP.rrCardBenefitsRating = 0;
        OPEN.config.APP.noOfReviewsTotal = 0;
        OPEN.config.APP.rrAddReviewLink = "";
        $(OPEN.config.ID.topPagination).addClass("noreviews");
        $(OPEN.config.CLS.bottomPagination).addClass("noreviews");
        OPEN.config.APP.pageNo = 1;
    },
    setResponseInfoTOConfig: function(){
        OPEN.config.APP.rrPageCount = rrPageCount;
        OPEN.config.APP.rrStartReview = rrStartReview;
        OPEN.config.APP.rrEndReview = rrEndReview;
        OPEN.config.APP.rrSCApplyNow = rrSCApplyNow;
        OPEN.config.APP.rrSCLearnMore = rrSCLearnMore;
        OPEN.config.APP.rrSCReviewsCount = rrSCReviewsCount;
        OPEN.config.APP.rrSCRating = rrSCRating;
        OPEN.config.APP.rrTotalReviews = rrTotalReviews;
        OPEN.config.APP.rrCustomerService = rrCustomerService;
        OPEN.config.APP.rrCustomerServiceRating = rrCustomerServiceRating;
        OPEN.config.APP.rrCardBenefits = rrCardBenefits;
        OPEN.config.APP.rrCardBenefitsRating = rrCardBenefitsRating;
        OPEN.config.APP.rrAddReviewLink = rrAddReviewLink; 
    },
    //adding l-m class to body
    large_med: function (width) {
        (width >= 800 && width < 1024) ? $("body").addClass('l-m') : $("body").removeClass('l-m');
    },
    //functionality in resizing 
    onBreakpointChange: function (obj) {
        if ((obj.wwidth > 660 && $(window).width() <= 660) || (obj.wwidth <= 660 && $(window).width() > 660)) {
            OPEN.config.APP.pageNo = 1;
            OPEN.RRModules.PageLoad.init();
            obj.wwidth = $(window).width();
            this.readCookie();
        }
    },
    isAjaxRefresh: false,
    rrUrlCardsParameters: {
        "american-express-gold-business-card": "111",
        "starwood-business-credit-card": "474",
        "business-platinum-card": "92",
        "delta-reserve-business-credit-card": "756",
        "platinum-delta-skymiles-business-credit-card": "141",
        "american-express-green-business-card": "89",
        "american-express-plum-card": "499",
        "gold-delta-skymiles-business-credit-card": "113",
        "lowes-business-rewards-credit-card": "251",
        "simplycash-business-credit-card": "1043",
        "simply-cash-plus-business-credit-card": "1043",
        "american-express-blue-for-business-credit-card": "79"
    },
    rrGetUrlParameters: function () {
        var thisObj = this;
        var j = "",
                h = "",
                c = "",
                d = "",
                e = "";
        var f = 0;
        var b = $(location).attr("href");
        OPEN.RRModules.Filter.rrClearAllCheckboxes();
        if (b.indexOf("?") > 0) {
            var a = b.split("?")[1].split("&");
            $.each(a, function (k, l) {
                c = l.replace("#", "").split("=");
                $.each(c[1].split(","), function (m, o) {
                    switch (c[0]) {
                        case "cards":
                            if (thisObj.rrUrlCardsParameters[o] != undefined) {
                                $("#rr_multipleCard #card_" + thisObj.rrUrlCardsParameters[o]).attr("checked", true).click();
                            }
                            break;
                        case "industry":
                            var n = o.replace(/%20/g, "").replace(/ /g, "");
                            $("#rr_filterIndustries input[name='" + n + "']").attr("checked", true).click();
                            break;
                        case "revenue":
                            var n = o.replace(/%20/g, "").replace(/ /g, "");
                            $("#rr_filterRevenue input[id='" + n + "']").attr("checked", true).click();
                            break;
                        case "employees":
                            var n = o.replace(/%20/g, "").replace(/ /g, "");
                            $("#rr_filterEmployees input[id='" + n + "']").attr("checked", true).click();
                            break
                    }
                })
            });            
            $(".filter-options .filter-action-submit:eq(0)").trigger("click");
            OPEN.config.APP.urlhasCardParameters = true;
        }
        return false
    },
    rrUrlCardBenefitParameters: function (i) {
        var g = window.location.search;
        var l = g.substring(1);
        var j = new Array();
        var h = l.split("&");
        for (var k = 0; k < h.length; k++) {
            queryvalue = h[k].split("=");
            if (queryvalue[0] == i) {
                return queryvalue[1]
            }
        }
    },
    // Apply all selected filters
    rrApplyFilter: function (eve) {
        (OPEN.config.APP.rrmorereviews == "") && $("#review-list").html('<div class="ajax-loading" />');
        (OPEN.config.APP.rrmorereviews == "yes") && $("#review-list ul").append('<div class="ajax-loading" />');
        var sortby = $(OPEN.config.CLS.srt_cntrl).find(".custom-select-box label").text();
        this.rrAjaxRefresh(sortby, "applyFilter", eve)
    },
    readHash: function () {
        var b = window.location + "",
                d = "",
                e = 0,
                c = 0,
                thisObj = this;
        if (b.indexOf("#") > 0 && !OPEN.config.APP.isUrlParameters) {
            (b.split("#/")[1] != undefined) ? (d = b.split("#/")[1].split("/")) : d = b.split("#")[1];
        } else {
            (thisObj.rrUrlCardBenefitParameters("cards")) && (thisObj.rrGetUrlParameters(), OPEN.config.APP.isUrlParameters = true);
            return;
        }
		$(".filter-options .filter-card-item input[type=checkbox]").removeAttr("checked").siblings(".checkbox-normal.checkbox-checked").removeClass("checkbox-checked").parent().removeClass(OPEN.config.APP._active);
        $("#filter-wrapper .filter").each(function () {
            $(this).find(".custom-select-box label").html($(this).find(OPEN.config.CLS._custDropDown + " .filter-heading").text());
        });
        if (d.length > 0) {
            $.each(d, function (g, h) {
                var f = h.split("-");
                switch (f[0]) {
                    case "cards":
                        $.each(f, function (j, ele) {
                            if (j > 0) {
                                $("#rr_multipleCard #card_" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass("active");
                            }
                        });
                        break;
                    case "ratings":
                        $.each(f, function (j, ele) {
                            if (j > 0) {
                                $("#rr_filterRatings #rating_" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass("active")
                            }
                        });
                        break;
                    case "industries":
                        $.each(f, function (j, ele) {
                            if (j > 0) {
                                $("#rr_filterIndustries [name=" + ele + "]").attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass("active")
                            }
                        });
                        break;
                    case "revenue":
                        $.each(f, function (j, ele) {
                            if (j > 0) {
                                $("#rr_filterRevenue #" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass("active")
                            }
                        });
                        break;
                    case "employees":
                        $.each(f, function (j, ele) {
                            if (j > 0) {
                                $("#rr_filterEmployees #" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass("active")
                            }
                        });
                        break;
                    default:
                        break
                }
            });
        }
        thisObj.clearResponseInfo();
        thisObj.rrApplyFilter();
        OPEN.RRModules.Filter.countFilterSelections($(".filter-options .filter"));
    },
    // Checks the no of cards selected
    rrIsSingleCard: function (cards) {
        var singleCard = "no";
        (cards !== "undefined" && !(cards.indexOf("^") > 0) && cards != "") && (singleCard = "yes");
        return singleCard;
    },
    readCookie: function () {
        var cookieArr = this.rrGetCookie();
        if (cookieArr == null || cookieArr == undefined) {
            $(".filter-options a.filter-action-clear").trigger("click");
            return false;
        } else {
            OPEN.RRModules.Filter.rrClearAllCheckboxes();
            $.each(cookieArr, function (e, filter) {
                /* Feab A code clean up  */
                if (filter.value != "") {
                    var val = filter.value.split("^");
                    switch (filter.id) {
                        case "rr_cards":


                            $.each(val, function (index, ele) {
                                $("#rr_multipleCard #card_" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass(OPEN.config.APP._active);
                            });

                            break;
                        case "rr_rating":
                            $.each(val, function (index, ele) {
                                $("#rr_filterRatings #rating_" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass(OPEN.config.APP._active)
                            });

                            break;
                        case "rr_industries":


                            jQuery.each(val, function (index, ele) {
                                $("#rr_filterIndustries [name=" + ele + "]").attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass(OPEN.config.APP._active)
                            });

                            break;
                        case "rr_revenue":


                            $.each(val, function (index, ele) {
                                $("#rr_filterRevenue #" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass(OPEN.config.APP._active)
                            });

                            break;
                        case "rr_employees":


                            $.each(val, function (index, ele) {
                                $("#rr_filterEmployees #" + ele).attr("checked", true).siblings(".checkbox-normal").addClass("checkbox-checked").parent().addClass(OPEN.config.APP._active)
                            });

                            break;
                        case "rr_sortBy":
                            val = filter.value;
                            $(".sortby-controls .custom-select-box label").text($.trim(val));
                            $(".sortby-controls .filter-card-item li.active,.filter-options .sort-filter .filter-card-item li.active").removeClass("active").find(".radio-normal").removeClass("radio-checked");
                            $(".sort-filter .filter-card-item li a." + $.trim(val).toLowerCase().replace(" ", "-")).parent().addClass("active").parent().addClass("active");
                            $(".filter-options .sort-filter .filter-card-item li a." + $.trim(val).toLowerCase().replace(" ", "-")).siblings(".radio-normal").addClass("radio-checked").parent().addClass("active").parent().addClass("active");
                            break;
                        default:
                            break
                    }
                }
            });
            OPEN.RRModules.Filter.countFilterSelections($(".filter-options .filter"));
        }
        return true;
    },
    rrGetCookie: function () {
        var rrfilterOptsArr = null;
        var rrFilterOptsObjAss = null;
        if (document.cookie.length > 0) {
            var cookie = document.cookie.split(";");
            for (var i = 0; i < cookie.length; i++) {
                cookie[i].match("ratings_and_reviews") && (rrfilterOptsArr = cookie[i].split("=")[1]);
            }
            if (rrfilterOptsArr != null) {
                rrFilterOptsObjAss = [];
                var indiFilter = "";
                var rrFilterOptsObj = rrfilterOptsArr.split("&");
                for (var i = 0; i < rrFilterOptsObj.length; i++) {
                    indiFilter = rrFilterOptsObj[i].split(":");
                    rrFilterOptsObjAss.push({
                        id: indiFilter[0],
                        value: indiFilter[1]
                    });
                }
            }
        }
        return rrFilterOptsObjAss;
    },
    rrAjaxNewURL: function () {
        var b = "";
        var rrUrlHaveParameters = function () {
            var a = $(location).attr("href");
            if (a.indexOf("business-card-reviews/") > 0) {
                return true;
            }
            return false;
        };
        (rrUrlHaveParameters()) && (b = "../");
        return b;
    },
    // Applying all filter through Ajax
    rrAjaxRefresh: function (sortby, filter, eve) {
        var thisObj = this;
        thisObj.isAjaxRefresh = true;
        var cards = "",
                industries = "",
                revenue = "",
                employees = "",
                queryStr = "",
                singleCard = "",
                rrVisibleReviewCount = $(window).width() <= 660 ? 5 : 10;
        var rrSetCookie = function (cookie) {
            document.cookie = "ratings_and_reviews=" + cookie + "; path=/; secure";
        };
        var createCookieAll = function (cards, ratings, industries, revenue, employees, sortBy) {
            var cookie = "";
            cookie = "rr_cards:" + cards + "&rr_rating:" + ratings + "&rr_industries:" + industries + "&rr_revenue:" + revenue + "&rr_employees:" + employees + "&rr_sortBy:" + sortBy;
            rrSetCookie(cookie);
        };
        var rrScrollTop = function () {
            $("html, body").animate({
                scrollTop: $(window).width() > 660 && $(window).width() <= 830 ? $("#content-filters").offset().top - $("#ajnav").height() : $("#content-filters .middle-container").offset().top - $("#ajnav").height()
            }, 0);
        };
        if (filter == "applyFilter") {
            cards = OPEN.RRModules.Filter.getSelectedCards();
            singleCard = thisObj.rrIsSingleCard(cards);
            ratings = OPEN.RRModules.Filter.getSelectedRatings(); 
            industries = OPEN.RRModules.Filter.rrGetSelectedIndustries();
            revenue = OPEN.RRModules.Filter.rrGetSelectedRevenue();
            employees = OPEN.RRModules.Filter.rrGetSelectedEmployees();
            createCookieAll(cards, ratings, industries, revenue, employees, sortby);
        } else {
            /* for sorting */
            if (filter == "sorting") {
                $("#review-list").html('<div class="ajax-loading" />');
                cards = OPEN.config.APP._filterVals.cards;
                singleCard = OPEN.config.APP._filterVals.isSingleCard;
                ratings = OPEN.config.APP._filterVals.rating;
                industries = OPEN.config.APP._filterVals.industry;
                revenue = OPEN.config.APP._filterVals.annualBusinessRevenue;
                employees = OPEN.config.APP._filterVals.numOfEmp;
            }
            /* for pagination and load more*/
            if (filter == "pagination" || filter == "load-more-reviews") {
                cards = OPEN.config.APP._filterVals.cards;
                singleCard = OPEN.config.APP._filterVals.isSingleCard;
                ratings = OPEN.config.APP._filterVals.rating;
                industries = OPEN.config.APP._filterVals.industry;
                revenue = OPEN.config.APP._filterVals.annualBusinessRevenue;
                employees = OPEN.config.APP._filterVals.numOfEmp;
                filter == "pagination" && rrScrollTop();
            }

            /* for see more reviews*/
            if (filter == "see-more-reviews") {
                $("#review-list").html('<div class="ajax-loading" />');
                cards = OPEN.RRModules.Filter.getSelectedCards();
                singleCard = thisObj.rrIsSingleCard(cards);
                ratings = OPEN.config.APP._filterVals.rating;
                industries = OPEN.config.APP._filterVals.industry;
                revenue = OPEN.config.APP._filterVals.annualBusinessRevenue;
                employees = OPEN.config.APP._filterVals.numOfEmp;
            }
            $(".filter-options .filter-card-item input[type=checkbox]").removeAttr("checked").parent().removeClass(OPEN.config.APP._active);
            createCookieAll(cards, ratings, industries, revenue, employees, sortby);
            thisObj.readCookie();
        }
        OPEN.config.APP._filterVals.visibleReviewCount = rrVisibleReviewCount;
        if (singleCard == "yes") {
            OPEN.RRModules.Header.rrLoadSingleCard(cards);
        } else {
            var singleCardClasses= $(OPEN.config.ID.cnt_tp).hasClass("pmc-card") && $(OPEN.config.ID.cnt_tp).attr("class");            
            $(OPEN.config.ID.cnt_tp).addClass("multi-card").removeClass(singleCardClasses);
            $("body").removeClass("pmc-card");
            ($("#content-top .card-art img").attr('src') !== OPEN.config.APP.multiCardImgSrc) && $("#content-top .card-art img").attr('src',OPEN.config.APP.multiCardImgSrc).css('opacity','0').load(function(){$("#content-top .card-art img").css('opacity','1')});
            $("#content-top .card-art img").attr("title", "Business Card Reviews - American Express OPEN");
        }

        $(OPEN.config.ID.topPagination).addClass("noreviews");
        //Hidding Load more reviews button and pagination
        var errorPageControls = function () {
            $(window).width() <= 660 && ((OPEN.config.APP.rrTotalReviews == 0) || (OPEN.config.APP.rrTotalReviews == OPEN.config.APP.rrEndReview) ? $("#load-more-btn").hide() : $("#load-more-btn").show());
            (OPEN.config.APP.rrTotalReviews == 0) ? $(OPEN.config.ID.topPagination).addClass("noreviews") : $(OPEN.config.ID.topPagination).removeClass("noreviews");
            (OPEN.config.APP.rrTotalReviews == 0 || OPEN.config.APP.rrPageCount <= 1) ? $(OPEN.config.CLS.bottomPagination).addClass("noreviews") : $(OPEN.config.CLS.bottomPagination).removeClass("noreviews");
        };        
        if (OPEN.config.APP.pageNo == 1) {
            var reviewNumber = $("#top_info p span.strong");
            $(reviewNumber).eq(0).html("0");
            $(reviewNumber).eq(1).html("0");
            $(reviewNumber).eq(2).html("0");
        }
        queryStr = thisObj.rrAjaxNewURL() + "ratings-and-reviews-apply-filter";
        OPEN.config.APP._filterVals = {
            sortBy: sortby,
            pageNumber: OPEN.config.APP.pageNo,
            cards: cards,
            rating: ratings,
            industry: industries,
            numOfEmp: employees,
            annualBusinessRevenue: revenue,
            isSingleCard: singleCard,
            SID: Math.random(),
            visibleReviewCount: rrVisibleReviewCount
        };
        $.ajax({
            type: "POST",
            url: queryStr,
            data: OPEN.config.APP._filterVals,
            dataType: "html",
            cache: false,
            success: function (m) {
                var resonseEle = (OPEN.config.APP.rrmorereviews == "yes") ? $("#more-reviews") : $(OPEN.config.ID.reviewsContainer);
                resonseEle.html(m);
		OPEN.RRModules.Common.setResponseInfoTOConfig();
                if (rrVisibleReviewCount == 5) {
                    if (OPEN.config.APP.rrmorereviews == "yes") {
                        $("#review-list ul").find(".ajax-loading").remove();
                        if (OPEN.config.APP.rrTotalReviews != 0)
                            $("#review-list ul")[0].innerHTML += $("#more-reviews ul").html();
                        else
                            $("#review-list")[0].innerHTML += $("#more-reviews").html();
                        OPEN.config.APP.rrmorereviews = "";
                        OPEN.RRModules.Reviews.card_name_height();
                    } else {
                        OPEN.RRModules.Reviews.card_name_height();
                        OPEN.RRModules.Reviews.first_review($(window).width());
                    }


                } else {
                    OPEN.config.APP.noOfReviewsTotal = (singleCard == "no" ? OPEN.config.APP.rrTotalReviews : OPEN.config.APP.rrSCReviewsCount);
                    (OPEN.config.APP.pageNo == 1) && OPEN.RRModules.Pagination.rrCreatePagination(1, 1);
                }
                if (filter == "applyFilter" || filter == "see-more-reviews") {
                    OPEN.RRModules.Header.rrLoadSingleCardRatings();
                    !OPEN.config.APP.urlhasCardParameters && thisObj.rrUpdateHash(cards, ratings, industries, revenue, employees, eve);
                    OPEN.config.APP.isUrlParameters = false;
                    OPEN.config.APP.urlhasCardParameters = false;
                }
                $("#rr-add-review-btn").attr("href", OPEN.config.APP.rrAddReviewLink);
                OPEN.RRModules.Pagination.rrUpdateReviewCountInfo();
                errorPageControls(); /* to show / hide pagination and more-reviews button */
                filter == "pagination" && rrScrollTop();
                OPEN.RRModules.Reviews.header_align();
                setTimeout(function () {
                    thisObj.isAjaxRefresh = false
                }, 500);

            },
            error: function () {
                /* localRRErr is used to load the dummy/static data for local environments only 
                 * Please find the defination for localRRErr in ratings-and-reviews-local.js
                 * */
                if (typeof localRRErr !== "undefined") {
                    localRRErr(OPEN, cards, sortby, rrVisibleReviewCount, singleCard, filter, ratings, industries, revenue, employees, eve, errorPageControls);
                } else {
                    $("#review-list ul").find(".ajax-loading").remove();
                    window.location = "../credit-cards/systemError";
                }
            },
            complete: function () {

            }
        });
    },
    rrUpdateHash: function (cards, ratings, industries, revenue, employees, eve) {
        var url = window.location + "";
        var selectedFilters = "";
        var isEventFired = false;
        var filterChanged = false;
        /* Feb A Code Clean up*/
        function crds_fltr(flts_by, urlst) {
            selectedFilters += "/" + urlst + "-" + flts_by.replace(/\^/g, "-");
            filterChanged = true;
        }
        ;
        cards.length > 0 && crds_fltr(cards, "cards");
        ratings.length > 0 && crds_fltr(ratings, "ratings");
        industries.length > 0 && crds_fltr(industries, "industries");
        employees.length > 0 && crds_fltr(employees, "employees");
        revenue.length > 0 && crds_fltr(revenue, "revenue");
        if (typeof eve != "undefined") {
            ($(eve.target).closest(".filter-action-clear").length == 1) && (selectedFilters += "/clearAll", isEventFired = true);
            ($(eve.target).closest(".filter-action-submit").length == 1 && cards.length == 0 && ratings.length == 0 && industries.length == 0 && employees.length == 0 && revenue.length == 0) && (selectedFilters += "/clearAll", isEventFired = true);
        }

        if (url.indexOf("#") > 0) {
            if (isEventFired || filterChanged) {
                window.location = url.split("#")[0] + "#" + selectedFilters;
            }

        } else if (isEventFired || filterChanged) {
            window.location = url + "#" + selectedFilters;
        }
        this.lastHash = selectedFilters;
        OPEN.RRModules.MobileFilter.countFilterOptions();
    }
};

/*open scrollbar start*/
(function (factory) {
    if (typeof define === 'function' && define.amd) {

        define(['jquery'], factory);
    } else if (typeof exports === 'object') {

        factory(require('jquery'));
    } else {
        factory(jQuery);
    }
}
(function ($) {
    $.openObj = $.openObj || {};
    $.openObj.scrollbar = {
        options: {
            axis: 'y',
            wheel: true,
            wheelSpeed: 40,
            wheelLock: true,
            scrollInvert: false,
            trackSize: false,
            thumbSize: false
        }
    };
    $.fn.openScrollber = function (params) {
        var options = $.extend({}, $.openObj.scrollbar.options, params);
        var t = this;
        t.each(function () {
            $(this).data('tsb', new Scrollbar($(this), options));
        });
        return this;
    };
    $.fn.openScrollber_update = function (sScroll) {
        return $(this).data('tsb').update(sScroll);
    };

    function Scrollbar($container, options) {
        var self = this,
                $viewport = $container.find(".viewport"),
                $overview = $container.find(".overview"),
                $scrollbar = $container.find(".scrollbar"),
                $track = $scrollbar.find(".track"),
                $thumb = $scrollbar.find(".thumb"),
                viewportSize = 0,
                contentSize = 0,
                contentPosition = 0,
                contentRatio = 0,
                trackSize = 0,
                trackRatio = 0,
                thumbSize = 0,
                thumbPosition = 0,
                mousePosition = 0,
                isHorizontal = options.axis === 'x',
                hasTouchEvents = ("ontouchstart" in window && (/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/).test(navigator.userAgent)) || window.DocumentTouch && document instanceof DocumentTouch || (navigator.msMaxTouchPoints > 0), // june release fix for mozilla 26
                sizeLabel = isHorizontal ? "width" : "height",
                posiLabel = isHorizontal ? "left" : "top";

        function initialize() {
            self.update();
            setEvents();
            return self;
        }
        this.update = function (scrollTo) {
            sizeLabelCap = sizeLabel.charAt(0).toUpperCase() + sizeLabel.slice(1).toLowerCase();
            viewportSize = $viewport[0]['offset' + sizeLabelCap];
            contentSize = $overview[0]['scroll' + sizeLabelCap];
            contentRatio = viewportSize / contentSize;
            trackSize = options.trackSize || viewportSize;
            thumbSize = Math.min(trackSize, Math.max(0, (options.thumbSize || (trackSize * contentRatio))));
            trackRatio = options.thumbSize ? (contentSize - viewportSize) / (trackSize - thumbSize) : (contentSize / trackSize);
            $scrollbar.toggleClass("disable", contentRatio >= 1);
            switch (scrollTo) {
                case "bottom":
                    contentPosition = contentSize - viewportSize;
                    break;
                case "relative":
                    contentPosition = Math.min(contentSize - viewportSize, Math.max(0, contentPosition));
                    break;
                default:
                    contentPosition = parseInt(scrollTo, 10) || 0;
            }

            setSize();
        };

        function setSize() {
            $thumb.css(posiLabel, contentPosition / trackRatio);
            $overview.css(posiLabel, -contentPosition);
            mousePosition = $thumb.offset()[posiLabel];
            $scrollbar.css(sizeLabel, trackSize);
            $track.css(sizeLabel, trackSize);
            $thumb.css(sizeLabel, thumbSize);
        }

        function setEvents() {
            if (hasTouchEvents) {
                $thumb[0].ontouchstart = function (event) {
                    if (1 === event.touches.length) {
                        start(event.touches[0]);
                        event.stopPropagation();
                    }
                };
                $viewport[0].ontouchstart = function (event) {
                    if (1 === event.touches.length) {
                        start(event.touches[0]);
                        event.stopPropagation();
                    }
                };
            } else {
                $thumb.bind("mousedown", start);
                $track.bind("mouseup", drag);
            }
            if (options.wheel && window.addEventListener) {
                $container[0].addEventListener("DOMMouseScroll", wheel, false);
                $container[0].addEventListener("mousewheel", wheel, false);
            } else if (options.wheel) {
                $container[0].onmousewheel = wheel;
            }
        }

        function start(event) {
            $("body").addClass("noSelect");
            mousePosition = isHorizontal ? event.pageX : event.pageY;
            thumbPosition = parseInt($thumb.css(posiLabel), 10) || 0;
            if (hasTouchEvents) {
                $viewport[0].ontouchmove = function (event) {
                    event.stopPropagation();
                    event.preventDefault();
                    drag(event.touches[0]);
                };
                $viewport[0].ontouchend = end;
                $thumb[0].ontouchmove = function (event) {
                    event.stopPropagation();
                    event.preventDefault();
                    drag(event.touches[0]);
                };
                $thumb[0].ontouchend = end;
            } else {
                $(document).bind("mousemove", drag);
                $(document).bind("mouseup", end);
                $thumb.bind("mouseup", end);
            }
        }

        function wheel(event) {
            if (contentRatio < 1) {
                var eventObject = event || window.event,
                        wheelSpeedDelta = eventObject.wheelDelta ? eventObject.wheelDelta / 120 : -eventObject.detail / 3;
                contentPosition -= wheelSpeedDelta * options.wheelSpeed;
                contentPosition = Math.min((contentSize - viewportSize), Math.max(0, contentPosition));
                $thumb.css(posiLabel, contentPosition / trackRatio);
                $overview.css(posiLabel, -contentPosition);
                if (options.wheelLock || (contentPosition !== (contentSize - viewportSize) && contentPosition !== 0)) {
                    eventObject = $.event.fix(eventObject);
                    eventObject.preventDefault();
                }
            }
        }

        function drag(event) {
            if (contentRatio < 1) {
                mousePositionNew = isHorizontal ? event.pageX : event.pageY;
                thumbPositionDelta = mousePositionNew - mousePosition;
                if (options.scrollInvert) {
                    thumbPositionDelta = mousePosition - mousePositionNew;
                }
                thumbPositionNew = Math.min((trackSize - thumbSize), Math.max(0, thumbPosition + thumbPositionDelta));
                contentPosition = thumbPositionNew * trackRatio;
                $thumb.css(posiLabel, thumbPositionNew);
                $overview.css(posiLabel, -contentPosition);
            }
        }

        function end() {
            $("body").removeClass("noSelect");
            $(document).unbind("mousemove", drag);
            $(document).unbind("mouseup", end);
            $thumb.unbind("mouseup", end);
            document.ontouchmove = document.ontouchend = null;
        }
        return initialize();
    }
}));
/*open scrollbar end*/
window.onpageshow = function (event) {
    if (event.persisted) {
        setTimeout(function () {
            OPEN.config.APP.brwse_type.match(/iPad/i) && $(window).resize();
        }, 100);
    }
}; /*Inav fix 10B*/