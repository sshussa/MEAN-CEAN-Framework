/* This JS is used only to run R&R page locally. 
 * Is not intended to move to E1/E2/E3   
 */


function localRRErr(OPEN, cards, sortby, rrVisibleReviewCount,  singleCard, filter, ratings, industries, revenue, employees, eve, errorPageControls){


    var errorhtml = "response.html";
    if (cards == 474 && (sortby == "Oldest" || sortby == "Newest" || sortby == "Highest Rating" || sortby == "Lowest Rating")) {
        errorhtml = "474.html";
    } else if (cards == 141 && (sortby == "Oldest" || sortby == "Newest" || sortby == "Highest Rating" || sortby == "Lowest Rating")) {
        errorhtml = "141.html";
    } else if (cards == 111 && (sortby == "Oldest" || sortby == "Newest" || sortby == "Highest Rating" || sortby == "Lowest Rating")) {
        errorhtml = "111.html";

    } else if (cards == 499 && (sortby == "Oldest" || sortby == "Newest" || sortby == "Highest Rating" || sortby == "Lowest Rating" || $(window).width() <= 660)) {
        errorhtml = "error.html";

    }

    if (rrVisibleReviewCount == 5 && cards != 499) {
        errorhtml = "more-reviews.html";
        if (OPEN.config.APP.rrmorereviews == "yes") {
            $("#more-reviews").load(errorhtml, function () {
                OPEN.RRModules.Common.setResponseInfoTOConfig();
                $("#review-list ul").find(".ajax-loading").remove();
				OPEN.RRModules.Header.rrLoadSingleCardRatings();
                $("#review-list ul")[0].innerHTML += $("#more-reviews ul").html();
                OPEN.RRModules.Reviews.card_name_height();
                errorPageControls(); /* to show / hide pagination and more-reviews button */
                OPEN.RRModules.Reviews.header_align();
            });
            $("#more-reviews").html("");
            OPEN.config.APP.rrmorereviews = "";
        } else {
            $("#review-list").load(errorhtml, function () {
                OPEN.RRModules.Common.setResponseInfoTOConfig();
                OPEN.config.APP.noOfReviewsTotal = (singleCard == "no" ? OPEN.config.APP.rrTotalReviews : OPEN.config.APP.rrSCReviewsCount);
				OPEN.RRModules.Header.rrLoadSingleCardRatings();
                OPEN.RRModules.Reviews.card_name_height();
                OPEN.RRModules.Reviews.first_review($(window).width());
                OPEN.RRModules.Reviews.header_align();
                errorPageControls(); /* to show / hide pagination and more-reviews button */
            });
        }

    } else {
        $("#review-list").load(errorhtml, function () {
            OPEN.RRModules.Common.setResponseInfoTOConfig();
            OPEN.config.APP.noOfReviewsTotal = (singleCard == "no" ? OPEN.config.APP.rrTotalReviews : OPEN.config.APP.rrSCReviewsCount);
            OPEN.RRModules.Header.rrLoadSingleCardRatings();
            OPEN.RRModules.Pagination.rrUpdateReviewCountInfo();
            (OPEN.config.APP.pageNo == 1) && OPEN.RRModules.Pagination.rrCreatePagination(1, 1);
            errorPageControls(); /* to show / hide pagination and more-reviews button */
            OPEN.RRModules.Reviews.header_align();
        });
    }
    if (filter == "applyFilter" || filter == "see-more-reviews") {
        $("#rr-add-review-btn").attr("href", OPEN.config.APP.rrAddReviewLink); /* for add review button */
        !OPEN.config.APP.urlhasCardParameters && OPEN.RRModules.Common.rrUpdateHash(cards, ratings, industries, revenue, employees, eve);
        OPEN.config.APP.isUrlParameters = false;
        OPEN.config.APP.urlhasCardParameters = false;
    }
    setTimeout(function () {
        OPEN.RRModules.Common.isAjaxRefresh = false;
    }, 500);
};

           