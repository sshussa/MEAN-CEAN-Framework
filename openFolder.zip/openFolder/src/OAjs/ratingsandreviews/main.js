if (!window.OPEN) {
    var OPEN = {};
}
if (!window.OPEN.RRModules) {
    OPEN.RRModules = {};
}
(function ($, window, document) {

    if (typeof jQuery == 'undefined') {
        throw new Error("JQuery library is not loaded which is mandatory to run the AMEX OPEN Application");
        return;
    }

    /*************************************************** Config Starts here ***********************************************/
    //Page level config details. but these are not Global variables.
    OPEN.config = {
        ID: {
            reviewsContainer: "#review-list",
            topPagination: "#top_info",
            _filterWrap: "#filter-wrapper",
            _overlayMask: "#cmn-overlay",
            cnt_tp: "#content-top"
        },
        CLS: {
            _customBox: ".custom-select-box",
            bottomPagination: ".pagination_controls",
            _custDropDown: ".custom-dropdown",
            srt_cntrl: ".sortby-controls",
            apply_bt: ".headers .apply-button"
        },
        APP: {
            rrPageCount: "",
            rrStartReview: "",
            rrEndReview: "",
            rrSCApplyNow: "",
            rrSCLearnMore: "",
            rrSCReviewsCount: "",
            rrSCRating: "",
            rrTotalReviews: "",
            rrCustomerServiceRating: "",
            rrCardBenefitsRating: "",
            rrmorereviews: "",
            rrAddReviewLink: "",
            pageNo: 1,
            bodyClass: "",
            _filtrShow: "filter-show",
            _active: "active",
            _filterVals: "",
            isLoad: false,
            brwse_type: navigator.userAgent,
            isUrlParameters: window.location.hash === "",
            noOfReviewsTotal: "",
            urlhasCardParameters: false
        }

    }

    /*************************************************** Config ends here ***********************************************/
    //Page level implementation 
    OPEN.RR = function () {

        //Closur global variables.

        var rrPage = {
            // --------- Private methods which are encapsulated inside the structure.            
            wwidth: $(window).width(),
            triggerResizeEnd: function () {
                var sett = setTimeout(function () {
                    OPEN.config.APP.bodyClass != $('body').attr('class') && $('body').hasClass('nexus') ? ($(window).resize(), OPEN.config.APP.bodyClass = $('body').attr('class')) : clearTimeout(sett);
                }, 2000)
                if (this.resizeTO)
                    clearTimeout(this.resizeTO);
                this.resizeTO = setTimeout(function () {
                    $(this).trigger('resizeEnd');
                }, 400);
            },
            // --------- Public methods which are exposed out-side the structure.
            public: {
                $attachFilterEventsAndHandlers: function () {
                    void 0 != OPEN.RRModules.CustomSelectBox && OPEN.RRModules.CustomSelectBox.init();
                    void 0 != OPEN.RRModules.Filter && OPEN.RRModules.Filter.init();
                    void 0 != OPEN.RRModules.MobileFilter && OPEN.RRModules.MobileFilter.init();
                },
                $onPageLaod: function() {
                    void 0 != OPEN.RRModules.PageLoad && OPEN.RRModules.PageLoad.init();
                },
                $attachReviewsEventsAndHandlers: function() {    
                    void 0 != OPEN.RRModules.Accordion && OPEN.RRModules.Accordion.init();
                    void 0 != OPEN.RRModules.Pagination && OPEN.RRModules.Pagination.init();
                    void 0 != OPEN.RRModules.ReviewFeedback && OPEN.RRModules.ReviewFeedback.init();
                    void 0 != OPEN.RRModules.Reviews && OPEN.RRModules.Reviews.init();
                },
                $mediumLarge: function () {
                    void 0 != OPEN.RRModules.Common && OPEN.RRModules.Common.large_med(_.wwidth);
                },
                //event handlers
                eventDelegates: function () {
                    //resize implementaion code is supposed to be placed in the following event block
                    $(window).resize(function (event) {
                        void 0 != OPEN.RRModules.Common && OPEN.RRModules.Common.large_med($(window).width());
                        void 0 != OPEN.RRModules.Common && OPEN.RRModules.Common.onBreakpointChange(_);
                        _.triggerResizeEnd();
                    });
                    $(window).bind('resizeEnd', function () {
                        iNavHeight = $(window).width() > 660 ? $('#iNavHdWrap').outerHeight() : $('#iNMbWrap').outerHeight();
                        OPEN.RRModules.Common.touch && ((window.innerHeight < window.innerWidth) ? $("body").addClass("mob-landscape") : $("body").removeClass("mob-landscape"));
                        void 0 !== OPEN.RRModules.Filter && OPEN.RRModules.Filter.resetFilterOnResize();
                        void 0 !== OPEN.RRModules.MobileFilter && OPEN.RRModules.MobileFilter.alignBackButton();
                        void 0 !== OPEN.RRModules.Reviews && OPEN.RRModules.Reviews.header_align() && OPEN.RRModules.Reviews.card_name_height();
                    });
                    $(window).bind("hashchange", function () {
                        void 0 !== OPEN.RRModules.Common && OPEN.RRModules.Common.readHashChange();
                    });
                }
            }

        }
        for (var obj in this)
            rrPage[obj] = this[obj];
        var _ = rrPage;
        return rrPage.public;
    }

    function INIT(init, inhr) {
        for (var obj in (OPEN.RR()))
            (init ? obj[0] == '$' : obj[0] != '$') && typeof (OPEN.RR()[obj]) == "function" && (OPEN.RR()[obj]).call(inhr);
    }

    $(document).ready(function (e) {
        //initialize the methods before HTML structure renders on web page.
        INIT(true, OPEN.config);
    });
    $(window).load(function (e) {
        //initialize the methods after all assets(HTML/CSS/JS) are loaded on web page.
        INIT(false, OPEN.config);
    });
})(window.jQuery, window, document);