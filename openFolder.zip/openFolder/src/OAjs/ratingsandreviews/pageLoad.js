OPEN.RRModules.PageLoad = {
	loadHeaderImg: function(){       
	var type = 'normal';
        var pR = !! window.devicePixelRatio ? window.devicePixelRatio : 1; 
        pR>=2 && (type = 'retina');  
        (typeof contentPath !== "undefined") &&  $("#content-top .card-art img");
        OPEN.config.APP.multiCardImgSrc = (typeof contentPath !== "undefined") && (contentPath+"/ngaosbn/OAimages/ratingsandreviews/"+type+"/multi-card-arts-stack-hero.png#resource_version");
	$("#content-top .card-art img").attr("src",OPEN.config.APP.multiCardImgSrc).css({'visibility':'visible'});
        
	},
    init: function () {
        OPEN.RRModules.PageLoad.loadHeaderImg();
        OPEN.config.APP.isLoad = true;
        OPEN.config.APP.bodyClass = $('body').attr('class');
        var urlClear = window.location + "";
        if (urlClear.split('#/')[1] != "clearAll") {
            if (!OPEN.config.APP.isUrlParameters || typeof OPEN.RRModules.Common.rrUrlCardBenefitParameters("cards") == "undefined") {
                (OPEN.RRModules.Common.readCookie()) && $(".filter-options a.filter-action-submit:eq(0)").trigger("click");
            } else {
                OPEN.RRModules.Common.rrGetUrlParameters();
                OPEN.config.APP.isUrlParameters = true;
            }
        }
        else {
            $(".filter-options a.filter-action-clear").trigger("click");
        }
        OPEN.RRModules.Common.touch && $(".custom-dropdown").addClass("touch-dropdown");
    }
};