OPEN.RRModules.Accordion = {
	 //accordion functionality for mobile break point
    onReviewListClick: function() {
        $("#review-list").on("click", ".rr-expand", function(e) {
            e.preventDefault();

            if ($(window).width() < 660 && $(e.target).closest('.dtreviewed').length === 0) {
                var _dis = $(this).closest('li'),
                    collapsed_height = _dis.find(".rating-detail").height() - _dis.find(".rating-detail .dtreviewed").height(),
                    icon=_dis.find(".rr-expand>span");
                if (_dis.hasClass('rr-collapse')) {
                    _dis.removeClass('rr-collapse');
                    icon.removeClass("minus-icon").addClass("plus-icon");
                    _dis.animate({
                        'height': collapsed_height
                    }, 300);
                    $(this).parent().find(".more-links").fadeOut("fast");
                } else {
                    _dis.addClass('rr-collapse');
                    icon.addClass("minus-icon").removeClass("plus-icon");
                    var expanded_height = _dis.find('.hreview').height();
                    _dis.animate({
                        'height': expanded_height
                    }, 300);
                    $(this).parent().find(".more-links").fadeIn("fast");
                }
            }
        });
		return this;
    },
	init: function(){
		this.onReviewListClick();
	}
};