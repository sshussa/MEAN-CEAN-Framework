OPEN.RRModules.MobileFilter = {
    filterNum: 0,
    onFiltersClick: function () {
        // To open the set of filters options on clicking a filter item
        $(".filter-options .custom-select-box").on("click", function (e) {
            if ($("body").hasClass("res_Small")) {
                $(".filter-options .custom-select-box").removeClass("selected");
                $(this).addClass("selected");
                $(".filter-options .custom-select-box .cust-arrow-up,.filter-options .custom-select-box .cust-arrow-down").removeClass("show-full");				
                $(this).parent().parent().prev().find(".cust-arrow-down").addClass("show-full");
                $(".filter-options").find(OPEN.config.CLS._custDropDown).removeClass(OPEN.config.APP._filtrShow);
                $(this).next().addClass(OPEN.config.APP._filtrShow);
                if (OPEN.RRModules.Common.touch) {
                    $(".viewport").each(function () {
                        $(this).css('height', $(this).find(".overview").height());
                    });
                    $(".viewport").css('height', $(window).height());
                }
                var ht = $(OPEN.config.ID._filterWrap).height();
                $(this).next().find(".viewport").css("height", ht);
                !OPEN.RRModules.Common.touch && $('.custom-scrollbar').openScrollber();
                var aht = $(this).next().find(".filter-card-item").height();
                aht < ht && ($(this).next().find(".viewport").css("height", aht), $(this).next().find(".scrollbar").hide());
                OPEN.RRModules.MobileFilter.alignBackButton();
            }
        });
        return this;
    },
    onFilterOverlayTouch: function () {
        // To adjust the filter overlay height in mobile devices when moved on the screen
        // Height changes if there are changed in browser tabs and options
        var lastScrollTop = 0;
        $(".filter-body,.filter-content").on("touchend", function (e) {
            var st = window.innerHeight;
            var ht = window.innerHeight - $(".filter-btns").height();
            if (OPEN.RRModules.Common.touch && $("body").hasClass("res_Small")) {
                if (st != lastScrollTop) {
                    $(window).width() == 320 && ht < $(window).height() - 50 && (ht = $(window).height() - 50);
                    $(window).width() == 480 || $(window).width() == 568 && ht < 162 && (ht = 162);
                    $(OPEN.config.ID._filterWrap).css("height", ht);
                    $(".custom-dropdown.filter-show .viewport").css("height", ht);
                    var aht = $(".custom-dropdown.filter-show .filter-card-item").height();
                    aht < ht && ($(".custom-dropdown.filter-show .viewport").css("height", aht), $(".custom-dropdown.filter-show .scrollbar").hide());
                }
                if (st > lastScrollTop) {
                    setTimeout(function () {
                        st = window.innerHeight;
                        var inc = st - lastScrollTop;
                        $(".custom-dropdown.filter-show .viewport").css("height", ht + inc);
                    }, 700)
                }
            }
            lastScrollTop = st;
        });
        return this;
    },
    onFilterTouchStart: function () {
        $(".filter-wrapper").on("touchstart", function () {
            $('body').hasClass("res_Small") && $('body').scrollTop(0);
        });
        return this;
    },
    onFilterLinkClick: function () {
        $(".filter-link").click(function (e) {
            OPEN.RRModules.MobileFilter.showMobFilter();
            $(".cards-option").trigger("click");
            OPEN.RRModules.Common.readCookie();
        });
        return this;
    },
    onFilterBackClick: function () {
        $(".filter-action-cancel").on("click", function (e) {
            e.preventDefault();
            $(OPEN.config.ID._overlayMask).hide();
            $("#filter-wrapper,.filter-options .custom-dropdown").removeClass(OPEN.config.APP._filtrShow);
            $("body").css("overflow", "visible");
            $(window).scrollTop(0);
        });
        return this;
    },
    alignBackButton: function () {
        var backHeight = $(".filter-body").height() - $(".filter-body>ul").height() - $(".filter-btns").height() - $("#filter-cancel").height() - 15;
        (!OPEN.RRModules.Common.touch || (OPEN.RRModules.Common.touch && $(window).width() == 600)) && $("#filter-cancel").css("margin-top", backHeight);
        OPEN.RRModules.Common.touch && $(window).width() == 360 && $("#filter-cancel").css("margin-top", "200px");
    },
    countFilterOptions: function () {
		thisObj=this;
        thisObj.filterNum = 0;
        $(".filter-wrapper .custom-dropdown").each(function () {
            var dis = $(this);
            dis.find(".filter-card-item>li").hasClass("active") && thisObj.filterNum++;
        });
        thisObj.filterNum--;
        thisObj.filterNum > 0 ? $(".filter-link").html("FILTER (" + thisObj.filterNum + ") ") : $(".filter-link").html("FILTER");
    },
	showMobFilter: function() {
		thisObj=this;
        var ht = window.innerHeight - $(".filter-btns").height();
        !$(OPEN.config.ID._filterWrap).hasClass(OPEN.config.APP._filtrShow) && $(OPEN.config.ID._filterWrap).addClass(OPEN.config.APP._filtrShow);
        $(".filter-body").css("height", ht);
        $(OPEN.config.ID._filterWrap).css("height", ht);
        $(window).scrollTop(0);
        !$(OPEN.config.ID._overlayMask).is(":visible") && $(OPEN.config.ID._overlayMask).show();
        $("body").css("overflow") != "hidden" && $("body").css("overflow", "hidden");
        $(".filter-body").height() < $(".filter-body>ul").height() + 100 ? $(".filter-body").addClass("show-scroll") : $(".filter-body").hasClass("show-scroll") && $(".filter-body").removeClass("show-scroll");
        thisObj.alignBackButton();
    },
    init: function () {
        this.onFiltersClick().onFilterOverlayTouch().onFilterLinkClick().onFilterBackClick().onFilterTouchStart();
    }

};