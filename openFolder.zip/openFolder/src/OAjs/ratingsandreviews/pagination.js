OPEN.RRModules.Pagination = {
    eventHandlers: function () {
        var navControls = $(".rr_nav_controls");
        // click on each pagination number
        navControls.on("click", ".pagination_controls a:not(.previous_page, .next_page)", function (h) {
            var currentPage = $(this).siblings("span:not(.previous_page, .next_page, .ellipsis)");
            OPEN.RRModules.Pagination.rrUpdatePagination(currentPage, parseInt($(this).text()));
            h.preventDefault();
            $('.ellipsis').next().css('border', 'none');
        });
        function pagen(page_up, ele) {
            var currentPage = ele.siblings("span:not(.previous_page, .next_page, .ellipsis)");
            var nextPage = parseInt($(currentPage).text()) + page_up;
            OPEN.RRModules.Pagination.rrUpdatePagination(currentPage, nextPage);
            $('.ellipsis').next().css('border', 'none');
        }

//previous click on pagination
        navControls.on("click", ".pagination_controls a.previous_page", function (e) {
            e.preventDefault();
            (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Previous_Pagination') : null;
            pagen(-1, $(this))
        });
        //next click on pagination
        navControls.on("click", ".pagination_controls a.next_page", function (e) {
            e.preventDefault();
            (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'Next_Pagination') : null;
            pagen(1, $(this));
        });
    },
    rrUpdateReviewCountInfo: function () {
        var reviewNumber = $("#top_info p span.strong");
        $(reviewNumber).eq(0).html(OPEN.config.APP.rrStartReview);
        $(reviewNumber).eq(1).html(OPEN.config.APP.rrEndReview);
        $(reviewNumber).eq(2).html(OPEN.config.APP.rrTotalReviews);
    },
    rrApplyPagination: function () {
        $("#review-list").html('<div class="ajax-loading" />');
        var sortby = $(OPEN.config.CLS.srt_cntrl).find(" .custom-select-box label").text();
        OPEN.RRModules.Common.rrAjaxRefresh(sortby, "pagination");
    },
    //new pagination
    //Update pagination variables sau
    rrUpdatePagination: function (cPage, nPage) {
        OPEN.config.APP.pageNo = nPage;
        var a = $(cPage).siblings("a[class=page_" + nPage + "]:not(.start,.end)");
        var cPageHtml = $(cPage).html();
        var previousPage = $(cPage).siblings(".previous_page");
        var nextPage = $(cPage).siblings(".next_page");
        var pControls = $(cPage).parents(".pagination_controls");
        this.rrCreatePagination(nPage, cPageHtml);
        this.rrApplyPagination(nPage);
        return false;
    },
    //new pagination
    //create pagination set 
    rrCreatePagination: function (nextPage, previousPage) {
        var newPageSet = "",
                paginationControls = $(".pagination_controls p"),
                endEllipse = '<span class="ellipsis">...</span><a href="#" tabindex="23" class="page_' + OPEN.config.APP.rrPageCount + ' end">' + OPEN.config.APP.rrPageCount + "</a>",
                startEllipse = '<a href="#" tabindex="23" class="page_1 start">1</a><span class="ellipsis">...</span>';
        $(paginationControls).html("");
        if (OPEN.config.APP.rrPageCount == 0) {
            var previousText = '<span class="previous_page"> Previous</span>';
            var nextText = '<span class="next_page">Next </span>';
            endEllipse = "";
            startEllipse = "";
        } else {
            if (OPEN.config.APP.rrPageCount == 1) {
                endEllipse = "";
                startEllipse = "";
                var previousText = '<span class="previous_page"> Previous</span>';
                var nextText = '<span class="next_page">Next </span>';
            } else {
                if (nextPage == 1) {
                    var previousText = '<span class="previous_page"> Previous</span>'
                } else {
                    var previousText = '<a href="#" tabindex="23" class="previous_page"> Previous</a>'
                }
                if (nextPage == OPEN.config.APP.rrPageCount) {
                    var nextText = '<span class="next_page">Next </span>'
                } else {
                    var nextText = '<a href="#" tabindex="23" class="next_page">Next </a>'
                }
            }
            if (OPEN.config.APP.rrPageCount > 1 && OPEN.config.APP.rrPageCount <= 7) {
                startEllipse = "";
                endEllipse = "";
                var setFirst = 1;
                var setLast = OPEN.config.APP.rrPageCount;
                for (var d = setFirst; d <= setLast; d++) {
                    if (d == nextPage) {
                        newPageSet += '<span  class="page_' + d + '">' + d + "</span>"
                    } else {
                        newPageSet += '<a href="#" tabindex="23" class="page_' + d + '">' + d + "</a>"
                    }
                }


            } else if (nextPage < 5 || nextPage > OPEN.config.APP.rrPageCount - 4) {

                if (nextPage < 5) {
                    startEllipse = "";
                    var setFirst = 1;
                    var setLast = Number(setFirst) + 5;
                } else if (nextPage > OPEN.config.APP.rrPageCount - 4) {
                    endEllipse = "";
                    var setFirst = OPEN.config.APP.rrPageCount - 5;
                    var setLast = OPEN.config.APP.rrPageCount;
                }
                for (var d = setFirst; d <= setLast; d++) {
                    if (d == nextPage) {
                        newPageSet += '<span class="page_' + nextPage + '">' + nextPage + "</span>";
                    } else {
                        newPageSet += '<a href="#" tabindex="23" class="page_' + d + '">' + d + "</a>"
                    }
                }
            } else {
                setFirst = nextPage - 2;
                setLast = nextPage + 2;
                for (var d = setFirst; d <= setLast; d++) {
                    if (d == nextPage) {
                        newPageSet += '<span class="page_' + nextPage + '">' + nextPage + "</span>";
                    } else {
                        newPageSet += '<a href="#" tabindex="23" class="page_' + d + '">' + d + "</a>"
                    }
                }

            }
        }
        $(paginationControls).html(previousText + startEllipse + newPageSet + endEllipse + nextText);
        $('ellipsis').next().css('border', 'none');
    },
    //update next and previous in pagination
    rrPaginationNextPrev: function (nPage, cPageHtml, previousPage, nextPage) {
        if (nPage == 1) {
            $(previousPage).replaceWith('<span class="previous_page" tabindex="' + $(previousPage).attr("tabindex") + '">Previous</span>');
        }
        if (nPage == OPEN.config.APP.rrPageCount) {
            $(nextPage).replaceWith('<span class="next_page" tabindex="' + $(nextPage).attr("tabindex") + '">Next</span>');
        }
        if (cPageHtml == 1) {
            $(previousPage).replaceWith('<a href="#" tabindex="23" class="previous_page" tabindex="' + $(previousPage).attr("tabindex") + '">Previous</a>');
        }
        if (cPageHtml == OPEN.config.APP.rrPageCount) {
            $(nextPage).replaceWith('<a href="#" tabindex="23" class="next_page" tabindex="' + $(nextPage).attr("tabindex") + '">Next</a>');
        }
    },
    init: function () {
        this.eventHandlers();
    }

};