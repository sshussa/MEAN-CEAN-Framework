
OPEN.cust_scroll= {

	scrollBar : function()
		{
			/*open scrollbar start*/
				(function (factory) {
                                    
					if (typeof define === 'function' && define.amd) {
				
						define(['jquery'], factory);
					} else if (typeof exports === 'object') {
				
						factory(require('jquery'));
					} else {
						factory(jQuery);
					}
				}
				(function ($) {
					$.openObj = $.openObj || {};
					$.openObj.scrollbar = {
						options: {
							axis: 'y',
							wheel: true,
							wheelSpeed: 40,
							wheelLock: true,
							scrollInvert: false,
							trackSize: false,
							thumbSize: false
						}
					};
					$.fn.openScrollber = function (params) {
						var options = $.extend({}, $.openObj.scrollbar.options, params);
						var t = this;
						t.each(function () {
							$(this).data('tsb', new Scrollbar($(this), options));
						});
						return this;
					};
					$.fn.openScrollber_update = function (sScroll) {
						return $(this).data('tsb').update(sScroll);
					};
				
					function Scrollbar($container, options) {
						var self = this,
								$viewport = $container.find(".viewport"),
								$overview = $container.find(".overview"),
								$scrollbar = $container.find(".scrollbar"),
								$track = $scrollbar.find(".track"),
								$thumb = $scrollbar.find(".thumb"),
								viewportSize = 0,
								contentSize = 0,
								contentPosition = 0,
								contentRatio = 0,
								trackSize = 0,
								trackRatio = 0,
								thumbSize = 0,
								thumbPosition = 0,
								mousePosition = 0,
								isHorizontal = options.axis === 'x',
								hasTouchEvents = ("ontouchstart" in window && (/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/).test(navigator.userAgent)) || window.DocumentTouch && document instanceof DocumentTouch || (navigator.msMaxTouchPoints > 0), // june release fix for mozilla 26
								sizeLabel = isHorizontal ? "width" : "height",
								posiLabel = isHorizontal ? "left" : "top";
				
						function initialize() {
							self.update();
							setEvents();
							return self;
						}
						this.update = function (scrollTo) {
							sizeLabelCap = sizeLabel.charAt(0).toUpperCase() + sizeLabel.slice(1).toLowerCase();
							viewportSize = $viewport[0]['offset' + sizeLabelCap];
							contentSize = $overview[0]['scroll' + sizeLabelCap];
							contentRatio = viewportSize / contentSize;
							trackSize = options.trackSize || viewportSize;
							thumbSize = Math.min(trackSize, Math.max(0, (options.thumbSize || (trackSize * contentRatio))));
							trackRatio = options.thumbSize ? (contentSize - viewportSize) / (trackSize - thumbSize) : (contentSize / trackSize);
							$scrollbar.toggleClass("disable", contentRatio >= 1);
							switch (scrollTo) {
								case "bottom":
									contentPosition = contentSize - viewportSize;
									break;
								case "relative":
									contentPosition = Math.min(contentSize - viewportSize, Math.max(0, contentPosition));
									break;
								default:
									contentPosition = parseInt(scrollTo, 10) || 0;
							}
				
							setSize();
						};
				
						function setSize() {
							$thumb.css(posiLabel, contentPosition / trackRatio);
							$overview.css(posiLabel, -contentPosition);
							mousePosition = $thumb.offset()[posiLabel];
							$scrollbar.css(sizeLabel, trackSize);
							$track.css(sizeLabel, trackSize);
							$thumb.css(sizeLabel, thumbSize);
						}
				
						function setEvents() {
							
							if (hasTouchEvents && !$scrollbar.hasClass("disable")) {
								
								$thumb[0].addEventListener("touchstart", function(event) {
									
									if (1 === event.touches.length) {
										start(event.touches[0]);
										event.stopPropagation();
									}
								});
								
								$viewport[0].addEventListener("touchstart", function(event) {
									if (1 === event.touches.length) {
										start(event.touches[0]);
										event.stopPropagation();
									}
								});
							} else {
								$thumb.bind("mousedown", start);
								$track.bind("mouseup", drag);
							}
							if (options.wheel && window.addEventListener) {
								$container[0].addEventListener("DOMMouseScroll", wheel, false);
								$container[0].addEventListener("mousewheel", wheel, false);
							} else if (options.wheel) {
								$container[0].onmousewheel = wheel;
							}
						}
				
						function start(event) {
							
							$("body").addClass("noSelect");
							mousePosition = isHorizontal ? event.pageX : event.pageY;
							thumbPosition = parseInt($thumb.css(posiLabel), 10) || 0;
							
							if (hasTouchEvents && !$scrollbar.hasClass('disable')) {
								
								$viewport[0].addEventListener("touchmove", function(event) {									
									event.stopPropagation();
									options.scrollInvert = true;
									drag(event.touches[0]);
								});
								$viewport[0].ontouchend = end;
								$thumb[0].addEventListener("touchmove", function(event) {
									event.stopPropagation();
									event.preventDefault();
									options.scrollInvert = false;
									drag(event.touches[0]);
								});
								$thumb[0].ontouchend = end;
							} else {
								$(document).bind("mousemove", drag);
								$(document).bind("mouseup", end);
								$thumb.bind("mouseup", end);
							}
						}
				
						function wheel(event) {
							if(!$scrollbar.hasClass("disable")) {
								var eventObject = event || window.event,
								wheelSpeedDelta = eventObject.wheelDelta ? eventObject.wheelDelta / 120 : -eventObject.detail / 3;
								contentPosition -= wheelSpeedDelta * options.wheelSpeed;
								contentPosition = Math.min((contentSize - viewportSize), Math.max(0, contentPosition));
								$thumb.css(posiLabel, contentPosition / trackRatio);
								$overview.css(posiLabel, -contentPosition);
								if (options.wheelLock || (contentPosition !== (contentSize - viewportSize) && contentPosition !== 0)) {
									eventObject = $.event.fix(eventObject);
									eventObject.preventDefault();
								}
								}
						}
				
						function drag(event) {
								var eventObject = event || window.event;
								mousePositionNew = isHorizontal ? event.pageX : event.pageY;
								thumbPositionDelta = mousePositionNew - mousePosition;
								if (options.scrollInvert) {
									thumbPositionDelta = mousePosition - mousePositionNew;
								}
								thumbPositionNew = Math.min((trackSize - thumbSize), Math.max(0, thumbPosition + thumbPositionDelta));
								contentPosition = thumbPositionNew * trackRatio;
								$thumb.css(posiLabel, thumbPositionNew);
								$overview.css(posiLabel, -contentPosition);
								if (contentPosition !== (contentSize - viewportSize) && contentPosition !== 0) {
									eventObject = $.event.fix(eventObject);
									eventObject.preventDefault();
								}
						}
								
						function end() {
							$("body").removeClass("noSelect");
							$(document).unbind("mousemove", drag);
							$(document).unbind("mouseup", end);
							$thumb.unbind("mouseup", end);
							document.ontouchmove = document.ontouchend = null;
						}
						return initialize();
					}
				}));
				/*open scrollbar end*/
		}
	
	}
	
	