if (!window.OPEN) {
    var OPEN = {};
}

var crds_cnt = $("#cards-content"),
    brwsr_type = navigator.userAgent,
    zipcodeUrl = typeof (zipcodeUrl) == 'undefined' ? "" : zipcodeUrl,
    isFocus = false,
    txt_fcs = false,
    _iNavHead = $("#iNavNGI_Header"),
    scroll = "true",
    navFlag = false,
    iNav = $(window).width() > 660 ? $('#iNavHdWrap') : $('#iNMbWrap'),
    iNavHeight = $(window).width() > 660 ? $('#iNavHdWrap').outerHeight() : $('#iNMbWrap').outerHeight(),
    _i = 1,
    isScr = false,
    isHome;
(typeof ($itag) == "undefined") ? isHome = false : ($itag.PageId == "6428" ? isHome = true : isHome = false);
var isCompare = $("ul#curr-selection").length > 0 ? true : false,
    isView = $("div#viewall-header").length > 0 ? true : false,
    rdoChkd = "radio-checked",
    _radioBtn = $("input:radio"),
    touch = ("ontouchstart" in window && (/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/).test(brwsr_type)) || window.DocumentTouch && document instanceof DocumentTouch || (navigator.msMaxTouchPoints > 0),
    ie9 = $.browser.msie && parseInt($.browser.version) == 9 ? true : false,
    setf = false,
    _cmprCrd = $("body").hasClass("newcompare") ? $("#compare-cards-clone") : $("#compare-cards"),
    _viewHead = $("#viewall-header"),
    _ajNav = $("#ajnav"),
    _isInavHidden = false,
    isOrientationChanged = false,
    isTab = (brwsr_type.match(/Android/i) && (($(window).width() == 1024 && $(window).height() == 413) || ($(window).width() == 600 && $(window).height() == 837))) ? true : false,
    _loading = isTab ? true : false,
    dynUrlString = $("#find-offers").attr("action"),
    eles = [
        ['#wrapper .view-holder'],
        ['#product-footer .product-footer-parent'],
        ["#footer"],
        ['#reviews-list'],
        ['.page-wrapper']
    ];
//universal web parts
OPEN.universal = {
    header: function () {
        var mblScr = brwsr_type.match(/iPhone/i) ? "mbl-scroll" : "scroll";
        touch && $('body').addClass('touchdevice');
        iNavHeight = $(window).width() > 660 ? $('#iNavHdWrap').outerHeight() : $('#iNMbWrap').outerHeight();
        var elements;
        if (brwsr_type.toLowerCase().indexOf("534.24") != -1 && brwsr_type.toLowerCase().indexOf("android") && (navigator.platform.indexOf("iPad") == -1 && brwsr_type.toLowerCase().indexOf("blackberry") == -1 && navigator.platform.toLowerCase().indexOf("iphone") == -1) && $(document).width() <= 768 && touch) {
            elements = $('#wrapper').filter(function () {
                return $(this).css('position') === 'fixed' && parseInt($(this).css('bottom')) != 0 && $(this).attr('id') != 'iNavHdWrap' && $(this).attr('class') != 'scroll-arrow'
            }).not(".newcompare #compare-cards,#cmn-overlay,.custom-dropdown,.filter-body").addClass(mblScr);
            scrFlg = true;
            $(window).bind('touchmove scroll', function (e) {
                if ($(window).scrollTop() <= 0) $(window).scrollTop(0);
                $(this).scrollTop() >= iNavHeight ? scrFlg && (elements.removeClass(mblScr), $('#ajnav').css('top', 0), scrFlg = false) : (scrFlg = true, elements.not('.newcompare #compare-cards,#quick-view-overlay,#overlay-mask,#cards-list-overlay,#product-footer-m,.scroll-arrow,.chat-container,.filter-body').addClass(mblScr).css('top', 'auto'));
                // OPEN.universal.setFixedHeder();
            });
        } else {
            $(" #overlay-mask").bind("click touchmove", function () { /* April A */
                $(" #overlay-mask,#quick-view-overlay,#cards-list-overlay" + (isCompare ? "-wrap" : "")).hide(); /* Aprila Pavan*/
            })
            elements = $('*').not('.hp-control-nav,.chat-container,#cmn-overlay,.custom-dropdown,.filter-body').filter(function () { /* feb a */
                return $(this).css('position') === 'fixed' && parseInt($(this).css('bottom')) != 0 && $(this).attr('id') != 'iNavHdWrap' && $(this).attr('id') != 'product-footer-m' && $(this).attr('class') != 'scroll-arrow'
            }).not('.newcompare #compare-cards,#quick-view-overlay,#overlay-mask,#cards-list-overlay,.chat-container').addClass(mblScr);
            scrFlg = true; /* April A */
            $("#wrapper,#cards-wrapper").bind('click', function (e) { /*debugathon1*/ /*feb fix to be merged*/
                if (touch) {
                    isView && $("div.list-content-card>span.learnmore-btnn").hide(); /*ios7*/
                    $(".hasSubNav ul").each(function () {
                        if ($(this).css("right") == "0px" && !$('#call-now input[type="text"]').is(":focus")) {

                            /* Marcha A*/
                            $("#ajnav .arrow-down").removeClass("arrow-down");
                            $(this).parents("li").siblings().css('background-color', '');
                            $("body").hasClass("full-version") && $(this).parents("li").css('background-color', ''); /*MarchB*/
                            $(this).css({
                                "right": "9999px",
                                "magin-right": "-4px"
                            }); /*ios7*/
                        }
                    });
                }
            });
            $(window).bind('touchmove scroll resize', function (e) { //FEB A 7-46
                /*C2C Drawer*/
                OPEN.universal.closeChatBar(e);
                $('#call-now input[type="text"],#call-now select').live("blur focus", function (e) {
                    txt_fcs = true
                })
                $('#call-now').live("click touchstart", function () {
                    txt_fcs = true
                });
                /* LP fix */
                if (touch && !txt_fcs) {
                    $(".hasSubNav ul").each(function () {
                        if ($(this).css("right") == "0px") {

                            /* Marcha A*/
                            $("#ajnav .arrow-down").removeClass("arrow-down");
                            $(this).parents("li").siblings().css('background-color', '');
                            $("body").hasClass("full-version") && $(this).parents("li").css('background-color', ''); /*MarchB*/
                            $(this).css({
                                "right": "9999px",
                                "magin-right": "-4px"
                            }); /*ios7*/
                            $(".ajnav").removeClass("aj-shadow");
                        }
                    });
                    $(".navheader li").click(function () {
                        if ($(this).find('ul').css('right') == "0px") {
                            ($("body").hasClass("full-version") && $(this).hasClass("hasSubNav")) && $(this).css('background-color', '#EAEAEA'); /*MarchB*/
                        } else {
                            ($("body").hasClass("full-version") && $(this).hasClass("hasSubNav")) && $(this).siblings().css('background-color', ''); /*MarchB*/
                        }
                    });
                }

                if (isTab) {
                    if (!_loading) {
                        $(this).scrollTop() >= iNavHeight ? scrFlg && (elements.not('.newcompare #compare-cards').removeClass(mblScr).css('top', 0), scrFlg = false) : (scrFlg = true, elements.not('.newcomapre #compare-cards,#quick-view-overlay,#overlay-mask,#cards-list-overlay,#cards-list-overlay-wrap,.chat-container').addClass(mblScr).removeAttr('style'), OPEN.universal.ajanvAlign()); /* feb a release */ /* April A */
                    }
                } else {
                    $(this).scrollTop() >= iNavHeight ? scrFlg && (elements.not('.newcompre #compare-cards').removeClass(mblScr).css('top', 0), scrFlg = false) : (scrFlg = true, elements.not('.newcomapre #compare-cards,#quick-view-overlay,#overlay-mask,#cards-list-overlay,#cards-list-overlay-wrap,.chat-container').addClass(mblScr).removeAttr('style'), OPEN.universal.ajanvAlign()); /* feb a release */ /* April A */
                }
                if (brwsr_type.match(/iPhone/i) || brwsr_type.match(/iPod/i) || brwsr_type.match(/iPad/i)) { /*feb fix to be merged*/
                    if (isFocus) {
                        setTimeout(function () {
                            _ajNav.css({
                                'position': "absolute",
                                'top': ($(document).scrollTop() - $("#iNavNGI_Header").height()) + 7 + 'px'
                            }).parent().css({
                                'margin-top': $(window).width() > 660 ? '-7px' : '-5px',
                                'z-index': '3000'
                            });
                            isView && _viewHead.addClass('hide');
                            _cmprCrd = $("body").hasClass("newcompare") ? $("#compare-cards-clone") : $("#compare-cards");
                            isCompare && _cmprCrd.addClass('hide');
                            if ($(document).scrollTop() < iNavHeight) {
                                _ajNav.css({
                                    'top': 0
                                }).parent().css({
                                    'position': 'relative',
                                    'z-index': '1300',
                                    '-webkit-transition': '1.2s ease',
                                    '-webkit-backface-visibility': 'hidden',
                                    'margin-top': '-7px'
                                });
                            }
                            /*end June C:-June A PIV*/
                        }, 300);
                    } else {
                        if (_ajNav.css('position') == "absolute") {
                            _ajNav.css({
                                'position': "fixed",
                                'top': '0px'
                            });
                            //$(document).scrollTop() < iNavHeight && _ajNav.css({'top': iNavHeight + 'px'});
                        }
                        isView && _viewHead.hasClass('hide') && _viewHead.removeClass('hide');
                        _cmprCrd = $("body").hasClass("newcompare") ? $("#compare-cards-clone") : $("#compare-cards")
                        isCompare && _cmprCrd.hasClass('hide') && _cmprCrd.removeClass('hide');
                        /*end June C:-June A PIV*/
                    }
                    /*iPad issue Ajnav overlapping with Inav at the time of scrolling down the page*/

                }
                var pixelRatio = !!window.devicePixelRatio ? window.devicePixelRatio : 1;
                $(window).width() > 830 && OPEN.universal.controlC2CDrawer(); //compare page flickering fix  
                $(window).width() > 660 ? ($('body').hasClass('newcompare') ?
                    $("#compare-cards .server-error").css({
                        position: 'relative',
                        top: -15
                    }) : $("#compare-cards .server-error").css({
                        position: 'relative',
                        top: 60,
                        "margin-bottom": '10px'
                    })) : ($('body').hasClass('newcompare') ?
                        $("#compare-cards .server-error").css({
                            position: 'relative',
                            top: -15
                        }) : $("#compare-cards .server-error").css({
                            position: 'relative',
                            top: 10,
                            "margin-bottom": '10px'
                        }));
                (touch && !isFocus) && (_ajNav.css({
                    'top': 0,
                    'margin-top': 0
                }),
                    $(document).scrollTop() < iNavHeight ? _ajNav.parent().css({
                        'position': 'relative',
                        'z-index': '1300',
                        '-webkit-transition': '1.2s ease',
                        '-webkit-backface-visibility': 'hidden',
                        'margin-top': $(window).width() > 660 ? '-7px' : '-5px'
                    }) : _ajNav.parent().css({
                        'margin-top': $(window).width() > 660 ? '-6px' : '-4px',
                        'z-index': '3000'
                    }))
            });


        };

        /* Commented in March B */
        /*
            if( brwsr_type.match(/iPod/i) || brwsr_type.match(/iPad/i) ){
                $('.rep-call').css('display','block');
                $('.open .navheader li ul li.need-advice').css('border-radius','0'); 
            }
            	*/
            $(document).mousedown(function(e) {
                $(window).scrollTop() < iNavHeight && $(window).width() < e.clientX && $("html, body").stop()
            });
            $(document).ontouchmove = function(e) {
                $("html, body").stop();
            }
            return this;
        },
        isDesktop: function() {
            var version;
            $(document).width() >= 1024 ? version = true : version = false;
            return version;
        },
        isMobile: function() {
            var version;
            $(document).width() <= 660 ? version = true : version = false;
            return version;
        },
        isPad: function() {
            var version;
            $(document).width() <= 830 ? version = true : version = false; /* feb a Regression*/
            return version;
        },
        IOS8SWIP6: function() {
            if ((brwsr_type.indexOf('OS 8') > -1 || brwsr_type.indexOf('OS 9') > -1) && $(window).width() < 670) {
                $('#wrapper').addClass('IOS8SWIP6');
            }
            return this;
        },
        isIphone: function() { /* June A*/
            if (brwsr_type.match(/iPhone/i)) $('body').addClass('iphone');
        },
        isIphoneSix: function() {
            if (navigator.userAgent.match(/iPhone/i) && ($(window).width() > 661 && $(window).width() < 830)) {
                $("body").addClass("iphonesix");
            }
        },
		//open in new a tab with respective URL.
		//links: group selector of the links. 
	openNewTab: function (links)
		{
			var objs = $(links);
            	objs && objs.on("click",'a', function() {					
                    var obj = $(this);
					var href = obj.attr("href") || null;
                    if($(this).parent().attr('class')=="viewallratings")
                    {
                    window.location.href =href ;
                     return false;
                     }
                     else
                    {                    
					if (!obj.is('.learnbutton,.cardartclick') && !obj.parent().hasClass("add-review")) {
						obj.attr('target','_blank');
						href && href != "#" && window.open(href,"","");
						return false;
					}
                    }
			});
		},
        getJsonData: function(url, method, func) {
            var data = {};
            var request;
            try {
                window.XMLHttpRequest ? request = new XMLHttpRequest() : request = new ActiveXObject("Microsoft.XMLHTTP");
                request.open(method, url, true);
                request.send(null);
                request.onreadystatechange = function() {
                    if (request.readyState == 4 && request.status == 200) {
                        data = window.eval("(" + request.responseText + ")");
                    }
                    func.call(data);
                };
            } catch (err) {
                alert(err.message);

            }
    },
    getJsonData: function (url, method, func) {
        var data = {};
        var request;
        try {
            window.XMLHttpRequest ? request = new XMLHttpRequest() : request = new ActiveXObject("Microsoft.XMLHTTP");
            request.open(method, url, true);
            request.send(null);
            request.onreadystatechange = function () {
                if (request.readyState == 4 && request.status == 200) {
                    data = window.eval("(" + request.responseText + ")");
                }
                func.call(data);
            };
        } catch (err) {
            alert(err.message);
        }
    },
    firstAllWords: function (str) {
        var pieces = str.split(" ");
        for (var i = 0; i < pieces.length; i++) {
            var j = pieces[i].charAt(0).toUpperCase();
            pieces[i] = j + pieces[i].substr(1);
        }
        return pieces.join(" ");
    },
    customCheckBox: function () {
        $(".privacy-statement input, .privacy-statement label").bind("click", function () {
            if ($(this).is(":checked")) {
                $(this).siblings("span").addClass("checkbox-checked");
            } else {
                $(this).siblings("span").removeClass("checkbox-checked");
            }
        });
        return this;
    },
    customRadio: function () {
        //_radioBtn.css("opacity", "0").parent().append("<span class=" + rdoChk + "></span>");
        $(_radioBtn + ":checked").siblings("span.radio-normal").addClass(rdoChkd);
        _radioBtn.click(function () {
            $(this).parent().siblings("li").find(">span.radio-normal").removeClass(rdoChkd);
            $(this).siblings("span.radio-normal").addClass(rdoChkd);
        });
        return this;
    },
    customSelectBox: {
        set: function () {
            var _this = this;
            if (brwsr_type.match(/Android/i) || brwsr_type.match(/iPhone/i)) {
                $("select").live("click", function (e) {
                    var crPos = $(document).scrollTop();
                    setTimeout(function () {
                        $(document).scrollTop(crPos)
                    }, 180);
                });
            } /*debugathon1*/
            $("select").each(function () { /* June A*/
                var selectedText = $(this).next().find(".customStyleSelectBoxInner");
                selectedText.text($(this).find("option:first").text()).css("color", "#888");
                $(this).change(function () {
                    _this.adjustText(selectedText, this);
                }).live("keypress", function () {
                    $(this).trigger("change");
                }); /*debugathon1*/
            })
        },
        adjustText: function (selectedText, selectbox) { /* June A*/
            selectedText.removeAttr("style"); /*JAN*/
            selectedText.text($(selectbox).find(":selected").text());
            ($(selectbox)[0].selectedIndex == 0) ? selectedText.css("color", "#888") : selectedText.css("color", "#000");
            if (isHome) {
                selectedText.height() > 40 ? selectedText.css({
                    "line-height": "13px",
                    "padding-top": "5px"
                }) : selectedText.css({
                    "line-height": "36px",
                    "padding-top": "0px"
                })
            } else {
                selectedText.height() > 33 ? selectedText.css({
                    "line-height": "12px",
                    "padding-top": "5px"
                }) : selectedText.css({
                    "line-height": "33px",
                    "padding-top": "0px"
                })
            }
        },
        setOnResize: function () { /* June A*/
            var _this = this;
            $("select").each(function () {
                var selectedText = $(this).next().find(".customStyleSelectBoxInner");
                selectedText.text($(this).find("option:first").text()).css("color", "#888");
                _this.adjustText(selectedText, this);
            })
        }
    },
    createCookie: function (cName, cValue, days) {
        var exdate = new Date();
        exdate.setDate(exdate.getDate() + days);
        var c_value = escape(cValue) + ((days == null) ? "" : "; expires=" + exdate.toUTCString()) + "; path=/; secure"; /*10-30-13*/
        document.cookie = cName + "=" + c_value;
    },
    readCookie: function (cName) {
        var cNameEQ = cName + "=";
        var i, x, y, OPEN = document.cookie.split(";");
        for (i = 0; i < OPEN.length; i++) {
            x = OPEN[i].substr(0, OPEN[i].indexOf("="));
            y = OPEN[i].substr(OPEN[i].indexOf("=") + 1);
            x = x.replace(/^\s+|\s+$/g, "");
            if (x == cName) {
                return unescape(y);
            }
        }
        return null;
    },
    updateCookie: function (cName, cValue, days) {
        this.createCookie(cName, cValue, days);
    },
    eraseCookie: function (cName) {
        this.createCookie(cName, "", -1);
    },
    stringify: function (crd, b) {
        var n = [],
            c, d;
        cookieArr = eval("(" + OPEN.universal.readCookie("cardInfo") + ")");
        if (isCompare || isHome) {
            cookieArr == null ? viewMode = "true" : viewMode = cookieArr.gridview;
        } else {
            //for vac page. change viewMode only for desktop breakpoint, for other breakpoint don't change the cookie. This is needed to maintain the state of grid/list on browser resize
            if ($(window).width() > 660) {
                //Read the grid-view class and set the cookie flag
                viewMode = crds_cnt.hasClass("grid-view");
            } else {
                //keep grid state same as cookie or if cookie doesn't exist then read it based on class grid-class
                cookieArr == null ? viewMode = crds_cnt.hasClass("grid-view") : viewMode = cookieArr.gridview;
            }

        }
        for (key in crd) {
            n.push('{"pmc":"' + crd[key].pmc + '"}');
        }
        d = n.toString();
        d = d.replace(/(\r\n|\n|\r)/gm, "");
        c = '{' + '\"cards\":' + '[' + d + ']' + ',' + '\"isEmpty\":' + b + ',' + '\"gridview\":' + viewMode + '}';
        return c;
    },
    vacCookie: function (_crdTry) {
        if (document.cookie.indexOf("cardInfo") != -1) {
            var cArr = eval('(' + OPEN.universal.readCookie("cardInfo") + ')');
            if (typeof (cArr.cards) != "undefined") {
                _fromCookie = true;
                //alert(cArr.cards);
                /*  Commented in May B */
                /*if($(window).width()<831){
                            cArr.cards.length>2 && cArr.cards.pop();
                    }*/
                for (var i = 0; i < cArr.cards.length; i++) {
                    var cis = $("#comparision ul.section>li[class^='pmc-']").eq(i);
                    var crdCls = cArr.cards[i].pmc;
                    var lis = $("ul#list-view>li");
                    var thisclass;
                    if (i == 2) //FEB A 4
                    {

                        $('#card-section').find('.' + crdCls).find('.compare-btn').removeClass('disable');
                    }
                    $.each(lis, function (i, v) {
                        $(v).hasClass("slide-cards") ? thisclass = ($(v).attr("class").split(" ")[0]) : thisclass = $(v).attr("class");
                        if (thisclass == crdCls) $(v).find(".compare-btn").not(".remove-btn").click(); /*JAN*/
                    })
                    cis.find(".card-art").show().parent().find('.mask-layer').show();
                }
            }
            _fromCookie = false;
        } else {
            var jsonString = OPEN.universal.stringify(_crdTry, true);
            OPEN.universal.createCookie("cardInfo", jsonString, 10);
        }
    },
    iTagProductNames: {
        "pmc-92": "PlatinumCard",
        "pmc-499": "Plum",
        "pmc-113": "GoldDelta",
        "pmc-111": "GoldCardfromOPEN",
        "pmc-756": "DeltaReserve",
        "pmc-89": "GreenRewards",
        "pmc-1043": "SimplyCashPlus",
        "pmc-79": "BlueForBusiness",
        "pmc-251": "Lowes",
        "pmc-141": "PlatinumDelta",
        "pmc-474": "Starwood"
    },
    getProductName: function (pmc) {
        var pObj = OPEN.universal.iTagProductNames;
        for (var i in pObj) {
            if (i == pmc) return pObj[i]

        }
    },
    alignAnchors: function () {
        var anch = $("#cards-list-overlay .cards-list ul li a");
        $.each(anch, function (i, v) {
            $(v).height() < 16 ? (console.log($(v).height() + "" + $(v).text() + " " + 16), $(v).css({
                "position": "relative",
                "top": "16px"
            })) : null;
            $(v).height() > 25 && $(v).height() < 40 ? (console.log($(v).height() + "" + $(v).text() + " " + 10), $(v).css({
                "position": "relative",
                "top": "10px"
            })) : null;
        })

    },
    formatTabName: function (t) {
        var str = t.indexOf('-') != -1 ? t.split('-') : t.split(' '),
            tName = '';
        for (var i = 0; i < str[i].length; i++) {
            var cap = str[i].charAt(0).toUpperCase();
            tName = tName + cap + str[i].slice(1, str[i].length);
            if (i == (str.length - 1)) break;
        }
        return tName;

    },
    setTrayWidth: function () {
        var PE = $('#cards-wrapper').length > 0 ? $('#cards-wrapper') : $('#wrapper');
        var tray = $('#cards-content').length > 0 ? $('#cards-content') : $('.viewall-tray');
        tray.css('width', PE.width() + 'px');
        $('#cards-wrapper').length > 0 && $(window).scrollTop() < iNavHeight ? tray.css('left', '0px') : tray.css('left', PE.offset().left + 'px');

    },
    hideStickyElements: function () {
        if (brwsr_type.match(/iPhone/i) || brwsr_type.match(/iPod/i) || brwsr_type.match(/iPad/i)) {
            /*$("#special-offers select").on({
                "focus": function() {
                 _cmprCrd =$("body").hasClass("newcompare")?$("#compare-cards-clone"):$("#compare-cards");
                    //_ajNav.addClass('hide'); //hiding ajnav when select box is auto populated and commented as part of June 08 release
                    isView && _viewHead.addClass('hide');
                    isCompare && _cmprCrd.addClass('hide');

                },
                "blur": function() {
                    if (_ajNav.css('position') == "absolute") {
                        _ajNav.css({
                            'position': "fixed",
                            'top': '0px'
                        });
                        $(document).scrollTop() <= iNavHeight && _ajNav.css({
                            'top': 0
                        });
                    }

                    _ajNav.hasClass('hide') && _ajNav.removeClass('hide');
                    isView && _viewHead.hasClass('hide') && _viewHead.removeClass('hide');
                     _cmprCrd =$("body").hasClass("newcompare")?$("#compare-cards-clone"):$("#compare-cards")
                    isCompare && _cmprCrd.hasClass('hide') && _cmprCrd.removeClass('hide');

                }
            });*/
            /* added as part of june 08 release */
            $("#special-offers input,#special-offers select").on({
                "focus": function () {

                    setTimeout(function () {
                        _ajNav.css({
                            'position': "absolute",
                            'top': ($(document).scrollTop() - $("#iNavNGI_Header").height()) + 7 + 'px'
                        }).parent().css({
                            'margin-top': $(window).width() > 660 ? '-7px' : '-5px',
                            'z-index': '3000'
                        });
                        isView && _viewHead.addClass('hide');
                        _cmprCrd = $("body").hasClass("newcompare") ? $("#compare-cards-clone") : $("#compare-cards");
                        isCompare && _cmprCrd.addClass('hide');
                        if ($(document).scrollTop() < iNavHeight) {
                            _ajNav.css({
                                'top': 0
                            }).parent().css({
                                'position': 'relative',
                                'z-index': '1300',
                                '-webkit-transition': '1.2s ease',
                                '-webkit-backface-visibility': 'hidden',
                                'margin-top': '-7px'
                            });
                        }
                    }, 300);

                },
                "blur": function () {
                    if (_ajNav.css('position') == "absolute") {
                        _ajNav.css({
                            'position': "fixed",
                            'top': '0px'
                        });
                        $(document).scrollTop() <= iNavHeight && _ajNav.css({
                            'top': 0
                        });

                    };
                    isView && _viewHead.hasClass('hide') && _viewHead.removeClass('hide');
                    _cmprCrd = $("body").hasClass("newcompare") ? $("#compare-cards-clone") : $("#compare-cards")
                    isCompare && _cmprCrd.hasClass('hide') && _cmprCrd.removeClass('hide');
                }
            })
        }
        return this;
    },
    pageExpire: function () {
        function gotoExpiry() {
            location.href = domainName + "/business-card-compare-error?timeout=true";
        }
        if (typeof (domainName) != "undefined") {
            (typeof (sessionTimeOutInMinutes) == "undefined") && (sessionTimeOutInMinutes = 5);
            var timeout = setTimeout(gotoExpiry, sessionTimeOutInMinutes * 1000 * 60);
            document.addEventListener("click", function (e) {
                clearTimeout(timeout);
                timeout = setTimeout(gotoExpiry, sessionTimeOutInMinutes * 1000 * 60)
            }, true);
        }
        return this;
    },
    addingClassToBodyElmnts: function () {
        setTimeout(function () {
            if ($("body").hasClass("bgr-hide")) {
                $("body").removeClass("bgr-hide");
            }
        }, 1000);
        if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
            $("#wrapper").addClass("safari-wrap")
        }
        ie9 ? $('body').addClass('ie9 ieall') : null; //Feb A
        $.browser.msie && parseInt($.browser.version) == 10 ? $('body').addClass('ie10 ieall') : null;
        (!!(brwsr_type.match(/Trident/) && !brwsr_type.match(/MSIE/))) && $('body').addClass('ie11 ieall'); /*sat 11a*/
        (brwsr_type.match(/Android/i)) && $('body').addClass('nexus');
        var pR = !!window.devicePixelRatio ? window.devicePixelRatio : 1;
        pR < 2 ? $('body').addClass('normal') : (pR >= 1.5 && pR < 2 ? $('body').addClass('hd') : (pR >= 2 && $('body').addClass('xhd')));
        if ($.browser.msie && parseInt($.browser.version) == 10 || ie9) $("#lpVoice a").addClass("impBck");
        return this;
    },
    hideInav: function () {
        function disableScrolling() {
            var x = window.scrollX;
            var y = window.scrollY;
            window.onscroll = function () { window.scrollTo(x, y); };
        }
        function enableScrolling() {
            window.onscroll = function () { };
        }

        function inavScroll() {
            if ($(window).scrollTop() < iNavHeight) {
                /* Inav loading fixes - March 2016 */
                $('html,body').scrollTop(iNavHeight)
                if (isTab) {
                    _loading = false;
                }

            }; /*May release*/ /*11A 11/17 piv fix*/
        }
        setTimeout(function () { inavScroll(); }, 2000);
        setTimeout(function () { $('body').removeClass('inavload'), disableScrolling() }, 2500);
        setTimeout(function () { $('body').removeClass('inavload'), enableScrolling() }, 3000);

        //setTimeout(function(){$("#iNavNGI_Header").css("cssText", "opacity:1 !important"),$("#iNavNGI_Header").css('visibility','auto'),$('body').css('overflow','auto');},1000)
        return this;
    },
    personalizaion: function () {
        /* personalizaion */
        if (typeof (eApply_MVT) != "undefined") {
            if (eApply_MVT == "TRUE") {
                var domain = typeof (domainName) == "undefined" ? '../credit-cards/extensionTracking?pZNPageId=' + pZNPageId + "&defaultOfferInd=" + defaultOfferInd : domainName + '/extensionTracking?pZNPageId=' + pZNPageId + "&defaultOfferInd=" + defaultOfferInd;

                if (isCompare) {
                    var cards_comprd = [];
                    $("#compare-cards .compare-section li").not("li.pmc-hldr").each(function (p, e) {
                        cards_comprd.push($(e).attr("class").replace("pmc-", ""))
                    });
                    domain += "&cmp_pmc=" + cards_comprd
                }
                if (typeof ($itag) != "undefined") {
                    if ($itag.PageId == "6438") {
                        domain += "&cmp_pmc=" + (itag_products.replace(";US:OPEN:", ""))
                    }
                }
                $.ajax({
                    type: "POST",
                    url: domain,
                    success: function () {
                        console.log("success");
                    },
                    error: function () {
                        console.log("Cannot get data");
                    }
                });
            }
        }


        return this;
    },
    livePerson: function () {
        var lpChat = $('#lpChat');
        var lpVoice = $('#lpVoice');
        lpVoice.is(':hidden') && (lpVoice.parent().hide(), $('#lpChat + span.ajnav-btm').show());
        lpChat.is(':hidden') && lpChat.parent().hide();
        lpVoice.is(':hidden') && lpChat.is(':hidden') && $('.hasSubNav ul li:first-child .ajnav-btm').show();
        return this;
    },
    mouseWheel: function () {
        if (window.addEventListener) document.addEventListener('DOMMouseScroll', mouseWeel, false);
        document.onmousewheel = mouseWeel;

        function mouseWeel(e) {
            $(window).scrollTop() < iNavHeight && $("html, body").stop();
        }
        return this;
    },
    iTrackerUniversal: function () {
        $('#explore-section ul li a,.hasSubNav ul li a,#cards-types ul li a').click(function () {
            var itag_linkname = '',
                section = '';

            function forma_lk() {
                return $(this).text().split(' ').join('');
            }
            if ($(this).parent().parent().parent().index() == 0 || $(this).parent().attr('id') == 'lpChat' || $(this).parent().attr('id') == 'lpVoice') {
                itag_linkname = forma_lk.call(this);
                section = 'NeedHelp_';
            } else if ($(this).parent().parent().parent().attr('id') == 'explore-section') {
                itag_linkname = forma_lk.call(this);
                section = 'Explore_';
            } else if ($(this).parent().parent().parent().attr('id') == 'cards-types') {
                itag_linkname = forma_lk.call(this);
                section = 'CardsByType_';
            }
            (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', section + itag_linkname) : null;
        });
        return this;
    },
    common: function () {
        $('a[href="#"],#quick-view-overlay #ovrly-goodfor-col a').not('.apply-now.dm,#content-top .bluebutton,#content-top .learn-more').on("click", function (e) {
            e.preventDefault();
        });
        $("#viewall-header #comparision .section>li,#compare-cards #curr-selection>li,#compare-cards #curr-selection-clone>li").on('contextmenu', ".pmc-hldr .card-art", function (e) {
            e.preventDefault();
        });
        return this;
    },
    triggerResizeEnd: function (windowObj) {

        if (windowObj.resizeTO) clearTimeout(windowObj.resizeTO);
        windowObj.resizeTO = setTimeout(function () {
            $(windowObj).trigger('resizeEnd');
        }, 1000);
        return this;
    },
    cntrlWindowScroll: function () {
        iNavHeight = $(window).width() > 660 ? $('#iNavHdWrap').outerHeight() : $('#iNMbWrap').outerHeight();
        if (isScr) {
            OPEN.universal.isDesktop() && $(window).scrollTop(iNavHeight)
        }
        if (isTab && $(window).scrollTop() < iNavHeight && $(window).width() >= 831) {
            $('#ajnav').addClass('scroll').removeAttr('style').css('margin-top', '-7px');
        }
        if (!jQuery.browser.msie && (jQuery.browser.version != 7 || jQuery.browser.version != 8)) {
            if ((!brwsr_type.match(/iPhone/i)) && (!brwsr_type.match(/iPod/i)) && (!brwsr_type.match(/iPad/i) && brwsr_type.toLowerCase().indexOf("android") != -1) && brwsr_type.toLowerCase().indexOf("blackberry") != -1) {
                OPEN.universal.isPad() && $(window).scrollTop(0);
            }
        }
        return this;
    },
    /* created a generic method for the A/B test */
    ABtest: function () {

        var queryV = UBA.getQueryString("PARAM") || UBA.getQueryString("param");

        typeof queryV != 'undefined' ? queryV : "";

        var qrV = void 0 !== queryV && queryV.split("-");
        var bdy = $("body");
        var numV = qrV.length;
        while (numV--) {
            var qval = qrV[numV].toLowerCase();
            bdy.addClass(qval);
        }
    }
},
OPEN.Const = {
    IsLocal: false,
    LocalXml: zipcodeUrl + "/ngaosbn/sbsapply/web/dynamicapp/xml/",
    RemoteXml: zipcodeUrl + "/ngaosbn/sbsapply/web/dynamicapp/xml/",
    LocalFormSubmit: "/business-card-application/newapply",
    RemoteFormSubmit: "/business-card-application/newapply"
};

OPEN.Const.LocalFormSubmit = (dynUrlString != "") ? dynUrlString : OPEN.Const.LocalFormSubmit;
OPEN.Const.RemoteFormSubmit = (dynUrlString != "") ? dynUrlString : OPEN.Const.RemoteFormSubmit;
OPEN.FormSubmitUrl = OPEN.Const.IsLocal ? OPEN.Const.LocalFormSubmit : OPEN.Const.RemoteFormSubmit;
OPEN.Exists = function (d) {
    var c;
    return d !== c && d !== null
};
OPEN.XHR = {
    SEND: function (b) {
        return $.ajax({
            url: OPEN.Exists(b.u) ? b.u : OPEN.FormSubmitUrl,
            type: OPEN.Exists(b.t) ? b.t : "get",
            contentType: OPEN.Exists(b.ct) ? b.ct : "application/x-www-form-urlencoded",
            dataType: OPEN.Exists(b.dt) ? b.dt : "json",
            cache: OPEN.Exists(b.c) ? b.c : "true",
            data: OPEN.Exists(b.d) ? b.d : "",
            async: OPEN.Exists(b.sync) ? b.sync : true,
            success: b.ok,
            error: OPEN.Exists(b.err) ? b.err : function () { }
        })
    }
};
//Biz UA validations
UBA = {


    loadXMLString: function (a) {
        if (window.DOMParser) {
            parser = new DOMParser();
            xmlDoc = parser.parseFromString(a, "text/xml")
        } else {
            xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
            xmlDoc.async = false;
            xmlDoc.loadXML(a)
        }
        return xmlDoc
    },
    //initializing validations
    init: function () {

        OPEN.Overlay ? OPEN.Overlay.init() : null;
        OPEN.universal.isIphoneSix();

    }
};

UBA.fetchError = function (f) {
    for (var d = 0; d <= UBA.errorMessages.length; d++) {
        var e = UBA.errorMessages[d];
        if (e != null) {
            if (e.error == f) {
                return e.message
            }
        }
    }
};
UBA.errorMessages = [{
    error: "AuthBadException",
    message: "The information you entered below does not match our records. Please try again."
}, {
        error: "AlmostLockedOutException",
        message: "The information you entered below does not match our records. For security reasons, the next unsuccessful attempt will temporarily suspend online access to your account."
    }, {
        error: "AlmostRevokedException",
        message: "The information you entered below does not match our records. For security reasons, the next unsuccessful attempt will temporarily suspend online access to your account."
    }, {
        error: "Exception",
        message: "The information you entered below does not match our records. For security reasons, the next unsuccessful attempt will temporarily suspend online access to your account."
    }, {
        error: "VerificationException",
        message: "The information you entered below does not match our records. For security reasons, the next unsuccessful attempt will temporarily suspend online access to your account."
    }, {
        error: "LockedOutException",
        message: "The information you entered below does not match our records. For security reasons, online access to your account has been temporarily suspended. To reset your account please call American Express Customer Services at 1-800-AXP-1234, available 24 Hrs a day, 7 days a week."
    }, {
        error: "RevokedException",
        message: " The information you entered below does not match our records. For security reasons, online access to your account has been temporarily suspended. To reset your account please call American Express Customer Services at 1-800-AXP-1234, available 24 Hrs a day, 7 days a week."
    }, {
        error: "CardAlreadyLockedOutException",
        message: "The information you entered below does not match our records. For security reasons, online access to your account has been temporarily suspended. To reset your account please call American Express Customer Services at 1-800-AXP-1234, available 24 Hrs a day, 7 days a week."
    }, {
        error: "CardAccountIsLockedException",
        message: "The information you entered below does not match our records. For security reasons, online access to your account has been temporarily suspended. To reset your account please call American Express Customer Services at 1-800-AXP-1234, available 24 Hrs a day, 7 days a week."
    }, {
        error: "noError",
        message: " Our systems are being updated. Please try again later, or call the toll-free number on the back of your card."
    }, {
        error: "01",
        message: "Sorry, we are unable to verify the information you provided, or your offer may be expired. Please verify your information and try again."
    }, {
        error: "02",
        message: "Sorry, we are unable to verify the information you provided, or your offer may be expired."
    }, {
        error: "03",
        message: "The offer for which you are trying to apply has expired."
    }, {
        error: "99",
        message: "Currently, our systems are not responding. Please try again later or call us at <b>1-800-519-OPEN (6736)</b> to apply for a Card. We apologize for any inconvenience."
    }];
UBA.getQueryString = function (i) {
    var g = window.location.search;
    var l = g.substring(1);
    var j = new Array();
    var h = l.split("&");
    for (var k = 0; k < h.length; k++) {
        queryvalue = h[k].split("=");
        if (queryvalue[0] == i) {
            return queryvalue[1]
        }
    }
};
OPEN.evalZip = function (a) {
    if (a.length == 5 && !isNaN(a)) {
        $(".SearchByBiz").removeClass("zip")
    }
};
OPEN.CityStateLookup = {
    get: function (f) {
        if (f.str.length < 5) {
            return
        }
        var d = OPEN.Const.IsLocal ? OPEN.Const.LocalXml : OPEN.Const.RemoteXml;
        d += d.match(/\/$/ig) ? "" : "/";
        d = d + f.str.slice(0, 4) + ".xml";
        var e = this;
        OPEN.XHR.SEND({
            u: d,
            d: f.data,
            dt: "xml",
            c: false,
            ok: function (a) {
                e.onSuccess(a, f)
            },
            err: function (a) { }
        })
    },
    onSuccess: function (f, h) {
        var e, g = null;
        $(f).find("zipcode").each(function () {
            if ($(this).attr("code") === h.str) {
                e = $(this).find("city").text();
                g = $(this).find("state").text()
            }
        });
        if (e != null && g != null) {
            /*julyB*/
            e = e.toLowerCase();
            /* $(h.city).focus().val(e);
            $(h.state).focus().val(g);*/
            $(h.city).focus().val(e).change().prev().hide();
            $(h.state).focus().val(g).change();
            //offerFields.keyup();
        }
    }
};
OPEN.mvt = function (map, ver) {
    var mvtContainer = $("#mvt-container").clone(),
        mvtMap = map,
        qs = UBA.getQueryString("pos"),
        wf = UBA.getQueryString("wo"),
        btnopt = UBA.getQueryString("btnopt"),
        btnclr = UBA.getQueryString("btnclr"),
        crs = "",
        lp = "";
    qs = typeof qs != "undefined" && qs != null && qs != "" && qs.split(',');
    if (qs) {
        $("#mvt-container").html("");
        $.each(qs, function (i, v) {
            var cntr = mvtContainer.find(mvtMap[qs[i]]);
            if (mvtContainer.find("#discoffer").length > 0 && i > 0) {
                mvtContainer.find("#discoffer").append(cntr);
                crs = "<li>" + mvtContainer.find("#discoffer").parent().html() + "</li>";
            }
            crs == "" && $("#mvt-container").append(cntr);
        });
        crs != "" && $("#mvt-container").append(crs);
    }
    (wf == "new") && ($("#welcome-offer2").css('display', 'none'), $("#welcome-offer1").css('display', 'block'));
    (wf == "old") && ($("#welcome-offer1").css('display', 'none'), $("#welcome-offer2").css('display', 'block'));
    (btnopt == "bopt") ? $("body").addClass("apply-bt-opt2") : $("body").removeClass("apply-bt-opt2");
    btnclr == "orange" ? ($("#product-footer-m").length > 0 ? $("body").addClass("apply-bt-cy") : $("body").addClass("mvt-apply")) : $("body").removeClass("apply-bt-opt2,mvt-apply");
};

OPEN.showbody = function () {
    setTimeout(function () {
        if ($("body").hasClass("hidebody")) {
            $("body").removeClass("hidebody");
        }
    }, 1000);
};

$(document).ready(function (e) {
    void 0 != OPEN.cust_scroll && OPEN.cust_scroll.scrollBar()
    OPEN.universal.header().customCheckBox().customRadio().hideStickyElements().IOS8SWIP6().pageExpire().addingClassToBodyElmnts().hideInav().ajNav_init().ClickToDrawerAnim().ajanvAlign().personalizaion().livePerson().mouseWheel().iTrackerUniversal().common().ABtest();
    !$("#productPage").length > 0 && OPEN.universal.inpageNav.pageReady();
    OPEN.universal.customSelectBox.set();
    OPEN.showbody();
});
window.addEventListener('orientationchange', function () { /* feb b */
    isOrientationChanged = true;
});
$(window).resize(function () {
    OPEN.universal.ajnav();
    OPEN.universal.triggerResizeEnd(this);
    OPEN.universal.ajInpgeAnm("aj-inpage");
    OPEN.universal.ajInpgeAnm("sub-nav");
    OPEN.universal.ajNav_resize().cntrlWindowScroll();
    OPEN.universal.ajanvAlign(); /*sat feba*/
    //OPEN.universal.setFixedHeder();
    (!touch) && (OPEN.universal.ClickToDrawer($(window).width(), eles, true));
    OPEN.universal.customSelectBox.setOnResize(); /* June A*/
    OPEN.universal.isIphoneSix();
});
$(window).bind('resizeEnd', function () {

    OPEN.universal.ajanvAlign(); /*sat feba*/
    iNavHeight = $(window).width() > 660 ? $('#iNavHdWrap').outerHeight() : $('#iNMbWrap').outerHeight();
    if (isOrientationChanged) {
        !_isInavHidden && !brwsr_type.match(/iPhone/i) && $(window).scrollTop(iNavHeight);
        touch && ($(window).scrollTop($(window).scrollTop() + 1), $(window).scrollTop($(window).scrollTop() - 1));
        isOrientationChanged = false;
    }

    (!touch) && (OPEN.universal.ClickToDrawer($(window).width(), eles, true));
    //OPEN.universal.setFixedHeder();
    OPEN.universal.isIphoneSix();
    (touch && !isFocus) && (_ajNav.css({
        'top': 0,
        'margin-top': 0
    }),
        $(document).scrollTop() < iNavHeight ? _ajNav.parent().css({
            'position': 'relative',
            'z-index': '1300',
            '-webkit-transition': '1.2s ease',
            '-webkit-backface-visibility': 'hidden',
            'margin-top': $(window).width() > 660 ? '-7px' : '-5px'
        }) : _ajNav.parent().css({
            'margin-top': $(window).width() > 660 ? '-6px' : '-4px',
            'z-index': '3000'
        }))
});
window.onpageshow = function (event) {
    //isView && OPEN.universal.vacCookie();
    if (event.persisted) {
        setTimeout(function () {
            navigator.userAgent.match(/iPad/i) && $(window).resize();
            $('.module2 .cards-type a.chrg').trigger("click");
            $('.module2 .cards-type a').removeClass('active');
            $(".chrg").addClass('active');
            $(".bgn-crds .link-txt").css("color", "#666");
        }, 100)
    }
}; /*Inav fix 10B*/
//Dilip: Added for Apply button as <buton> markup
//launch URL in same window
var launchURLInSameWindow = function (url) {
    window.location.href = url;
    return false;
};

var launchLearnMore = function (learnMoreURL) {
    launchURLInSameWindow(learnMoreURL);
};
//Apply card for offsite flow 
var applyForOffsiteFlow = function (applyNowURL) {
    launchURLInSameWindow(applyNowURL);
};

var applyForUAOffer = function (applyNowURL) {
    submitEnteredValues(applyNowURL);
};

var applyWithOfferGating = function (applyNowURL, pmcCode) {
    var f = "pmcCode=" + pmcCode + "&pZNPageId=" + pZNPageId;
    var b = typeof (domainName) == "undefined" ? "../credit-cards/pznoffer-gating?" + f : domainName + "/pznoffer-gating?" + f;
    $.ajax({
        url: b,
        type: "POST",
        cache: false,
        async: false,
        success: function (e) {
            (e.result == "error") ? window.location = domainName + "/business-card-compare-error" : ($("form[name='pznApplicationForm']").children("input[name='pznOfferGatingResp']").val(e.result), document.pznApplicationForm.action = applyNowURL, document.pznApplicationForm.submit())
        },
        error: function (e) {
            window.location = domainName + "/business-card-compare-error"
        }
    })
};

var applyForBusinessCard = function (applyNowURL, pmcCode, flow) {

    if (flow === 'UA') {
        applyForUAOffer(applyNowURL);
    } else if (flow === 'PZN' || flow === 'RICHEROFFER') {
        applyWithOfferGating(applyNowURL, pmcCode);
    } else {
        applyForOffsiteFlow(applyNowURL);
    }
    return false;
};
/*Start of Module reordering 7B */
(function () {
    var getQueryString = function (i) {
        var g = window.location.search,
            l = g.substring(1),
            j = new Array(),
            h = l.split("&");
        for (var k = 0; k < h.length; k++) {
            queryvalue = h[k].split("=");
            if (queryvalue[0] == i) {
                return queryvalue[1]
            }
        }
    },
        home = (typeof (itag_pagename) != 'undefined' && itag_pagename == "Homepage") ? true : false;
        
    //console.log("home :: " + home);
    var fetchOrder = null;
    /*added for new compare defualt mod order*/
    if ($('body').hasClass('newcompare') || getQueryString("param") == "newcompare") {
        moduleOrderChangedByTestVendor = true;
        PageExperience = { "moduleOrder": [{ "name": "OVERVIEW" }, { "name": "ANNUAL-FEE" }, { "name": "GOOD-FOR" }, { "name": "REWARDS" }, { "name": "PAYMENT-TYPE" }, { "name": "DETAILS" }] };
    }
    /**/
    if (typeof moduleOrderChangedByTestVendor != "undefined" && moduleOrderChangedByTestVendor && PageExperience != null) {
        fetchOrder = typeof PageExperience != "undefined" && typeof PageExperience.moduleOrder != "undefined" ? PageExperience.moduleOrder : null;
        for (var k = 0; k < fetchOrder.length; k++) {
            if ($("#cards-content").length < 1) {
                fetchOrder.splice((fetchOrder[k].name == "OVERVIEW" ? fetchOrder.indexOf(fetchOrder[k]) : fetchOrder.length), 1);
                fetchOrder.splice((fetchOrder[k].name == "DETAILS" ? fetchOrder.indexOf(fetchOrder[k]) : fetchOrder.length), 1);
            }
        }

    } else {
        fetchOrder = typeof getQueryString("modorder") != "undefined" ? (decodeURIComponent(getQueryString("modorder").toUpperCase()).split(",")) : null;
        if ($("#cards-content").length < 1) {
            fetchOrder && (fetchOrder.splice((fetchOrder.indexOf("OVERVIEW") != -1 ? fetchOrder.indexOf("OVERVIEW") : fetchOrder.length), 1), fetchOrder.splice((fetchOrder.indexOf("DETAILS") != -1 ? fetchOrder.indexOf("DETAILS") : fetchOrder.length), 1));
            fetchOrder && (typeof getQueryString("bannerorder") != "undefined" && getQueryString("bannerorder") == "true" ? fetchOrder : (fetchOrder.splice((fetchOrder.indexOf("BANNER") != -1 ? fetchOrder.indexOf("BANNER") : fetchOrder.length), 1)))
        }
    }
    if ((typeof moduleOrderChangedByTestVendor != "undefined" && moduleOrderChangedByTestVendor == true) || typeof PageExperience != "undefined" || typeof getQueryString("modorder") != "undefined") {

        var modules = {
            "home": {
                "BANNER": "banner",
                "IN-THE-SPOTLIGHT": "in-the-spotlight",
                "VIEW-ALL-CARDS": "view-all-cards",
                "COMPARE-CARDS": "compare-cards",
                "GET-CARD-ADVICE": "get-card-advice",
                "FIND-OFFERS": "find-offers"
            },
            "product": {
                "OVERVIEW": "overview",
                "DETAILS": "details",
                "REWARDS": "rewards-benefits",
                "EXPENSE-MANAGEMENT": "expense-benefits",
                "BENEFITS": "service-benefits,#open-benefits",
                "CARD-REVIEW": "card-review",
                "TRAVEL": "travel-benefits",
                "PAYMENT-FLEXIBILITY": "paymentflexibility-benefits",
                "FUNDING-BENEFITS": "funding-benefits",
                "NPSL-BENEFITS": "npsl-benefits"
            },
            "compare": {
                "OVERVIEW": "overview",
                "ANNUAL-FEE": "annual-fee",
                "GOOD-FOR": "good-for",
                "REWARDS": "rewards",
                "PAYMENT-TYPE": "payment-type",
                "DETAILS": "details"
            },
            "homeInpageNav": {
                "IN-THE-SPOTLIGHT": "In The Spotlight",
                "VIEW-ALL-CARDS": "View All Cards",
                "COMPARE-CARDS": "Compare Cards",
                "GET-CARD-ADVICE": "Get Card Advice",
                "FIND-OFFERS": "Find Offers"
            },
            "productInpageNav": {
                "OVERVIEW": "Overview",
                "DETAILS": "Details",
                "REWARDS": "Rewards",
                "EXPENSE-MANAGEMENT": "Expense Management",
                "BENEFITS": "Benefits",
                "CARD-REVIEW": "Card Reviews",
                "TRAVEL": "Travel",
                "PAYMENT-FLEXIBILITY": "Flexible Payments",
                "FUNDING-BENEFITS": "Funding And Rewards",
                "NPSL-BENEFITS": "Buying Power"
            },
            "compareInpageNav": {
                "OVERVIEW": "Overview",
                "GOOD-FOR": "Good For",
                "REWARDS": "Rewards",
                "PAYMENT-TYPE": "Payment Type",
                "ANNUAL-FEE": "Annual Fee",
                "DETAILS": "Details"
            },
        };

        //var fetchOrder = typeof PageExperience.moduleOrder != "undefined" ? PageExperience.moduleOrder : null;
        var modList = home ? $(".module") : $("ul#accordion>li"),
            reOrder = "",
            navreOrder = "";

        if (fetchOrder && fetchOrder.length >= 1 && fetchOrder.indexOf(0) == -1 && $("#pre-compare-modules").length < 1) {
            $("#aj-inpage ul.in-page li").removeClass("active last-nav");
            var moduleIndex = 0;
            for (var j = 0; j < fetchOrder.length; j++) {
                //(typeof (modList[j]) != "undefined") ? reOrder+= (typeof $("#"+modules.product[fetchOrder[j].name])[0]) != "undefined" ? $("#"+modules.product[fetchOrder[j].name])[0].outerHTML : $("#"+modules.product[fetchOrder[j]])[0].outerHTML :null;
                if (typeof (modList[moduleIndex]) != "undefined") {
                    var moduleMap = home ? modules.home : modules.product,
                        inpageMap = home ? modules.homeInpageNav : modules.productInpageNav;
                    //fetchOrder[j] = fetchOrder[j].toUpperCase();
                    if (typeof (moduleOrderChangedByTestVendor) == "undefined" || !moduleOrderChangedByTestVendor)
                        (typeof $("#" + moduleMap[fetchOrder[j]])[0] != "undefined") ? (reOrder += home ? $("#" + moduleMap[fetchOrder[j]]).parent()[0].outerHTML : (modules.product[fetchOrder[j]].split(",").length > 1 ? ($("#" + modules.product[fetchOrder[j]])[0].outerHTML + $("#" + modules.product[fetchOrder[j]])[1].outerHTML) : $("#" + modules.product[fetchOrder[j]])[0].outerHTML), moduleIndex++ , navreOrder += typeof inpageMap[fetchOrder[j]] != "undefined" ? $("#ajnav ul.in-page li a[title='" + inpageMap[fetchOrder[j]] + "']").parent()[0].outerHTML : "") : (reOrder += "", navreOrder += "");

                    else
                        (typeof $("#" + moduleMap[fetchOrder[j].name])[0] != "undefined") ? (reOrder += home ? $("#" + moduleMap[fetchOrder[j].name]).parent()[0].outerHTML : (moduleMap[fetchOrder[j].name].split(",").length > 1 ? ($("#" + moduleMap[fetchOrder[j].name])[0].outerHTML + $("#" + moduleMap[fetchOrder[j].name])[1].outerHTML) : $("#" + moduleMap[fetchOrder[j].name])[0].outerHTML), moduleIndex++ , navreOrder += typeof inpageMap[fetchOrder[j].name] != "undefined" ? $("#ajnav ul.in-page li a[title='" + inpageMap[fetchOrder[j].name] + "']").parent()[0].outerHTML : "") : (reOrder += "", navreOrder += "");

                };
            };
            home ? (typeof getQueryString("bannerorder") != "undefined" && getQueryString("bannerorder") == "true" ? $(".module").remove() : $(".module").not(".banner-module").remove()) : $("ul#accordion>li").remove();
            $("#aj-inpage ul.in-page li a:not(a[title='Overview'],a[title='Details'])").parent().remove();
            //console.log("The new inpage nav reorder"+navreOrder);
            reOrder != "" && (home ? $("#wrapper")[0].innerHTML += reOrder : $("ul#accordion")[0].innerHTML += reOrder);
            navreOrder != "" && ($("#aj-inpage ul.in-page")[0].innerHTML += navreOrder);

        }
        else if (fetchOrder && fetchOrder.length >= 1) {
            $("#aj-inpage ul.in-page li").removeClass("active last-nav");
            var moduleIndex = 0, modList = $("div.accordion");
            for (var j = 0; j < fetchOrder.length; j++) {
                //(typeof (modList[j]) != "undefined") ? reOrder+= (typeof $("#"+modules.product[fetchOrder[j].name])[0]) != "undefined" ? $("#"+modules.product[fetchOrder[j].name])[0].outerHTML : $("#"+modules.product[fetchOrder[j]])[0].outerHTML :null;
                if (typeof (modList[moduleIndex]) != "undefined") {
                    var moduleMap = modules.compare,
                        inpageMap = modules.compareInpageNav;
                    // fetchOrder[j] = fetchOrder[j].toUpperCase();
                    if (typeof (moduleOrderChangedByTestVendor) == "undefined" || !moduleOrderChangedByTestVendor)
                        (typeof $("#" + moduleMap[fetchOrder[j]])[0] != "undefined") ? (
                            reOrder += $("#" + moduleMap[fetchOrder[j]]).parents(".accordion")[0].outerHTML, moduleIndex++ , navreOrder += typeof inpageMap[fetchOrder[j]] != "undefined" ?
                                $("#ajnav ul.in-page li a[title='" + inpageMap[fetchOrder[j]] + "']").parent()[0].outerHTML : "") :
                            (reOrder += "", navreOrder += "");

                    else
                        (typeof $("#" + moduleMap[fetchOrder[j].name])[0] != "undefined") ?
                            (reOrder += $("#" + moduleMap[fetchOrder[j].name]).parents(".accordion")[0].outerHTML, moduleIndex++ , navreOrder += typeof inpageMap[fetchOrder[j].name] != "undefined" ?
                                $("#ajnav ul.in-page li a[title='" + inpageMap[fetchOrder[j].name] + "']").parent()[0].outerHTML : "") :
                            (reOrder += "", navreOrder += "");

                };
            };

            $("div.accordion").remove();
            $("#aj-inpage ul.in-page li a").parent().remove();
            //console.log("The new inpage nav reorder"+navreOrder);
            reOrder != "" && ($("#wrapper #cards-content")[0].innerHTML += reOrder);
            navreOrder != "" && ($("#aj-inpage ul.in-page")[0].innerHTML += navreOrder);
        }
    }
    $("body").css('visibility', 'visible');
})();
/*End of Module reordering*/
/*Adding sub modules to the mdoule order*/

/*Adding sub modules to the mdoule order completed*/
/*ajnav issue*/
$(window).bind('touchstart touchmove touchend', function (e) {
    console.log(e.type);
    (touch && !isFocus) && (_ajNav.css({
        'top': 0,
        'margin-top': 0
    }),
        $(document).scrollTop() < iNavHeight ? _ajNav.parent().css({
            'position': 'relative',
            'z-index': '1300',
            '-webkit-transition': '1.2s ease',
            '-webkit-backface-visibility': 'hidden',
            'margin-top': $(window).width() > 660 ? '-7px' : '-5px'
        }) : _ajNav.parent().css({
            'margin-top': $(window).width() > 660 ? '-6px' : '-4px',
            'z-index': '3000'
        }))
})