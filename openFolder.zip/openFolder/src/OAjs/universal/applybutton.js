//Dilip: Added for Apply button as <buton> markup
//launch URL in same window
var launchURLInSameWindow = function(url) {
    window.location.href = url;
    return false;
};

var launchLearnMore = function(learnMoreURL) {
    launchURLInSameWindow(learnMoreURL);
};
//Apply card for offsite flow 
var applyForOffsiteFlow = function(applyNowURL) {
    launchURLInSameWindow(applyNowURL);
};

/* UA-Decode parameters encryption requirement*/
var applyWithOffer = function(applyNowURL, pmcCode, flow) {
    var urlPath= (flow==="UA") ? "/uadecode-gating" : "/pznoffer-gating",f = (flow==="UA") ?"":"?pmcCode=" + pmcCode + "&pZNPageId=" + pZNPageId,		
        b = typeof(domainName) == "undefined" ? "../credit-cards"+ urlPath + f : domainName + urlPath + f;
    $.ajax({
        url: b,
        type: "POST",
        cache: false,
        async: false,
        success: function(e) {
			if(e.result == "error") {
				window.location = domainName + "/business-card-compare-error"
			} else {
				if(flow==="UA") {
					$("form[name='applicationForm']").children("input[name='uaGatingOfferResp']").val(e.result);
					document.applicationForm.action = applyNowURL;
					document.applicationForm.submit();
				} else {
					$("form[name='pznApplicationForm']").children("input[name='pznOfferGatingResp']").val(e.result);
					document.pznApplicationForm.action = applyNowURL;
					document.pznApplicationForm.submit();
				}
			}/* UA-Decode parameters encryption requirement*/
        },
        error: function(e) {
            window.location = domainName + "/business-card-compare-error"
        }
    })
};

var applyForBusinessCard = function(applyNowURL, pmcCode, flow) {
/* UA-Decode parameters encryption requirement*/
    if (flow === 'UA' || flow === 'PZN' || flow === 'RICHEROFFER') {
        applyWithOffer(applyNowURL, pmcCode, flow);
    } else {
        applyForOffsiteFlow(applyNowURL);
    }
    return false;
};