OPEN.universal.ClickToDrawer=function(w,eles,resiize){
	var rightPos=0;
	for(var i=0;i<eles.length;i++){	
		for ( id=0; id<eles[i].length;id++)
		if($(eles[i][id]).length>0){ 
			(rightPos=w-($(eles[i][id]).offset().left + $(eles[i][id]).outerWidth()));	/* April a */		
			//(w>1440)&&(rightPos=w-1440)
		$('.chat-container').css('right',Math.abs(rightPos));
		}
	}
	var hh=$(window).height()>630?($(window).height()>850?($(window).height()>950?300:165):65):23;
	var setp=function(){
		/*personalization fix*/
		$('.scroll-arrow').length>0?($(".onlyModule").length==0) && $('.chat-container').css({"bottom":(parseInt($('.scroll-arrow').css('bottom'))+($('.scroll-arrow').height()+hh)-25),"top":"auto","margin-top":"0px"}):$('.chat-container').css("top","63%");
	}
 !resiize?setTimeout(function(){setp()},3000):setp();
}
OPEN.universal.controlC2CDrawer=function(){
	var drawer=$(".chat-container");
		//var drawer=$(".chat-with-us-active");
		if(drawer.length > 0)
		{
			var drawerPos=drawer.offset().top+drawer.height();
			var footerPos=$("#iNavNGI_FooterMain").offset().top;
			drawerPos<footerPos && drawer.css("visibility", "visible").find("#chat-wrap-side").css("display", "block")&&drawer.find("#call-wrap-side").css("display", "block");
			drawerPos>footerPos && drawer.css("visibility", "hidden").find("#chat-wrap-side").css("display", "none")&&drawer.find("#call-wrap-side").css("display", "none");
		}
	}
OPEN.universal.closeChatBar=function(e){
	if ($(e.target).closest('.chat-container').length === 0 && $(".chat-container").width()>$("#chat-with-us").width()) {				
                ($(".chat-container").stop(false,true).animate({width:$("#chat-with-us").width()},200));
				$("#chat-with-us").removeClass('expand')             
                
            }
}
OPEN.universal.ClickToDrawerAnim=function(){
$("#chat-with-us").click(function(e) {
		var chatActive=$("#chat-with-us").width()+$(".chat-with-us-active").width();
			 //$(".chat-container").animate({ width:chatW+chatActive }, 500);
        //$(".chat-container").hasClass("expand") ? $(".chat-container").removeClass("expand") : $(".chat-container").addClass("expand")
		($(this).hasClass("expand"))?($(".chat-container").stop().animate({width:$("#chat-with-us").width()},300)):($(".chat-container").stop().animate({width:chatActive+"px"},300),$(".chat-with-us-tive").stop().animate({left:46},300),typeof omn_rmaction == "function" && omn_rmaction("US:AMEX:Acq:OPEN:AJ:ChatWidget","click>ChatWithUs")); /* March A */
			$(this).toggleClass("expand");
	
	});
	/* March A start*/
	$("#call-wrap-side").on("click",".call-icon.active",function() {
		omn_rmaction("US:AMEX:Acq:OPEN:AJ:ChatWidget","click>RepCall");	
	});
        
       
           
                

	$("#chat-wrap-side").on("click",".chat-icon.active",function() {
		omn_rmaction("US:AMEX:Acq:OPEN:AJ:ChatWidget","click>ClickToChat");	
	});
	/* March A end*/
  	/*C2C hover end*/
	return this;
	};
 (!touch) && ($('.chat-container').show(),OPEN.universal.ClickToDrawer($(window).width(),eles));
 $("body").on('click', function (e) {
		OPEN.universal.closeChatBar(e);
		if($(e.target).closest('#call-now').length === 0) txt_fcs=false;
});