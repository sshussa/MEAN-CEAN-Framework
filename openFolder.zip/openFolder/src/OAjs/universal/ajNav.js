/* Dynamic generation of Fixed left navigation panel based on total number of modules in page*/
var ajnavFlg = true, ajInpgeFlg = true, cmp_crds = $('#compare-cards'), find_Offer = 'find-offers', aj_menu = $(".navheader ul li,.new-navheader .sub-nav ul li"), _whyOpen = $('.why-open'), _ajSbc = $('.aj-sbc'), _viewallajnav = $('.viewall-ajnav'), sharedajnavFlag = false;
/*ajnav variations marchb**/
OPEN.universal.ajnav = function () {
    var ajnav = UBA.getQueryString("ajnav")/*pavan*/;
    /* pavan */

    if ($('body').hasClass("ajnav3") || $('body').hasClass("ajnav2")) {
        !(_ajNav.hasClass('full-version')) && $('body').addClass('full-version');
        ($('body').hasClass("ajnav2")) ? (_whyOpen.removeClass('hide'), $('body').addClass('ajnav2').removeClass('ajnav3'), $('.open-logo').attr("title", "Small Business Cards")) : _whyOpen.addClass('hide');
        ($('body').hasClass("ajnav3")) ? (_ajSbc.removeClass('hide'), $('body').addClass('ajnav3').removeClass('ajnav2'), $('.open-src').attr("href", $('.why-open a').attr('href')), $('.open-logo,.open-src').attr("title", "American Express OPEN")) : _ajSbc.addClass('hide');
        $(window).width() < 661 ? _viewallajnav.removeClass('hide') : _viewallajnav.addClass('hide');
        if ($('body').hasClass("ajnav3") && isHome) {
            $('.open-src').css('cssText', 'cursor:pointer !important');
            $('.open-src').on('click', function () {
                window.location.href = $('.open-src').attr("href");
            })
        }

    } else {
        (_ajNav.hasClass('full-version')) && $('body').removeClass('full-version');
        !(_whyOpen.hasClass('hide')) && _whyOpen.addClass('hide');
        !(_ajSbc.hasClass('hide')) && _ajSbc.addClass('hide');
    } /* pavan */

};
OPEN.universal.ajanvAlign = function () {
    if ($(window).width() > 830)
    {
        _ajNav.css("right", $(window).width() - ($("#iNavUtilitySection").offset().left + $("#iNavUtilitySection").width()));
    } else
    {
        _ajNav.css("right", "auto");
    }
    return this;
};
OPEN.universal.navPanelPosIndexed = function () {
    var navliHt = [];
    $('#ajnav .aj-inpage .in-page li').each(function (ll, ele) {
        if (ll == 0)
            navliHt[ll] = $(ele).height() / 2;
        else {
            var ht = 0;
            for (innerj = 0; innerj < ll; innerj++)
            {
                ht = ht + $('#ajnav .aj-inpage .in-page li').eq(innerj).height();
            }
            navliHt[ll] = ht + ($(ele).height() / 2);
        }
    });
    return navliHt;
};
OPEN.universal.ajnavVerPosIP = function () {
    if ($(window).width() < 661) {
        if ($(window).scrollTop() < $('#iNMbWrap').height()) {
            brwsr_type.match(/iPhone/i) ? ($('.ajnav').addClass('scroll'), cmp_crds.addClass('scroll'), $('#viewall-header').addClass('scroll')) : null;
//         $(OPEN.config.ID. _cmprCrds).find("#curr-selection li a.card-art").show();
        $(OPEN.config.ID. _cmprCrds).find("#curr-selection li .close-btn-hldr").removeClass("cbh-update");
//         $(OPEN.config.ID. _cmprCrds).find("#curr-selection li .close-btn-hldr span.learnmorebutton").removeClass("lmb-update");
          $(OPEN.config.ID. _cmprCrds).find("#curr-selection li h2").removeClass("h2-update");
          $(OPEN.config.ID. _cmprCrds).find("#curr-selection li span.applybutton").removeClass("ab-update");
        } else
        {
            brwsr_type.match(/iPhone/i) ? ($('.ajnav').removeClass('scroll'), cmp_crds.removeClass('scroll'), $('#viewall-header').removeClass('scroll')) : null;
//         $(OPEN.config.ID. _cmprCrds).find("#curr-selection li a.card-art").hide();
          $(OPEN.config.ID. _cmprCrds).find("#curr-selection li .close-btn-hldr").addClass("cbh-update");
//           $(OPEN.config.ID. _cmprCrds).find("#curr-selection li .close-btn-hldr span.learnmorebutton").addClass("lmb-update");
           $(OPEN.config.ID. _cmprCrds).find("#curr-selection li h2").addClass("h2-update");
            $(OPEN.config.ID. _cmprCrds).find("#curr-selection li span.applybutton").addClass("ab-update");
        }
    }
    if ($(window).width() >= 661 && $(window).width() <= 667) {
        if ($(window).scrollTop() < $('#iNavHdWrap').height()) {
            brwsr_type.match(/iPhone/i) ? ($('.ajnav').addClass('scroll'), cmp_crds.addClass('scroll'), $('#viewall-header').addClass('scroll')) : null;
//        $(OPEN.config.ID. _cmprCrds).find("#curr-selection li a.card-art").show();
        } else
        {
            brwsr_type.match(/iPhone/i) ? ($('.ajnav').removeClass('scroll'), cmp_crds.removeClass('scroll'), $('#viewall-header').removeClass('scroll')) : null;
//        $(OPEN.config.ID. _cmprCrds).find("#curr-selection li a.card-art").hide();
        }

    }
};
OPEN.universal.ajInpgeAnm = function (navTpe)
{
    var ajnav = $(".open .new-navheader ." + navTpe + ">a");
    var slr = touch ? "click" : "mouseenter click touch";
    ajnav.on(slr, function (e) {
        e.stopImmediatePropagation();
        $(this).text() != "VIEW ALL CARDS" && e.preventDefault();
        var htDrp = ajnav.parent().find(".items>ul").outerHeight() + 5;
        if (touch)
        {

            if (e.type != "mouseenter") {
                if (parseInt($(this).parent().find(".items>ul").css("top")) == 0)
                {
                    $(this).parent().find(".items").css({"height": "0", "overflow": "hidden"}).find("ul").css({top: -htDrp + 5});
                    ajnav.parent().removeClass('new-ajhover');
                    OPEN.universal.ajNav_Mn_methods();
                } else
                {
                    $(this).parent().find(".items").css({"height": "", "overflow": "visible"}).find("ul").css({top: 0});
                    ajnav.parent().addClass('new-ajhover');
                    $('.dropdown-menu').hide();
                }
            }
        } else
        {
            $(this).parent().find(".items").css({height: htDrp}).find("ul").css({top: 0});
            ajnav.parent().addClass('new-ajhover');
            if (!($("body").hasClass("noflyout")) && (e.type == "mouseenter")) {
               ($("li.dropdown-submenu").find("a").first()).click(function(e){
                    e.preventDefault();
                });
            }
    
        }

    }).parent().on("mouseleave", function () {
        var htDrp = ajnav.parent().find(".items>ul").outerHeight() + 5;
        $(this).find(".items").css({"height": "0", "overflow": "hidden"}).find("ul").css({top: -htDrp + 5});
        ajnav.parent().removeClass('new-ajhover');
        OPEN.universal.ajNav_Mn_methods();
    });
};
OPEN.universal.ajVariations = function (curr)
{
    var bdy = $("body");
    switch (curr)
    {
        case 1:
            bdy.addClass("ajnav2 full-version");
            break;
        case 2:
            bdy.addClass("new-ajnav");
            break;
        case 3:
            bdy.addClass("new-ajnav ajvac");
            break;
        case 4:
            bdy.addClass("new-ajnav ajvac-inpge");
            break;
        default:
            bdy.addClass("ajnav2 full-version");
    }
};

//Shared AJ NAV code

OPEN.universal.Shrd_AjNav_Clck = function () {
    if (!($("body").hasClass("noflyout")) && (touch)) {
        $('.dropdown-submenu').on('click', function () {
           
            if (!$('.dropdown-menu').is(':visible'))
                $('.dropdown-submenu').addClass('active');
            $('.dropdown-menu').slideToggle(10, function () {
                if (!$('.dropdown-menu').is(':visible'))
                    $('.dropdown-submenu').removeClass('active');
            });

            //check if element is visible in the viewport 
            var topOfElement = $(".sub-nav ul.dropdown-menu li:last-child").offset().top;
            var bottomOfElement = topOfElement + $(".sub-nav ul.dropdown-menu li:last-child").outerHeight(true);
            var viewportHeight = $(window).height();
            if ((viewportHeight < bottomOfElement) && ($(window).height() < $(window).width())) {
                sharedajnavFlag = true;
                // Element is hidden (below viewable area)
                $(".sub-nav ul.dropdown-menu").addClass('dropdown-top');
                $(window).bind('touchmove scroll', function (e) {

                    if ((($(window).scrollTop() > iNavHeight + 10) && ($(window).width() >= 661 && $(window).width() <= 667))||((($(".ajnav-scroll").scrollTop() == iNavHeight + 132) && ($(window).width() < 661)) || ($(window).height() > $(window).width()))) {
                        OPEN.universal.ajNav_tchmve_Scrll();
                    }
                });
            }
            if (($(window).height() < $(window).width()) && ($(window).width() < 661)) {
                $(".open .new-navheader > li.sub-nav .items").toggleClass('ajnav-scroll');

            }

        });

    }
};

OPEN.universal.noFlyout_tchdevice_methd = function () {
    if (!($("body").hasClass("noflyout")) && (touch)) {
        ($("li.dropdown-submenu").find("a").first()).click(function(e){
          e.preventDefault();
        });
    }
};

OPEN.universal.ajNav_tchmve_Scrll = function () {
    var mnHtDrp = $(".open .new-navheader .sub-nav").find(".items>ul").outerHeight() + 5;
    $(".open .new-navheader .sub-nav").find(".items").css({height: 0}).find("ul").css({top: -mnHtDrp});
    $(".open .new-navheader >  li ").removeClass('new-ajhover');
    $(".open .new-navheader > li.sub-nav .items").css({"overflow": "hidden"}).find("li.dropdown-submenu.active").removeClass("active").children("ul.dropdown-menu").slideUp();
    $(".open .new-navheader > li.sub-nav .items").removeClass('ajnav-scroll');
};
OPEN.universal.ajNav_Mn_methods = function () {
    $(".open .new-navheader > li.sub-nav .items").find("li.dropdown-submenu.active").removeClass("active").children("ul.dropdown-menu").slideUp();
    $(".open .new-navheader > li.sub-nav .items").removeClass('ajnav-scroll');
};

OPEN.universal.ajNav_init = function () {
    $('#needhelp-section ul li:visible').last().addClass("ajn-lst");
    //isHome && $('.new-navheader .devider+li a').click(function(e){e.preventDefault(); }); /* junec */ 
    $("body").addClass("inpg");/* junec */
    OPEN.universal.ajInpgeAnm("aj-inpage");/* junec */
    OPEN.universal.ajInpgeAnm("sub-nav");/* junec */
    OPEN.universal.ajInpgeAnm("vac-link");/* junec */
    ($(window).width() >= 1280 && $('body').hasClass('ajvac-inpge')) ? $('.new-navheader .sub-nav .items').addClass('itemsli') : $('.new-navheader .sub-nav .items').removeClass('itemsli');
    //!touch && $(".open .new-navheader > li#call-sec").click(function(e){e.preventDefault(); });
    $(".open .new-navheader > li").not("#call-sec,#aj-inpage").on("mouseenter click touch", function (e) {
        $(this).addClass('new-ajhover');
    });
    $(".open .new-navheader > li.sub-nav .items li,.open .navheader > li ul li").on(touch ? "touchstart" : "mouseenter", function (e) {
        $(this).parent().find("li").removeClass("active");
        $(this).addClass('active');
        $(".open .new-navheader > li.sub-nav .items").css({"overflow": "visible"});
        $(this).removeClass('new-ajhover');
    });
    $(".open .new-navheader > li.aj-inpage .items li").on(touch ? "touchstart" : "mouseenter", function (e) {
        $(this).parent().find("li").removeClass("in-act");
        !$(this).hasClass("active") && $(this).addClass('in-act');
    });
    $(".open .new-navheader > li.sub-nav .items").on("mouseleave", function (e) {
        $(".open .new-navheader > li.sub-nav .items").css({"height": "0", "overflow": "hidden"});
        $(this).removeClass("active");
    });
    $(".open .new-navheader > li.aj-inpage .items li").on(touch ? "touchend" : "mouseleave", function (e) {
        $(this).removeClass("in-act");
    });
    touch && $('#ajnav').addClass('touch'); /*aprilb*/
    //(!brwsr_type.match(/iPhone/i)) && ((!touch || $(window).width()>660) && $('#call-sec a').attr('href','#')); /*JuneC*/
    $(".open .new-navheader >  li ").not("#call-sec,#aj-inpage").on("mouseleave", function (e) {
        $(this).removeClass('new-ajhover');
    });
    if (brwsr_type.indexOf('OS 8') > -1 || brwsr_type.indexOf('OS 9') > -1) {
        $("#ajnav").addClass("ios8-device")
    }
    OPEN.universal.ajnav();
    if (isHome) {
        $("#call-section + li>a").css("cursor", "default");
    }
    $('.ajnav .navheader li.hasSubNav').hover(function () {
        $('.ajnav').addClass('aj-shadow')
    }, function () {
        $('.ajnav').removeClass('aj-shadow')
    });
    if ((typeof (ua_applicable) != "undefined" && !ua_applicable) || (typeof (findoffers_disable) != "undefined" && findoffers_disable)) {
        aj_menu.each(function ( ) {
            if ($(this).text() == "Find Special Offers") {
                $(this).hide();
            }
        });
    }
    /*Debugathon Start*/
    $('#' + find_Offer).bind('click', function (e) {
        isFocus == false && $("#explore-section .need-advice+li>a").triggerHandler("click");
    })
    $("#call-section>a").click(function (e) {
        e.preventDefault();
        window.location.href = 'tel:18005196736';
    });
    $("#lpVoice a").bind('click', function (e) {
        if (!$(this).hasClass("active")) {
            $(this).addClass('active');
            $("#call-now").slideDown();
        } else {
            $(this).removeClass('active');
            $("#call-now").slideUp();
        }
        e.preventDefault();
    });
    $(".navheader ul").mouseleave(function () {
        $('#call-now').hide();
        $("#lpVoice a").removeClass('active');
    });

    if (touch) {
        /* LP fix */
        $('#call-now').live('click touch touchmove', function (e) {
            e.stopPropagation();
            txt_fcs = true;
        });/* LP fix */
        if ($(window).width() >= 600) {
            $(".navheader li:first-child ul").addClass("no-call");
            $(".no-call li").not(".need-advice").on('click', function (e) {
                if ((e.target.tagName == "INPUT" || e.srcElement.tagName == "INPUT" || e.target.tagName == "SELECT" || e.srcElement.tagName == "SELECT" || e.target.tagName == "A" || e.srcElement.tagName == "A"))
                {
                    e.stopPropagation();
                    return true;
                } else
                    return false;
            });
        }
        /* LP fix */	$("#call-now").live('touchmove scroll drag', function (e) {
            e.stopPropagation()
            e.preventDefault();/* LP fix */
        });
        //$(document).scrollTop(1, 1);
        var timer;
        var propagated = false;
        /* LP fix */      !txt_fcs && ($('#call-now:visible').hide(), $('.navheader>li ul').css('right', "9999px"));
        $('.navheader>li').click(function (e) {
            if ($(this).parent().hasClass("navheader")) {
                if (!propagated) {
                    if ($(this).find('ul').css('right') != "0px") {
                        /* LP fix */             ($('#call-now:visible').hide(), $('.navheader>li ul').css('right', '9999px'));/*JANB PIV*/
                        /* Marcha A*/$("#ajnav .arrow-down").removeClass("arrow-down");
                        $(this).find('ul').css('right', "0px");
                        $(this).hasClass("hasSubNav") && $(".ajnav").addClass("aj-shadow");
                        $(this).children("a").addClass("arrow-down");
                        $(this).hasClass("hasSubNav") && $(this).css('background-color', '');
                        $(this).hasClass("hasSubNav") && $(this).siblings().css('background-color', '#EAEAEA');
                        ($("body").hasClass("full-version") && $(this).hasClass("hasSubNav")) && $(this).css('background-color', '#EAEAEA');/*MarchB*/
                        ($("body").hasClass("full-version") && $(this).hasClass("hasSubNav")) && $(this).siblings().css('background-color', '');/*MarchB*/

                    } else {
                        $(".ajnav").removeClass("aj-shadow");
                        $('.navheader>li ul').css('right', "9999px");
                        /* Marcha A*/ $(this).children("a").removeClass("arrow-down");
                        $(this).siblings().css('background-color', '');
                        ($("body").hasClass("full-version") && $(this).hasClass("hasSubNav")) && $(this).css('background-color', '');/*MarchB*/
                    }
                }
                propagated = false;
            } else {
                propagated = true;
            }
            e.stopPropagation();
        });
        /* LP fix */ txt_fcs = false;
    } else {
        $("ol.hp-control-nav li a").live('mouseenter mouseleave', function (e) {
            if (e.type == 'mouseenter') {
                $(this).addClass('hovered');
            } else {
                $(this).removeClass('hovered');
            }
        });
        $(".navheader>li").hover(function () {
            $(".open .navheader > li ul li").removeClass("active");
            $(this).addClass("hovered").siblings().css('background-color', '#EAEAEA');
            $("body").hasClass("full-version") && $(this).addClass("hovered").siblings().css('background-color', '');/*MarchB*/

            $(this).children("a").addClass("arrow-down");
        }, function () { // Mouse out
            $(this).removeClass("hovered").siblings().css('background-color', '').children("a");
            $("body").hasClass("full-version") && $(this).removeClass("hovered").siblings().css('background-color', '').children("a");/*MarchB*/
            $('.navheader>li ul').css('right', 9999);
            $(this).children("a").removeClass("arrow-down");
        });

        $('.navheader>li>a').live('focus', function (e) {
            $('.navheader>li ul').css('right', 9999);
            /* Marcha A*/$("#ajnav .arrow-down").removeClass("arrow-down");
            //$(this).siblings('ul').css('right', 0);/*marchb*/
            $(this).addClass("arrow-down");
            return false;
        });
    }

    if ((!brwsr_type.match(/iPhone/i)) && (!brwsr_type.match(/iPod/i)) && (!brwsr_type.match(/iPad/i))) {
        $('.navheader li ul li:last a,.callnow-btn').live('keydown', function (e) {
            if (e.keyCode == 9) {
                $(this).parents("ul").css('right', 9999);
                $(this).parents("ul").siblings("a").removeClass("arrow-down");
            }
        });
        $("#lpVoice a").live('keydown', function (e) {
            if (e.keyCode == 13) {
                $("#lpVoice a").live('keydown', function (e) {
                    if (e.keyCode == 9) {
                        $(this).parents("ul").css('right', 0);
                        $(this).parents("ul").siblings("a").addClass("arrow-down");
                    }
                });
            } else if (e.keyCode == 9) {
                $(this).parents("ul").css('right', 9999);
                /* Marcha A*/$("#ajnav .arrow-down").removeClass("arrow-down");
            }

        });
    }
    $("#call-section + li").click(function (e) {
        if (isHome) {
            $(this).siblings().css('background-color', '');
            e.preventDefault();
            return false;
        }
    });
    $('#explore-section ul li a,#needhelp-section .need-advice a').click(function () {/*feb fix to be merged*/
        if ($(this).parent().parent().css("right") == "0px") {
            $(this).parents(".hasSubNav").removeClass("hovered");
            /* Marcha A*/$("#ajnav .arrow-down").removeClass("arrow-down");
            $(this).parent().parent().parents("li").siblings().css('background-color', '');
            $(this).parent().parent().css('right', "9999px");
        }
    });
    /* March B */ touch && ($("#ajnav ul.navheader li").click(function () {
        $(this).hasClass("hovered") && $(this).removeClass("hovered")
    })); /* AprilB PIV Fix */
    $('.special-offers li').click(function () {
        (typeof ($iTagTracker) == 'function') ? $iTagTracker('rmaction', 'SpecialOffers_' + $(this).find('a').text().split(' ').join('')) : null;
    })
    /*ajnav "see our most popular cards" right click disable augb */
    $("#ajnav #explore-section ul li.see-our-most-pop-crds a").on('click', function (f) {
        if (f.button) {
            f.preventDefault();
            return false;
        }
    });
    /*bug explore AJnav iphone*/
    if ($(window).width() <= 600) {
        window.addEventListener('load', function () {
            var els = $('#explore-section ul>li');
            for (var i = 0; i < els.length; i++)
            {
                els[i].addEventListener('touchstart', function (e) {
                    e.stopPropagation();
                    $(this).parents('#explore-section ul').find('li').removeClass('active');
                    $(this).addClass('active');
                });
            }
            $('#explore-section').click(function (e) {
                e.stopPropagation();
                $(this).find('li').removeClass('active');
            });
        });
    }
    /*shared AJ NAV code */
    $(window).on('touchmove scroll', function (e) {
        OPEN.universal.ajnavVerPosIP();//ios8 17
        $(window).scrollTop() > iNavHeight ? (_isInavHidden = true) : (_isInavHidden = false);
        $(".open .navheader > li ul li").removeClass("active");
        $(".open .new-navheader > li.aj-inpage .items").css({"overflow": "hidden"}).parent().removeClass('new-ajhover');
        if (parseInt($(".open .new-navheader .sub-nav .items > ul").css('top')) == 0 || parseInt($(".open .new-navheader .aj-inpage .items > ul").css('top')) == 0) {
            var ajnav = $(".open .new-navheader .sub-nav>a");
            var mnHtDrp = $(".open .new-navheader .sub-nav").find(".items>ul").outerHeight() + 5;
            var pageHtDrp = $(".open .new-navheader .aj-inpage").find(".items>ul").outerHeight() + 5;
            if (touch && !sharedajnavFlag) {
                e.stopPropagation();
                $(".open .new-navheader .sub-nav").find(".items").css({height: 0}).find("ul").css({top: -mnHtDrp});
                $(".open .new-navheader >  li ").removeClass('new-ajhover');
                $(".open .new-navheader > li.sub-nav .items").css({"overflow": "hidden"}).find("li.dropdown-submenu.active").removeClass("active").children("ul.dropdown-menu").slideUp();
                sharedajnavFlag = false;
            }
            $(".open .new-navheader .aj-inpage").find(".items").css({height: 0}).find("ul").css({top: -pageHtDrp});
        }
        ajInpgeFlg = true;
        ajnavFlg = true;
    });

    $(window).on('touchmove', function (e) {
        /* Marcha A*/$("#ajnav .arrow-down").removeClass("arrow-down");
        $(".hasSubNav ul").parents("li").siblings().css('background-color', '');
        $(".hasSubNav ul").css({"right": "9999px", "magin-right": "-4px"});/*ios7*/
        $(".ajnav").removeClass("aj-shadow");
    });
    $(window).load(function () {
        OPEN.universal.Shrd_AjNav_Clck();
        OPEN.universal.noFlyout_tchdevice_methd();
        $('#needhelp-section ul li:visible').last().addClass("ajn-lst"); /*aprilb*/
        void 0 != OPEN.lptag && OPEN.lptag.pageload();
        OPEN.universal.controlC2CDrawer();
    });
    if (brwsr_type.match(/Android/i)) {
        window.addEventListener('orientationchange', function () {
            if ($(window).width() < 600) {
                $(".navheader li:first-child ul").addClass("no-call");
                $(".no-call li").on('click', function () {
                    return false;
                });
            }
            // isOrientationChanged = true feb B 
        });
    }



    $('#explore-section ul li a,#new-explore-section ul li a,#needhelp-section ul li a').click(function (e) { /* junec */
        if ($('#' + $(this).attr('href').split('#')[1]).size() > 0)
        {
            brwsr_type.match(/Nexus/i) == null && e.preventDefault(); /*debugathon1*/
            var gotom = $(window).width() < 831 ? $('#' + $(this).attr('href').split('#')[1]).offset().top - ($(window).width() < 661 && $($("body").hasClass("new-ajnav") ? '.new-navheader > li' : '.navheader').height()) : $('#' + $(this).attr('href').split('#')[1]).offset().top;
            $(window).width() > 660 && !$('#' + $(this).attr('href').split('#')[1]).parent().hasClass("first-module") && (gotom = gotom - ($("#ajnav").height() - 7)); /*JulyB*/
            $('html,body').animate({scrollTop: gotom}, 300, function () {
                touch && $('.navheader>li ul').css({'right': '9999px'})
            })
        }
    });

    return this;
};

OPEN.universal.ajNav_resize = function () {
        if (($(window).height() < $(window).width()&&($(window).width() <= 660))||($(window).height() > $(window).width()&&($(window).width() <= 660))) {
               OPEN.universal.ajNav_tchmve_Scrll();
           };
    ($(window).width() >= 1280 && $('body').hasClass('ajvac-inpge')) ? $('.new-navheader .sub-nav .items').addClass('itemsli') : $('.new-navheader .sub-nav .items').removeClass('itemsli');
    ($(window).width() <= 660) && $("#needhelp-section a.arrow-down").length == 1 && $('.navheader>li').css("background-color", "");/* sat 11a issue for tab*/
    ($(window).width() >= 831) && $("#needhelp-section a.arrow-down").length == 1 && $('.navheader>li').css("background-color", "#eaeaea") && $("#needhelp-section").css("background-color", "");/* 11a issue for tab*/
    return this;
};