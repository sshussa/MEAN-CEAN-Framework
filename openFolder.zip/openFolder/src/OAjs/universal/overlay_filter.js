OPEN.overlayfilter = {		
filterData: {
  overlay_Filters: {
                header: "SHOW CARDS BY FEATURE",
                overlay: true,
                filterList: {
                    see_all_crds: {
                        label: "All Cards",
                        title: "Check if you want all Cards.",
                        features: [],
                        pmc: [92, 111, 141, 89, 1043, 756, 113, 474, 499, 79, 251]
                    },
                    charge_cr: {
                        label: "Charge Cards",
                        title: "Check if you wantCharge Cards.",
                        features: [],
                        pmc: [111, 89, 92, 499]
                    },
                    credit_crds: {
                        label: "Credit Cards",
                        title: "Check if you want Credit Cards.",
                        features: [],
                        pmc: [756, 141, 79, 113, 251, 1043, 474]
                    },
                    flexible_crds: {
                        label: "Flexible Payment Card",
                        title: "Check if you want Flexible Payment Card.",
                        features: [],
                        pmc: [499]
                    },
                    trl_rwds: {
                        label: "Travel Rewards",
                        title: "Check if you want Travel Rewards.",
                        features: [],
                        pmc: [756, 141, 113, 111, 92, 474, 89]
                    },
                    mbr_rwds: {
                        label: "Membership Rewards<sup>&reg;</sup> Program",
                        title: "Check if you want Membership Rewards.",
                        features: [],
                        pmc: [79, 111, 89, 92]
                    }
                }
            },
			
			  renderCardFilters: function(cfg) {
            var section = "";
            var ovlyCnt = "";
            var mini_Filters = $("#cards-list-overlay").find('.card-types');
			var frag = document.createDocumentFragment();
			
            var data = this.overlay_Filters;
            data && (this.overlay_Filters = data);
            
            frag.appendChild($('<ul></ul>')[0]);
            $(data).each(function() {
                if (this.header && this.header != "") {
                    var header=this.header;
                    var ftrMkp;
                    if (this.filterList) {
                        ftrMkp = '<ul>';
                        $.each(this.filterList, function(index, items) {
                            var type = 'radio';
                            var altTag = items.label.replace(/(<sup>|<\/sup>)/g, "");
                            ftrItm = "<li><input id='" + index.split("_").join("-") + "' type='" + type + "' name='" + header.split("_").join("-") + "' title='" + altTag + "' /><label for='" + index.split("_").join("-") + "'>" + items.label + "</label>";
                            ovlyCnt = ovlyCnt + ftrItm + "</li>";                         
                        });
                    }
                    
                }
              
            });
            //detail_Filters.append(frag);			
 		   ovlyCnt != "" && mini_Filters && $(mini_Filters).append($('<ul>' + ovlyCnt + '</ul>'));
           this.customRadio.set(mini_Filters);
           this.customCheckBox.set(mini_Filters);
			},
			
			   ovrlay_FilterCards: function() {		   
        var _cardsLst = $("#cards-list-overlay");
        _cardsLst.find(".cards-list li:last-child").after(_cardsLst.find(".close-icon").focus());   
            var pmcVal = OPEN.overlayfilter.filterData.overlay_Filters.filterList[$(this).attr('id').split('-').join('_')].pmc;
            $(this).is(':checked') ? (pmcVal != null && typeof pmcVal != 'undefined' ?  OPEN.overlayfilter.filterData.overly_cardsSelection(pmcVal, true) : null) : null;
   
			
},
    overly_cardsSelection: function(pmc, tag) {
        var _cardsLst = $("#cards-list-overlay");
        _cardsLst.find(".cards-list li").hide();
        tag ? $.each(pmc, function(k, crdPmc) {
            _cardsLst.find(".cards-list li[class='pmc-" + crdPmc + "-sml'],.cards-list li[class='pmc-" + crdPmc + "-sml disabled']").show();
        }) : null;

    },
	     customRadio: {
            set: function(ele) {
                var rdo = ele.find('input:radio');
                var rdoChk = "radio-normal";
                var rdoChkd = "radio-checked";
                rdo.css("opacity", "0").parent().append("<span class=" + rdoChk + "></span>");
                $(rdo + ":checked").siblings("span").addClass(rdoChkd);
                rdo.live("click", function() {
                    $(this).parent().siblings("li").find(">span").removeClass(rdoChkd);
                    $(this).siblings("span").addClass(rdoChkd);
                    rdo = null;
                })
            }
        },
		   customCheckBox: {
            set: function(ele) {
                var chk = "checkbox-normal";
                var chkd = "checkbox-checked";
                var chkb = ele.find('input:checkbox');
                chkb.css("opacity", "0").parent().append("<span class=" + chk + "></span>");
                $(chkb + ":checked").siblings("span").addClass(chkd);
                chkb.live("click", function() {
                    $(this).siblings("span").toggleClass(chkd);
                })
            }
        }
		}

};