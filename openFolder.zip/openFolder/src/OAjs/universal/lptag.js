OPEN.lptag = {
    pageload: function () {
        var productMapping = [
            {
                P6D: "The Plum Card",
                NZJ: "Delta Reserve for Business Credit Card",
                NLT: "The Business Gold Rewards Card",
                RJF: "Business Platinum Card",
                QLG: "Starwood Preferred Guest Business Credit Card",
                JB8: "Business Green Rewards Card",
                H9G: "Blue for Business Credit Card",
                R6G: "Lowes Business Rewards Card from American Express",
                P53: "Gold Delta SkyMiles Business Credit Card",
                SM6: "Platinum Delta SkyMiles Business Credit Card",
                MYK: "SimplyCash Plus Business Credit Card"
            }
        ];
        if (typeof (lpTag) == "undefined") {
            window.lpTag = {}
        }
        if (typeof (lpMTagConfig) == "undefined") {
            window.lpMTagConfig = {}
        }
        ;
        window.lpTag.vars = lpTag.vars || [];
        window.lpTag.dbs = lpTag.dbs || [];
        window.lpTag.section = "open";
        if (typeof omn == "undefined") {
            window.omn = "";
            window.omn.hierarchy = ""
        }
        window.arrLPvars = [
            {scope: 'page', name: 'PageName', value: itag_pagename},
            {scope: 'page', name: 'PageID', value: $itag.PageId},
            {scope: 'page', name: 'ProspectFlow', value: omn.hierarchy}
        ];
        typeof (lpTag.vars) != "undefined" && lpTag.vars.push(arrLPvars);
        typeof (lpTag) == "object" && typeof (lpTag.vars.send) == "function" && lpTag.vars.send();

        /* PZN LOOPINNG CODE */

        if (typeof (eApply_MVT) != "undefined") { /* Check if page is populated in PZN flow */
            if (eApply_MVT == "TRUE" && typeof (PageExperience) != "undefined" && PageExperience != null) {/*enter into loop only if PageExperience is availble*/
                lpTag.vars.push([
                    {scope: 'page', name: 'mmpID', value: typeof (PageExperience.mmpID) != 'undefined' ? PageExperience.mmpID : ""},
                    //{scope: 'page', name: 'pageId', value: typeof (PageExperience.pageId) != 'undefined' ? PageExperience.pageId : ""},
                    {scope: 'page', name: 'sessionId', value: typeof (PageExperience.sessionId) != 'undefined' ? PageExperience.sessionId : ""},
                    {scope: 'page', name: 'requestId', value: typeof (PageExperience.requestId) != 'undefined' ? PageExperience.requestId : ""},
                ])
                lpTag.vars.send();
                if (typeof (PageExperience.productOrder) != "undefined" && PageExperience.productOrder.length > 0)
                {
                    for (i = 0; i < PageExperience.productOrder.length; i++)
                    {
                        var productName = PageExperience.productOrder[i].name
                        lpTag.vars.push([
                            {scope: 'page', name: 'P' + Math.floor(i / 10) + Math.ceil(i % 10) + '_OfferId', value: PageExperience.productOrder[i].offerId},
                            {scope: 'page', name: 'P' + Math.floor(i / 10) + Math.ceil(i % 10) + '_Order', value: PageExperience.productOrder[i].order},
                            {scope: 'page', name: 'P' + Math.floor(i / 10) + Math.ceil(i % 10) + '_Name', value: productMapping[0][productName]},
                            {scope: 'page', name: 'P' + Math.floor(i / 10) + Math.ceil(i % 10) + '_SpecialOfferIndicator', value: PageExperience.productOrder[i].specialOfferIndicator},
                            {scope: 'page', name: 'P' + Math.floor(i / 10) + Math.ceil(i % 10) + '_AffluentIndex', value: PageExperience.productOrder[i].affluentIndex},
                            {scope: 'page', name: 'P' + Math.floor(i / 10) + Math.ceil(i % 10) + '_ProfileType', value: PageExperience.productOrder[i].profileType}
                        ]);
                        lpTag.vars.send();
                    }
                }
                if (typeof (PageExperience.moduleOrder) != "undefined" && PageExperience.moduleOrder.length > 0)
                {
                    for (i = 0; i < PageExperience.moduleOrder.length; i++) {
                        lpTag.vars.push([
                            {scope: 'page', name: 'M' + Math.floor(i / 10) + Math.ceil(i % 10) + '_ModuleConfigId', value: PageExperience.moduleOrder[i].moduleConfigId},
                            {scope: 'page', name: 'M' + Math.floor(i / 10) + Math.ceil(i % 10) + '_Name', value: PageExperience.moduleOrder[i].name},
                            {scope: 'page', name: 'M' + Math.floor(i / 10) + Math.ceil(i % 10) + '_order', value: PageExperience.moduleOrder[i].order}
                        ]);
                        lpTag.vars.send();
                    }
                }
            }
        }
    }
}
