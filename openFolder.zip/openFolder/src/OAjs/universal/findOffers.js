OPEN.findOffers={
tool_vlidate:$("#validateTipWrapper"),spclofrs:$(".all-business-cards .special-offers"),rsvp_Code:isHome ? $("#rsvp-offers :input"): $(".mail-offer #rsvp-code"),biz_LegalName : $(".mail-offer #biz-legalname"),submitbtn:'submit-block',offerFields : $("#special-offers input[type='text'],#special-offers select,#email-submit input[type='text'], #module-05 label.label-mask"),fieldErr :'fieldErrors',securdtltip:$(".secured-tooltip"),srvrErr:"",
validate: function () {
var _this=this;
        _this.offerFields.live('blur',function () {
            ele = null;
			isFocus=false;
            OPEN.Validate.BusinessForm.validateField(this);
            OPEN.Overlay.isVisible && OPEN.Overlay.hide();
            $(this).siblings("label").css("color", "#000")
        }).focus(function (a) {
            ele = null;
            OPEN.Overlay.hide();
			isFocus=true;
            $(this).parent().hasClass(_this.fieldErr) || $(this).parent().parent().hasClass(_this.fieldErr) ? OPEN.Validate.BusinessForm.validateField(this) : null;
			(($(this).attr('id'))=="quiz-email")? (_this.tool_vlidate.css('cssText','display:none !important' )):null	
            a.preventDefault()
        }).on("focusout",function(){
			isFocus=false;
        }).keyup(function (a) {
			(($(this).attr('id'))=="quiz-email")? ( _this.tool_vlidate.css('cssText','display:none !important' )):null
            $(this).val() == "" ? $(this).siblings("label").show().css("color", "#888") : $(this).siblings("label").hide()
        }).change(function (a) {
            if (a.target.nodeName == "SELECT") {
                $(this).val() != "" && $(this).parent().parent().removeClass("fieldErrors")
            }
        })
		return this;
    },
    submitForm: function () {
		var _this=this;
        $("#submit-btn-find").click(function () {
            isHome ? (_this.srvrErr = $(this).closest('form').find('.server_error')) : (_this.srvrErr = $('#special-offers>p.server_error'));
            var a = OPEN.Validate.BusinessForm.validateForm("find-special-offers");
            var b = UBA.getQueryString("dm") || UBA.getQueryString("cm") || UBA.getQueryString("lgn");
            if (a) {
                if ($("#privacy-statement-find").attr("checked") == "checked" || $("#privacy-statement-find").attr("checked") == true && $("#privacy-statement-find").attr("checked") != false) {
                    if ($("#ultBizApplyWrapper").hasClass("RSVP")) {
                        omn_rmaction("US:OPEN:BizUA:ProspectDM", "click>BizInfoSubmit")
                    } else {
                        omn_rmaction("US:OPEN:BizUA:ProspectUA", "click>Submit")
                    }
                    $("#find-special-offers").submit()
                } else {
                    _this.srvrErr.html("Please make sure you check the checkbox ").show();
                    return false
                }
            } else {
                _this.srvrErr.show().html("Please make sure all required fields are complete and valid ");
                return false
            }
        })
		return this;
    },
	special_Offer: function () {
		var _this=this;
        this.spclofrs.find("li").click(function () {
            if ((!isHome) || (isHome && $(window).width() < 830)) {
                $("#validateTipWrapper,.server_error").hide();
                $("." + $(this).attr("id")).show().siblings().hide();
				
                $(this).addClass("active").siblings().removeClass("active");
				$(".by-legal-name").is(":visible") ? $('#special-offers').addClass('long'):$('#special-offers').removeClass('long');
            }
            return false
        });
        _this.rsvp_Code.focus(function () {
			$('#special-offers').removeClass('long');
            _this.biz_LegalName.parent().removeClass("fieldErrors");
            $("#special-offers>p.server_error,#rsvp-offers p.server_error,#business-offers p.server_error").hide();/* feb a PIV */
            $(this).parent().next().find('ul').show();
            $("." + _this.submitbtn).insertAfter(".by-rsvp").show();
            $(".by-legal-name").hide();
            !$(this).parent().hasClass("fieldErrors") && _this.tool_vlidate.hide();
        });
	
        _this.biz_LegalName.focus(function () {
			$('#special-offers').addClass('long');
            $("#special-offers>p.server_error,#rsvp-offers p.server_error").hide();/* feb a PIV */
            _this.rsvp_Code.parent().removeClass("fieldErrors");
            $(this).parent().next().children().show();
            $("." + _this.submitbtn).insertAfter(".by-legal-name").show();
            $(".by-rsvp").hide();
            !isHome ? (!$(this).parent().hasClass("fieldErrors") && _this.tool_vlidate.hide()) : (!$(this).parent().hasClass("fieldErrors") && _this.tool_vlidate.hide());
        });
        $(".secured-img").click(function () {
            if (!isHome) _this.securdtltip.css("display", "block");
            else $(this).next().hasClass('secured-tooltip') ? $(this).next().show() : $(this).parent().next().show();
        });
        $(".secured-tooltip .close").bind("click touch", function () {
            !isHome ? _this.securdtltip.css("display", "none") : $(this).parent().hide();
        })
		return this;
    },
    marketoCallForReporting: function(){
        /* Marketo changes start*/					 	
        var marketoData = {
                "rsvpCode":$(".mail-offer #rsvp-code").val(),
                "emailAddress":$(".mail-offer .by-rsvp #rsvp-email").val(),
                "zipCode":$(".mail-offer .by-rsvp #rsvp-zipcode").val()
            };
        var marketoAPIURL;
        if (typeof domainName !== "undefined") {
            marketoAPIURL=domainName+"/marketo-submission";
        } else {
            marketoAPIURL="../credit-cards/marketo-submission";
        }
        //Make asynchrounouse call and don't wait for response
        $.ajax({
                url: marketoAPIURL,
                dataType: "json",
                data:  JSON.stringify(marketoData),
                type: "POST",
                contentType: "application/json; charset=utf-8"						
        });					 
        /* Marketo changes end*/
    },
    validateEntries: function (a, ele) {
        isHome ? (this.srvrErr = ele.closest('form').find('.server_error')) : (this.srvrErr = $("#special-offers>p.server_error"));
        if (a.statusCode == 0) {
            a.url != "" ? $("#rsvp-offers").attr("action", a.url.toString()).submit() : $("#rsvp-offers").submit()
        } else {
            if (a.statusCode == 2) {
                this.disableRSVPForm()
            }
            this.srvrErr.show().html(UBA.fetchError(a.statusCode.toString()))
        }
		return this;
    },
	disableRSVPForm :function () {
    var d = $(".RSVP_CODE input");
    var f = $("#RSVP_SubmitBtn");
    var e = $(".RSVP_CODE .helpDiv");
    d.css("color", "#888").parent().removeClass("UAfieldError").find(".fld").hide().parent().find(".helpDiv").unbind().attr("disabled", "disabled");
    $(".RSVP_CODE input,#RSVP_SubmitBtn").attr("disabled", "disabled");
    f.css({
        opacity: 0.3
    });
    e.attr("disabled", "disabled");
    if ($.browser.msie && parseInt($.browser.version, 10) == 7) {
        e.attr("disabled", "disabled");
        f.css({
            opacity: 0.3,
            width: 72,
            "padding-left": 18,
            "margin-left": 162
        })
    }
    if ($.browser.msie && parseInt($.browser.version, 10) == 8) {
        $("#RSVP_SubmitBtn,#RSVP_SubmitBtn a").css({
            opacity: 0.3
        })
    }
	return this;
},
enableRSVPForm :function () {
    $(".RSVP_CODE input,#RSVP_SubmitBtn").removeAttr("disabled")
},
fetchRSVPZipcode:function(){$("#biz-zipcode").bind("keyup change", function (f) {
        if (this.value.length == 5 && !isNaN(this.value)) {
            $(".SearchByBiz").removeClass("zip");
            var a = "#biz-city";
            var e = "#biz-state";
            OPEN.CityStateLookup.get({
                str: this.value,
                city: a,
                state: e
            })
        }
    });
	return this;
	},
 fetchZipcode:function(){   $("#business-zipcode").bind("keyup change", function (f) {
        if (this.value.length == 5 && !isNaN(this.value)) {
            $(".SearchByBiz").removeClass("zip");
            var a = "#business-city";
            var e = "#business-state";
            OPEN.CityStateLookup.get({
                str: this.value,
                city: a,
                state: e
            })
        }
    });
	return this;
	},
 submitRSVPform:function(){
 $("#submit-btn-receive").click(function () {
		var _this=this;
        var t = $(this);
        isHome ? (_this.srvrErr = t.closest('form').find('.server_error')) : (_this.srvrErr = $('#special-offers>p.server_error'));
        var j = t.closest("form").attr("id");
        var e = OPEN.Validate.BusinessForm.validateForm(j);
        if (e) {
            var h = $(".privacy-statement").find("span").hasClass("checkbox-checked");
            if (!h) {
                _this.srvrErr.html("Please make sure you check the checkbox ").show();
                return false
            }
            if (j == "business-offers") {
                $("#" + j).submit()
            } else {
                if (j == "rsvp-offers") {
                    var i = {};
                    $("#rsvp-offers").find(":input, select").not("input[type=button]").not("input[type=checkbox]").each(function (k) {
                        i[$(this).attr("name")] = $(this).val()
                    });					                   									
                    $.ajax({
                        url: $("#rsvp-offers").attr("action"),
                        dataType: "json",
                        data: i,
                        type: "POST",
                        cache: false,
                        success: function (l) {
                            var k = l;
                            OPEN.findOffers.validateEntries(k.rsvpOffer, t);
                            //Make marekto call if RSVP code was valid
                            if (k.rsvpOffer.statusCode == 0) {
                                OPEN.findOffers.marketoCallForReporting();
                            }
                            OPEN.Overlay.hide()
                        },
                        error: function (k) {
                            _this.srvrErr.html("<p>" + k.responseText + "</p>");
                            return false
                        }
                    })
					
                }
            }
        } else {
            _this.srvrErr.html("Please make sure all required fields are complete and valid").show();
            return false
        }
    });
	return this;
	},
	pageResize:function(){ 
			if (this.tool_vlidate.is(":visible") && typeof (_overlayArr) != "undefined") {
				OPEN.Overlay.hide();
				OPEN.Overlay.show(_overlayArr[0], _overlayArr[1]);
			}
		return this;
		},
	pageLoad:function(){
		var offerFields = $("#special-offers input:text,#email-submit input[type='text'], #module-05 label.label-mask");
		$.each(offerFields, function (i, v) {
			$(v).val() == "" ? $(v).prev().show() : $(v).prev().hide();
		})
		$('#submit-btn-find').removeAttr('disabled');
		$(".specialoffers-cnt input").live("blur focus", function () {
			$(window).scroll();
		});
	},
	init:function(){
		UBA.init();
		this.validate().submitForm().special_Offer().fetchZipcode().fetchRSVPZipcode().submitRSVPform().pageLoad();
		
	}
};
OPEN.findOffers.init();