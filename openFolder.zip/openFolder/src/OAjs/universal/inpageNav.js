OPEN.universal.inpageNav={
/* Navigate to specific module on clicking of each item in Left side navigation panel */
	navigate:function(o){
		var navClick=0,_this=this;
		$("#ajnav .aj-inpage .in-page a").click(function(e, data){/*May release*//* junec */
		//var deeplink = window.location.hash, mtStr = "";
			//(deeplink.indexOf("-ajnav") != -1) && (mtStr = deeplink.replace(deeplink, deeplink.substr(0,deeplink.length-6)), window.location.hash = mtStr);
			navClick++;	
			
			//alert(data)
				/*tabs tracking iTag*/
				
				if($(this).parent().parent().hasClass("in-page"))
				{
				var htDrp = $(this).parent().parent().outerHeight()+5;
				$(this).parent().parent().css({top:-htDrp}).parent().css({height:0});
				}
				
				var itag_tabname=OPEN.universal.formatTabName($(this).text());
				//Apply layered tracking event only for home page.
                                //rmaction code for homepage specific--omniture
				if(isHome){				
					(typeof($iTagTracker)=='function' )? $iTagTracker('rmaction',itag_tabname + "_LeftNav") : null;
				}							
				data != "load" &&(navFlag = true);
				_this.scrollSec($(this).text().toLowerCase(),o);
				//$("#"+$(this).attr("class")).find("input,a").eq(0).focus();
				$("#ajnav .aj-inpage .in-page a").parent().removeClass("active");/* junec */
				$(this).parent().addClass("active");
				$("#"+$(this).text().toLowerCase().replace(" ", "-")).find(".view:first").addClass("bg");
				return false;
		}).focus(function(e) {$("#ajnav .aj-inpage .in-page a").parent().removeClass("active");$(this).parent().addClass("active");});/* junec */
			return this;
	},
	/* Animation effect for navigating to specific module on clicking of each item in Left side navigation panel */
	scrollSec:function(txt,o){
		/*11-01*/
		//var hhh=($(window).height()-Number($('#' + txt.toLowerCase().split(' ').join('-')).parents(".module").height()))/2;	

 
			var scrl_hgt= $('#' + txt.toLowerCase().split(' ').join('-')).parents(".module").hasClass("first-module")?Number($('#' + txt.toLowerCase().split(' ').join('-')).parents(".module").offset().top):Number($('#' + txt.toLowerCase().split(' ').join('-')).parents(".module").offset().top-$("#ajnav").height()+7);	
		$("html, body").animate({"scrollTop":scrl_hgt},function(){							
			
			setTimeout(function(){navFlag = false},600);
		});           

	},
	/* Highlighting(or)Enabling the specific navigation item in Left side navigation panel on scrolling the page(or)window */
	navigateSec:function(o){
		var crdSec = $("#wrapper").find(".module");
		$(crdSec).bind("touchstart",function(){navFlag = false});
		$(window).scroll(function(e){
			if(!navFlag)
			{
				if($(window).scrollTop()<743)
				{
					$("#ajnav .aj-inpage .in-page li").removeClass("active");/* junec */
					$("#ajnav .aj-inpage .in-page li:eq(0)").addClass("active");
				}
				crdSec.each(function (index, element) {
					/* April A implementation*/
				/* @param secPos gives module position
				   @param inpageOffset gives inpage navigation position
				   @param moduleId gives id of a module or a sub module
				   @param currentnav gives respective module's in page navigation link index
				   @param currentnavtop gives postion of the present module's inpage nav link w.r.t to navigation
				 */			
                    var secPos = $(".new-ajnav .aj-inpage .in-page").is(":visible")?$(element).offset().top-$(document).scrollTop():$(element).offset().top,
					
					moduleId=!$(element).find(".view-holder").attr("id") ?$(element).attr('id'):$(element).find(".view-holder").attr("id"),
					
					currentnavtop= $(".new-ajnav .aj-inpage .in-page").is(":visible")?$(window).height()/2:0;
					secPos < currentnavtop?($("#ajnav .aj-inpage .in-page a").parent().removeClass("active"),$("#"+moduleId).find(".view:first").addClass("bg"), $("#ajnav .aj-inpage .in-page a."+ moduleId + "").parent().addClass("active")):null;/* junec */
				});
			}
			
			/* live person tagging implementation : start*/
				var prevModuleId = null;
				var moduleId = $("#ajnav .aj-inpage .in-page li.active a").text().toLowerCase().split(' ').join('-');/* junec */
				if($("#"+moduleId).parent().hasClass("module"))
				{
					moduleId = $("#"+moduleId).parent().attr("id");
				}
				else
				{
					if($("#"+moduleId).hasClass("product-details"))
					{
						moduleId = $("#"+moduleId).attr("id");
					}
				}
				
				if(moduleId != prevModuleId)
				{	
					typeof(lpTag)!='undefined'?lpTag.vars.push([ {scope:"page",name:"carousel",value: moduleId}]):null;
					typeof(lpTag) =="object"  &&  typeof(lpTag.vars.send)=="function" && lpTag.vars.send();
					prevModuleId = moduleId;
				}
				
			/* live person tagging implementation : end*/
			
			
		});
		
		return this
	},
	pageReady:function(o){
		this.navigate().navigateSec();
	}

};
OPEN.universal.subModuleNavMap ={
		"receiptmatch": 
		{
			"anchorText":"<span class='rec-small'>receiptmatch<sup class='sm-sup'>sm</sup><span class='lowercase'> with </span></span><span>quickbooks<sub  class='reg'>&reg;</sub></span>", 
			"liClass":"nav-rp",
			"anchorTitle":"ReceiptMatch"
		},
		"open-benefits": 
		{
			"anchorText":"<span class='rec-small'>receiptmatch<sup class='sm-sup'>sm</sup><span class='lowercase'> with </span></span><span>quickbooks<sub class='reg'>&reg;</sub></span>", 
			"liClass":"nav-rp",
			"anchorTitle":"ReceiptMatch"
		},
		"details": 
		{
			"anchorText":"details", 
			"liClass":"",
			"anchorTitle":"Details"
		},
		"travel-benefits":
		{
			"anchorText":"travel", 
			"liClass":"",
			"anchorTitle":"Travel"
		},
		"service-benefits":
		{
			"anchorText":"benefits", 
			"liClass":"",
			"anchorTitle":"Benefits"
		},
		"rewards-benefits":
		{
			"anchorText":"rewards", 
			"liClass":"",
			"anchorTitle":"Rewards"
		},
		"paymentflexibility-benefits":
		{
			"anchorText":"payment flexibility", 
			"liClass":"nav-rp",
			"anchorTitle":"Flexible Payments"
		},
		"expense-benefits":
		{
			"anchorText":"Expense Management", 
			"liClass":"",
			"anchorTitle":"Expense Management"
		}		
		
	};

