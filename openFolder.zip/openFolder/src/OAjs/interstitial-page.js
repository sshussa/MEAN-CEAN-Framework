if (!window.COOKIE) {
    var COOKIE = {};
}
COOKIE.createCookie = function(name, value, days) {
    var expires;
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    }
    else expires = "";
    document.cookie = name + "=" + value + expires + "; path=/; secure";
	
}

COOKIE.readCookie = function(name) {
    var nameEQ = name + "=";	
    var ca = document.cookie.split(';');	
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];		
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) {		
		return c.substring(nameEQ.length, c.length);
		}
    }	
    return null;
}

COOKIE.eraseCookie = function(name) {
    COOKIE.createCookie(name, "", -1);
	
}

function invokeDestination(){				
	    document.getElementById("adobeForm").action= window.location.href;				
		document.getElementById("adobeForm").submit();			
}

COOKIE.areCookiesEnabled= function() {	
    var r = false;
    COOKIE.createCookie("validateCookie", "Hello", 1);
    if (COOKIE.readCookie("validateCookie") != null) {
        r = true;        
    }
	COOKIE.eraseCookie("validateCookie");
    if(r == false)
    {
    	window.location.href = "https://www.americanexpress.com";	
    }
	
}

COOKIE.areCookiesEnabled();