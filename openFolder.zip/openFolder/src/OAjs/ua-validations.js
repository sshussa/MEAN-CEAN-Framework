var qz_section = false;
var _overlayArr = [];
$.fn.getBox = function() {
    return {
        left: Math.round($(this).offset().left),
        top: Math.round($(this).offset().top),
        width: $(this).outerWidth(),
        height: $(this).outerHeight(),
        owidth: $(this).width(),
        oheight: $(this).height()
    }
};
$.fn.positionToElm = function(j, d) {
    var v = {
        t: 0,
        l: 0,
        c: 0.5,
        b: 1,
        r: 1,
        m: -1
    };
    var h = {
        anchor: ["tl", "tl"],
        fromParent: false,
        offset: [0, 0]
    };
    d = $.extend(h, d);
    var a = $(j).getBox();
    var c = $(this).getBox(true);
    var g = a.left;
    var b = a.top;
    b -= v[d.anchor[0].charAt(0)] * c.height;
    g -= v[d.anchor[0].charAt(1)] * c.width;
    b += v[d.anchor[1].charAt(0)] * a.height;
    g += v[d.anchor[1].charAt(1)] * a.width;
    g += d.offset[0];
    g = Math.abs(g);
    b += d.offset[1];
    if (d.fromParent) {
        var e = Math.round($(this).offsetParent().offset().left);
        var s = Math.round($(this).offsetParent().offset().top);
        g = (g - e);
        b = (b - s)
    }
    $(this).css({
        left: g + "px",
        top: b + "px"
    })
};
if (!window.OPEN) {
    var OPEN = {}
}
if (!window.OPEN.Validate) {
    OPEN.Validate = {}
}
if (!window.OPEN.ValidatorMaps) {
    OPEN.ValidatorMaps = {}
}
OPEN.Overlay = {
    wrapper: null,
    content: null,
    arrow: null,
    isVisible: false,
    init: function() {
        this.wrapper = $("#validateTipWrapper");
        this.content = $("#validateTipWrapper p");
        this.arrow = $("#validateTipWrapper .overlay_arrow");
        this.closebt = $("#validateTipWrapper .close");
        if ($(this.wrapper).length === 0) {
            return
        }
        var b = this;
        this.closebt.click(function() {
            b.hide();
            return false
        })
    },
    show: function(l, d, j, h) {
        if (this.isVisible) {
            return
        }
        if (!h) {
            h = 254
        }
        if (!j) {
            j = "centerTop"
        }
        this.wrapper.css("width", h + "px");
        this.setTipContent(l, d);
        this.alignArrow(j);
        var k = $(l).width();
        var g = $(l).height();
        if (j.indexOf("centerTop") != -1) {
            $(this.arrow).removeClass("right").removeClass("topCenter").removeClass("bottom").addClass("bottomCenter");
            this.wrapper.positionToElm(l, {
                anchor: ["bc", "lc"],
                offset: [0, -15]
            })
        } else {
            if (j.indexOf("centerBtm") != -1) {
                $(this.arrow).removeClass("right").removeClass("bottom").removeClass("left").removeClass("bottomCenter").addClass("topCenter");
                this.wrapper.positionToElm(l, {
                    anchor: ["tl", "bl"],
                    offset: [0, 15]
                })
            } else {
                if (j.indexOf("ltSide") != -1) {
                    $(this.arrow).removeClass("bottom").removeClass("left").addClass("right");
                    this.wrapper.positionToElm(l, {
                        anchor: ["cl", "cr"],
                        offset: [-273 - k, 0]
                    })
                } else {
                    if (j.indexOf("topSide") != -1) {
                        $(this.arrow).removeClass("right").removeClass("left").addClass("bottom");
                        if ($.browser.msie) {
                            if ($.browser.version < 7) {
                                this.wrapper.positionToElm(l, {
                                    anchor: ["bl", "br"],
                                    offset: [-200 - k, -33]
                                })
                            } else {
                                this.wrapper.positionToElm(l, {
                                    anchor: ["bl", "br"],
                                    offset: [-200 - k, -40]
                                })
                            }
                        } else {
                            this.wrapper.positionToElm(l, {
                                anchor: ["bl", "br"],
                                offset: [-200 - k, -35]
                            })
                        }
                    } else {
                        if (j.indexOf("rtSide") != -1) {
                            $(this.arrow).removeClass("right").removeClass("bottom").addClass("left");
                            if (($(".homeAddressSummary").css("display") == "inline-block")) {
                                if ($.browser.safari) {
                                    console.log("Rendering in a webkit browser home street address");
                                    this.wrapper.positionToElm(l, {
                                        anchor: ["cl", "cr"],
                                        offset: [28 - k, 5]
                                    })
                                } else {
                                    console.log("Rendering in a non-webkit browser home street address");
                                    this.wrapper.positionToElm(l, {
                                        anchor: ["cl", "cr"],
                                        offset: [28 - k, 33]
                                    })
                                }
                            } else {
                                console.log("For fields other than home street address");
                                this.wrapper.positionToElm(l, {
                                    anchor: ["cl", "cr"],
                                    offset: [28 - k, 20]
                                })
                            }
                        }
                    }
                }
            }
        }
        this.setTipContent("");
        this.setTipContent(d);
        this.wrapper.css("visibility", "visible").css("display", "block");
        this.isVisible = true
    },
    hide: function() {
        if (!this.isVisible) {
            return
        }
        this.wrapper.css("visibility", "hidden").css("display", "none");
        this.isVisible = false
    },
    alignArrow: function(g) {
        var h = this.wrapper.innerHeight();
        var j = this.arrow.height();
        var d = this.arrow.width();
        h = this.toInt((h / 2));
        j = this.toInt((j / 2));
        if (g.indexOf("centerTop") != -1) {
            this.arrow.css("top", "auto");
            this.arrow.css("bottom", -14 + "px")
        } else {
            if (g.indexOf("centerBtm") != -1) {
                this.arrow.css("top", "-14px")
            } else {
                if (g.indexOf("ltSide") != -1) {
                    this.arrow.css("left", d + 238 + "px");
                    this.arrow.css("top", h - j - 2 + "px");
                    this.arrow.css("bottom", "auto")
                } else {
                    if (g.indexOf("topSide") != -1) {
                        this.arrow.css("left", d + 195 + "px");
                        this.arrow.css("top", "auto");
                        if ($.browser.msie && $.browser.version < 9) {
                            if ($.browser.version < 7) {
                                this.arrow.css("bottom", -16 + "px")
                            }
                        } else {
                            this.arrow.css("bottom", -15 + "px")
                        }
                    } else {
                        if (g.indexOf("rtSide") != -1) {
                            this.arrow.css("left", d - 30 + "px");
                            this.arrow.css("top", h - j - 20 + "px");
                            this.arrow.css("bottom", "auto")
                        }
                    }
                }
            }
        }
    },
    setTipContent: function(l, b) {
        this.content.html(b);

        ($(l).attr('id') == 'quiz-email') ? ($("#module-05 .email-content .error_msg").html(b)) : null;
    },
    toInt: function(b) {
        return Math.floor(b)
    }
};
OPEN.formatSSN = function(a) {
    var b = a.split(".")[0];
    b = b.replace(/[-]/g, "");
    if (isNaN(b) || b.length != 9) {
        return a
    }
    b = parseFloat(b);
    if (!isNaN(b) && isFinite(b)) {
        var n = "",
            b = String(b),
            d = b.length - 1,
            o, e, p;
        for (e = 0; e <= d; e++) {
            n += o = b.charAt(e);
            if (d - e == 4) {
                n += "-"
            } else {
                if ((d - e) == 6) {
                    n += "-"
                }
            }
        }
        return (b = n)
    } else {
        return a
    }
};
OPEN.formatTaxid = function(a) {
    var b = a.split(".")[0];
    b = b.replace(/[-]/g, "");
    if (isNaN(b) || b.length != 9) {
        return a
    }
    b = parseFloat(b);
    if (!isNaN(b) && isFinite(b)) {
        var n = "",
            b = String(b),
            d = b.length - 1,
            o, e, p;
        for (e = 0; e <= d; e++) {
            n += o = b.charAt(e);
            if (d - e == 7) {
                n += "-"
            }
        }
        return (b = n)
    } else {
        return a
    }
};
OPEN.formatPhone = function(a) {
    var b = a.split(".")[0];
    b = b.replace(/[-]/g, "");
    if (isNaN(b) || b.length != 10) {
        return a
    }
    b = parseFloat(b);
    if (!isNaN(b) && isFinite(b)) {
        var n = "",
            b = String(b),
            d = b.length - 1,
            o, e, p;
        for (e = 0; e <= d; e++) {
            n += o = b.charAt(e);
            if (d - e == 4) {
                n += "-"
            } else {
                if ((d - e) % 3 == 1 && d - e > 5) {
                    n += "-"
                }
            }
        }
        return (b = n)
    } else {
        return a
    }
};
OPEN.Validator = function(e) {
    function b(c) {
        this.RuleMap = c || {}
    }
    b.prototype.validateForm = function(c) {
        c = document.getElementById(c);
        if (typeof c === "undefined" || c === null) {
            return false
        }
        var l = this;
        var k = true;
        var j = function(o) {
            o.value = l.trimAll(o.value);
            for (rule in l.RuleMap[fieldKey]) {
                var m = l.RuleMap[fieldKey][rule];
                m.field = o;
                var n = false;
                if (typeof m.validator !== "function") {
                    n = l[m.validator](o, m.args)
                } else {
                    n = m.validator.call(l, o, m.args)
                } if (n === false) {
                    l.onFormError(m);
                    k = false
                }
            }
            return false
        };
        for (fieldKey in this.RuleMap) {
            var g = this.getElement(c, fieldKey);
            if (g === null) {
                continue
            }
            if (g > 0) {
                for (var d = 0; d < g.length; d++) {
                    j(g[d])
                }
            } else {
                j(g)
            }
        }
        return k
    };
    b.prototype.validateField = function(l) {
        if (typeof l === "undefined" || l === null) {
            return false
        }
        var c = this.getNameOrID(l);
        if (c === null) {
            return false
        }
        var m = this.RuleMap[c];
        if (l.id != "userPassword") {
            var n = /^\s+|\s+$/g.test(l.value);
            if (n) {
                l.value = this.trimAll(l.value)
            }
        }
        for (rule in m) {
            var d = m[rule];
            d.field = l;
            var g = false;
            if (typeof d.validator !== "function") {
                g = this[d.validator](l, d.args)
            } else {
                g = d.validator.call(this, l, d.args)
            }
            g ? this.onFieldSuccess(d) : this.onFieldError(d);
            if (g) {
                continue
            } else {
                return false
            }
        }
        return true
    };
    b.prototype.email = function(c) {
        return /^[a-zA-Z0-9_\.\-]+\@([a-zA-Z0-9\-]+\.)+[a-zA-Z0-9]+$/i.test(c.value)
    };
    b.prototype.invalidemail = function(c) {
        return /^([0-9a-zA-Z"']+([_.-]?[0-9a-zA-Z]+)*@[0-9a-zA-Z'"]+[0-9,a-z,A-Z,.,-]*(\.){1}[a-zA-Z]{2,4})+$/i.test(c.value)
    };
    b.prototype.url = function(c) {
        return /^(((ht|f){1}(tp:[/][/]){1})|((www.){1}))[-a-zA-Z0-9:%_\+.,#?&//]+$/.test(c.value)
    };
    b.prototype.required = function(c) {
        switch (c.nodeName.toLowerCase()) {
            case "select":
                return c.selectedIndex !== 0 ? true : false;
            case "input":
                if (this.isCheckBox(c)) {
                    return c.checked ? true : false
                }
            default:
                return c.value.length >= 1 ? true : false
        }
    };
    b.prototype.validChars = function(c) {
        return /^[A-Za-z\-\s]*$/i.test(c.value)
    };
    b.prototype.validChar = function(g) {
        var c = g.value.substring(0, 1);
        var d = g.value.substring(1, g.value.length);
        var h = /^[A-Za-z]*$/i.test(c);
        if (h) {
            return /^[0-9]*$/i.test(d)
        } else {
            return /^[A-Za-z]*$/i.test(c)
        }
    };
    b.prototype.validSingleChar = function(d) {
        var c = d.value.substring(0, 1);
        return /^[A-Za-z0-9]*$/i.test(c)
    };
    b.prototype.emailvalidChars = function(c) {
        return /^[A-Za-z0-9@".-_-\s']*$/i.test(c.value)
    };
    b.prototype.cityValidChars = function(c) {
        return /^[A-Za-z0-9\s.-]*$/i.test(c.value)
    };
    b.prototype.emailvalidCharsAt = function(c) {
        var d = c.value.split("@").length - 1;
        if (d == 1) {
            return true
        } else {
            return false
        }
    };
    b.prototype.validCharsExt1 = function(c) {
        return /^[A-Za-z@&\-'\s]*$/i.test(c.value)
    };
    b.prototype.validCharsExt2 = function(c) {
        return /^[A-Za-z.,&\/\-'\s]*$/i.test(c.value)
    };
    b.prototype.validCharsExt3 = function(c) {
        return /^[[A-Za-z]+[A-Za-z.\-\s]*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNum = function(c) {
        return /^[A-Za-z0-9]*$/i.test(c.value)
    };
    b.prototype.SSNValidCharsAlphaNum = function(c) {
        return /^[0-9]*$/i.test(c.value)
    };
    b.prototype.validBizCharsAlphaNum = function(c) {
        return /^[A-Za-z0-9\s'@&-]*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNumExt = function(c) {
        return /^[A-Za-z0-9#&,\/\.\-\s]*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNumExt1 = function(c) {
        return /^[A-Za-z0-9#&,\/\.\-\:\_\s]*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNumExt2 = function(c) {
        return /^[A-Za-z0-9@&\-'\s]*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNumExt3 = function(c) {
        return /^[A-Za-z0-9\-\#\/]*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNumExt4 = function(c) {
        return /^(1{1}|3{1}|8{1}).*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNumExt5 = function(c) {
        return /^[A-Za-z0-9#?\s]*$/i.test(c.value)
    };
    b.prototype.validCharsAlphaNumExt6 = function(c) {
        return /^[^-'.,/&amp;$#%?@]*$/i.test(c.value)
    };
    var a = false;
    b.prototype.minLength = function(d, c) {
        return d.value.length >= c.len
    };
    b.prototype.maxLength = function(d, c) {
        return d.value.length <= c.len
    };
    b.prototype.exactLength = function(d, c) {
        return d.value.length == c.len
    };
    b.prototype.validNumbers = function(c) {
        return /^[0-9]*$/i.test(c.value)
    };
    b.prototype.excludeNumbers = function(c) {
        return /^[^0-9]*$/i.test(c.value)
    };
    b.prototype.validateYear = function(c) {
        return /^(189[0-9])|(19|20)[0-9]{2}$/.test(c.value)
    };
    b.prototype.validateMonth = function(c) {
        return /^0[1-9]|1[012]$/.test(c.value)
    }, b.prototype.validateDays = function(c) {
        return /^0[1-9]|[12][0-9]|3[01]$/.test(c.value)
    };
    b.prototype.validateDayMonth = function(c) {
        var d = /^04|06|09|11$/;
        if (c.m == 2) {
            return /^0[1-9]|[12][0-9]$/.test(c.d)
        } else {
            if (d.test(c.m)) {
                return /^0[1-9]|[12][0-9]|3[0]$/.test(c.d)
            } else {
                return /^0[1-9]|[12][0-9]|3[01]$/.test(c.d)
            }
        }
    };
    b.prototype.validateDayYear = function(c) {
        var d = /^02$/;
        if (d.test(c.m)) {
            if (this.isLeapYear(c.y)) {
                return /^0[1-9]|[12][0-9]$/.test(c.d)
            } else {
                return /^0[1-9]|1[0-9]|2[0-8]$/.test(c.d)
            }
        } else {
            return /^0[1-9]|[12][0-9]|3[01]$/.test(c.d)
        }
    };
    b.prototype.validateAgeRangeBasic = function(c, m) {
        var d = null;
        var k = new Date();
        if (c.y < 1000) {
            var o = 1000;
            k.setFullYear(o, c.m - 1, c.d)
        } else {
            k.setFullYear(c.y, c.m - 1, c.d)
        }
        var l = new Date();
        l.setFullYear(l.getFullYear() - m.lower);
        var n = new Date();
        n.setFullYear(n.getFullYear() - m.upper);
        if ((l - k) < 0) {
            return "underRangeLimit"
        } else {
            if ((n - k) > 0) {
                return "overRangeLimit"
            }
        }
    };
    b.prototype.socialSecurity = function(c) {
        if (c.value % 111111111 == 0 || c.value == 123456789) {
            return false
        } else {
            return true
        }
    };
    b.prototype.SSN1 = function(m) {
        var l = $("#supp1SSN1").val();
        var g = $("#supp1SSN2").val();
        var d = $("#supp1SSN3").val();
        var c = l + g + d;
        if (c % 111111111 == 0 || c == 123456789) {
            $("#supp1SSN1").addClass("fieldErrors");
            $("#supp1SSN2").addClass("fieldErrors");
            $("#supp1SSN3").addClass("fieldErrors");
            return false
        } else {
            $("#supp1SSN1").removeClass("fieldErrors");
            $("#supp1SSN2").removeClass("fieldErrors");
            $("#supp1SSN3").removeClass("fieldErrors");
            return true
        }
    };
    b.prototype.SSN2 = function(m) {
        var l = $("#supp2SSN1").val();
        var g = $("#supp2SSN2").val();
        var d = $("#supp2SSN3").val();
        var c = l + g + d;
        if (c % 111111111 == 0 || c == 123456789) {
            $("#supp2SSN1").addClass("fieldErrors");
            $("#supp2SSN2").addClass("fieldErrors");
            $("#supp1SSN3").addClass("fieldErrors");
            return false
        } else {
            $("#supp2SSN1").removeClass("fieldErrors");
            $("#supp2SSN2").removeClass("fieldErrors");
            $("#supp2SSN3").removeClass("fieldErrors");
            return true
        }
    };
    b.prototype.SSN3 = function(m) {
        var l = $("#supp3SSN1").val();
        var g = $("#supp3SSN2").val();
        var d = $("#supp3SSN3").val();
        var c = l + g + d;
        if (c % 111111111 == 0 || c == 123456789) {
            $("#supp3SSN1").addClass("fieldErrors");
            $("#supp3SSN2").addClass("fieldErrors");
            $("#supp3SSN3").addClass("fieldErrors");
            return false
        } else {
            $("#supp3SSN1").removeClass("fieldErrors");
            $("#supp3SSN2").removeClass("fieldErrors");
            $("#supp3SSN3").removeClass("fieldErrors");
            return true
        }
    };
    b.prototype.SSN4 = function(m) {
        var l = $("#supp4SSN1").val();
        var g = $("#supp4SSN2").val();
        var d = $("#supp4SSN3").val();
        var c = l + g + d;
        if (c % 111111111 == 0 || c == 123456789) {
            $("#supp4SSN1").addClass("fieldErrors");
            $("#supp4SSN2").addClass("fieldErrors");
            $("#supp4SSN3").addClass("fieldErrors");
            return false
        } else {
            $("#supp4SSN1").removeClass("fieldErrors");
            $("#supp4SSN2").removeClass("fieldErrors");
            $("#supp4SSN3").removeClass("fieldErrors");
            return true
        }
    };
    b.prototype.SSN5 = function(m) {
        var l = $("#supp5SSN1").val();
        var g = $("#supp5SSN2").val();
        var d = $("#supp5SSN3").val();
        var c = l + g + d;
        if (c % 111111111 == 0 || c == 123456789) {
            $("#supp5SSN1").addClass("fieldErrors");
            $("#supp5SSN2").addClass("fieldErrors");
            $("#supp5SSN3").addClass("fieldErrors");
            return false
        } else {
            $("#supp5SSN1").removeClass("fieldErrors");
            $("#supp5SSN2").removeClass("fieldErrors");
            $("#supp5SSN3").removeClass("fieldErrors");
            return true
        }
    };
    b.prototype.validateNoPoBox = function(h) {
        var d = "",
            o = false,
            g = ["POBOX", "P.O.BOX", "PO.BOX", "PO-BOX", "P.OBOX", "PBOX", "P/OBOX", "P-O-BOX", "PO/BOX", "POB", "POSTBOX", "PO BOX", "POSTOFFICEBOX"];
        for (var n = 0; n < h.value.length; n++) {
            if (h.value.charAt(n) != " ") {
                d += h.value.charAt(n)
            }
        }
        d = d.toUpperCase();
        for (var c = 0; c < g.length; c++) {
            if (d.indexOf(g[c]) != -1) {
                return false
            } else {
                o = true
            }
        }
        return o
    }, b.prototype.trimEnds = function(c) {
        if (!c) {
            return ""
        }
        c = c.replace(/^\s\s*/, "");
        ws = /\s/;
        i = c.length;
        while (ws.test(c.charAt(--i))) {}
        return c.slice(0, i + 1)
    };
    b.prototype.trimAll = function(d) {
        if (!d) {
            return ""
        }
        d = d.replace(/^\s\s*/, "");
        ws = /\s/;
        i = d.length;
        while (ws.test(d.charAt(--i))) {}
        var c = d.slice(0, i + 1);
        return c.replace(/\s+/, " ")
    };
    b.prototype.getElement = function(c, d) {
        return c.elements[d] ? c.elements[d] : null
    };
    b.prototype.getNameOrID = function(c) {
        return c.getAttribute("name") ? c.getAttribute("name") : c.getAttribute("id") ? c.getAttribute("id") : null
    };
    b.prototype.isCheckBox = function(c) {
        return /checkbox/i.test(c.type)
    };
    b.prototype.getLength = function(c, d) {
        switch (d.nodeName.toLowerCase()) {
            case "select":
                return $("option:selected", d).length;
            case "input":
                if (this.isCheckBox(d)) {
                    return $('"#' + d.id + '"').filter(":checked").length
                }
        }
        return c.length
    };
    b.prototype.isLeapYear = function(d) {
        var c = (+d);
        return (c % 400 == 0) || ((c % 4 == 0) && (c % 100 != 0)) ? true : false
    };
    b.prototype.checkBoxHasError = function(d, c) {
        c === true ? d.parent().addClass("fieldErrors") : d.parent().removeClass("fieldErrors")
    };
    b.prototype.fixOldIE = function(d, c) {
        if ($.browser.msie && $.browser.version <= 7) {
            if (d.is("select")) {
                if (d.hasClass("fieldErrorsIESelect")) {
                    d.removeClass("fieldErrorsIESelect")
                } else {
                    if (c) {
                        d.addClass("fieldErrorsIESelect")
                    }
                }
            }
        }
    };
    b.prototype.onFieldSuccess = function(d) {
        this.Overlay.hide();
        var c = $(d.field);
        if (this.isCheckBox(c[0])) {
            this.checkBoxHasError(c, false)
        } else {
            if (c.parent().hasClass("fieldErrors")) {
                c.parent().removeClass("fieldErrors")
            }
        }
        this.fixOldIE(c, false);
        return true
    };
    b.prototype.onFieldError = function(d) {
        var c = $(d.field);
        if (this.Overlay.isVisible) {}
        this.fixOldIE(c, true);
        if (d.field.value.length !== 0 || (d.field.value.length == 0 && c.parent().hasClass("fieldErrors"))) {
            this.Overlay.show(d.field, d.msg);
            _overlayArr = [];
            _overlayArr.push(d.field);
            _overlayArr.push(d.msg)
        }
        if (this.isCheckBox(c[0])) {
            this.checkBoxHasError(c, true)
        } else {
            if ($(d.field).is("select")) {
                f = $(d.field).parent().parent();
                f.addClass("fieldErrors")
            } else {
                /************* Samsung s3 Fix**************/
                if (qz_section) {

                    (!OPEN.homePage.quiz.touch_dev || !navigator.userAgent.match(/Android/i)) && (c.parent().addClass("fieldErrors"));
                    (OPEN.homePage.quiz.errmsg_cnt >= 2 && navigator.userAgent.match(/Android/i)) && (c.parent().addClass("fieldErrors"));

                } else {
                    c.parent().addClass("fieldErrors")
                }
                /************* Samsung s3 Fix**************/
            }
        }
        return false
    };
    b.prototype.onFormSuccess = function(g) {
        for (var d = g.elements.length; d--;) {
            var c = $(g.elements[d]).parent();
            if ($(g.elements[d]).is("select")) {
                c = $(d.field).parent().parent()
            }
            c.removeClass("fieldErrors");
            if (this.isCheckBox(c)) {
                this.checkBoxHasError(c, false)
            }
            this.fixOldIE(c, false)
        }
        $(".warning-area").addClass("noshow");
        return true
    };
    b.prototype.onFormError = function(c) {
        var d = $(c.field);
        if ($(c.field).is("select")) {
            d = $(c.field).parent();
        }
        d.removeClass("hglt").parent().addClass("fieldErrors");
        if (this.isCheckBox(d[0])) {
            this.checkBoxHasError(d, true)
        }
        this.fixOldIE(d, true);
        return false
    };
    return new b(e)
};
OPEN.ValidatorMaps.RuleMapBusiness = {
    uaBusinessName: {
        rulel: {
            validator: "required",
            msg: "Your Business Name is required to find your offers."
        },
        rule2: {
            validator: function(a) {
                if (a.value.length > 0) {
                    return this.validSingleChar(a)
                }
                return true
            },
            msg: "The first character in your Business Name must be a letter or number."
        },
        rule3: {
            validator: "validBizCharsAlphaNum",
            msg: "Your Business Name can only contain the special characters '@& and -"
        },
        rule4: {
            validator: "minLength",
            args: {
                len: 1
            },
            msg: "Your Legal Business Name is required to process the application"
        },
        rule5: {
            validator: "maxLength",
            args: {
                len: 30
            },
            msg: "Your Legal Business Name cannot exceed 30 characters"
        }
    },
    businessSuite: {
        rule1: {
            validator: function(b) {
                return /[\s]/i.test(b.value) ? false : true
            },
            msg: "Your Company Suite Number  should not contain any spaces"
        },
        rule2: {
            validator: "validCharsAlphaNumExt3",
            msg: "Your Company Suite cannot contain special characters other than -/#"
        },
        rule3: {
            validator: "maxLength",
            args: {
                len: 15
            },
            msg: "Your Company Suite value should not exceed 15 characters"
        }
    },
    CardAccountNumber1: {
        rulel: {
            validator: "required",
            msg: "Please enter your Card Account Number."
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Card Account Number can only contain numbers."
        },
        rule3: {
            validator: "exactLength",
            args: {
                len: 4
            },
            msg: "Your Card Account Number cannot have less than 15 digits."
        },
        rule4: {
            validator: "validCharsAlphaNum",
            msg: "Card Account Number is invalid"
        },
        rule5: {
            validator: "maxLength",
            args: {
                len: 4
            },
            msg: "Your Card Account Number must contain 4 digits"
        }
    },
    CardAccountNumber2: {
        rulel: {
            validator: "required",
            msg: "Please enter Card Account Number"
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Card Account Number should contain only numbers"
        },
        rule3: {
            validator: "exactLength",
            args: {
                len: 6
            },
            msg: "Your Card Account Number cannot have less than 15 digits"
        },
        rule4: {
            validator: "validCharsAlphaNum",
            msg: "Card Account Number is invalid"
        },
        rule5: {
            validator: "maxLength",
            args: {
                len: 6
            },
            msg: "Your Card Account Number # must contain 6 digits"
        }
    },
    CardAccountNumber3: {
        rulel: {
            validator: "required",
            msg: "Please enter Card Account Number"
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Card Account Number should contain only numbers"
        },
        rule3: {
            validator: "exactLength",
            args: {
                len: 5
            },
            msg: "Your Card Account Number  cannot have less than 15 digits"
        },
        rule4: {
            validator: "validCharsAlphaNum",
            msg: "Card Account Number is invalid"
        },
        rule5: {
            validator: "maxLength",
            args: {
                len: 5
            },
            msg: "Your Card Account Number # must contain 5 digits"
        }
    },
    businessNameOnCard3: {
        rulel: {
            validator: "required",
            msg: "Your Business Name on Card is required to process the application"
        },
        rule2: {
            validator: function(a) {
                if (a.value.length > 0) {
                    return this.validChar(a)
                }
                return true
            },
            msg: "The first character in your Business Name on Card must be a letter"
        },
        rule3: {
            validator: function(a) {
                var c = $("input[name='businessName']").val();
                c = c.toLowerCase();
                var b = a.value.toLowerCase();
                if (c === b) {
                    return true
                } else {
                    return this.validCharsAlphaNumExt2(a)
                }
            },
            msg: "Your Business Name on Card cannot contain special characters other than '@&-"
        },
        rule4: {
            validator: "minLength",
            args: {
                len: 1
            },
            msg: "Your Business Name on Card is required to process the application"
        },
        rule5: {
            validator: "maxLength",
            args: {
                len: 20
            },
            msg: "Your Business Name on Card cannot exceed 20 characters. Please shorten or change the name if necessary"
        }
    },
    doingBusinessAs: {
        rule1: {
            validator: function(a) {
                if (a.value.length > 0) {
                    return this.validChar(a)
                }
                return true
            },
            msg: "The first character in your Doing Business As must be a letter"
        },
        rule2: {
            validator: "validCharsAlphaNumExt2",
            msg: "Your Doing Business As cannot contain special characters other than '@&-"
        },
        rule3: {
            validator: "minLength",
            args: {
                len: 0
            },
            msg: "Your Doing Business As is required to process the application"
        },
        rule4: {
            validator: "maxLength",
            args: {
                len: 30
            },
            msg: "Your Doing Business As cannot exceed 30 characters"
        }
    },
    uaBusinessAddress: {
        rulel: {
            validator: "required",
            msg: "Your Street Address is required to find your offers."
        },
        rule2: {
            validator: "validCharsAlphaNumExt",
            msg: "Your Street Address can only contain the special characters #, &, / and -."
        },
        rule3: {
            validator: "minLength",
            args: {
                len: 2
            },
            msg: "Your Street Address must contain at least 2 characters."
        },
        rule4: {
            validator: "maxLength",
            args: {
                len: 40
            },
            msg: "Your Street Address cannot exceed 20 characters. Please use abbreviations"
        },
        rule5: {
            validator: "validateNoPoBox",
            msg: "Your Street Address cannot contain a PO Box"
        }
    },
    businessStreetAddress: {
        rulel: {
            validator: "required",
            msg: "Your Street Address is required to find your offers."
        },
        rule2: {
            validator: "validCharsAlphaNumExt",
            msg: "Your Street Address can only contain the special characters #, &, / and -."
        },
        rule3: {
            validator: "minLength",
            args: {
                len: 2
            },
            msg: "Your Street Address must contain at least 2 characters."
        },
        rule4: {
            validator: "maxLength",
            args: {
                len: 40
            },
            msg: "Your Street Address cannot exceed 20 characters. Please use abbreviations"
        },
        rule5: {
            validator: "validateNoPoBox",
            msg: "Your Street Address cannot contain a PO Box"
        }
    },
    rsvpCode: {
        rulel: {
            validator: "required",
            msg: "Your RSVP Code is required to find your offers."
        },
        rule2: {
            validator: function(a) {
                if (a.value.length > 0) {
                    return this.validChar(a)
                }
                return true
            },
            msg: "Your RSVP code should begin with a letter and only contain letters and numbers."
        },
        rule3: {
            validator: "minLength",
            args: {
                len: 14
            },
            msg: "Your RSVP Code must contain 14 characters."
        },
        rule4: {
            validator: "maxLength",
            args: {
                len: 14
            },
            msg: "Your RSVP Code cannot exceed 14 characters"
        }
    },
    userID: {
        rulel: {
            validator: "required",
            msg: "Your User ID is required to find your offers."
        },
        rule2: {
            validator: function(a) {
                return /^[A-Za-z0-9\s'@&-]*$/i.test(a.value)
            },
            msg: "This field contains invalid characters."
        },
        rule3: {
            validator: "maxLength",
            args: {
                len: 30
            },
            msg: "Your User ID cannot exceed 30 characters"
        }
    },
    password: {
        rulel: {
            validator: "required",
            msg: "Your password is required to find your offers."
        },
        rule2: {

            validator: function(a) {
                return /[\s]/i.test(a.value) ? false : true
            },
            msg: "Your password cannot contain spaces."
        },
        rule3: {
            validator: "maxLength",
            args: {
                len: 20
            },
            msg: "Your password cannot exceed 20 characters"
        }
    },
    socialSecurity: {
        rulel: {
            validator: "required",
            msg: "Your SSN is required to find your offers."
        },
        rule2: {
            validator: "SSNValidCharsAlphaNum",
            msg: "The last 4 digits of your SSN must be numbers."
        },
        rule3: {
            validator: "validNumbers",
            msg: "Your SSN cannot contain all zeros."
        },
        rule4: {
            validator: "minLength",
            args: {
                len: 4
            },
            msg: "Your SSN must contain at least 4 digits."
        },
        rule5: {
            validator: "socialSecurity",
            msg: "Your SSN cannot contain all zeros."
        }
    },
    CID: {
        rulel: {
            validator: "required",
            msg: "Your Card Identification Number is required to find your offers."
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Card Identification Number can only contain numbers."
        },
        rule3: {
            validator: "minLength",
            args: {
                len: 4
            },
            msg: "Your Card Identification Number must contain at least 4 digits."
        }
    },
    UAZip: {
        rulel: {
            validator: "required",
            msg: "Your Zip Code is required to find your offers."
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Zip Code should only contain digits."
        },
        rule3: {
            validator: "maxLength",
            args: {
                len: 5
            },
            msg: "Your Zip Code cannot exceed five (5) digits"
        },
        rule4: {
            validator: "exactLength",
            args: {
                len: 5
            },
            msg: "Your Zip Code must contain five digits."
        }
    },
    zipCode: {
        rulel: {
            validator: "required",
            msg: "Your Zip Code is required to find your offers."
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Zip Code should only contain digits."
        },
        rule3: {
            validator: "maxLength",
            args: {
                len: 5
            },
            msg: "Your Zip Code cannot exceed five (5) digits"
        },
        rule4: {
            validator: "exactLength",
            args: {
                len: 5
            },
            msg: "Your Zip Code must contain five digits."
        }
    },
    businessZip: {
        rulel: {
            validator: "required",
            msg: "Your Zip Code is required to find your offers."
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Zip Code should only contain digits."
        },
        rule3: {
            validator: "maxLength",
            args: {
                len: 5
            },
            msg: "Your Zip Code cannot exceed five (5) digits"
        },
        rule4: {
            validator: "exactLength",
            args: {
                len: 5
            },
            msg: "Your Zip Code must contain five digits."
        }
    },
    UAcity: {
        rulel: {
            validator: "required",
            msg: "Your City is required to find your offers."
        },
        rule2: {
            validator: "cityValidChars",
            msg: "Your City can only contain the special character - (dash)."
        },
        rule3: {
            validator: function(a) {
                return /[0-9]/i.test(a.value) ? false : true
            },
            msg: "Your City cannot contain any digits."
        },
        rule4: {
            validator: "minLength",
            args: {
                len: 1
            },
            msg: "Your City is required to process the application"
        },
        rule5: {
            validator: "maxLength",
            args: {
                len: 20
            },
            msg: "Your Business City cannot exceed 20 characters"
        }
    },
    businessCity: {
        rulel: {
            validator: "required",
            msg: "Your City is required to find your offers."
        },
        rule2: {
            validator: "cityValidChars",
            msg: "Your City can only contain the special character - (dash)."
        },
        rule3: {
            validator: function(a) {
                return /[0-9]/i.test(a.value) ? false : true
            },
            msg: "Your City cannot contain any digits."
        },
        rule4: {
            validator: "minLength",
            args: {
                len: 1
            },
            msg: "Your City is required to process the application"
        },
        rule5: {
            validator: "maxLength",
            args: {
                len: 20
            },
            msg: "Your Business City cannot exceed 20 characters"
        }
    },
    UAState: {
        rulel: {
            validator: "required",
            msg: "Your State is required to find your offers."
        }
    },
    businessState: {
        rulel: {
            validator: "required",
            msg: "Your State is required to find your offers."
        }
    },
    companyPhone1: {
        rulel: {
            validator: "required",
            msg: "Your Business Phone Number is required to process the application"
        },
        rule2: {
            validator: function(b) {
                var c = OPEN.formatPhone(b.value);
                return /^\d{3}([\- ])\d{3}([\- ])\d{4}$/.test(c)
            },
            msg: "Your phone number should be of 10 digits."
        }
    },
    companyPhone2: {
        rulel: {
            validator: "required",
            msg: "Your Business Phone Number is required to process the application"
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Business Phone Number should only contain numbers"
        },
        rule3: {
            validator: "exactLength",
            args: {
                len: 3
            },
            msg: "Your Business Phone Number must be ten (10) digits"
        }
    },
    companyPhone3: {
        rulel: {
            validator: "required",
            msg: "Your Business Phone Number is required to process the application"
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Business Phone Number should only contain numbers"
        },
        rule3: {
            validator: "exactLength",
            args: {
                len: 4
            },
            msg: "Your Business Phone Number must be ten (10) digits"
        }
    },
    email: {
        rulel: {
            validator: "required",
            msg: "Your E-mail Address is required to find your offers."
        },
        rule2: {
            validator: function(a) {
                return /[\s]/i.test(a.value) ? false : true
            },
            msg: "Your E-mail address cannot contain any spaces"
        },
        rule3: {
            validator: "emailvalidChars",
            msg: "Please enter a valid E-mail Address."
        },
        rule4: {
            validator: function(a) {
                return !/@/i.test(a.value) ? false : true
            },
            msg: "Please enter a valid E-mail Address."
        },
        rule5: {
            validator: "emailvalidCharsAt",
            msg: "Your E-mail address can only contain one @ symbol"
        },
        rule6: {
            validator: function(a) {
                return !/\./i.test(a.value) ? false : true
            },
            msg: "Please enter a valid E-mail Address."
        },
        rule7: {
            validator: "invalidemail",
            msg: "Please enter a valid E-mail Address."
        }
    },
    emailAddress: {
        rulel: {
            validator: "required",
            msg: "Your E-mail Address is required to find your offers."
        },
        rule2: {
            validator: function(a) {
                return /[\s]/i.test(a.value) ? false : true
            },
            msg: "Your E-mail address cannot contain any spaces"
        },
        rule3: {
            validator: "emailvalidChars",
            msg: "Please enter a valid E-mail Address."
        },
        rule4: {
            validator: function(a) {
                return !/@/i.test(a.value) ? false : true
            },
            msg: "Please enter a valid E-mail Address."
        },
        rule5: {
            validator: "emailvalidCharsAt",
            msg: "Your E-mail address can only contain one @ symbol"
        },
        rule6: {
            validator: function(a) {
                return !/\./i.test(a.value) ? false : true
            },
            msg: "Please enter a valid E-mail Address."
        },
        rule7: {
            validator: "invalidemail",
            msg: "Please enter a valid E-mail Address."
        }
    },
    quizmail: {
        rulel: {
            validator: "required",
            msg: "Your email address is required"
        },
        rule2: {
            validator: function(a) {
                return /[\s]/i.test(a.value) ? false : true
            },
            msg: "Your email address cannot contain any spaces"
        },
        rule3: {
            validator: "emailvalidChars",
            msg: "Please enter a valid email address."
        },
        rule4: {
            validator: function(a) {
                return !/@/i.test(a.value) ? false : true
            },
            msg: "Please enter a valid email address."
        },
        rule5: {
            validator: "emailvalidCharsAt",
            msg: "Your E-mail address can only contain one @ symbol"
        },
        rule6: {
            validator: function(a) {
                return !/\./i.test(a.value) ? false : true
            },
            msg: "Please enter a valid email address."
        },
        rule7: {
            validator: "invalidemail",
            msg: "Please enter a valid email address."
        },
        rule8: {
            validator: "email",
            msg: "Please enter a valid email address."
        }
    },
    typeofIndustry: {
        rulel: {
            validator: "required",
            msg: "Your Type of Business is required to process the application"
        }
    },
    legalStructure: {
        rulel: {
            validator: "required",
            msg: "Your Company Structure is required to process the application"
        }
    },
    roleInCompany: {},
    annualBusinessRevenue: {
        rulel: {
            validator: "required",
            msg: "Your Annual Business Revenue is required to process the application"
        }
    },
    yearsinOperation: {
        rulel: {
            validator: "required",
            msg: "Your Years In Business is required to process the application"
        }
    },
    numberofEmployees: {
        rulel: {
            validator: "required",
            msg: "Your Number of Employees is required to process the application"
        },
        rule2: {
            validator: "validNumbers",
            msg: "Your Number of Employees should only contain numbers"
        },
        rule3: {
            validator: "maxLength",
            args: {
                len: 3
            },
            msg: "Your Number of Employees must be between 1 and 999"
        },
        rule4: {
            validator: function(a) {
                return /^([1-9]|[1-9][0-9]|[1-9][0-9][0-9])$/.test(a.value)
            },
            msg: "Your Number of Employees must be between 1 and 999"
        }
    },
    tin1: {
        rule1: {
            validator: function(b) {
                var a = $("select[name='legalStructure']");
                if (a.length > 0 && $(a).attr("selectedIndex") != 3) {
                    if (!this.required(b)) {
                        this.RuleMap.tin1.rule1.msg = "Your Federal Tax ID is required to process the application";
                        return false
                    }
                }
                return true
            },
            msg: "Your Federal Tax ID is required to process the application"
        },
        rule2: {
            validator: function(b) {
                var c = OPEN.formatTaxid(b.value);
                return /^\d{2}([\- ])\d{7}$/.test(c)
            },
            msg: "Your phone number is invalid format(xx-xxxxxxx)."
        }
    },
    tin2: {
        rule1: {
            validator: function(c) {
                var d = $("select[name='legalStructure']");
                if (d.length > 0 && $(d).attr("selectedIndex") != 3) {
                    if (!this.required(c)) {
                        this.RuleMap.tin2.rule1.msg = "Your Federal Tax ID is required to process the application";
                        return false
                    }
                }
                if (!this.validNumbers(c)) {
                    this.RuleMap.tin2.rule1.msg = "Your Federal Tax ID should only contain numbers";
                    return false
                }
                if ($("#tin2").val().length > 0) {
                    if (!this.exactLength(c, {
                        len: 7
                    })) {
                        this.RuleMap.tin2.rule1.msg = " Your Federal Tax ID must contain nine (9) digits";
                        return false
                    }
                }
                return true
            },
            msg: "Your Federal Tax ID is required to process the application"
        }
    },
    estimatedMonthlySpend: {
        rule1: {
            validator: function(a) {
                if (a.value.length > 0) {
                    return /^\$?[0-9,]*[0-9]$/.test(a.value)
                } else {
                    return true
                }
            },
            msg: "Your Estimated Monthly Spend should only contain numbers"
        }
    },
    businessWebsiteURL: {
        rule1: {
            validator: "validCharsAlphaNumExt1",
            msg: "Your Business Website URL must be in the format 'www.americanexpress.com' and cannot contain characters other than letters, numbers, and .,/:-_#&"
        },
        rule2: {
            validator: "maxLength",
            args: {
                len: 40
            },
            msg: "Your Business Website URL cannot exceed 40 characters"
        }
    }
};
OPEN.Validate.BusinessForm = OPEN.Validator(OPEN.ValidatorMaps.RuleMapBusiness);
OPEN.Validate.BusinessForm.Overlay = OPEN.Overlay;