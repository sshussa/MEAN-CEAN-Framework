/*
 systemInfo is set of methods for capturing system details.
 */
//    var pDataCollectionStatus = true;
//    var pDataUrl = '\URL';
var systemInfo = ((function (doc, wnd) {
    'use strict';
    var Capture = function () {
        this.viewportHeight = 0;
        this.viewportWidth = 0;
        this.windowHeight = 0;
        this.windowWidth = 0;
    };
    /*
     * following method capture viewport details.
     */
    Capture.prototype.viewport = function () {
        if (doc.compatMode === 'BackCompat') {
            this.viewportHeight = doc.body.clientHeight;
            this.viewportWidth = doc.body.clientWidth;
            return;
        }
        this.viewportHeight = doc.documentElement.clientHeight;
        this.viewportWidth = doc.documentElement.clientWidth;
    };
    /*
     * following method capture window details.
     */
    Capture.prototype.screen = function () {
        this.windowWidth = wnd.screen.width;
        this.windowHeight = wnd.screen.height;
    };
    /*
     * following method return object with viewport&window details.
     */
    Capture.prototype.fetch = function () {
        return (this.viewport(), this.screen(), {
            'windowWidth': this.windowWidth,
            'windowHeight': this.windowHeight,
            'viewportWidth': this.viewportWidth,
            'viewportHeight': this.viewportHeight
        });
    };
    /*
     * following method return compatible ajax object.
     */
    Capture.prototype.ajax = function () {
        if (typeof XMLHttpRequest !== 'undefined') {
            return new XMLHttpRequest();
        }
        var versions = ['MSXML2.XmlHttp.6.0', 'MSXML2.XmlHttp.5.0', 'MSXML2.XmlHttp.4.0', 'MSXML2.XmlHttp.3.0', 'MSXML2.XmlHttp.2.0', 'Microsoft.XmlHttp'];
        var xhr;
        for (var i = 0; i < versions.length; i++) {
            try {
                xhr = new ActiveXObject(versions[i]);
                break;
            } catch (e) {
            }
        }
        return xhr;
    };
    /*
     * following method send the system details to the specified URL through
     * AJAX.
     */
    return {'send': function (url, callback, async) {
            if (async === undefined) {
                async = true;
            }
            var capture = new Capture();
            var ajaxObj = capture.ajax();
            ajaxObj.withCredentials = true;
            ajaxObj.open('POST', url, async);
            ajaxObj.onreadystatechange = function () {
                if (ajaxObj.readyState === 4) {
                    callback(ajaxObj.responseText);
                }
            };
            ajaxObj.setRequestHeader('Content-type', 'application/json');
            ajaxObj.send(JSON.stringify(capture.fetch()));
        }};

})(document, window));
/*
 * following method reuturn compatible event object.
 */
var addEvent = function (element, eventName, fn) {
    if (element.addEventListener) {
        element.addEventListener(eventName, fn, false);
    } else if (element.attachEvent) {
        element.attachEvent('on' + eventName, fn);
    }
};

/*
 * following method trigger the process of sending system details to server.
 */
addEvent(window, 'load', function () {
    if (typeof pDataCollectionStatus !== 'undefined' && pDataCollectionStatus &&
            typeof pDataUrl !== 'undefined' && pDataUrl) {
        systemInfo.send(pDataUrl, function () {}, true);
    }
});
