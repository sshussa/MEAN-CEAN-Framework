if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.benefits) {
    OPEN.productPage.benefits = {};
}

OPEN.productPage.benefits.trimDescription = function () {
    if ($(window).width() < 661) {
        $(".benefits p.content-description").each(function () {
            $(this).text($.trim($(this).text()))
        })
    }
};


OPEN.productPage.benefits.addClickAndTouchEventToAccordionHeader = function () {
    $("#accordion > li").live("click touch", function (e) {

        if ($(window).width() < 661) {

            if ($(this).find(".content").css("display") == "block" || $(this).find(".content").css("display") == "") {
                $(this).removeClass("activeFlag");
                $(this).hasClass("expense-benefits") && $(".em-bg-rptr").removeClass("mob-rptr").slideUp("slow");
                $(this).find(".content").slideUp("slow");
                $(this).find("span.indicator").removeClass("down-arrow-icon").addClass("right-arrow-icon"); /*MAY A*/

                return false;
            }
            else {
                $(this).addClass("activeFlag");
                $(this).hasClass("expense-benefits") && ($(".open.res_Small .em-slides .slide-cont .custom-scrollbar .scrollbar").hide(), $(".em-bg-rptr").slideDown("slow", function () { /* !!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/) && $('.open.res_Small .em-slide .viewport').css({height: 215}); */
                    $(".em-bg-rptr").addClass("mob-rptr");
                    OPEN.productPage.ratingsReviews.customCarousel.setOnResize();
                    $(".open.res_Small .em-slides .slide-cont .custom-scrollbar .scrollbar").show();
                    setTimeout(function () {
                        OPEN.productPage.ratingsReviews.customCarousel.setOnResize();
                    }, 400);
                }));
                $(this).find(".content").slideDown("slow", function () {
                    $(this).closest("li").hasClass("card-review") && OPEN.productPage.ratingsReviews.customCarousel.setOnResize(); /*MAY A*/
                });
                $(this).hasClass("expense-benefits") && ($("#expense-management").css("margin-left", ($("#expense-benefits").width() - $("#expense-management").outerWidth()) / 2), OPEN.productPage.alignArrows());
                $(this).find("span.indicator").removeClass("right-arrow-icon").addClass("down-arrow-icon"); /*MAY A*/

                return false;
            }

        }
    });
};
OPEN.productPage.benefits.addClickAndTouchEventToAccordionContent = function () {
    $("#accordion > li div.content ").live("click touch", function (r) {
        r.stopPropagation()
    });
};
