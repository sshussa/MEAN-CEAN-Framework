var container = $("#wrapper");
var module = ".isNav";
var _navFlag = false;
var pixelRatio = !!window.devicePixelRatio ? window.devicePixelRatio : 1;
var isIpad2 = (navigator.userAgent.match(/iPad/i) != null && pixelRatio < 2 && parseInt("" + navigator.userAgent.charAt(navigator.userAgent.indexOf("OS ") + 3)) < 5) ? true : false;
var title = document.title;
var pagetitle = title.substr(0, title.length - 23).replace(/ /g, "");
var navliHt = []; /* Aprila */
var ios7 = (navigator.userAgent.match(/.*CPU.*OS 7_\d/i) != null);
var _bkpt = ($(window).width() > 830 ? 831 : ($(window).width() > 660 ? 661 : 320)); // 11A for R&R module
var resz_cnt = 0;
var vdoLayer = null;
var ovr_cls = "list-overlay";
var view_hld = ".view-holder";
var _overH = $("#offer-overview").outerHeight(true); /*aprilb*/
var em_slds = $(".em-slides");

//Add logic on document ready
$(document).ready(function () {

    //Set the footer location
    OPEN.productPage.footer.setFooterPosition();
    //Check for iPhone
    OPEN.universal.isIphone();
    //Set IE CSS class in body tag if needed
    OPEN.productPage.addIECssClassInBody(navigator);
    //Trim the benefits description
    OPEN.productPage.benefits.trimDescription();
    //set large medium specific css class 
    OPEN.productPage.large_medium($(window).width());
    //Add wraper class for safari in page nav
    OPEN.productPage.addWrapClassForSafari(navigator);
    //Set class for pzn special offer
    OPEN.productPage.offer.addClassForSplOffer();
    //Set class for large desktop
    OPEN.productPage.large($(window).width());
    //Set touch event for card review
    OPEN.productPage.ratingsReviews.setTouchstartEvent();
    //set the mvt setting
    OPEN.mvt({"pos1": "#mvt-cntr1", "pos2": "#mvt-cntr2", "pos3": "#mvt-cntr3"});
    //Add click event to inner anchor
    OPEN.productPage.addClickEventToInnerAnchor();
    //Get bodyClass as per current state. This will be matched
    bodyClass = $('body').attr('class'); // 11A for fixing tab issue 
    //Add add review event 
    OPEN.productPage.addEventForAddReview(pagetitle);
    //Set imaginary product page prev action event 
    OPEN.productPage.overview.setPrevActionEvent(pagetitle);
    //Set imaginary product page next action event 
    OPEN.productPage.overview.setNextActionEvent(pagetitle);
    //Add event for footer
    OPEN.productPage.footer.addShareamexContainerEvent();
    //Ovveride in-page nav build logic as per 
    OPEN.universal.buildNavs = OPEN.productPage.inPageNav.buildInPageNav;
    //Add class to last in page nav module
    OPEN.productPage.inPageNav.addClassToLastModule();
    //Intialize product page    
    OPEN.productPage.pageLoad.init();
    //Add event for accordian control for mobile breakpoint
    OPEN.productPage.benefits.addClickAndTouchEventToAccordionHeader();
    OPEN.productPage.benefits.addClickAndTouchEventToAccordionContent();
    //Add evnet to highlight in-page accordion contorl on page up or down
    OPEN.productPage.addEventForPageUpOrDown();
 
	 OPEN.universal.openNewTab(".social-icons");
    var d = $(window).width();
    var n = $(".mobileenable").parent();
    var b = new Array();
    var o = null;
    var h = true;
    $(view_hld).not("#card-reviews,#overview").each(function () { // 11A for R&R module
        b.push($(this).html())
    });
	
	
    setTimeout(function(){$("#productPage .new-navheader > li.aj-inpage .items li a:hidden").addClass("invisible")},0);
    var f = function () {
        $(".mobileenable").each(function () {
            $(this).Amex_HP_Slider({
                animation: "slide",
                animationLoop: false,
                slideshow: false,
                minItems: 1,
                maxItems: 1,
                start: function (r) {
                    $("body").removeClass("loading")
                },
                before: function (r) {
                    q(r)
                }
            })
        })
    };
    var c = function () {
        $(".carousel-set1").each(function () {
            $(this).Amex_HP_Slider({
                selector: ".slides:first .view",
                animation: "slide",
                animationLoop: false,
                slideshow: false,
                minItems: 1,
                maxItems: 1,
                start: function (r) {
                    r.find(".hp-prev").text(r.currentSlide + 1);
                    r.find(".hp-next").text(r.count);
                    $("body").removeClass("loading")
                },
                before: function (r) {
                    r.find(".view:eq(" + r.animatingTo + ")").addClass("bg")
                },
                after: function (s) {
                    s.find(".hp-prev").text(s.currentSlide + 1);
                    $(s).find(".hp-active-slide").next().addClass("bg");
                    var r = s.find(".view").eq(s.currentSlide).attr("id");
                    typeof (lpTag) != "undefined" ? lpTag.vars.push([ {scope:"page",name:"carousel",value: r}]) : null;
                   typeof(lpTag) =="object"  &&  typeof(lpTag.vars.send)=="function" &&  lpTag.vars.send();
                }
            })
        })
    };

    function q(r) {

        /* June A*/
        if (r.animatingTo == 1) {

            r.find(".hp-viewport").css({
                "background-position": "right center"
            })
            //}
        } else {

            r.find(".hp-viewport").css({
                "background-position": "left center"
            })

        }
    }
    var a = function (r) {


        /*Feb A */
        function vie_hlder() {
            $(view_hld).not("#card-reviews,#overview").each(function (s) {
                $(this).html(b[s])
            });

        }

        if (r < 661) {
            if (o >= 661 || o == null) {
                $(view_hld).not("#card-reviews,#overview").each(function (s) {
                    $(this).html(b[s])
                });
            }
        } else {
            if (o < 661 || o == null) {
                /* if (!ie78) {June A*/
                $(view_hld).not("#card-reviews,#overview").each(function (s) {
                    $(this).html(b[s])
                });
            }

        }
        if (isIpad2 || !touch) {
            $(".hp-control-nav").css("z-index", "1");
            $("#hp-nav1 li a").css("z-index", "10")
        }

    };


    // 11A for R&R module end
    $(window).resize(function (v) {
        if (this.resizeTO)
            clearTimeout(this.resizeTO);
        this.resizeTO = setTimeout(function () {
            $(this).trigger('resizeEnd');
        }, 400);
        var sett = setTimeout(function () {
            bodyClass != $('body').attr('class') ? ($(window).resize(), bodyClass = $('body').attr('class')) : clearTimeout(sett);
        }, 2000);

        if ($(window).width() < 831) {
            ($("body").hasClass("full-version") || $("body").hasClass("new-ajnav")) && $("#product-footer").css({
                "margin-top": "0px"
            })
        }
        if ($(window).width() < 661) {
            $("#overview").height() - $(".product-footer").height() <= $(window).height() ? $("#overview-view1 .hp-control-nav").css("top", $(window).height() - $("#ajnav").height() - $(".product-footer").height() + 25) : $("#overview-view1 .hp-control-nav").css({
                "top": "auto"
            });
            $(".benefits p.content-description").each(function () {
                $(this).text($.trim($(this).text()))
            });
			
			
        }

        winWidth = $(window).width()
        OPEN.productPage.large(winWidth);
        OPEN.productPage.large_medium($(window).width());
        OPEN.productPage.overview.setoverviewHeight(); /*aprilb*/
        d = $(window).width();
        a(d);

        o = d;
        h = true;
        g();
        if ($(window).width() < 661) {
            $(".mobileenable").each(function () {
                var x = $(this);
                if (x.find(".hp-control-paging a.hp-active").parent().index() == 0) {
                    x.find(".hp-viewport").css({
                        "background-position-x": "0px",
                        "background-position-y": "center"
                    })
                } else {
                    x.find(".hp-viewport").css({
                        "background-position-x": ($(window).width() - 640) + "px",
                        "background-position-y": "center"
                    })
                }
            })
        }

        OPEN.productPage.offer.setSpecialOffer();
        $(".offer-badge,.special-offer span").each(function () {
            $.trim($(this).text()) == "" ? $(this).hide() : $(this).show(); /*aprilb*/
        }); /*aprilb*/
        // 11A start 
        d > 830 && d < 1280 && OPEN.productPage.ratingsReviews.customCarousel.hideReviews();

        // 11A end 

        /*MayA*/
        void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageResize(OPEN.config);
    });
    //Event on resize end
    $(window).bind('resizeEnd', function () {
        /* !ie78 && */
        OPEN.productPage.ratingsReviews.reInitiateRRCarousel($(window).width());
        OPEN.productPage.alignArrows();
    });

    var k = null;
    
    //Add evnet on page scroll
    $(window).scroll(function () {

        g();
        var r = $("#ajnav  ul.in-page li.active a").text().toLowerCase().split(" ").join("-");
        if ($("#" + r).parent().hasClass("module")) {
            r = $("#" + r).parent().attr("id")
        } else {
            if ($("#" + r).hasClass("product-details")) {
                r = $("#" + r).attr("id")
            }
        }
        if (r != k) {
            typeof (lpTag) != "undefined" ? lpTag.vars.push([ {scope:"page",name:"carousel",value: r}]) : null;
            typeof(lpTag) =="object"  &&  typeof(lpTag.vars.send)=="function"  && lpTag.vars.send();
            k = r
        }
        if (!isIpad2 && touch) {
            $(".hp-control-nav").css("z-index", "401");
            if (activeSlide == "details") {
                $(".product-footer-container").css("z-index", "450")
            } else {
                $(".product-footer-container").css("z-index", "2998")
            }
           
        }
         void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageScroll(OPEN.config);
    });
    a(d);
    o = d;
   
    var g = function () {

        var u = $("#product-footer");
        var r = u.height();
        var y = $(this).scrollTop();
        var s = $("#wrapper").width();
        var w = $(".module:first").offset().top + $(".module:first").height(); // 11A  
        /*var t = ie78; June A*/
        var ajnavH = $("#ajnav").outerHeight(true); /*aprilb*/
        if (!isIpad2) {
            x = s > 830 ? 90 : (s >= 661 ? 54 : 11); /*11A andsh*/
            if (s >= 661) {
                if (y >= (w - $(window).height() + r)) {
                    if (y >= (w - (ajnavH))) {

                        /*aprilb*/
                        if ($(window).width() > 660 && $('.product-footer .cardart-image1').is(":hidden")) {
                            $('.product-footer .cardart-image1').css({
                                "display": "block"

                            }).stop().animate({
                                "top": "40px"
                            }, typeof $('.product-footer .cardart-image1')[0].style.transition != "undefined" ? 1 : 400);
                        }


                        /*aprilb*/

                        $(".product-footer .rating").hide();
                        if (!$("body").hasClass("full-version") && !$("body").hasClass("new-ajnav")) { /*JuneC*/
                            $(".product-footer-parent").css({
                                "padding-top": "40px"
                            });
                        } /*AprilB*/
                        if (!touch) {
                            u.css({
                                "position": "fixed",
                                "top": "0px",
                                "bottom": "auto"
                            });
                            if ($("body").hasClass("full-version") || $("body").hasClass("new-ajnav")) {
                                u.css({
                                    "top": ajnavH + "px"
                                });
                            } /*AprilB*/
                        } else {						 
                           !u.parent().is("body") && u.appendTo($('body'));
						   u.css({
                                "position": "fixed",
                                "top": "0px",
                                "bottom": "auto"
                            });
                            if ($("body").hasClass("full-version") || $("body").hasClass("new-ajnav")) {
                                u.css({
                                    "top": ajnavH + "px"
                                });
                            } /*AprilB*/
                            $('#overview').parent().css("overflow", "hidden");
                        }
                    } else {
                        if ($("body").hasClass("full-version") || $("body").hasClass("new-ajnav")) {
                            $(".product-footer-parent").css({
                                "padding-top": "0px"
                            });
                        } /*AprilB*/
                        /*aprilb*/
                        $(".product-footer .cardart-image1").css({
                            "display": "none"
                        }).stop().animate({
                            "position": "absolute",
                            "top": "120px",
                        }, "slow");
                        /*aprilb*/

                        $(".product-footer .rating").show();
                        if ($("#product-footer").css("position") == "fixed" || h == true) {
                            if (!$("body").hasClass("full-version") && !$("body").hasClass("new-ajnav")) {
                                $(".product-footer-parent").css({
                                    "padding-top": "0px"
                                });
                            } /*AprilB*/
                            if (!touch) {
                                u.css({
                                    "position": "absolute",
                                    "top": w + "px",
                                    "bottom": "auto",
                                });
                                ($("body").hasClass("full-version") || $("body").hasClass("new-ajnav")) && u.css({
                                    "marginTop": "0px"
                                }); /*March B*/
                            } else {
                                !u.parent().is("#overview") && u.appendTo($('#overview'));
								u.css({
                                    "position": "absolute",
                                    "top": "auto",
                                    "bottom": "-" + u.height() + "px"
                                });
                                //$("body").hasClass("full-version") && u.css({"marginTop": "0px"/*March B*/  });
                                $('#overview').parent().css("overflow", "visible");
                            }
                        }
                    }
                } else {
                    $(".product-footer-parent").css({
                        "padding-top": "0px"
                    }); /*aprilb*/
                    $(".product-footer .cardart-image1").css({
                        "display": "none"
                    }).stop().animate({
                        "position": "absolute",
                        "top": "120px",
                    }, "slow");
                    $(".product-footer .rating").show();
                    if (!touch) {
                        u.css({
                            "position": "fixed",
                            "top": "auto",
                            "bottom": "0px"
                        });
                    } else {
						!u.parent().is("body") && u.appendTo($('body'));
                        u.css({
                            "position": "fixed",
                            "top": "auto",
                            "bottom": "0px"
                        });
                        $('#overview').parent().css("overflow", "hidden");
                    }
                }
            } else {
                $(".product-footer-parent").css({
                    "padding-top": "0px"
                }); /*aprilb*/
                $(".product-footer .cardart-image1").css({
                    "display": "none"
                }).stop().animate({
                    "position": "absolute",
                    "top": "120px",
                }, "slow");
                $(".product-footer .rating").hide();
                u.css({
                    "position": "fixed",
                    "top": "auto",
                    "bottom": "0px"
                });
                ($("body").hasClass("full-version") || $("body").hasClass("new-ajnav")) && $("#product-footer").css({
                    "margin-top": "0px"
                }); /* March B */
            }
        }
        h = false


    };
    $(window).scroll();
    $(".member-ship ul li span").not(".new-label").each(function () {
        $(this).siblings().length <= 0 ? $(this).css({
            "width": "100%"
        }) : null
    });
    $(".offer-badge,.special-offer span").each(function () {
        $.trim($(this).text()) == "" ? $(this).hide() : $(this).show(); // $(this).show().css("padding", "1px 3px") /*aprilb*/
    }); /*aprilb*/
    OPEN.productPage.offer.setSpecialOffer();

    /* MAY A */
    $.fn.onAvailable = function (fn) {
        var sel = this.selector;
        var timer;
        var self = this;
        if (this.length > 0) {
            fn.call(this);
        } else {
            timer = setInterval(function () {
                if ($(sel).length > 0) {
                    fn.call($(sel));
                    clearInterval(timer);
                }
            }, 0);
        }
    };
    OPEN.productPage.addTouchAndScrollEvent();
    OPEN.productPage.overview.setTOPCssOnResize();
    OPEN.productPage.alignArrows(); /* MAY A */
});

//Add event for window load
$(window).load(function () {
    OPEN.productPage.ratingsReviews.customCarousel.alignLineOfSightElements();
    OPEN.productPage.ratingsReviews.customScrollBar();
    OPEN.productPage.ratingsReviews.customCarousel.setRepeatorHeight(); /* April A*/
    OPEN.productPage.footer.setCardContentClass();
    
});
//Build product page arrows
OPEN.productPage.alignArrows(); /* MAY A */
//Set specfical offer class
OPEN.productPage.offer.setSpecialOffer();
//Set footer class
OPEN.productPage.footer.addShareamexEmailEvent();
OPEN.productPage.footer.addShareamexCloseEvent();


/*open scrollbar start*/
(function (factory) {
    if (typeof define === 'function' && define.amd) {

        define(['jquery'], factory);
    } else if (typeof exports === 'object') {

        factory(require('jquery'));
    } else {
        factory(jQuery);
    }
}
(function ($) {
    $.openObj = $.openObj || {};
    $.openObj.scrollbar = {
        options: {
            axis: 'y',
            wheel: true,
            wheelSpeed: 40,
            wheelLock: true,
            scrollInvert: false,
            trackSize: false,
            thumbSize: false
        }
    };
    $.fn.openScrollber = function (params) {
        var options = $.extend({}, $.openObj.scrollbar.options, params);
        var t = this;
        t.each(function () {
            $(this).data('tsb', new Scrollbar($(this), options));
        });

        return this;
    };

    $.fn.openScrollber_update = function (sScroll) {
        return $(this).data('tsb').update(sScroll);
    };

    function Scrollbar($container, options) {
        var self = this,
                $viewport = $container.find(".viewport"),
                $overview = $container.find(".overview"),
                $scrollbar = $container.find(".scrollbar"),
                $track = $scrollbar.find(".track"),
                $thumb = $scrollbar.find(".thumb"),
                viewportSize = 0,
                contentSize = 0,
                contentPosition = 0,
                contentRatio = 0,
                trackSize = 0,
                trackRatio = 0,
                thumbSize = 0,
                thumbPosition = 0,
                mousePosition = 0,
                isHorizontal = options.axis === 'x',
                hasTouchEvents = ("ontouchstart" in window && (/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/).test(navigator.userAgent)) || window.DocumentTouch && document instanceof DocumentTouch || (navigator.msMaxTouchPoints > 0), // june release fix for mozilla 26
                sizeLabel = isHorizontal ? "width" : "height",
                posiLabel = isHorizontal ? "left" : "top";

        function initialize() {
            self.update();
            setEvents();
            return self;
        }
        this.update = function (scrollTo) {
            sizeLabelCap = sizeLabel.charAt(0).toUpperCase() + sizeLabel.slice(1).toLowerCase();
            viewportSize = $viewport[0]['offset' + sizeLabelCap];
            contentSize = $overview[0]['scroll' + sizeLabelCap];
            contentRatio = viewportSize / contentSize;
            trackSize = options.trackSize || viewportSize;
            thumbSize = Math.min(trackSize, Math.max(0, (options.thumbSize || (trackSize * contentRatio))));
            trackRatio = options.thumbSize ? (contentSize - viewportSize) / (trackSize - thumbSize) : (contentSize / trackSize);

            $scrollbar.toggleClass("disable", contentRatio >= 1);
            switch (scrollTo) {
                case "bottom":
                    contentPosition = contentSize - viewportSize;
                    break;

                case "relative":
                    contentPosition = Math.min(contentSize - viewportSize, Math.max(0, contentPosition));
                    break;

                default:
                    contentPosition = parseInt(scrollTo, 10) || 0;
            }

            setSize();
        };

        function setSize() {
            $thumb.css(posiLabel, contentPosition / trackRatio);
            $overview.css(posiLabel, -contentPosition);
            mousePosition = $thumb.offset()[posiLabel];

            $scrollbar.css(sizeLabel, trackSize);
            $track.css(sizeLabel, trackSize);
            $thumb.css(sizeLabel, thumbSize);
        }

        function setEvents() {
            if (hasTouchEvents) {
                $thumb[0].ontouchstart = function (event) {
                    if (1 === event.touches.length) {
                        options.scrollInvert = false;
                        start(event.touches[0]);
                        //event.stopPropagation();
                    }
                };
                $viewport[0].ontouchstart = function (event) {
                    if (1 === event.touches.length) {
                        options.scrollInvert = true;
                        start(event.touches[0]);
                        //event.stopPropagation();
                    }
                };
            } else {
                $thumb.bind("mousedown", start);
                $track.bind("mouseup", drag);
            }
            if (options.wheel && window.addEventListener) {
                $container[0].addEventListener("DOMMouseScroll", wheel, false);
                $container[0].addEventListener("mousewheel", wheel, false);
            } else if (options.wheel) {
                $container[0].onmousewheel = wheel;
            }
        }

        function start(event) {
            $("body").addClass("noSelect");
            ie9 ? $("#wrapper").attr("unselectable", "on") : $("#wrapper").addClass("noselect");
            mousePosition = isHorizontal ? event.pageX : event.pageY;
            thumbPosition = parseInt($thumb.css(posiLabel), 10) || 0;

            if (hasTouchEvents) {
                $viewport[0].ontouchmove = function (event) {
                    //event.stopPropagation();
                    (contentRatio < 1) && event.preventDefault();
                    drag(event.touches[0]);
                };
                $viewport[0].ontouchend = end;

                $thumb[0].ontouchmove = function (event) {
                    //event.stopPropagation();
                    (contentRatio < 1) && event.preventDefault();
                    drag(event.touches[0]);
                };
                $thumb[0].ontouchend = end;
            } else {
                $(document).bind("mousemove", drag);
                $(document).bind("mouseup", end);
                $thumb.bind("mouseup", end);
            }
        }

        function wheel(event) {
            if (contentRatio < 1) {
                var eventObject = event || window.event,
                        wheelSpeedDelta = eventObject.wheelDelta ? eventObject.wheelDelta / 120 : -eventObject.detail / 3;
                contentPosition -= wheelSpeedDelta * options.wheelSpeed;
                contentPosition = Math.min((contentSize - viewportSize), Math.max(0, contentPosition));
                $thumb.css(posiLabel, contentPosition / trackRatio);
                $overview.css(posiLabel, -contentPosition);
                if (options.wheelLock || (contentPosition !== (contentSize - viewportSize) && contentPosition !== 0)) {
                    eventObject = $.event.fix(eventObject);
                    eventObject.preventDefault();
                }
            }
        }

        function drag(event) {
            if (contentRatio < 1) {
                mousePositionNew = isHorizontal ? event.pageX : event.pageY;
                thumbPositionDelta = mousePositionNew - mousePosition;

                if (options.scrollInvert) {
                    thumbPositionDelta = mousePosition - mousePositionNew;
                }
                thumbPositionNew = Math.min((trackSize - thumbSize), Math.max(0, thumbPosition + thumbPositionDelta));
                contentPosition = thumbPositionNew * trackRatio;
                $thumb.css(posiLabel, thumbPositionNew);
                $overview.css(posiLabel, -contentPosition);
            }
        }

        function end() {
            $("body").removeClass("noSelect");
            ie9 ? $("#wrapper").removeAttr("unselectable", "on") : $("#wrapper").removeClass("noselect");
            $(document).unbind("mousemove", drag);
            $(document).unbind("mouseup", end);
            $thumb.unbind("mouseup", end);
            document.ontouchmove = document.ontouchend = null;
        }
        return initialize();
    }
}));