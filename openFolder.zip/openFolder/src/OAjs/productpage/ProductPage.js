if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

OPEN.productPage.addIECssClassInBody = function (navigator) {
    navigator.appVersion.indexOf("MSIE") != -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./) ? ($('body').addClass('ie')) : null; /*aprilb*/
};

OPEN.productPage.large_medium = function (width) {
    (width >= 1024 && width < 1280) ? $("body").addClass('large_1024') : $("body").removeClass('large_1024');
};

OPEN.productPage.addWrapClassForSafari = function (navigator) {
    if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
        $("#wrapper").addClass("safari-wrap");
    }
};
OPEN.productPage.large = function (width) {
    if (width >= 1280) {
        $("body").addClass('large');
    } else {
        $("body").removeClass('large');
    }
};

OPEN.productPage.addClickEventToInnerAnchor = function () {
    $(".module ul.slides li a.inneranchor").live("click", function (r) {
        var s = $(this).attr("href").split("#").pop();
        s != "details" && (r.preventDefault(), $("html,body").stop().animate({
            "scrollTop": $("#" + s).offset().top - ($("#product-footer").outerHeight(true) + 80)
        }, 20))
    });
};

OPEN.productPage.addEventForAddReview = function (pagetitle) {
    $(".inneranchor,.add-review").live("click", function () {
        var r = pagetitle;
        (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", "Details_" + r) : null
    });
};

OPEN.productPage.addEventForPageUpOrDown = function () {
    $(".module .slides li a").live("keydown", function (t) {
        t.preventDefault();
        if (t.shiftKey && t.keyCode == 9) {
            if ($(this).parents(".hp-viewport").html() != null) {
                var s = $(this).parents(".hp-viewport").siblings("ul");
                if (s.find("a.hp-prev").hasClass("hp-disabled")) {
                    var r = $(this).parents(".module").prev();
                    r.find("a:first").focus();
                    $("#ajnav ul.in-page a." + r.find(view_hld).attr("id") + "").click()
                } else {
                    s.find("a.hp-prev").click()
                }
            } else {
                var r = $(this).parents(".module").prev();
                r.find("a:first").focus();
                $("#ajnav ul.in-page a." + r.find(view_hld).attr("id") + "").click()
            }
        } else {
            if (t.keyCode == 9) {
                if ($(this).parents(".hp-viewport").html() != null) {
                    var s = $(this).parents(".hp-viewport").siblings("ul");
                    if (s.find("a.hp-next").hasClass("hp-disabled")) {
                        var u = $(this).parents(".module").next();
                        u.find("a:first").focus();
                        $("#ajnav ul.in-page a." + u.find(view_hld).attr("id") + "").click()
                    } else {
                        s.find("a.hp-next").click()
                    }
                } else {
                    var u = $(this).parents(".module").next();
                    u.find("a:first").focus();
                    $("#ajnav ul.in-page a." + u.find(view_hld).attr("id") + "").click()
                }
            }
        }
    });
};

OPEN.productPage.addTouchAndScrollEvent = function () {
    $(window).on("touchmove scroll", function (e) {
        $(".list-overlay").removeClass(ovr_cls);
    });
};
