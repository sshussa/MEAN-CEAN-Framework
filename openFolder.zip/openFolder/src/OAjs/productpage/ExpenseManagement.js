if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.expenseManagement) {
    OPEN.productPage.expenseManagement = {};
}

/*MayA EM module*/
var mngSld = [];
var slides = '.em-slide';
var sclV = 0.00;
var secV = 0.00;
var secRt = 0.00;
var matrixRegex = /matrix\((-?\d*\.?\d+),\s*0,\s*0,\s*(-?\d*\.?\d+),\s*0,\s*0\)/;
var prefix = "";
var rvsCrs = true;
var arr = null;
var scl = null;
var crSld = 1;
var mobFlg = true;
var emObj = null;
var running = false;
var emOnce = true;

OPEN.productPage.expenseManagement.updateSlidesList = function (mngSld) {
    for (var i = 0; i < $(slides).length; i++) {
        mngSld.push(i);
    }
};

OPEN.productPage.expenseManagement.getPrefixForAnimation = function () {
    var stl = window.getComputedStyle(document.documentElement, '');
    var pre = (Array.prototype.slice.call(stl).join('').match(/-(moz|webkit|ms)-/) || (stl.OLink === '' && ['', 'o']))[1];
    return '-' + pre + '-';

};


OPEN.productPage.expenseManagement.setActiveClass = function () {
    if ($("#expense-management").length) {
        var apnd = "";
        for (var i = 0; i < $(".em-slide").length; i++) {
            apnd = apnd + "<a href='#'></a>";
            $($(".em-slide")[i]).hasClass("lrg-sld") && (actv = i);
        }
        $(".em-mob-indicator").append(apnd);
        $(".em-mob-indicator a").removeClass().eq(actv).addClass("active");
    }
};

OPEN.productPage.expenseManagement.addBuildCarouselEvent = function (crSld) {
    var dly = false;
    $('.em-mob-indicator> a').on("click", function (e) {
        e.preventDefault();
        if (!$(this).hasClass("active")) {
            var indx = $(this).index();
            var mobrvs = crSld < indx;
            var itr = mobrvs ? (indx - crSld) : (crSld - indx);
            dly = itr == 2 ? (dly = true) : (dly = false);
            var sldS = 500 - (itr * 150);
            $(".em-mob-indicator> a").removeClass('active').eq($(this).index()).addClass('active');
            for (var i = crSld; mobrvs ? (i <= indx) : (i >= indx); mobrvs ? i++ : i--) {
                (function (cnt) {
                    var i = cnt;
                    $(".em-mob-indicator> a").eq(indx).delay(dly ? (i == (mobrvs ? 2 : 0) ? sldS : 0) : 0).queue(function (next) {
                        OPEN.productPage.expenseManagement.carousel(slides, null, 'lt-sld', 'lrg-sld', 'rt-sld', $(this), i, sldS);
                        next();
                    });
                })(i);
            }
            return false;
        }
    });
};

OPEN.productPage.expenseManagement.genMsr = function (ele, val) {
    var msr = null;
    switch (val) {
        case 1:
            ele == 'lrg-sld' ? msr = $("." + ele).outerWidth() : msr = (parseInt($("." + ele).outerWidth()) * ((0.63 * 100) / 1)) / 100;
            break;
        case 2:
            msr = String($("." + ele).css(prefix + "transform")).match(matrixRegex)[1];
            break;
        case 3:
            var bkpFx = ($(window).width() == 831 && prefix == '-webkit-') ? 0.76 : 0;
            var iosFx = $(window).width() == 768 && 1;
            ele == 'lrg-sld' ? (msr = $("." + ele).position().left) : ele == 'lt-sld' ? (msr = -($(".em-slides").outerWidth() * 13) / 100) : msr = ((($(".em-slides").outerWidth() - (parseInt($("." + ele).outerWidth()))) + ($(".em-slides").outerWidth() * 13) / 100) - (!!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/) ? iosFx : bkpFx));
            break;
    }
    return msr;
};


OPEN.productPage.expenseManagement.carousel = function (slds, rvs, ltCrd, lrgCrd, rtCrd, mobNav, inx, spd) {
    if (running == false) {
        scl = [OPEN.productPage.expenseManagement.genMsr(ltCrd, 2), OPEN.productPage.expenseManagement.genMsr(lrgCrd, 2), OPEN.productPage.expenseManagement.genMsr(rtCrd, 2), parseFloat((OPEN.productPage.expenseManagement.genMsr(lrgCrd, 2) * 85) / 100), parseFloat(OPEN.productPage.expenseManagement.genMsr(lrgCrd, 2)) + parseFloat(((OPEN.productPage.expenseManagement.genMsr(lrgCrd, 2) * 3) / 100))];
        sclAr = [
            [rvs ? 4 : 0, 0],
            [3, 1],
            [rvs ? 0 : 4, 0]
        ];
        var cntr = ((OPEN.productPage.expenseManagement.genMsr(lrgCrd, 1)) / 2) - (($('.em-slides').outerWidth() - OPEN.productPage.expenseManagement.genMsr(lrgCrd, 1)) / 2);
        var lrgP = ($('.em-slides').outerWidth() - $("." + lrgCrd).outerWidth()) / 2;
        var extr = (parseInt($(".lrg-sld").outerWidth()) * ((0.03 * 100) / 1)) / 100;
        var rtp = $('.em-slides').outerWidth() - (OPEN.productPage.expenseManagement.genMsr(rtCrd, 1) + (($.browser.msie && parseInt($.browser.version)) == 9 ? (OPEN.productPage.expenseManagement.genMsr(rtCrd, 3) + $("." + rtCrd).position().left) : $("." + rtCrd).position().left));
        var rtPos = ($.browser.msie && parseInt($.browser.version)) == 9 ? (OPEN.productPage.expenseManagement.genMsr(rtCrd, 3) + $("." + rtCrd).position().left) : $('.rt-sld').position().left;
        arr = [parseFloat(OPEN.productPage.expenseManagement.genMsr(ltCrd, 3)), rvs ? cntr : lrgP, OPEN.productPage.expenseManagement.genMsr(rtCrd, 3), (OPEN.productPage.expenseManagement.genMsr(rtCrd, 3)) - (((OPEN.productPage.expenseManagement.genMsr(lrgCrd, 1) * 85) / 100) - OPEN.productPage.expenseManagement.genMsr(rtCrd, 1)), (OPEN.productPage.expenseManagement.genMsr(ltCrd, 3)) + ((((OPEN.productPage.expenseManagement.genMsr(lrgCrd, 1) * 85) / 100) - OPEN.productPage.expenseManagement.genMsr(ltCrd, 1))) / 2, (OPEN.productPage.expenseManagement.genMsr(ltCrd, 3)) - OPEN.productPage.expenseManagement.genMsr(rtCrd, 3), -(($('.em-slides').outerWidth() - $("." + lrgCrd).outerWidth()) - (($('.' + ltCrd).position().left) * 2 + extr)), (lrgP - ($('.em-slides').outerWidth() - (OPEN.productPage.expenseManagement.genMsr(rtCrd, 1) + rtPos)) - (extr / 2)), (OPEN.productPage.expenseManagement.genMsr(ltCrd, 3) * 2) - OPEN.productPage.expenseManagement.genMsr(rtCrd, 3), (lrgP * 2) + (67 - extr), OPEN.productPage.expenseManagement.genMsr(rtCrd, 3) - lrgP];
        var ele = null
        rvs != null && (rvs ? ele = mngSld.shift() : ele = mngSld.pop());
        rvs != null && (rvs ? mngSld.push(ele) : mngSld.unshift(ele));
        var obj = [
            [rvs ? 6 : 8, rvs ? 3 : 0, rvs ? 3 : 0, rvs ? 4 : 3, rvs ? 300 : 600, rvs ? 5 : 8, 0, 0, 3, rvs ? lrgCrd : rtCrd, 0.4, rvs ? 0.01 : 0.4],
            [rvs ? 3 : 4, 1, 1, 5, 300, rvs ? 0 : 1, 2, 2, 5, rvs ? rtCrd : ltCrd, 0.01, 0.01],
            [rvs ? 2 : 7, rvs ? 0 : 3, rvs ? 0 : 3, rvs ? 3 : 4, rvs ? 600 : 300, rvs ? 2 : 10, 0, 0, 2, rvs ? ltCrd : lrgCrd, rvs ? 0.4 : 0.4, rvs ? 0.4 : 0.01]
        ];
        rvsCrs = rvs;
        var sld = $(slds);
        var tmp = $(sld.eq(ele));
        var mobile = true;
        if ($(window).width() <= 660) {
            var indx = inx;
            var mobrvs = crSld < indx;
            if (crSld != indx) {


                mobrvs ? mngSld.push(mngSld.shift()) : mngSld.unshift(mngSld.pop());
                var cls = [ltCrd, lrgCrd, rtCrd]
                var slds = 3;
                sld.eq(crSld).css({
                    'left': 0,
                    'z-index': 10
                });
                while (slds--) {

                    sld.eq(mngSld[slds]).removeClass(lrgCrd + " " + ltCrd + " " + rtCrd).addClass(cls[slds]);
                }

                var mobL = ((parseFloat($("." + lrgCrd).outerWidth()) * 2) + $('.em-slides').outerWidth() - $("." + lrgCrd).outerWidth());
                var mobPos = parseFloat($('.em-slides').outerWidth());
                sld.eq(mngSld[1]).css('left', mobrvs ? mobPos : -(prefix == '-moz-' ? mobL * 2 : mobL));
                sld.eq(crSld).animate({
                    left: mobrvs ? (crSld == 0 && indx == 2) ? -mobL : -mobPos : mobPos
                }, spd, 'linear', function () {
                    $(this).removeAttr('style')
                });
                sld.eq(mngSld[1]).animate({
                    left: 0
                }, spd, 'linear', function () {
                    sld.removeClass('ctr-sld');
                    running = false;
                    !!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/) && $(document).scrollTop($(document).scrollTop() - (1)).scrollTop($(document).scrollTop() + (1));
                });
                crSld = inx;
            }
        } else {
            running = true;
            $(".em-mask").show();
            tmp.addClass(rvs ? 'lt-tmp' : 'rt-tmp');
            var rtcurr = $(".rt-sld");
            $(".rt-sld,.rt-tmp").css({
                "left": OPEN.productPage.expenseManagement.genMsr(rtCrd, 3)
            });
            !!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/) && tmp.css("left", OPEN.productPage.expenseManagement.genMsr(ltCrd, 3));
            tmp.animate({
                left: lrgP
            }, 300, function () {
                $(this).removeAttr('style').removeClass(rvs ? 'lt-tmp' : 'rt-tmp')
            });
            var i = 3;
            $(rvs ? '.lt-tmp' : '.rt-tmp').removeClass(rvs ? 'lt-sld' : 'rt-sld');
            sld.not(rvs ? '.lt-tmp' : '.rt-tmp').removeClass("lt-sld").removeClass("rt-sld").removeClass("lrg-sld");
            var frx = prefix == '-moz-';
            while (i--) {
                (function (i) {
                    var i = i;
                    var slds = sld.eq(mngSld[i]).removeClass(lrgCrd + " " + ltCrd + " " + rtCrd).addClass(obj[i][9]);
                    !rvs && $("." + lrgCrd).css({
                        "margin-left": lrgP,
                        "margin-right": lrgP
                    });
                    slds.animate({
                        transform: {
                            scale: scl[sclAr[i][0]],
                            opacity: obj[i][11],
                            left: arr[obj[i][0]]
                        },
                        "z-index": obj[i][3]
                    }, obj[i][4], 'linear', function () {
                        var ss = '';
                    }).animate({
                        transform: {
                            scale: scl[sclAr[i][1]],
                            opacity: obj[i][10],
                            left: arr[obj[i][5]]
                        },
                        "z-index": obj[i][8]
                    }, 600, 'linear', function () {
                        running = false;
                        rtcurr.removeAttr('style');
                        $(this).removeAttr('style');
                        $(this).find('.em-mask').removeAttr('style');
                        i == 0 && $(this).removeClass(lrgCrd + " " + ltCrd + " " + rtCrd).addClass(ltCrd);
                        i == 1 && $(this).removeClass(lrgCrd + " " + ltCrd + " " + rtCrd).addClass(lrgCrd);
                        i == 2 && $(this).removeClass(lrgCrd + " " + ltCrd + " " + rtCrd).addClass(rtCrd);
                        sld.removeClass('onc');
                        crSld = $("." + lrgCrd).index();
                        $(".em-mob-indicator a").removeClass('active').eq(crSld).addClass('active');
                        $(".lrg-sld .em-mask").hide();
                    });
                })(i);
            }
        }
    }
}


OPEN.productPage.expenseManagement.move = function (e) {
    if (compD == true) {
        if (emOnce) {
            var curr = e.touches[0].pageX - comp_pos;
            /*			if(Math.abs(diff) <=6) {  */
            if (Math.abs(curr) >= 5) {
                if (e.touches[0].pageX < comp_pos) {
                    $(window).width() > 660 ? $(".em-next").trigger('click') : ($(".em-mob-indicator a.active").next().length == 1 && $(".em-mob-indicator a.active").next().trigger('click'));
                }
                if (e.touches[0].pageX > comp_pos) {
                    $(window).width() > 660 ? $(".em-prev").trigger('click') : $(".em-mob-indicator a.active").prev().length == 1 && $(".em-mob-indicator a.active").prev().trigger('click');
                }
            }
            emOnce = false
        }
    }
};

OPEN.productPage.expenseManagement.touchUp = function (e) {
    comp_pos = 0;
    compD = false;
    compH = 0;
    emOnce = false; /* MAYA */
    $(document)[0].removeEventListener('touchmove', OPEN.productPage.expenseManagement.move, true);
    emObj = null;
};

OPEN.productPage.expenseManagement.touchDown = function (e) {
    emObj = e.touches[0].target;
    comp_pos = e.touches[0].pageX;
    compD = true;
    emOnce = true; /* MAYA */
    $(document)[0].addEventListener('touchmove', OPEN.productPage.expenseManagement.move, true);
};
/*MayA EM module*/

OPEN.productPage.expenseManagement.bindTouchEvent = function (em_slds) {
    if (em_slds.length) {
        em_slds[0].addEventListener('touchend', OPEN.productPage.expenseManagement.touchUp, true);
        em_slds[0].addEventListener('touchstart', OPEN.productPage.expenseManagement.touchDown, true);
    }
};

OPEN.productPage.expenseManagement.bindClickEvent = function () {
    $(".em-carousel button").on("click", function (e) {
        var t = $(this);
        setTimeout(function () {
            if (running == false) {
                t.hasClass("em-prev") ? OPEN.productPage.expenseManagement.carousel(slides, false, 'lt-sld', 'lrg-sld', 'rt-sld', null, null, null) : OPEN.productPage.expenseManagement.carousel(slides, true, 'lt-sld', 'lrg-sld', 'rt-sld', null, null, null);
            }
        }, 300);
    });
};

OPEN.productPage.expenseManagement.applyFontFix = function () {
    document.documentElement.clientWidth > 1024 ? $("#expense-management").addClass("fontfix") : $("#expense-management").removeClass("fontfix");
};

OPEN.productPage.expenseManagement.setHeightOnResize = function () {
  $(".em-bg-rptr").length > 0 && $(".em-bg-rptr").css({"height":$(window).width() < 661?$("#expense-management").outerHeight():$("#expense-benefits").outerHeight(),"top":$("#expense-benefits").offset().top}); /*julyB*/
};

OPEN.productPage.expenseManagement.setClassOnResize = function () {
    if ($(window).width() < 661) {
		$("#expense-benefits").hasClass("activeFlag") && $("#expense-management").show(0);
        $(".em-slide").removeAttr("style");
        $("#expense-management").css("margin-left", ($("#expense-benefits").width() - $("#expense-management").outerWidth()) / 2);
        $(".em-mask").hide();
    } else {
        $(".lt-sld .em-mask,.rt-sld .em-mask").show();
        //$(window).width() < 830 && $("#expense-management").removeAttr("style"); /*10 B */
		//$(window).width() > 830 ? $("#expense-management").css("margin-left", "18%") : $("#expense-management").css("margin-left", 0);
    }
};

OPEN.productPage.expenseManagement.changeClassOnAvailable = function () {
    $(".em-bg-rptr").css("height", $(window).width() < 661?$("#expense-management").outerHeight():$("#expense-benefits").outerHeight()); /*julyB*/
    $(window).width() < 661 ? ($("#expense-management").css("margin-left", ($("#expense-benefits").width() - $("#expense-management").width()) / 2), $(".em-mask").hide()) : $(".lrg-sld .em-mask").hide();
};

OPEN.productPage.expenseManagement.animateOnAvailable = function () {
    if ((navigator.userAgent).indexOf("MSIE") > 0 || navigator.userAgent.indexOf("Firefox") > 0) {
        $("#expense-management").onAvailable(function () {
            window.location.hash == "#expense-management" && $('#ajnav ul.in-page').find(".receiptmatch").click();
        });
    } else {
        if (window.location.hash == "#expense-management") {
            receiptMatchPos = $("#expense-management").offset().top - $("#product-footer").outerHeight();
            (navigator.userAgent).indexOf("rv:11") > 0 ? $("html,body").animate({
                scrollTop: receiptMatchPos - 38
            }, 700) : $("html,body").animate({
                scrollTop: receiptMatchPos - 22
            }, 700);
        }
    }
};

$.fx.step["transform"] = function (sld) {
    if (!sld.EM_crl) {
        sld.$elem = $(sld.elem), sld.startTime = $.now();
        var mtx = $(sld.elem).css(prefix + 'transform');
        var sldVal = 0;
        if (rvsCrs) {
            if ((parseFloat(mtx.match(matrixRegex)[1])) > 0.63) {
                $(sld.elem).hasClass('rt-sld') ? (sldVal = parseFloat(arr[3])) : sldVal = parseFloat($(sld.elem).position().left);
                if (parseFloat(mtx.match(matrixRegex)[1]) != 1) {
                    $(sld.elem).hasClass('lrg-sld') && (sldVal = parseFloat(arr[6]));
                }
                if ((prefix == '-moz-' || !!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/)) && parseFloat(mtx.match(matrixRegex)[1]) != 1) {
                    $(sld.elem).hasClass('lrg-sld') ? (sldVal = parseFloat(arr[6])) : !$(sld.elem).hasClass('rt-sld') && (sldVal = parseFloat($(sld.elem).position().left));
                } else if (prefix == '-moz-' || !!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/)) {
                    $(sld.elem).hasClass('lrg-sld') ? (sldVal = parseFloat(0)) : sldVal = parseFloat($(sld.elem).position().left);
                }
            } else {
                !$(sld.elem).hasClass('lrg-sld') ? sldVal = parseFloat(($(".em-slides").outerWidth() - (parseInt($(".rt-sld").outerWidth()))) + ($(".em-slides").outerWidth() * 10) / 100) : sldVal = parseFloat($(sld.elem).position().left - ($(".em-slides").outerWidth() * 10) / 100);
                $(sld.elem).hasClass('lt-sld') && $(sld.elem).hasClass('onc') ? $(sld.elem).removeClass('onc') : $(sld.elem).hasClass('lt-sld') && $(sld.elem).addClass('onc');
                $(sld.elem).hasClass('onc') ? $(sld.elem).hasClass('lt-sld') && (sldVal = (($(".em-slides").outerWidth() - (parseInt($(sld.elem).outerWidth()))) + ($(".em-slides").outerWidth() * 10) / 100) - ($(".em-slides").outerWidth() * 10) / 100) : sldVal = arr[2];
            }
        } else {
            if ((parseFloat(mtx.match(matrixRegex)[1])) > 0.63) {
                $(sld.elem).hasClass('lt-sld') ? (sldVal = parseFloat(arr[4])) : sldVal = parseFloat($(sld.elem).position().left);
                $(sld.elem).hasClass('lrg-sld') && (parseFloat(mtx.match(matrixRegex)[1])) != 1 && (sldVal = arr[7]);
                if ((prefix == '-moz-' || !!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/)) && parseFloat(mtx.match(matrixRegex)[1]) == 1) {
                    sldVal = !$(sld.elem).hasClass('lrg-sld') && (sldVal = parseFloat(0));
                }
            } else {
                !$(sld.elem).hasClass('lrg-sld') ? sldVal = parseFloat(arr[0]) : sldVal = parseFloat($(sld.elem).position().left);
                $(sld.elem).hasClass('rt-sld') && $(sld.elem).hasClass('onc') ? $(sld.elem).removeClass('onc') : $(sld.elem).addClass('onc');
                $(sld.elem).hasClass('onc') ? $(sld.elem).hasClass('rt-sld') && (sldVal = (parseFloat(arr[8]) - parseFloat(arr[0]))) : sldVal = arr[8];
            }
        }
        sld.start = {
            scale: +parseFloat(mtx.match(matrixRegex)[1]),
            opacity: +parseFloat($(sld.elem).find('.em-mask').css('opacity')),
            left: +sldVal
        };
        sld.EM_crl = true;
    }
    sclC = (((($.now() - sld.startTime) / 100) * 100) / sld.options.duration);
    if (sclC < 1) {
        sld.now = {
            "scale": (sld.end.scale ? +(sld.start.scale + ((sld.end.scale - sld.start.scale) * sclC)) : sld.start.scale),
            "opacity": (sld.end.opacity ? +(sld.start.opacity + ((sld.end.opacity - sld.start.opacity) * sclC)) : sld.start.opacity),
            "left": (sld.end.left ? +(sld.start.left + ((sld.end.left - sld.start.left) * sclC)) : sld.start.left)
        };
        sld.$elem.css(prefix + "transform", "scale(" + sld.now.scale + ")").css("left", sld.now.left).find('.em-mask').css({
            'opacity': sld.now.opacity
        });
    }
}
    