if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.simplycash) {
    OPEN.productPage.simplycash = {};
}
OPEN.productPage.simplycash.fixAlignment = function (){
    /*simply cash alignment fix aprilb*/
    if ($("#overview-view1.pp-simplycash-01").length > 0) {
        var alignSimplyCash = (function () {
            var u = $("#overview-view1.pp-simplycash-01 #offer-overview ul"),
                    l = $(u)[0].getElementsByTagName("li"),
                    s = [],
                    h = 0;
            for (var i = 0; i < l.length; i++) {
                s.push(l[i].getElementsByTagName("span")[1]);
            }
            return function () {
                h = Math.max($(s[0]).outerHeight(), $(s[1]).outerHeight(), $(s[2]).outerHeight()) + ($(window).width() <= 830 ? ($(window).width() <= 660 ? 26 : 19) : 0);
                l[1].style.height = h + "px";
                //$(window).width()<=660?console.log(1):console.log(0)
            }
        })();
        var simplycashalign = alignSimplyCash;
        simplycashalign();
    };
    $("#npsl-video>a").on("contextmenu", function(){
        return false;
    });
};

