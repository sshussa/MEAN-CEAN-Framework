if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}
var rr_reviws = $("#rr-module .carousel-reviews");
var el = rr_reviws[0];
var viewAllObj;
var startX;
var startY;
var startT;
var rrViewport;
var activeSlide;
var lastSlide;
var offset;
var leftV;
var nextArrow;
var prevArrow;
var dx;
var noSlide;
var scrolling;
OPEN.productPage.ratingsReviews = {
    customCarousel: {
        leftV: "",
        viewport: 0,
        carousel: $('#rr-module .carousel-reviews'),
        slide: $('#rr-module #slider'),
        noOfItems: $('#rr-module .carousel-reviews .slides li').length,
        maxNumItems: function () {
            return ($(window).width() >= 830 ? 4 : ($(window).width() > 660 ? 3 : 1)) /* June A*/
        },
        slideWidth: function () {
            return ($(window).width() >= 830 ? ($(this.slide.selector).parent().width() - 3 * 45) / 4 : ($(window).width() > 660 ? 170 : 260)) /* June A*/
        },
        isAnimating: true,
        prevTitle: "click to go to previous slide",
        nextTitle: "click to go to next slide",
        numOfSlides: function () {
            var visible = this.maxNumItems();
            var quotient = this.noOfItems / visible;
            var numOfSlides = (this.noOfItems % visible == 0) ? quotient : (Math.floor(quotient) + 1);
            return numOfSlides;
        },
        setViewport: function () {
            $(this.slide.selector).find("li").width(this.slideWidth());
            this.viewport = $(this.slide.selector).parent().width();

        },
        setSlider: function () {
            $(this.slide.selector).width(this.numOfSlides() * this.viewport);

        },
        hideReviews: function () {
            var activeSlide = parseInt($(".hp-view-paging .hp-view-active").text());
            for (var i = activeSlide * this.maxNumItems(); i < this.noOfItems; i++)
                $('#rr-module .carousel-reviews .slides li').eq(i).css("visibility", "hidden");

        },
        showReviews: function () {
            $('#rr-module .carousel-reviews .slides li').css("visibility", "visible");
        },
        wrapItems: function () {
            var reviewsCount = this.noOfItems;
            var visible = this.maxNumItems();
            if (reviewsCount <= visible) {
                var rem = reviewsCount % (visible);
                var slideWidth = this.slideWidth();
                var reviewWidth = slideWidth * visible / rem;
                $(this.slide.selector).find("li").width(reviewWidth);
            }
        },
        buildPagination: function () {
            this.carousel.append("<ol class='hp-view-paging'><li class='hp-view-active'>1</li><li class='hp-view-count'>/" + this.numOfSlides() + "</li></ol>");
        },
        buildNavigation: function () {
            this.carousel.append("<ul class='hp-nav-reviews' id='hp-nav-reviews'><li><a class='hp-prev hp-disabled' href='#'></a></li><li><a class='hp-next hp-disabled' href='#' title='click to go to next slide' hidefocus='true'></a></li></ul>")
        },
        updateSlides: function () {
            var activeSlide = parseInt($(".hp-view-paging .hp-view-active").text()),
                    slide = $(this.slide.selector),
                    leftV = parseInt(slide.css("left")),
                    car = this,
                    noOfSlides = this.numOfSlides(),
                    activ = activeSlide > noOfSlides ? noOfSlides : activeSlide,
                    leftV = (car.viewport) * (activ - 1),
                    rightArrow = $(this.carousel.selector).find(".hp-next").removeClass('hp-disabled').attr('title', this.nextTitle),
                    leftArrow = $(this.carousel.selector).find(".hp-prev").removeClass('hp-disabled').attr('title', this.prevTitle);
            slide.stop().animate({
                "left": -leftV
            }, 100, "swing");
            (Math.abs(leftV) == 0) && leftArrow.addClass("hp-disabled").removeAttr('title');
            (Math.abs(leftV) === this.viewport * (noOfSlides - 1)) && rightArrow.addClass("hp-disabled").removeAttr('title');
            $(".hp-view-paging .hp-view-active").text(activ);
            $(".hp-view-paging .hp-view-count").text("/" + noOfSlides);
        },
        updateNavigation: function () {
            var paging = $(this.carousel.selector).find(".hp-view-paging"),
                    navigation = $(this.carousel.selector).find(".hp-nav-reviews"),
                    nextArrow = $(this.carousel.selector).find(".hp-next");
            (this.noOfItems <= this.maxNumItems()) ? (paging.addClass("disable"), navigation.addClass("disable")) : (paging.removeClass("disable"), navigation.removeClass("disable"), nextArrow.removeClass("hp-disabled"))
        },
        animateCarousel: function (direction) {
            if (this.isAnimating) {
                var car = this;
                var slide = $(this.slide.selector);
                var rightArrow = $(this.carousel.selector).find(".hp-next").removeClass("hp-disabled").attr('title', this.nextTitle),
                        leftArrow = $(this.carousel.selector).find(".hp-prev").removeClass("hp-disabled").attr('title', this.prevTitle),
                        currentSlide = parseInt($(".hp-view-paging .hp-view-active").text()),
                        leftV = 0,
                        noOfSlides = this.numOfSlides();

                direction == "next" ? (currentSlide = currentSlide + 1) : (currentSlide = currentSlide - 1);
                leftV = (car.viewport) * (currentSlide - 1);
                (Math.abs(leftV) == 0) && leftArrow.addClass("hp-disabled").removeAttr('title');

                (Math.abs(leftV) === this.viewport * (noOfSlides - 1)) && rightArrow.addClass("hp-disabled").removeAttr('title');
                !(currentSlide < 1 || currentSlide > noOfSlides) && $(".hp-view-paging .hp-view-active").text(currentSlide);
                car.isAnimating = false;
                slide.stop().animate({
                    "left": -leftV
                }, 500, "swing", function () {
                    car.isAnimating = true;
                })
            }
        },
        events: function () {
            var car = this;
            this.carousel.find(".hp-nav-reviews a").live("click", function (e) {
                e.preventDefault();
                direction = ($(this).hasClass("hp-next")) ? "next" : "prev";
                !$(this).hasClass("hp-disabled") && car.animateCarousel(direction);
            });
        },
        findFirstInSlide: function () {
            $(this.carousel.selector).find(".slides>li").removeClass("first-in-slide")
            if ($(window).width() > 660) {
                var carousel = $(this.carousel.selector);
                var noOfReviews = this.noOfItems;
                var visible = this.maxNumItems();
                for (var i = 0; i < noOfReviews / (visible); i++) {
                    carousel.find(".slides>li").eq((i + 1) * (visible)).addClass("first-in-slide");
                }
            }
        },
        alignLineOfSightElements: function () {
            var titles = $("#rr-module .slides li h3.summary");
            titles.height("auto");
            if ($(window).width() > 660) {
                var noOfReviews = this.noOfItems;
                var visible = this.maxNumItems();
                var maxTitlesHeight = new Array();
                for (var i = 0; i < noOfReviews / (visible); i++) {


                    maxTitlesHeight.push($(titles[visible * i]).height());

                    for (var j = (visible * i) + 1; j < visible * (i + 1) && j < noOfReviews; j++) {
                        if (maxTitlesHeight[i] < $(titles[j]).height())
                            maxTitlesHeight[i] = $(titles[j]).height()
                    }
                }
                for (var i = 0; i < noOfReviews / (visible); i++) {
                    for (var j = visible * i; j < visible * (i + 1) && j < noOfReviews; j++) {
                        $(titles[j]).height(maxTitlesHeight[i]);
                    }
                }
            }

        },
        setRepeatorHeight: function () { /* April A */
            $("#card-review .rr-bgr").height($("#card-review .content").height() + parseInt($("#card-review .content").css("padding-bottom")));
        },
        setOnResize: function () {
            this.updateNavigation();
            this.setViewport();
            this.findFirstInSlide();
            this.setSlider();
            this.wrapItems();
            this.alignLineOfSightElements();
            this.updateSlides();
            this.showReviews();
            OPEN.productPage.ratingsReviews.customScrollBar();
            this.setRepeatorHeight(); /* April A*/
        },
        init: function () {
            this.setViewport();
            this.findFirstInSlide();
            this.setSlider();
            this.buildPagination();
            this.buildNavigation();
            this.updateNavigation();
            this.events();
            this.wrapItems();
            this.setRepeatorHeight(); /* April A*/
            //this.adjustViewPort();				
            OPEN.productPage.ratingsReviews.customScrollBar();
            navliHt = OPEN.universal.navPanelPosIndexed();
        }
    },
    customScrollBar: function () {
        var customScroll = $('.custom-scrollbar');
        customScroll.openScrollber();
    },
    onTouchStart: function (e) {
        if (e.touches.length === 1) {
            viewAllObj = e.touches[0].target;
            startX = e.touches[0].pageX;
            startY = e.touches[0].pageY;
            startT = Number(new Date());
            rrViewport = OPEN.productPage.ratingsReviews.customCarousel.viewport;
            activeSlide = parseInt($(".hp-view-paging .hp-view-active").text());
            lastSlide = OPEN.productPage.ratingsReviews.customCarousel.numOfSlides();
            offset = rrViewport * (activeSlide - 1);
            leftV = rrViewport * (activeSlide);
            nextArrow = $(".carousel-reviews .hp-nav-reviews .hp-next");
            prevArrow = $(".carousel-reviews .hp-nav-reviews .hp-prev");
            el.addEventListener('touchmove', OPEN.productPage.ratingsReviews.onTouchMove, false);
            el.addEventListener('touchend', OPEN.productPage.ratingsReviews.onTouchEnd, false);
        }
    },
    onTouchMove: function (e) {
        dx = startX - e.touches[0].pageX;
        noSlide = (dx < 0 && prevArrow.hasClass("hp-disabled")) || (dx > 0 && nextArrow.hasClass("hp-disabled"))
        scrolling = Math.abs(dx) < Math.abs(e.touches[0].pageY - startY);
        //console.log(Math.abs(e.touches[0].pageY - startY));
        if (!scrolling || Number(new Date()) - startT > 500) {
            e.preventDefault();
            dx = dx / ((activeSlide === 1 && dx < 0 || activeSlide === lastSlide && dx > 0) ? (Math.abs(dx) / rrViewport + 2) : 1);
            $('#rr-module #slider').stop().animate({
                "left": -(offset + dx)
            }, 10, "swing");
        }
    },
    onTouchEnd: function (e) {
        el.removeEventListener('touchmove', OPEN.productPage.ratingsReviews.onTouchMove, false);
        if (!(dx === null)) {
            if ((Number(new Date()) - startT < 500) && Math.abs(dx) >= 50 || (Math.abs(dx) >= rrViewport / 2)) {
                if (!scrolling) {
                    OPEN.productPage.ratingsReviews.customCarousel.isAnimating = true;
                    dx > 0 && nextArrow.trigger('click');
                    dx < 0 && prevArrow.trigger('click');
                    if (noSlide)
                        $('#rr-module #slider').stop().animate({
                            "left": -offset
                        }, 500, "swing");
                }
            } else {


                $('#rr-module #slider').stop().animate({
                    "left": -offset
                }, 500, "swing");
            }
        }
        el.removeEventListener('touchend', OPEN.productPage.ratingsReviews.onTouchEnd, false);
        viewAllObj = null;
        startX = null;
        startY = null;
        dx = null;
        offset = null;

    },
    setTouchstartEvent: function () {
        if (rr_reviws.length != 0) { // 11A for R&R module start June A
            rr_reviws[0].addEventListener('touchstart', OPEN.productPage.ratingsReviews.onTouchStart, false);
        }
    },
    // 11A for R&R module start
    reInitiateRRCarousel: function (winWidth) {
        if (winWidth <= 660) {
            if (_bkpt != 320) {
                OPEN.productPage.ratingsReviews.customCarousel.setOnResize();
                _bkpt = 320;
               // console.log("lessthan 660")
            }
        } else if (winWidth <= 830) {
            if (_bkpt != 661) {
                OPEN.productPage.ratingsReviews.customCarousel.setOnResize();
                _bkpt = 661;
               // console.log("lessthan 830")
            }
        } else if (winWidth >= 831) {
            OPEN.productPage.ratingsReviews.customCarousel.setOnResize();
            _bkpt = 831;
            //console.log("greaterthan 830")
        } 
        //OPEN.productPage.ratingsReviews.customCarousel.setOnResize();
    }



};

   