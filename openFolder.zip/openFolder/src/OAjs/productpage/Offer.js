if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.offer) {
    OPEN.productPage.offer = {};
}

OPEN.productPage.offer.addClassForSplOffer = function () {
    $('.offer-details span.off-txt').parents('#overview-view1').addClass('spl-offer');
    $('.two .special-offer span.off-txt').parents('.special-offer p').addClass('det-spl'); /* Personalization */
};

OPEN.productPage.offer.setSpecialOffer = function() {
    $(window).width() < 661 ? $("#details .special-offer").not(".new-offer").insertAfter($("#details h3")) : $("#details .special-offer").not(".new-offer").appendTo(".col.two")
};