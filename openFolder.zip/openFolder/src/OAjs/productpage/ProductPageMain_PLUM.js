/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 Created on : Sep 12, 2016, 3:32:23 PM
 Author     : pjanmeja
 */

if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.plum) {
    OPEN.productPage.plum = {};
}
//Add logic on document ready
$(document).ready(function () {
    //Do the clenaup for plum card
    OPEN.productPage.plum.removeSplOfferForPlum(itag_pagename);
});

$(window).resize(function (v) {
});



OPEN.productPage.plum.removeSplOfferForPlum = function (itag_pagename) {   
    itag_pagename == "Plum" && $('.special-offer').find('p:empty').remove();
};