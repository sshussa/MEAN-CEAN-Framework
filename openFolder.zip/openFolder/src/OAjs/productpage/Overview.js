if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.overview) {
    OPEN.productPage.overview = {};
}

OPEN.productPage.alignArrows = function () {
    $(".slide-cont .custom-scrollbar ul>li>span").each(function () {
        if ($(window).width() > 660) {
            $(this).height() <= 21 ? $(this).css("margin-top", "4px") : $(this).css("margin-top", "-4px");
        } else {
            $(this).height() <= 15 ? $(this).css("margin-top", "2px") : $(this).css("margin-top", "-2px");
        }
    });
};

OPEN.productPage.overview.setoverviewHeight = function () {
    var u = $(window).width(),
            r = $(window).height(),
            t = 700 / 1280,
            w = u * t,
            padd = $("#product-footer").height() + parseInt($("#product-footer").css("margin-top")) + 8,
            ptop = $("#overview").length > 0 && ($('body').hasClass('res_Large') ? ($("#product-footer").height() + $("#ajnav").height() + 40) : ($("#product-footer").height() + $("#ajnav").height() + 20)); /*JuneB*/
    dis = $("#module-01");

    if (u > 660 && u < 831) {
        dis.css("height", "auto").find("#offer-overview").css({
            "height": "auto",
            "background-size": "auto"
        });
    } else {
        var aH = dis.find("#header-section").outerHeight() + dis.find(".offer-content").outerHeight(true);
        dis.css("height", (r - iNavHeight) > aH ? r - iNavHeight : aH);
        var oH = dis.height() - dis.find("#header-section").outerHeight();
        dis.find("#offer-overview").css({
            "height": oH > _overH ? oH : _overH
        }).css({
            "background-size": "100% " + $("#offer-overview").height() * 1.5 + "px"
        })
    }
    $("#overview").length > 0 ? ($(window).width() > 660 ? ($(".isNav:first").css({
        "padding-top": "0"
    }), $(".isNav:eq(1)").css({
        "padding-top": ptop + "px"
    })) : ($(".isNav:first").css({
        "padding-top": "0"
    }), $(".isNav:eq(1)").css({
        "padding-top": "0px"
    }))) : ($(window).width() > 660 ? $(".isNav:first").css({
        "padding-top": padd + "px"
    }) : $(".isNav:first").css({
        "padding-top": "0px"
    })); /*JulyB*/
    //} JUNE A
    $(window).width() > 660 && $(".card-content").css("top", -($(".card-content img").height() * 0.4347));
};

OPEN.productPage.overview.setPrevActionEvent = function (pagetitle) {
    $(".hp-prev").live("click", function () {
        var t = $(this).parent().parent().siblings().find(".hp-active-slide h2").html();
        var s = $(this).parent().parent().parent().attr("id");
        var r = pagetitle + "-" + s + "-" + t;
        (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", "click_BackInCarousel:" + r) : null
    });
};

OPEN.productPage.overview.setNextActionEvent = function (pagetitle) {
    $(".hp-next").live("click", function () {
        var t = $(this).parent().parent().siblings().find(".hp-active-slide h2").html();
        var s = $(this).parent().parent().parent().attr("id");
        var r = pagetitle + "-" + s + "-" + t;
        (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", "click_NextInCarousel:" + r) : null
    });
};
OPEN.productPage.overview.setTOPCssOnResize = function () {
    $("#overview").height() - $(".product-footer").height() <= $(window).height() ? $("#overview-view1 .hp-control-nav").css("top", $(window).height() - $("#ajnav").height() - $(".product-footer").height() + 25) : $("#overview-view1 .hp-control-nav").css({
        "top": "auto"
    });
};
