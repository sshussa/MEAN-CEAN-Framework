if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.inPageNav) {
    OPEN.productPage.inPageNav = {};
}

OPEN.productPage.inPageNav.navigate = function () {

    $("#ajnav .aj-inpage .in-page a").on("click", function () { /* junec */
        var b = $(this).text() + '_LeftNav';
        (typeof ($iTagTracker) == "function") ? $iTagTracker("rmaction", b) : null;
        if (!ios7) {
            _navFlag = true;
            $("#ajnav .aj-inpage .in-page a").parent().removeClass("active"); /* junec */
            $(this).parent().addClass("active");
        }
        OPEN.productPage.pageLoad.scrollSec($(this));
        // !touch && $("#" + $(this).attr("class")).find("input,a").eq(0).focus();

        var a = $(this).text().toLowerCase().replace(" ", "-");
        $("#" + a).parents(".module").addClass("visible").find(".view:eq(0)").addClass("bg");
        $("#" + a).parents(".module").next().addClass("visible").find(".view:eq(0)").addClass("bg");
        return false
    }).focus(function (a) {
        $("#ajnav .aj-inpage .in-page a").parent().removeClass("active"); /* junec */
        $(this).parent().addClass("active")
    })
};

OPEN.productPage.inPageNav.navigateSec = function () {
    var d = "";
    var c = $("#good-for ul li div .top-bg span:first-child");
    var x = $("#good-for ul li div .top-bg .good-for-span a"); /*debugathon*/
    var a = $("#good-for ul li div");
    c.live("click touch", function () {
        clearInterval(d);
        $("#good-for ul li").find("div").removeClass(ovr_cls);
        $(this).parent().parent().addClass(ovr_cls);
        d = setTimeout(function () {
            $(".list-overlay").removeClass(ovr_cls)
        }, 7000);
        $(this).parent().parent().addClass(ovr_cls).find(".close-icon").live("click touch", function () {
            $(this).parent().removeClass(ovr_cls);
            return false
        });
        return false
    });
    /*debugathon*/
    x.live("click touch", function () {
        clearInterval(d);
        $("#good-for ul li").find("div").removeClass(ovr_cls);
        $(this).parent().parent().parent().addClass(ovr_cls);
        d = setTimeout(function () {
            $(".list-overlay").removeClass(ovr_cls)
        }, 7000);
        $(this).parent().parent().parent().addClass(ovr_cls).find(".close-icon").live("click touch", function () {
            $(this).parent().removeClass(ovr_cls);
            return false
        });
        return false
    });

    $("body").live("click touch", function () {
        $(".list-overlay").removeClass(ovr_cls)
    });

    // var b = $("#wrapper").find(".isNav");
    // b.push($("#details"));
    //(isBgr) && b.push($("#open-benefits"));
    var b = (typeof RmMvt != "undefined" && RmMvt) ? ($("#wrapper").find(".isNav:visible").not("#expense-management")) : ($("#wrapper").find(".isNav:visible").not("#open-benefits")) /*augustA Release*/
    var crdSec = $("#wrapper").find(".isNav"); /*ios7*/ /* April A*/
    $(crdSec).bind("touchstart", function () {
        _navFlag = false
    }); /*ios7*/
    $(window).scroll(function (f) {
        if (!_navFlag) { /*ios7*/
            if ($(window).scrollTop() < 743) {
                $("#ajnav .aj-inpage .in-page li").removeClass("active"); /* junec */
                $("#ajnav .aj-inpage .in-page li:eq(0)").addClass("active"); /* junec */
            }
            b.each(function (index, element) {
                /* April A implementation*/
                /* @param secPos gives module position
                 @param inpageOffset gives inpage navigation position
                 @param moduleId gives id of a module or a sub module
                 @param currentnav gives respective module's in page navigation link index
                 @param currentnavtop gives postion of the present module's inpage nav link w.r.t to navigation
                 */
                var strT = $(".new-ajnav .aj-inpage .in-page").is(":visible") ? $('.new-ajnav .aj-inpage').offset().top + $("#product-footer").height() : 0; /* junec */
                var secPos = ($(element).offset().top - parseInt($(element).css("margin-top"))) - ($(".new-ajnav .aj-inpage .in-page").is(":visible") ? $(document).scrollTop() : 0),
                        inpageOffset = strT,
                        /*junec */
                        moduleId = !$(element).find(view_hld).attr("id") ? $(element).attr('id') : $(element).find(view_hld).attr("id"),
						currentnavtop = $(".new-ajnav .aj-inpage .in-page").is(":visible") ? $(window).height() / 2 : inpageOffset + 0,                        
                        secPos = (moduleId === "details") ? secPos + $("#product-footer").height() : secPos;
                secPos < currentnavtop ? ($("#ajnav .aj-inpage .in-page a." + moduleId + "").parent().is(":visible") && $("#ajnav .aj-inpage .in-page a").parent().removeClass("active"), $("#ajnav .aj-inpage .in-page a." + moduleId + "").parent(":visible").addClass("active")) : null; /* junec */
            });
            /*End Aprila */
        }
    });
    $("#ajnav .aj-inpage .in-page a").mouseleave(function (f) { /* junec */
        _navFlag = false
    })
};

OPEN.productPage.inPageNav.addClassToLastModule = function () {
    $(".module:lt(2)").addClass("visible").find(".view:first").addClass("bg");
};



OPEN.productPage.inPageNav.buildInPageNav =  function (modparent, modul, callBack) {

        emptyMod = modparent.find(modul).each(function (index, element) {
            moduleText = $.trim($(this).children("*").text());
            (moduleText == null || moduleText == "") ? $(this).remove() : null;
        });
        modules = container.find(modul);
        modules.each(function (index, element) {
             
            moduleId = $(this).find(".view-holder:first-child").attr("id");
            if (typeof moduleId != "undefined") {
                anchorId = moduleId.replace(/\-/g, '');
                anchorText = moduleId.replace(/\-/g, ' ');

            } else {
                // for sub module as inpage navigation
                // Add a class "isNav" 
                // And should have a id specific to this module
                moduleId = $(this).attr("id");
                anchorId = moduleId.replace(/\-/g, '');
                anchorText = OPEN.universal.subModuleNavMap[moduleId]["anchorText"];
           
            }
            if ($(this).hasClass("isNew")) {
               
                $("<span class='new'>NEW<span>").insertBefore($(this).find(".indicator"));
            }
            /* } march A*/
        });

    
        navliHt = OPEN.universal.navPanelPosIndexed();
        callBack();
    };

