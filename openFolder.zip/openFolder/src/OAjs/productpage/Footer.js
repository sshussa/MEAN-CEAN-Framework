if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.footer) {
    OPEN.productPage.footer = {};
}

OPEN.productPage.footer.setFooterPosition = function () {
    var overview = $("#overview").length > 0 ? true : false;
    !overview ? ($("body").addClass("setfixedpos"), ($(window).width() > 660 && $("#product-footer").addClass("scroll"))) : $("body").removeClass("setfixedpos");
    if (!overview) {
        $(window).bind('touchmove scroll', function (e) {
            $(window).width() > 660 && ($(this).scrollTop() >= iNavHeight ? $("#product-footer").removeClass("scroll") : $("#product-footer").addClass("scroll"));
        });
    }
};

OPEN.productPage.footer.addShareamexContainerEvent = function () {
    $(".shareamex-container ul li").live("click", function () {
        var r = $(this).attr("class").substr(10, 20);
        if (r == "GoogleBookmark") {
            r = r.substr(0, 6) + "+"
        }
        (typeof ($iTagTracker) == "function") ? $iTagTracker("socialaction", "<SocialMediaName>", "Share") : null
    });
};
OPEN.productPage.footer.addShareamexEmailEvent = function () {
    $(".shareamex-Email").live("click touch", function () {
        if ($(".shareamex-email").find(".shareamex-emailbox").html() == null) {
            var a = $(this).find(".shareamex-emailbox").clone();
            $(this).find(".shareamex-emailbox").remove();
            $(".shareamex-email").append(a).css({
                "left": ($(window).width() - a.width()) / 2 + "px",
                "top": ($(window).scrollTop() + 50) + "px"
            })
        } else {
            $(".shareamex-email").find(".shareamex-emailbox").remove()
        }
    });
};

OPEN.productPage.footer.addShareamexCloseEvent = function () {
   $(".shareamex-close").live("click touch", function () {
    $(this).parents(".shareamex-emailbox").remove()
});
};
OPEN.productPage.footer.setCardContentClass = function () {
   $(window).width() > 660 && $(".card-content").css("top", -($(".card-content img").height() * 0.4347));
};
