/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 Created on : Sep 12, 2016, 3:32:23 PM
 Author     : pjanmeja
 */

//Add logic on document ready
$(document).ready(function () {

    //Special alignment fix for simplycash
    OPEN.productPage.simplycash.fixAlignment();
    
    $("#npsl-video img,#npsl-video>a").live("click touchstart", function() {
    var npsl = $("#npsl-benefits");
                OPEN.component.playYouTubeVideo("#npsl-video","https://www.youtube.com/embed/QhXpa0y-i2U?autoplay=1&html5=1","",true,function(){
                                                !OPEN.universal.isMobile() && (!npsl.hasClass("activeFlag") && npsl.addClass("activeFlag").children(".content").css("display","block"));},function(){
                                                !OPEN.universal.isMobile() && (npsl.hasClass("activeFlag") && npsl.removeClass("activeFlag").children(".content").css("display","none"));
                                });	
		 
 	});
});

$(window).resize(function (v) {
    $("#overview-view1.pp-simplycash-01").length > 0 && OPEN.productPage.simplycash.fixAlignment(); /*August A*/
});