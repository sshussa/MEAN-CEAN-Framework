if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.pageLoad) {
    OPEN.productPage.pageLoad = {};
}

OPEN.productPage.pageLoad.scrollSec = function (a) {
    var navClass = a.attr("class"),
            ind = a.parent().index();
    a = a.text();
    var selector = $("#" + a.toLowerCase().split(" ").join("-")).hasClass("product-details") ? "#" + a.toLowerCase().split(" ").join("-") : ("#" + navClass);
    var isnavfirst = $(".isNav:eq(1)").attr("id"),
            footerHeight = $(selector).attr("id") == isnavfirst ? 0 : ($("#product-footer").height() + $("#ajnav").height()); /*JulyB*/
    if ($("#overview").length > 0) {
        if (!$("#" + a.toLowerCase().split(" ").join("-")).parent().hasClass("module1")) { // 11A for R&R module
            $("html, body").animate({
                "scrollTop": Number($(selector).offset().top - footerHeight)+3 /*Module reorder fix*/
            }, function () {
                if (isIpad2) {
                    $(window).scroll()
                }
                setTimeout(function () {
                    _navFlag = false
                }, 600);
                footerHeight > 0 && $("#details a:first").blur();
                console.log($("#product-footer").outerHeight(true) + "::::::::::" + Number($(selector).offset().top - footerHeight) + "::::::::::::::" + Number($(selector).offset().top - footerHeight))
            })
        } else {
            $("html, body").animate({
                    "scrollTop": Number($("#" + a.toLowerCase().split(" ").join("-")).parents(".module").offset().top-$("#ajnav").height())+3 /*Module reorder fix*/
            }, function () {
                if (isIpad2) {
                    $(window).scroll()
                }
            })
        }
    } else {
        var padd = ind == 0 ? 0 : (navClass == "details") ? $("#product-footer").height() : navClass == "rewards-benefits" ? $("#product-footer").height() + parseInt($("#product-footer").css("margin-top")) : $("#product-footer").height() + parseInt($("#product-footer").css("margin-top")); /*JuneB*/
         var scroll_height =  $(body).hasClass('res_Small')? ($(selector).offset().top - padd-$("#product-footer").height())+3:($(selector).offset().top - padd)+3 /*Module reorder fix*/
        $("html, body").animate({
            "scrollTop": ($(selector).offset().top - padd)+3 /*Module reorder fix*/
        }, function () {
            console.log($(window).scrollTop() + ":::::" + $(selector).index())
        })
    }
};

OPEN.productPage.pageLoad.init = function () {
    OPEN.productPage.overview.setoverviewHeight(); /*aprilb*/
    OPEN.productPage.inPageNav.navigate();
    OPEN.productPage.inPageNav.navigateSec();
    OPEN.productPage.ratingsReviews.customCarousel.init(); // 11A for R&R module start
    OPEN.productPage.alignArrows(); /* MAY A */
    OPEN.config = {
        CLS: {
            scrl_arrow: $(".scroll-arrow"),
            only_mdle: $(".onlyModule"),
            isTT: $("#spotlight-nav").css("display") == "block" ? true : false,
            MWWrapper:$(".page-wrapper"),
            modules:$(".isNav:visible").not(".open-benefits"),
            scrollPadding:$("#product-footer").outerHeight(),
            lastscrollPadding:0
        },
        APP: {            
            module_array: []           
        }
    }
    void 0 !== OPEN.moduleNav && OPEN.moduleNav.moduleNavPageReady(OPEN.config);

};
