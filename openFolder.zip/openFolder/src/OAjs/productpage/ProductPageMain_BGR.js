if (!window.OPEN) {
    var OPEN = {}
}

if (!window.OPEN.productPage) {
    OPEN.productPage = {};
}

if (!window.OPEN.productPage.bgr) {
    OPEN.productPage.bgr = {};
}


//Add logic on document ready
$(document).ready(function () {

    //Add expense managment slides in the list
    OPEN.productPage.expenseManagement.updateSlidesList(mngSld);
    //Set active class
    OPEN.productPage.expenseManagement.setActiveClass();

    //Add event to build the carousel
    OPEN.productPage.expenseManagement.addBuildCarouselEvent(crSld);
    //Get prefix to define css for Expense managmenet 
    prefix = OPEN.productPage.expenseManagement.getPrefixForAnimation();
    //Bind touch event 
    OPEN.productPage.expenseManagement.bindTouchEvent(em_slds);
    //Bind click event
    OPEN.productPage.expenseManagement.bindClickEvent();
    //Apply font fix
    OPEN.productPage.expenseManagement.applyFontFix();

    OPEN.productPage.expenseManagement.changeClassOnAvailable();


    OPEN.productPage.expenseManagement.animateOnAvailable();

    $('#details').hasClass('product_gold') && $('body').addClass('gld_crd');

    /*fix the fontsize above 1280 bkp*/
    document.documentElement.clientWidth > 1024 ? $("#expense-management").addClass("fontfix") : $("#expense-management").removeClass("fontfix");

    $(window).width() < 661 ? $("#expense-management").css("margin-left", ($("#expense-benefits").width() - $("#expense-management").outerWidth()) / 2) : null

});



//Add event for window load
$(window).load(function () {
    OPEN.productPage.expenseManagement.setHeightOnResize();

});

//Event on resize end
$(window).bind('resizeEnd', function () {
    /* !ie78 && */
    OPEN.productPage.expenseManagement.setHeightOnResize();
    OPEN.productPage.expenseManagement.setClassOnResize();
});