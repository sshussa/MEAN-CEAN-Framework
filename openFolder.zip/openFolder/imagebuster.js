/**
 * Module: v10
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: v10 - <DESC_HERE>
 */
'use strict';
module.exports = {
    version: "1",//ovverride it as per requirement 
    supportedImages: [".png", ".jpg", ".gif", ".jpeg"],//ovverride it as per requirement 
    //Change the version of image in css to bust the cache
    cssImageBuster: function (file, enc, callback) {
        var stringData = String(file.contents);
        //loop for each supported images types
        for (var i = 0; i < module.exports.supportedImages.length; i++) {
            //add version of image
            stringData = cssImageBusterForOneImageType(stringData, module.exports.supportedImages[i]);
        }
        var finalBinaryData = new Buffer(stringData, "binary");
        file.contents = finalBinaryData;
        callback(null, file);
    },
    //Change the version of image in css to bust the cache
    jsImageBuster: function (file, enc, callback) {
        var stringData = String(file.contents);
        //replace the version
        var finalVar = "?" + module.exports.version;
        var placeholder = "#resource_version";
        stringData = replaceAll(placeholder, finalVar, stringData);
        var finalBinaryData = new Buffer(stringData, "binary");
        file.contents = finalBinaryData;
        callback(null, file);
    }
};
function replaceAll(find, replace, str) {
    return str.replace(new RegExp(find, 'g'), replace);
}
//Bust cache for one image type in a file
var cssImageBusterForOneImageType = function (stringData, imageExtension) {
    //replace the version
    var finalVar = imageExtension + "?" + module.exports.version;
    var placeholder = imageExtension;
    return replaceAll(placeholder, finalVar, stringData);
};