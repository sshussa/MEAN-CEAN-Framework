/**
 * Module: v10
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: v10 - <DESC_HERE>
 */
'use strict';
// loads various gulp modules
var version = "5";
var supportedImages = [".png", ".jpg", ".gif", ".jpeg"];
var gulp = require('gulp');
var concat = require('gulp-concat');
var minifyCSS = require('gulp-minify-css');
var uglifyJs = require('gulp-uglify');
var autoprefixer = require('gulp-autoprefixer');
var runSequence = require('run-sequence');
var spritesmith = require('gulp.spritesmith');
var through = require('through2');
var fs = require('fs');
var es = require("event-stream");
var sort = require('gulp-sort');
var jshint = require('gulp-jshint');
var csslint = require('gulp-csslint');
var clean = require('gulp-clean');
var watch = require('gulp-watch');
var livereload = require('gulp-livereload');
// To check file size
var checkFilesize = require('./gulp-check-filesize');
var imagebuster = require('./imagebuster');
var imagemin = require('gulp-imagemin');
var colors = require('colors');
//Ovverride image buster config
imagebuster.version = version;
imagebuster.supportedImages = supportedImages;

//Define config for assets
var config = {
    "src": {
        cssPath: './src/OAcss',
        htmlPath: './src/OAhtml',
        imagesPath: './src/OAimages',
        jsPath: './src/OAjs',
        jsonPath: './src/json'
    },
    "dest": {
        cssPath: './OAcss',
        htmlPath: './OAhtml',
        imagesPath: './OAimages',
        jsPath: './OAjs',
        jsonPath: './json'
    }
};

var goodFor = {
    "src": {
        imagesPath: './src/OAimages/amex-open/goodfor',
        "cards": [
            {
                "name": "bgr",
                "icons": ["advertising.png", "e-commerce.png", "financial-tools.png", "frequent-flyers.png", "large-business.png"]
            },
            {
                "name": "blue",
                "icons": ["payment-flexibility.png", "business-expenses.png"]
            },
            {
                "name": "green",
                "icons": ["no-fee.png", "purchasing-power.png", "business-expenses.png"]
            },
            {
                "name": "bplat",
                "icons": ["frequent-travelers.png", "airport-lounge-access.png", "concierge-service.png"]
            },
            {
                "name": "deltareserve",
                "icons": ["delta-sky-club.png", "medallion-status.png", "concierge-service.png", "priority-delta-flights.png"]
            },
            {
                "name": "deltagold",
                "icons": ["priority-delta-flights.png", "in-flight-discount.png"]
            },
            {
                "name": "lowe",
                "icons": ["home-improvement.png", "construction-business.png", "property-management.png"]
            },
            {
                "name": "deltaplat",
                "icons": ["medallion-status.png", "in-flight-discount.png", "priority-delta-flights.png"]
            },
            {
                "name": "simply-cash-plus",
                "icons": ["customize-rewards.png", "large-business.png", "wireless-subsribers.png"]
            },
            {
                "name": "starwood",
                "icons": ["award-nights.png", "free-flights-with-SPG.png", "sheraton-club.png", "spg-gold-status.png"]
            },
            {
                "name": "plum",
                "icons": ["seasonal-businesses.png", "financial-control.png", "billing-cycle.png"]
            }
        ]
    },
    "dest": {
        imagePath: './OAimages/amex-open/goodfor', //image needs to directly generate at dest to directly used.
        cssPath: './src/OAcss/goodfor' //css will be generated at source so that it can be concatnate with final css file
    }
};

/*var goodForNewCompare = {
    "src": {
        imagesPath: './src/OAimages/amex-open/comparepage/goodforicon',
        "cards": [
            {
                "name": "bgr",
                "icons": ["e-commerce.png", "financial-tools.png", "frequent-flyers.png", "large-business.png"]
            },
            {
                "name": "blue",
                "icons": ["payment-flexibility.png", "business-expenses.png"]
            },
            {
                "name": "green",
                "icons": ["no-fee.png", "purchasing-power.png", "business-expenses.png"]
            },
            {
                "name": "bplat",
                "icons": ["frequent-travelers.png", "airport-lounge-access.png", "concierge-service.png"]
            },
            {
                "name": "deltareserve",
                "icons": ["delta-sky-club.png", "medallion-status.png", "concierge-service.png", "priority-delta-flights.png"]
            },
            {
                "name": "deltagold",
                "icons": ["priority-delta-flights.png", "in-flight-discount.png"]
            },
            {
                "name": "lowe",
                "icons": ["home-improvement.png", "construction-business.png", "property-management.png"]
            },
            {
                "name": "deltaplat",
                "icons": ["medallion-status.png", "in-flight-discount.png", "priority-delta-flights.png"]
            },
            {
                "name": "simply-cash-plus",
                "icons": ["customize-rewards.png", "large-business.png", "wireless-subsribers.png"]
            },
            {
                "name": "starwood",
                "icons": ["award-nights.png", "free-flights-with-SPG.png", "sheraton-club.png", "spg-gold-status.png"]
            },
            {
                "name": "plum",
                "icons": ["seasonal-businesses.png", "financial-control.png", "billing-cycle.png"]
            }
        ]
    },
    "dest": {
        imagePath: './OAimages/amex-open/goodfor/comparepage', //image needs to directly generate at dest to directly used.
        cssPath: './src/OAcss/goodfor/comparepage' //css will be generated at source so that it can be concatnate with final css file
    }
};*/

var getGoodForSrcPath = function (icons, type) {
    var goodForSrcPath = [];
    if (typeof icons !== "undefined" && icons.length > 0) {
        for (var i = 0; i < icons.length; i++) {
            var path = goodFor.src.imagesPath + "/" + type + "/" + icons[i];
            goodForSrcPath.push(path);
            console.log(path);
        }
    }
    return goodForSrcPath;
};

/*var newcomparepredefbucket = {
    "src": {
        imagesPath: './src/OAimages/amex-open/comparepage/comparebucket/retina',
        "imagesprite": [
            {
                "name": "compare-predef-bucket",
                "arts": ["most-popular.png", "most-popular_hover.png", "travel-reward.png", "travel-reward_hover.png", "flexible-payments.png","flexible-payments_hover.png", "cash-back.png", "cash-back_hover.png", "no-annual-fee.png", "no-annual-fee_hover.png"]
            }
			
        ]
    },
    "dest": {
        imagePath: './OAimages/amex-open/comparepage/comparebucket/', //image needs to directly generate at dest to directly used.
        cssPath: './src/OAcss/comparepage' //css will be generated at source so that it can be concatnate with final css file
    }
};


var getSpriteSrcPath = function (srcImgPath,icons, type) {
    var cardSpriteSrcPath = [];
    if (typeof icons !== "undefined" && icons.length > 0) {
        for (var i = 0; i < icons.length; i++) {
            var path = srcImgPath + "/" + type + "/" + icons[i];
            cardSpriteSrcPath.push(path);
            //console.log(path);
        }
    }
    return cardSpriteSrcPath;
};*/

var flatcardart = {
    "src": {
        imagesPath: './src/OAimages/amex-open/cardarts/thumbnail/flat',
        "cardsprite": [
            {
                "name": "flat-card-arts-1",
                "arts": ["flat-cardart-92.png", "flat-cardart-251.png", "flat-cardart-756.png"]
            },
            {
                "name": "flat-card-arts-2",
                "arts": ["flat-cardart-111.png", "flat-cardart-474.png", "flat-cardart-141.png"]
            },
            {
                "name": "flat-card-arts-3",
                "arts": ["flat-cardart-113.png", "flat-cardart-89.png", "flat-card-art-placeholder-min.png"]
            },
            {
                "name": "flat-card-arts-4",
                "arts": ["flat-cardart-499.png", "flat-cardart-79.png", "flat-cardart-1043.png"]
            }
			
        ]
    },
    "dest": {
        imagePath: './OAimages/amex-open/cardarts/thumbnail/flat', //image needs to directly generate at dest to directly used.
        cssPath: './src/OAcss/cardsprite' //css will be generated at source so that it can be concatnate with final css file
    }
};

var getVacCardSpriteSrcPath = function (icons, type) {
    var vacCardSpriteSrcPath = [];
    if (typeof icons !== "undefined" && icons.length > 0) {
        for (var i = 0; i < icons.length; i++) {
            var path = flatcardart.src.imagesPath + "/" + type + "/" + icons[i];
            vacCardSpriteSrcPath.push(path);
            //console.log(path);
        }
    }
    return vacCardSpriteSrcPath;
};

function replaceAll(find, replace, str) {
    return str.replace(new RegExp(find, 'g'), replace);
}

var updateSpriteCSS = function (file, enc, callback) {
    var stringData = String(file.contents);
    //replace icon- from the generated css
    stringData = replaceAll(".icon-", ".", stringData);
    var finalBinaryData = new Buffer(stringData, "binary");
    file.contents = finalBinaryData;
    callback(null, file);
};
var getFilesList = function (folderPath) {
    var files = fs.readdirSync(folderPath);
    //Iterate and remove .DS_Store
    var indexOfUnusedFile = -1;
    for (var i = 0; i < files.length; i++) {
        var file = files[i];
        if (file === '.DS_Store') {
            indexOfUnusedFile = i;
        }
    }
    if (indexOfUnusedFile !== -1) {
        files.splice(indexOfUnusedFile, 1);
    }
    //return the list
    return files;
};

var cssForRetinaIconSprite = function () {
    return '{transform: scale(.5);transform-origin:0 0;-webkit-transform: scale(.5);-webkit-transform-origin:0 0;-moz-transform:scale(.5);-moz-transform-origin:0 0;}';
};

var extraCSSForRetinaRatingsIcons = function () {
    //for mozilla fix
    return '.rating-holder{margin-right:-72px!important}';
};

var addBackgroundCSSForSprite = function (cssClass) {
    //for mozilla fix
    return cssClass+'{background-repeat: no-repeat;}';
};

var getRetinaCSSSelectorForIconSprite = function (folderPath, extension) {
    //Get the list of files
    var iconsList = getFilesList(folderPath);
    //Iterarate each to create the css selector
    var css = "";
    for (var i = 0; i < iconsList.length; i++) {
        var className = iconsList[i].replace(extension, '');
        css = css + '.' + className;
        //Add comma except for the last one
        if (i !== iconsList.length - 1) {
            css = css + ',';
        }
    }
    return css;
};

var getRetinaCSSForIconSprite = function (folderPath, extension) {
    //Get the css slector
    var css = getRetinaCSSSelectorForIconSprite(folderPath, extension);
    //get the css for retina
    var cssForRetina = cssForRetinaIconSprite();
    //Create final class
    css = css + cssForRetina;
    return css;
};

//Following pipe filter is currently only for icon sprites. Do not use for Good for or others
var addRetinaCSSForIconSprite = function (file, enc, callback) {
    var stringData = String(file.contents);
    //Get css for retina
    var retinaCss = getRetinaCSSForIconSprite(config.src.imagesPath + '/amex-open/icons/retina', '.png');
    //append the retina css
    stringData = stringData + '\n' + retinaCss;
    //Add extra css
    stringData = stringData + '\n' + extraCSSForRetinaRatingsIcons();
    var finalBinaryData = new Buffer(stringData, "binary");
    file.contents = finalBinaryData;
    callback(null, file);
};

gulp.task('goodforsprite', function () {
    //generate sprite for all cards
    for (var i = 0; i < goodFor.src.cards.length; i++) {
        var spriteData =
                gulp.src(getGoodForSrcPath(goodFor.src.cards[i].icons, 'retina')) // source path of the sprite images                
                .pipe(spritesmith({
                    imgName: goodFor.src.cards[i].name + '-sprite.png',
                    cssName: goodFor.src.cards[i].name + '-sprite.css',
                    padding: 5,
                    algorithm: 'left-right',
                    imgPath: '.' + goodFor.dest.imagePath + '/' + goodFor.src.cards[i].name + '-sprite.png',
                    cssOpts: {
                        cssSelector: function (sprite) {
                            return addBackgroundCSSForSprite('.'+sprite.name)+'.' + sprite.name;
                        }
                    }

                }));
        spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(goodFor.dest.imagePath)); // output path for the sprite
        spriteData.css.pipe(gulp.dest(goodFor.dest.cssPath)); // output path for the CSS
    }
});

/*gulp.task('goodforspritenewcompare', function () {
    //generate sprite for all cards
    for (var i = 0; i < goodForNewCompare.src.cards.length; i++) {
        var spriteData =
                gulp.src(getGoodForSrcPath(goodForNewCompare.src.imagesPath,goodForNewCompare.src.cards[i].icons, 'retina')) // source path of the sprite images                
                .pipe(spritesmith({
                    imgName: goodForNewCompare.src.cards[i].name + '-sprite.png',
                    cssName: goodForNewCompare.src.cards[i].name + '-sprite.css',
                    padding: 5,
                    algorithm: 'left-right',
                    imgPath: '.' + goodForNewCompare.dest.imagePath + '/' + goodForNewCompare.src.cards[i].name + '-sprite.png',
                    cssOpts: {
                        cssSelector: function (sprite) {
                            return addBackgroundCSSForSprite('.newcompare .'+sprite.name)+'.newcompare .' + sprite.name;
                        }
                    }

                }));
        spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(goodForNewCompare.dest.imagePath)); // output path for the sprite
        spriteData.css.pipe(gulp.dest(goodForNewCompare.dest.cssPath)); // output path for the CSS
    }
});*/


gulp.watch('goodFor.src.cards', function (event) {
    console.log('watching images ', event);
}, true);


/*gulp.watch('goodForNewCompare.src.cards', function (event) {
    console.log('watching images ', event);
}, true);*/


gulp.task('flatcardartspriteretina', function () {

    //generate sprite for all cards
    for (var i = 0; i < flatcardart.src.cardsprite.length; i++) {
        var spriteData =
                gulp.src(getVacCardSpriteSrcPath(flatcardart.src.cardsprite[i].arts, 'retina')) // source path of the sprite images                
                .pipe(spritesmith({
                    imgName: flatcardart.src.cardsprite[i].name + '-sprite.png',
                    padding: 5,
                    algorithm: 'left-right',
                    cssName: flatcardart.src.cardsprite[i].name + '-sprite-retina.css',
                    imgPath: '.' + flatcardart.dest.imagePath + '/retina/' + flatcardart.src.cardsprite[i].name + '-sprite.png',
                    cssOpts: {
                        cssSelector: function (sprite) {
                            return addBackgroundCSSForSprite('.xhd .' + sprite.name)+ '.xhd .' + sprite.name;
                        }
                    }

                }));
        spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(flatcardart.dest.imagePath + '/retina')); // output path for the sprite
        spriteData.css.pipe(gulp.dest(flatcardart.dest.cssPath + '/retina')); // output path for the CSS
    }
});

gulp.task('flatcardartspritenormal', function () {

    //generate sprite for all cards
    for (var i = 0; i < flatcardart.src.cardsprite.length; i++) {
        var spriteData =
                gulp.src(getVacCardSpriteSrcPath(flatcardart.src.cardsprite[i].arts, 'normal')) // source path of the sprite images                
                .pipe(spritesmith({
                    imgName: flatcardart.src.cardsprite[i].name + '-sprite.png',
                    padding: 5,
                    algorithm: 'left-right',
                    cssName: flatcardart.src.cardsprite[i].name + '-sprite-normal.css',
                    imgPath: '.' + flatcardart.dest.imagePath + '/normal/' + flatcardart.src.cardsprite[i].name + '-sprite.png',
                    cssOpts: {
                        cssSelector: function (sprite) {
                            return addBackgroundCSSForSprite('.normal .' + sprite.name)+'.normal .' + sprite.name;
                        }
                    }

                }));
        spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(flatcardart.dest.imagePath + '/normal')); // output path for the sprite
        spriteData.css.pipe(gulp.dest(flatcardart.dest.cssPath + '/normal')); // output path for the CSS
    }
});
gulp.task('flatcardartspritenormalsmall', function () {
    //generate sprite for all cards
    for (var i = 0; i < flatcardart.src.cardsprite.length; i++) {
        var spriteData =
                gulp.src(getVacCardSpriteSrcPath(flatcardart.src.cardsprite[i].arts, 'normalsmall')) // source path of the sprite images                
                .pipe(spritesmith({
                    imgName: flatcardart.src.cardsprite[i].name + '-sprite.png',
                    padding: 5,
                    algorithm: 'left-right',
                    cssName: flatcardart.src.cardsprite[i].name + '-sprite-normalsmall.css',
                    imgPath: '.' + flatcardart.dest.imagePath + '/normalsmall/' + flatcardart.src.cardsprite[i].name + '-sprite.png',
                    cssOpts: {
                        cssSelector: function (sprite) {
                            return addBackgroundCSSForSprite('.normal .' + sprite.name)+'.normal .' + sprite.name;
                        }
                    }

                }));
        spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(flatcardart.dest.imagePath + '/normalsmall')); // output path for the sprite
        spriteData.css.pipe(gulp.dest(flatcardart.dest.cssPath + '/normalsmall')); // output path for the CSS
    }
});

//task to create sprite for icons
gulp.task('iconspriteretina', function () {
    var spriteData =
            gulp.src(config.src.imagesPath + '/amex-open/icons/retina/*.*') // source path of the sprite images
            .pipe(spritesmith({
                imgName: 'icons-sprite.png',
                padding: 5,
                algorithm: 'top-down',
                cssName: 'icons-sprite.css',
                imgPath: '.' + config.dest.imagesPath + '/amex-open/icons/retina/icons-sprite.png',
                cssOpts: {
                    cssSelector: function (sprite) {
                        var additionalCSS= addBackgroundCSSForSprite('.'+sprite.name);
                        var css;
                        //For radio button checked, change the class name
                        if (sprite.name === 'radio-quiz-checked') {
                            css = '.radio-quiz-normal.active';
                        } else if (sprite.name === 'rewards-icon-white') { //keep product page 320bkpt accordian icon namd same as desktop to keep same markup
                            css =  '.open.res_Small .rewards-icon';
                        } else if (sprite.name === 'travel-icon-white') {
                            css =  '.open.res_Small .travel-icon';
                        } else if (sprite.name === 'card-reviews-icon-white') {//card review icon only for 320bkpt
                            css =  '.open.res_Small .card-reviews-icon-white';
                        } else if (sprite.name === 'active-call-icon') {//keep em only for 320bkpt
                            css =  '.active.call-icon';
                        } else if (sprite.name === 'active-chat-icon') {//keep em only for 320bkpt
                            css =  '.active.chat-icon';
                        } else if (sprite.name === 'open-logo-icon-white') { //This is only for proudct page 320bkpt
                            css =  '.open.res_Small #open-benefits .open-logo-icon';
                        } else if (sprite.name === 'open-logo-icon-retina') { //This is only for mac
                            css =  '.open.xhd .open-logo-icon';
                        } else if (sprite.name === 'open-logo-icon-normal') { //This is only for window
                            css =  '.open.normal .open-logo-icon';   
                        } else if (sprite.name === 'access-to-benefits-icon-white') {
                            css =  '.open.res_Small .access-to-benefits-icon';
                        } else if (sprite.name === 'card-reviews-icon-white') {//card review icon only for 320bkpt
                            css =  '.open.res_Small .card-reviews-icon-white';
                        } else {
                            css =  '.' + sprite.name;
                        }
                        return additionalCSS+css;
                    }
                }
            }));
    spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(config.dest.imagesPath + '/amex-open/icons/retina')); // output path for the sprite
    spriteData.css
            .pipe(through.obj(addRetinaCSSForIconSprite))
            .pipe(gulp.dest(config.src.cssPath + '/icons/retina')); // output path for the CSS
});


//task to create card by type icons
gulp.task('cardsbytypesprite', function () {
    var spriteData =
            gulp.src(config.src.imagesPath + '/amex-open/cardbytype/retina/*.*') // source path of the sprite images
            .pipe(spritesmith({
                imgName: 'cardsbytype-sprite.png',
                padding: 5,
                algorithm: 'left-right',
                cssName: 'cardsbytype-sprite.css',
                imgPath: '.' + config.dest.imagesPath + '/amex-open/cardbytype/cardsbytype-sprite.png',
                cssOpts: {
                    cssSelector: function (sprite) {
                        return addBackgroundCSSForSprite('.'+sprite.name)+'.' + sprite.name;

                    }
                }
            }));
    spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(config.dest.imagesPath + '/amex-open/cardbytype')); // output path for the sprite
    spriteData.css.pipe(gulp.dest(config.src.cssPath + '/cardbytype')); // output path for the CSS
});


//task to create card by type icons
/*gulp.task('comparepredefbucket', function () {
    var spriteData =
            gulp.src(config.src.imagesPath + '/amex-open/comparepage/comparebucket/retina/*.*') // source path of the sprite images
            .pipe(spritesmith({
                imgName: 'comparepredefbucket-sprite.png',
                padding: 5,
                algorithm: 'left-right',
                cssName: 'comparepredefbucket-sprite.css',
                imgPath: '.' + config.dest.imagesPath + '/amex-open/comparepage/comparepredefbucket-sprite.png',
                cssOpts: {
                    cssSelector: function (sprite) {
                        return addBackgroundCSSForSprite('.newcompare .'+sprite.name)+'.newcompare .' + sprite.name;

                    }
                }
            }));
    spriteData.img.pipe(imagemin({progressive: true})).pipe(gulp.dest(config.dest.imagesPath + '/amex-open/comparepage')); // output path for the sprite
    spriteData.css.pipe(gulp.dest(config.src.cssPath + '/comparepage')); // output path for the CSS
});*/

var goodforspritechange = './src/OAimages/amex-open/goodfor/retina/*';
//var goodfornewcomparespritechange = './src/OAimages/amex-open/goodfor/comparepage/retina/*';
var iconspritechange = './src/OAimages/amex-open/icons/retina/*';
var flatcardartspriteretinachange = './src/OAimages/amex-open/cardarts/thumbnail/flat/retina/*';
var flatcardartspritenormalchange = './src/OAimages/amex-open/cardarts/thumbnail/flat/normal/*';
var cardsbytypespritechange = './src/OAimages/amex-open/cardsbytype/retina/*';
//var comparepredefbucketchange = './src/OAimages/amex-open/comparepage/comparebucket/retina/*';
var basichtml = './src/OAhtml/**/*';

gulp.task('watch', function () {

    //gulp.watch(goodfornewcomparespritechange, ['goodforspritenewcompare']);
    gulp.watch(goodforspritechange, ['goodforsprite']);
    gulp.watch(iconspritechange, ['iconspriteretina']);
    gulp.watch(flatcardartspriteretinachange, ['flatcardartspriteretina']);
    gulp.watch(flatcardartspritenormalchange, ['flatcardartspritenormal']);
    gulp.watch(cardsbytypespritechange, ['cardsbytypesprite']);
    //gulp.watch(comparepredefbucketchange, ['comparepredefbucket']);
    gulp.watch(basichtml, ['copy']);

});

//Copy all static files which are not suppose to process
//var staticFiles = [config.src.htmlPath + '/**/*', config.src.imagesPath + '/**/*', config.src.jsonPath + '/**/*', '!' + config.src.imagesPath + '/amex-open/icons/**', '!' + config.src.imagesPath + '/amex-open/goodfor/**', '!' + config.src.imagesPath + '/amex-open/cardbytype/**', '!' + config.src.imagesPath + '/amex-open/cardarts/thumbnail/flat/normalsmall/**', '!' + config.src.imagesPath + '/amex-open/cardarts/thumbnail/flat/normal/flat-card-art-placeholder-min.png', '!' + config.src.imagesPath + '/amex-open/comparepage/comparebucket/**', '!' + config.src.imagesPath + '/amex-open/comparepage/goodforicon/**'];
var staticFiles = [config.src.htmlPath + '/**/*', config.src.imagesPath + '/**/*', config.src.jsonPath + '/**/*', '!' + config.src.imagesPath + '/amex-open/icons/**', '!' + config.src.imagesPath + '/amex-open/goodfor/**', '!' + config.src.imagesPath + '/amex-open/cardbytype/**', '!' + config.src.imagesPath + '/amex-open/cardarts/thumbnail/flat/normalsmall/**', '!' + config.src.imagesPath + '/amex-open/cardarts/thumbnail/flat/normal/flat-card-art-placeholder-min.png'];
gulp.task('copy', function () {
    //Copy all html, images, json
    gulp.src(staticFiles, {"base": "./src"}).pipe(gulp.dest('./'));
});

var productPagesCSS = [
    {
        "name": "bplat",
        "css": 'business-platinum-card'
    },
    {
        "name": "bgr",
        "css": 'american-express-gold-business-card'
    },
    {
        "name": "plum",
        "css": 'american-express-plum-card'
    },
    {
        "name": "starwood",
        "css": 'starwood-business-credit-card'
    },
    {
        "name": "deltagold",
        "css": 'gold-delta-skymiles-business-credit-card'
    },
    {
        "name": "green",
        "css": 'american-express-green-business-card'
    },
    {
        "name": "simply-cash-plus",
        "css": 'simply-cash-plus-business-credit-card'
    },
    {
        "name": "blue",
        "css": 'american-express-blue-for-business-credit-card'
    },
    {
        "name": "deltaplat",
        "css": 'platinum-delta-skymiles-business-credit-card'
    },
    {
        "name": "deltareserve",
        "css": 'delta-reserve-business-credit-card'
    },
    {
        "name": "lowe",
        "css": 'lowes-business-rewards-credit-card'
    }
];

//Common css for all product pages
var commonProductPageNonImgSrcCss = [
    config.src.cssPath + '/common/custom-scrollbar.css',
    config.src.cssPath + '/productpage/in-page-nav.css',
    config.src.cssPath + '/productpage/in-page-nav-nonimg.css',
    config.src.cssPath + '/productpage/offer-nonimg.css',
    config.src.cssPath + '/productpage/overview-nonimg.css',
    config.src.cssPath + '/icons/retina/icons-sprite.css',
    config.src.cssPath + '/productpage/ratings-stats.css',
    config.src.cssPath + '/productpage/footer.css',
    config.src.cssPath + '/productpage/footer-nonimg.css',
    config.src.cssPath + '/productpage/details.css',
    config.src.cssPath + '/productpage/good-for.css',
    config.src.cssPath + '/productpage/accordian.css',
    config.src.cssPath + '/productpage/benefits.css',
    config.src.cssPath + '/productpage/card-reviews.css',
    config.src.cssPath + '/productpage/common.css',
    config.src.cssPath + '/productpage/super-sub-script.css',
    config.src.cssPath + '/component/scroll-arrow-nav_module.css',
    config.src.cssPath + '/component/custom-background.css'
];

var createProductPageCSS = function (productName, type, commonFilesList, productCss, callback) {
    console.log("createProductPageCSS >> " + productName + "   " + type + "   " + productCss);
    //first do for imaginary
    var destCss = "product-page-" + type + "-" + productCss + ".css";
    // create final list of source css file list
    var srcCss = commonFilesList.slice(0); //create new instance
    //Add card specfic specific css
    if (type === 'img') {
        srcCss.splice(6, 0, config.src.cssPath + '/productpage/offer-' + productName + '.css');
        srcCss.splice(8, 0, config.src.cssPath + '/productpage/overview-' + type + '-' + productName + '.css');
    } else {
        srcCss.splice(6, 0, config.src.cssPath + '/productpage/offer-' + type + '-' + productName + '.css');
        srcCss.splice(8, 0, config.src.cssPath + '/productpage/overview-' + type + '-' + productName + '.css');
    }
    //Add BGR specfic code
    if (productName === "bgr") {
        srcCss.push(config.src.cssPath + '/productpage/expense-management.css');
    }
    //Add SC+ specfic code for the video module
    if (productName === "simply-cash-plus") {
        srcCss.push(config.src.cssPath + '/productpage/simply-cash-npsl.css');
        srcCss.push(config.src.cssPath + '/component/video_module.css');
    }
    //Add BPLAT enhanced benefits module css code
    if (productName === "bplat") {
        srcCss.push(config.src.cssPath + '/productpage/enhanced-benefits.css');
    }
    //Add good for card specfic
    srcCss.push(config.src.cssPath + '/goodfor/' + productName + '-sprite.css');
    //run gulp
    gulp.src(srcCss)
            .pipe(csslint())
            .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
            .pipe(minifyCSS())
            .pipe(concat(destCss, {newLine: ' '}))
            .pipe(through.obj(imagebuster.cssImageBuster))
            .pipe(gulp.dest(config.dest.cssPath))
            .on('end', callback)
            .pipe(livereload());
};

//create both non img and img css for product page
var createBothIMGAndNONImgProductPageCSS = function (productPagesCSS, i, callback) {
    var product = productPagesCSS[i];
    var productName = product.name;
    var productCss = product.css;
    //generate for non imaginary
    createProductPageCSS(productName, "nonimg", commonProductPageNonImgSrcCss, productCss, function () {
        console.log("Finished non img processing of " + productName);
        //now call for next product recursively  until all are finished
        i++;
        if (i < productPagesCSS.length) {
            createBothIMGAndNONImgProductPageCSS(productPagesCSS, i, callback);
        } else {
            callback();
        }
    });
};



var createBothIMGAndNONImgCSSForAllProductPage = function (callback) {
    //Start creating css for product page recursively to avoid asynchronous call
    createBothIMGAndNONImgProductPageCSS(productPagesCSS, 0, callback);
};


//task for product page css
gulp.task('productpagecss', function (callback) {
    createBothIMGAndNONImgCSSForAllProductPage(function () {
        console.log("Finished processing of all product pages css");
        if (callback) {
            callback();
        }
    });
});

function getdate(){
var currentdate = new Date(); 
var datetime =  currentdate.getDate() + "-"
                + (currentdate.getMonth()+1)  + "-" 
                + currentdate.getFullYear() + " @ "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();

				return datetime;
}

//Task for watcher and livereload
var productPageNonImgSrcCssWatcher = commonProductPageNonImgSrcCss.slice(0); //create new instance;
productPageNonImgSrcCssWatcher.push(config.src.cssPath + '/productpage/expense-management.css');
gulp.watch(productPageNonImgSrcCssWatcher, function (event) {
    livereload.listen();
    console.log('Last', event.type+" at "+getdate().yellow.bold);
    if (event.type == 'changed') {
        gulp.start('productpagecss');
    }
});
var productPageNonImgSrcCssWatcher = commonProductPageNonImgSrcCss.slice(0); //create new instance;
productPageNonImgSrcCssWatcher.push(config.src.cssPath + '/productpage/enhanced-benefits.css');
gulp.watch(productPageNonImgSrcCssWatcher, function (event) {
    livereload.listen();
    console.log('Last', event.type+" at "+getdate().yellow.bold);
    if (event.type == 'changed') {
        gulp.start('productpagecss');
    }
});
//task for compare-no-js css
var comparenojsSrcCss = [
    config.src.cssPath + "/compare-no-js.css"
];
var comparenojsDistCss = "compare-no-js.css";
gulp.task('comparenojscss', function () {
    gulp.src(comparenojsSrcCss)
            .pipe(csslint())
            .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
            .pipe(minifyCSS())
            .pipe(concat(comparenojsDistCss, {newLine: ' '}))
            .pipe(through.obj(imagebuster.cssImageBuster))
            .pipe(gulp.dest(config.dest.cssPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(comparenojsSrcCss, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type == 'changed') {
        gulp.start('comparenojscss');
    }
});

//task for compare page css
var comparePageSrcCss = [
    config.src.cssPath + '/common/custom-scrollbar.css',
    config.src.cssPath + '/findoffer/find-Offer-vac-compare.css',
    config.src.cssPath + '/findoffer/find-Offer-common.css',
    config.src.cssPath + '/comparepage/annual-fee.css',
    config.src.cssPath + '/comparepage/compare-page.css',
    config.src.cssPath + '/comparetray/compare-tray.css',
    config.src.cssPath + '/comparetray/newcompare-tray.css',
    config.src.cssPath + '/comparepage/css-buttons.css',
    config.src.cssPath + '/comparepage/details.css',
    config.src.cssPath + '/overlay/overlay.css',
    config.src.cssPath + '/comparepage/overview.css',
    config.src.cssPath + '/comparepage/payment-type.css',
    config.src.cssPath + '/comparepage/rewards.css',
    config.src.cssPath + '/comparepage/terms-regulations.css',
    config.src.cssPath + '/comparepage/good-for.css',
    config.src.cssPath + '/icons/retina/icons-sprite.css',
    config.src.cssPath + '/responsivecardart/card-art-scaling.css',
    config.src.cssPath + '/cardbytype/cardsbytype-sprite.css',
	config.src.cssPath + '/comparepage/mobile_overlay.css',
    config.src.cssPath + '/component/scroll-arrow-nav_module.css'


];
var getListOfComparePageCSSSrc = function () {
    var srcList = comparePageSrcCss;
    //Now add all the good for css
    for (var i = 0; i < productPagesCSS.length; i++) {
        var productName = productPagesCSS[i].name;
        srcList.push(config.src.cssPath + '/goodfor/' + productName + '-sprite.css');
    }
    
    
    
    //Add base good for css
    srcList.push(config.src.cssPath + '/comparepage/good-for.css');
    //Add icons css
    srcList.push(config.src.cssPath + '/icons/retina/icons-sprite.css');
    //Keep compare-page.css at the end so that if require we can ovveride sprite css
    srcList.push(config.src.cssPath + '/compare-page.css');
    //srcList.push(config.src.cssPath + '/comparepage/compare-inpageNav.css');

    return srcList;
};
gulp.task('comparepagecss', function (callback) {
    var srcCss = getListOfComparePageCSSSrc();
    var destCss = 'compare-page.css';
    gulp.src(srcCss)
            .pipe(csslint())
            .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
            .pipe(minifyCSS())
            .pipe(concat(destCss, {newLine: ' '}))
            .pipe(through.obj(imagebuster.cssImageBuster))
            .pipe(gulp.dest(config.dest.cssPath))
            .on('end', callback)
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(getListOfComparePageCSSSrc(), function (event) {
    livereload.listen();
    console.log('Last ', event.type +" "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('comparepagecss');
    }
});


//task for viewall page css

var viewAllCardsSrcCss = [
    config.src.cssPath + '/common/custom-scrollbar.css', 
    config.src.cssPath + '/viewallcardspage/main.css',
    config.src.cssPath + '/findoffer/find-Offer-vac-compare.css',
    config.src.cssPath + '/findoffer/find-Offer-common.css',
    config.src.cssPath + '/viewallcardspage/header-horizontal.css',
    config.src.cssPath + '/comparetray/compare-tray.css',
    config.src.cssPath + '/comparetray/newcompare-tray.css',
    config.src.cssPath + '/overlay/overlay.css',
    config.src.cssPath + '/responsivecardart/card-art-scaling.css',
    config.src.cssPath + '/responsivecardart/card-art-scaling-tile.css',
    config.src.cssPath + '/cardbytype/cardsbytype-sprite.css',
    config.src.cssPath + '/viewallcardspage/filter-horizontal.css', 
    config.src.cssPath + '/viewallcardspage/filter-vertical.css',   
/*    config.src.cssPath + '/viewallcardspage/compare-tray-dropdown.css',*/ 
    config.src.cssPath + '/viewallcardspage/compare-tray-horizontal.css', 
    config.src.cssPath + '/viewallcardspage/page-view-horizontal.css',
    config.src.cssPath + '/viewallcardspage/page-view-vertical.css',
    config.src.cssPath + '/viewallcardspage/grid-view-tile.css',
     config.src.cssPath + '/viewallcardspage/gcp-grid-list-view.css',
    config.src.cssPath + '/viewallcardspage/grid-view.css',
    config.src.cssPath + '/viewallcardspage/list-view-tile.css',
    config.src.cssPath + '/viewallcardspage/list-view.css',
    config.src.cssPath + '/viewallcardspage/quick-look.css',
    config.src.cssPath + '/viewallcardspage/fat-footer.css',
    config.src.cssPath + '/viewallcardspage/cards-by-type.css',
    config.src.cssPath + '/viewallcardspage/ua-offer.css',
    config.src.cssPath + '/viewallcardspage/good-for.css',
    config.src.cssPath + '/plumoffer/plum-benefits.css',
    config.src.cssPath + '/viewallcardspage/cards-show-hide.css',
    config.src.cssPath + '/viewallcardspage/iphone-six.css'
];

var getListOfViewallPageCSSSrc = function () {
    var srcList = viewAllCardsSrcCss;
    //Now add all the good for css
    for (var i = 0; i < productPagesCSS.length; i++) {
        var productName = productPagesCSS[i].name;
        srcList.push(config.src.cssPath + '/goodfor/' + productName + '-sprite.css');
    }

    //Add icons css
    srcList.push(config.src.cssPath + '/icons/retina/icons-sprite.css');
    return srcList;
};
gulp.task('viewallcardcss', function (callback) {
    var srcCss = getListOfViewallPageCSSSrc();
    var destCss = 'viewall-cards.css';
    gulp.src(srcCss)
            .pipe(csslint())
            .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
            .pipe(minifyCSS())
            .pipe(concat(destCss, {newLine: ' '}))
            .pipe(through.obj(imagebuster.cssImageBuster))
            .pipe(gulp.dest(config.dest.cssPath))
            .on('end', callback)
            .pipe(livereload());
});
//Task for watcher and livereload

gulp.watch(getListOfViewallPageCSSSrc(), function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('viewallcardcss');
    }
});

//This is for nom imaginary product page
var productPageSrcjs = [
    config.src.jsPath + '/productpage/Benefits.js',
    config.src.jsPath + '/productpage/CardReviews.js',
    config.src.jsPath + '/productpage/Details.js',
    config.src.jsPath + '/productpage/ExpenseManagement.js',
    config.src.jsPath + '/productpage/Footer.js',
    config.src.jsPath + '/productpage/InPageNav.js',
    config.src.jsPath + '/productpage/Offer.js',
    config.src.jsPath + '/productpage/Overview.js',
    config.src.jsPath + '/productpage/PageLoad.js',
    config.src.jsPath + '/productpage/ProductPage.js',
    config.src.jsPath + '/productpage/SimplyCash.js',
    config.src.jsPath + '/productpage/ProductPageMain.js',
    config.src.jsPath + '/component/scroll-arrow-nav_module.js',
    config.src.jsPath + '/component/video_module.js'
];
var productPageNonImgDistjs = "product-page-nonimg.js";
gulp.task('productpagejs', function () {
    gulp.src(productPageSrcjs)
            .pipe(uglifyJs())
            .pipe(concat(productPageNonImgDistjs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload
var productPageSrcjsWatcher = productPageSrcjs.slice(0); //create new instance;
productPageSrcjsWatcher.push(config.src.jsPath + '/productpage/ExpenseManagement.js');
gulp.watch(productPageSrcjsWatcher, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('productpagejs');
    }
});

//imaginary product page
var productPageImaginarySrcjs = [
    config.src.jsPath + '/carousel.js',
    config.src.jsPath + '/product-details.js'
];
var productPageImginaryDistjs = "product-details.js";
gulp.task('productpageimaginaryjs', function () {
    gulp.src(productPageImaginarySrcjs)
            .pipe(uglifyJs())
            .pipe(concat(productPageImginaryDistjs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(productPageImaginarySrcjs, function (event) {
    livereload.listen();
    console.log('Last ', event.type);
    if (event.type === 'changed') {
        gulp.start('productpageimaginaryjs');
    }
});


//task for homepage css
var homepageSrcCss = [
	config.src.cssPath + '/common/custom-scrollbar.css',
    config.src.cssPath + '/icons/retina/icons-sprite.css',
    config.src.cssPath + '/cardsprite/normal/*.*',
    config.src.cssPath + '/cardsprite/retina/*.*',
    config.src.cssPath + '/carousel.css',
    config.src.cssPath + '/homepage/main.css',
    config.src.cssPath + '/homepage/inthespotlight-module.css',
    config.src.cssPath + '/homepage/bgr-spotlight-module.css',
    config.src.cssPath + '/homepage/bplat-spotlight-module.css',
    config.src.cssPath + '/homepage/plum-spotlight-module.css',
    config.src.cssPath + '/homepage/spg-spotlight-module.css',
    config.src.cssPath + '/homepage/gold_delta-spotlight-module.css',
    config.src.cssPath + '/homepage/simply_cash-spotlight-module.css',
    config.src.cssPath + '/homepage/banner-module.css',
    config.src.cssPath + '/homepage/viewallcards-module.css',
    config.src.cssPath + '/homepage/comparecards-module.css',
    config.src.cssPath + '/homepage/quiz-module.css',
    config.src.cssPath + '/findoffer/find-Offer-homepage.css',
    config.src.cssPath + '/findoffer/find-Offer-common.css',
    config.src.cssPath + '/homepage/common.css',
    config.src.cssPath + '/homepage/card-art-scaling.css',
    config.src.cssPath + '/component/scroll-arrow-nav_module.css',
    config.src.cssPath + '/common/vac-offer.css'
];
var homepageDistCss = "home-page.css";
gulp.task('homepagecss', function () {
    gulp.src(homepageSrcCss)
            .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
            .pipe(minifyCSS())
            .pipe(concat(homepageDistCss, {newLine: ' '}))
            .pipe(through.obj(imagebuster.cssImageBuster))
            .pipe(gulp.dest(config.dest.cssPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(homepageSrcCss, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('homepagecss');
    }
});


//task for universal css
var universalSrcCss = [
    config.src.cssPath + '/common/component.css',
    config.src.cssPath + '/common/buttons.css',
    config.src.cssPath + "/universal/universal.css",
    config.src.cssPath + "/universal/C2C-Drawer.css",
    config.src.cssPath + "/universal/ajNav.css"
];
var universalDistCss = "universal.css";
gulp.task('universalcss', function () {
    gulp.src(universalSrcCss)
            .pipe(csslint())
            .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
            .pipe(minifyCSS())
            .pipe(concat(universalDistCss, {newLine: ' '}))
            .pipe(through.obj(imagebuster.cssImageBuster))
            .pipe(gulp.dest(config.dest.cssPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(universalSrcCss, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('universalcss');
    }
});

//task for universal js
var universalSrcJs = [    
    config.src.jsPath + "/universal/main.js", 
    config.src.jsPath + "/universal/applybutton.js", 
    config.src.jsPath + "/universal/C2C-Drawer.js", 
    config.src.jsPath + "/universal/lptag.js",
    config.src.jsPath + "/universal/ajNav.js", 
    config.src.jsPath + "/universal/inpageNav.js"
];
var jqueryminSrcJs = config.src.jsPath + "/jquery.min.js";

var universalDistJs = "universal.js";
gulp.task('universaljs', function () {
    es.concat(
            gulp.src(jqueryminSrcJs),
            gulp.src(universalSrcJs).pipe(concat(universalDistJs, {newLine: ' '}))
            )
            .pipe(sort())
            .pipe(concat(universalDistJs, {newLine: ' '}))
            .pipe(uglifyJs())
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});


//Task for watcher and livereload

gulp.watch(universalSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('universaljs');
    }
});

//task for home page js
var homepageSrcJs = [
    config.src.jsPath + "/ua-validations.js",
    config.src.jsPath + "/carousel.js",
    config.src.jsPath + "/universal/findOffers.js",
    config.src.jsPath + "/homepage/inthespotlight-module.js",
    config.src.jsPath + "/homepage/viewallcards-module.js",
    config.src.jsPath + "/homepage/comparecards-module.js",
    config.src.jsPath + "/homepage/quiz-module.js",
    config.src.jsPath + "/homepage/common.js",
    config.src.jsPath + "/homepage/main.js",
    config.src.jsPath + "/component/scroll-arrow-nav_module.js",
	config.src.jsPath + "/universal/scrollbar.js"

];
var homepageDistJs = "home-page.js";
gulp.task('homepagejs', function () {
    gulp.src(homepageSrcJs)
            .pipe(uglifyJs())
            .pipe(concat(homepageDistJs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(homepageSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('homepagejs');
    }
});

// compare page gulp task ua-validation + compare page
var comparePageSrcJs = [
    config.src.jsPath + "/ua-validations.js",
    config.src.jsPath + "/universal/findOffers.js",
    config.src.jsPath + "/component/utility.js",
    config.src.jsPath + "/comparepage/main.js",
    config.src.jsPath + "/comparepage/ready.js",
    config.src.jsPath + "/comparepage/reload.js",
    config.src.jsPath + "/comparepage/filter.js",
    config.src.jsPath + "/comparepage/accordion.js",
    config.src.jsPath + "/comparepage/add-remove-card.js",
    config.src.jsPath + "/comparepage/navigate.js",
    config.src.jsPath + "/comparepage/common.js",
	config.src.jsPath + "/comparepage/mobile_overlay.js",
	config.src.jsPath + "/universal/scrollbar.js",
	config.src.jsPath + "/universal/overlay_filter.js",
    config.src.jsPath + "/component/scroll-arrow-nav_module.js"

];
var comparePageDistJs = "compare-cards.js";
gulp.task('comparepagejs', function () {
    gulp.src(comparePageSrcJs)           
            .pipe(uglifyJs())
            .pipe(concat(comparePageDistJs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(comparePageSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('comparepagejs');
    }
});

//view-all card gulp task
var viewAllCardsPageSrcJs = [
    config.src.jsPath + "/ua-validations.js",
    config.src.jsPath + "/universal/findOffers.js",
    config.src.jsPath + "/viewallcardspage/main.js",
    config.src.jsPath + "/viewallcardspage/common.js",
    config.src.jsPath + "/component/utility.js",
    config.src.jsPath + "/viewallcardspage/filter-horizontal.js",
    config.src.jsPath + "/viewallcardspage/filter-vertical.js",
    config.src.jsPath + "/viewallcardspage/compare-tray-horizontal.js",
    config.src.jsPath + "/viewallcardspage/compare-tray-dropdown.js",
    config.src.jsPath + "/viewallcardspage/grid-view-bau.js",
    config.src.jsPath + "/viewallcardspage/grid-view-tile.js",
    config.src.jsPath + "/viewallcardspage/list-view-bau.js",
    config.src.jsPath + "/viewallcardspage/list-view-tile.js",    
    config.src.jsPath + "/viewallcardspage/page-view-horizontal.js",
    config.src.jsPath + "/viewallcardspage/page-view-vertical.js",
    config.src.jsPath + "/viewallcardspage/quick-look.js",
    config.src.jsPath + "/viewallcardspage/cards-show-hide.js",
    config.src.jsPath + "/universal/findOffers.js",
    config.src.jsPath + "/universal/scrollbar.js"
];
var viewAllCardsPageDistJs = "viewall-cards.js";
gulp.task('viewallcardsjs', function () {
    gulp.src(viewAllCardsPageSrcJs)            
            .pipe(concat(viewAllCardsPageDistJs, {newLine: ' '}))
            .pipe(jshint()).pipe(uglifyJs())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//task for goodfor.js
var goodforSrcJs = [
    config.src.jsPath + "/goodfor.js"
];
var goodforDistJs = "goodfor.js";
gulp.task('goodforjs', function () {
    gulp.src(goodforSrcJs)
            .pipe(uglifyJs())
            .pipe(concat(goodforDistJs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});
//Task for watcher and livereload

gulp.watch(viewAllCardsPageSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('viewallcardsjs');
    }
});

//task for ratings-and-reviews css
var ratingsandreviewsSrcCss = [
    config.src.cssPath + '/icons/retina/icons-sprite.css',
    config.src.cssPath + '/common/custom-scrollbar.css',
    config.src.cssPath + "/ratingsandreviews/common.css",
    config.src.cssPath + '/cardsprite/normal/*.*',
    config.src.cssPath + '/cardsprite/retina/*.*',
    config.src.cssPath + "/ratingsandreviews/rr-buttons.css",
    config.src.cssPath + "/ratingsandreviews/multiplecards-reviews-header.css",
    config.src.cssPath + "/ratingsandreviews/singlecard-review-header.css",
    config.src.cssPath + "/ratingsandreviews/filter.css",
    config.src.cssPath + "/ratingsandreviews/filter-mobile.css",
    config.src.cssPath + "/ratingsandreviews/pagination.css",
    config.src.cssPath + "/ratingsandreviews/icon-scaling.css",
    config.src.cssPath + "/ratingsandreviews/multiplecards-reviews-results.css",
    config.src.cssPath + "/ratingsandreviews/single-reviews-results.css",
    config.src.cssPath + "/ratingsandreviews/sorry-page.css"
];
gulp.task('ratingsandreviewscss', function (callback) {
    var srcCss = ratingsandreviewsSrcCss;
    var destCss = 'ratings-and-reviews.css';
    gulp.src(srcCss)
            .pipe(csslint())
            .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9'))
            .pipe(minifyCSS())
            .pipe(concat(destCss, {newLine: ' '}))
            .pipe(through.obj(imagebuster.cssImageBuster))
            .pipe(gulp.dest(config.dest.cssPath))
            .on('end', callback)
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(ratingsandreviewsSrcCss, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('ratingsandreviewscss');
    }
});
//task for ratings-and-reviews.js
var ratingsandreviewsSrcJs = [
    config.src.jsPath + "/ratingsandreviews/main.js",
    config.src.jsPath + "/ratingsandreviews/common.js",
    config.src.jsPath + "/ratingsandreviews/customDropDown.js",
    config.src.jsPath + "/ratingsandreviews/filter.js",
    config.src.jsPath + "/ratingsandreviews/mobileFilter.js",
    config.src.jsPath + "/ratingsandreviews/pageLoad.js",
    config.src.jsPath + "/ratingsandreviews/accordion.js",
    config.src.jsPath + "/ratingsandreviews/header.js",
    config.src.jsPath + "/ratingsandreviews/reviews.js",
    config.src.jsPath + "/ratingsandreviews/reviewFeedback.js",
    config.src.jsPath + "/ratingsandreviews/pagination.js"

];
var ratingsandreviewsDistJs = "ratings-and-reviews.js";
gulp.task('ratingsandreviewsjs', function () {
    gulp.src(ratingsandreviewsSrcJs)
            .pipe(uglifyJs())
            .pipe(concat(ratingsandreviewsDistJs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(ratingsandreviewsSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('ratingsandreviewsjs');
    }
});

//task for ratings-and-reviews-local.js
var ratingsandreviewslocalSrcJs = [
    config.src.jsPath + "/ratingsandreviews/ratings-and-reviews-local.js"
];
var ratingsandreviewslocalDistJs = "ratings-and-reviews-local.js";
gulp.task('ratingsandreviewslocaljs', function () {
    gulp.src(ratingsandreviewslocalSrcJs)
            .pipe(uglifyJs())
            .pipe(concat(ratingsandreviewslocalDistJs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(ratingsandreviewsSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('ratingsandreviewsjs');
    }
});

//task for quiz.js
var quizSrcJs = [
    config.src.jsPath + "/quiz.js"
];
var quizDistJs = "quiz.js";
gulp.task('quizjs', function () {
    gulp.src(quizSrcJs)
            .pipe(uglifyJs())
            .pipe(concat(quizDistJs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(quizSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('quizjs');
    }
});

//task for interstitial-page.js
var interstitialpageSrcJs = [
    config.src.jsPath + "/interstitial-page.js"
];
var interstitialpageDistJs = "interstitial-page.js";
gulp.task('interstitialpagejs', function () {
    gulp.src(interstitialpageSrcJs)
            .pipe(uglifyJs())
            .pipe(concat(interstitialpageDistJs, {newLine: ' '}))
            .pipe(jshint())
            .pipe(through.obj(imagebuster.jsImageBuster))
            .pipe(gulp.dest(config.dest.jsPath))
            .pipe(livereload());
});

//Task for watcher and livereload

gulp.watch(interstitialpageSrcJs, function (event) {
    livereload.listen();
    console.log('Last ', event.type+" at "+getdate().yellow.bold);
    if (event.type === 'changed') {
        gulp.start('interstitialpagejs');
    }
});

//Task to delete the build folders
gulp.task('cleanbuild', function () {
    var buildPathList = [];
    //Get the array structure as required by gulp task
    for (var key in config.dest) {
        if (config.dest.hasOwnProperty(key)) {
            buildPathList.push(config.dest[key]);
        }
    }
    return gulp.src(buildPathList).pipe(clean());
});

// task to catch all images over 100Kb in size
gulp.task('checkbigimg', function () {
    var allFileSizeValid = true;
    gulp.src(config.dest.imagesPath + '/**/*.*')
            .pipe(
                    checkFilesize({
                        fileSizeLimit: 102400 // 102400 === 100Kb 
                    }, function (err, file, isValid) {
                        if (isValid === false) {
                            allFileSizeValid = false;
                        }
                    })
                    )
            .on('end', function () {
                console.log("End ");
                //Throw error for last file
                if (allFileSizeValid === false) {
                    throw new Error("Few of the file size is greater than the given limit. Please check the error");
                } else {

                }
            });

});

// run tasks together
gulp.task('build', false, function () {
    runSequence('cleanbuild', 'watch', 'goodforsprite', 'flatcardartspriteretina', 'flatcardartspritenormal','flatcardartspritenormalsmall', 'iconspriteretina', 'cardsbytypesprite', 'productpagecss', 'comparepagecss', 'viewallcardcss', 'productpagejs', 'universaljs', 'homepagejs', 'homepagecss', 'comparepagejs', 'viewallcardsjs', 'ratingsandreviewsjs', 'ratingsandreviewslocaljs', 'ratingsandreviewscss', 'universalcss', 'comparenojscss', 'quizjs', 'interstitialpagejs', 'copy', 'checkbigimg', 'goodforjs');
});
