var map = require('map-stream'),
	gutil = require('gulp-util'),
	getFileSize = require('filesize'),
	zlib = require('zlib');

module.exports = function(options, gulpcallback){
	'use strict';

	if (typeof options === 'undefined') {
		options = {};
	}

	return map(function(file, callback){
		var filenameShort = file.path.split(/\/|\\/).pop(),
			//Check if file.stat exists (gulp.concat removes it for example)
			filesize = file.stat && file.stat.size ? file.stat.size : Buffer.byteLength(String(file.contents)),
			formattedFilesize = getFileSize(filesize);

		if (typeof options.fileSizeLimit !== 'undefined' && filesize > options.fileSizeLimit) {
			var message = '';
			message = gutil.colors.bold.red('ERROR:') + ' ' + gutil.colors.red(file.path) +
				' exceeded filesize limit of ' + getFileSize(options.fileSizeLimit) + ': ' +
				gutil.colors.red(formattedFilesize) + ' ';	
			console.error(message);
			gulpcallback(null,file,false);
		} else {
			gulpcallback(null,file,true);	
		}
		
	});
};