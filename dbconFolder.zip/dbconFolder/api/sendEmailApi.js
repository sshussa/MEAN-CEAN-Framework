/**
 * Created by shuss22 on 6/17/2017.
 */

'use strict';

var co = require('co');
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var MongoClient = require('mongodb').MongoClient
    , assert = require("assert");
var hbs = require('nodemailer-express-handlebars');



//mongodb config

var environmentVariable=process.env.EPAAS_ENV;

console.log("environment variable::",environmentVariable);

var url =(environmentVariable==='e1')?'mongodb://dbcon_user:c0mp1expassw0rd@LPDOSPDB00394:27017/dbcon?authSource=admin': (environmentVariable==='e2')?'mongodb://dbcon_user:c0mp1expassw0rd@LPQOSPDB00385:27017,LPQOSPDB00384:27017, LPQOSPDB00383:27017/dbcon?replicaSet=pqmcl141&authSource=admin':'mongodb://dbcon_user:c0mp1expassw0rd@LGPOSPDB00609:27017,LGPOSPDB00607:27017, LGPOSPDB00608:27017, LPPOSPDB40269:27017/dbcon?replicaSet=gpmcl157&authSource=admin';


// create reusable transporter object using the default SMTP transport
var transporter = nodemailer.createTransport(smtpTransport({
    host: (environmentVariable==='e1')?'tenant-proxy-e1.aexp.com':(environmentVariable ==='e2')?'tenant-proxy-e2.aexp.com':'tenant-proxy-e32.aexp.com',
    port: 25
}));


//attach the plugin to the nodemailer transporter
transporter.use('compile', hbs({
    viewPath:'./views/',
    extName:'.hbs'
}));


// routes
var appRouter = function (app) {

    app.get('/api/userDetails', function(req, res) {
        var ssoResponses = req.headers;
        res.send(ssoResponses); // OK!
    });

    app.get('/get-data', function(req,res,next){
        var resultArray=[];
        MongoClient.connect(url,function(err,db){
            assert.equal(null, err);
            console.log("Connected correctly to server");
            var cursor=db.collection('registerDbCon').find({}).count().then((n) => {
                console.log(`There are ${n} documents`);
                var count = `${n}`;
                resultArray.push({count:count});
                db.close();
                res.send(resultArray);
            });
        });
    });


    app.post('/formReg', function (req,res, next) {

        var user = {
            firstname : req.headers.firstname,
            lastname : req.headers.lastname,
            email : req.headers.email,
            employeeid :req.headers.employeeid,
            pass1:req.body.pass1,
            pass2:req.body.pass2,
            pass3:req.body.pass3,
            pass4:req.body.pass4,
            pass5:req.body.pass5,
            pass6:req.body.pass6,
            pass7:req.body.pass7,
            pass8:req.body.pass8,
            pass9:req.body.pass9
        };

        var timestamp = new Date();
        user.timestamp = timestamp;

        MongoClient.connect(url, function(err, db) {
            assert.equal(null, err);
            console.log("Connected correctly to mongo db server");
            db.collection('registerDbCon').insertOne(user,function (error,result) {
                assert.equal(null,error);
                console.log("successfully inserted!");
                db.close();
            })
        });

        var mailOptions = {
            from: 'DBCONSupport@aexp.com',
            to: req.headers.email,
            subject: "DBCON Registration Confirmation",
            template: 'email',
            context: {
                user: user
            }
        };

        // send mail with defined transport object
        transporter.sendMail(mailOptions, function(error, info){
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
            res.sendStatus(200);
         });
    });
    
};

module.exports = appRouter;