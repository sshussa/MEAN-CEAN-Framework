var fs = require('fs');
var https = require('https');
var path = require("path");
var session = require('cookie-session');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var morgan  = require('morgan');
var methodOverride = require('method-override');
var helmet = require('helmet');


//SSL Configuration Global

 var port = process.env.PORT || '8443';
 var ip   = '0.0.0.0';
 var privateKey = fs.readFileSync('/opt/epaas/certs/key');
 var certificate = fs.readFileSync('/opt/epaas/certs/cert');
 var ca = fs.readFileSync('/opt/epaas/certs/ca');
 var pass = fs.readFileSync('/opt/epaas/certs/pass','ascii');


//SSL Config Local

/*var port = process.env.PORT || '8443';
var ip   = '0.0.0.0';
var privateKey = fs.readFileSync('C:/certs/key.txt');
var certificate = fs.readFileSync('C:/certs/cert.txt');
var ca = fs.readFileSync('C:/certs/ca.txt');
var pass = fs.readFileSync('C:/certs/pass.txt','ascii');*/


//cross origin request headers

app.use(function (req, res, next) { //allow cross origin requests
    res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
    res.header("Access-Control-Allow-Origin", "https://localhost,https://dbcon-dev.aexp.com, https://dbcon-qa.aexp.com, https://dbcon.aexp.com");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

//All environments

app.set('port',port);
// view engine setup
app.set('views', path.join(__dirname+ '/views'));
app.set('view engine', 'hbs');
app.use('/assets', express.static(path.join(__dirname + '/assets'))); // set the static files location /public/img will be /img for users
app.use(morgan('dev'));                                              // log every request to the console
app.use(bodyParser.urlencoded({'extended':'true'}));                // parse application/x-www-form-urlencoded
app.use(bodyParser.json());                                        // parse application/json
app.use(bodyParser.json({ type: 'application/vnd.api+json' }));   // parse application/vnd.api+json as json
app.use(methodOverride());
app.use(helmet());


var expiryDate = new Date(Date.now() + 60 * 60 * 500) // 30 mins
app.use(session({
    name: 'session',
    keys: ['key1', 'key2'],
    cookie: {
        secure: true,
        httpOnly: true,
        domain :'aexp.com',
        path: '/',
        expires: expiryDate
    }
}));

var options = {
    key: privateKey,
    cert: certificate,
    ca: ca,
    passphrase: pass,
    requestCert: true,
    rejectUnauthorized: false
};

options.agent = new https.Agent(options);

var sendEmailApi = require('./api/sendEmailApi.js')(app);

app.all('*', function(req, res) {
    res.sendFile(__dirname +'/index.html');
});

https.createServer(options, app).listen(port, ip, function () {
    console.log('Running on ' + ip + ':' + port);
});




