# DBCON is a ePaaS Cloud Application implemented in JQuery and Node.js. This application is configured with Custom SSO seamless based authentication.

