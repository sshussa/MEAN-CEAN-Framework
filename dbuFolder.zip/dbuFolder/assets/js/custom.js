/* Write here your custom javascript codes */

jQuery(document).ready(function() {
    App.init();
    App.initCounter();
    App.initParallaxBg();
    RevolutionSlider.initRSfullScreenOffset();
});