/**
 * Created by kdmckiss on 7/20/17.
 */
'use strict';
// var http = require('http');
var request = require('request');
const conSS = {};
conSS.do = function (pageNum, query, cb) {
    //siteSearch+~+"couchbase"&queryString=couchbase
    //'+query+'&limit=300
    console.log('pageNum in confluenceSearch ' + pageNum);
    var offset = ((pageNum - 1) * 25);
    console.log('offset ' + offset);
    request.get('https://enterprise-confluence.aexp.com/confluence/rest/api/search?cql=text~' + query + '%20AND%20type!=attachment&limit=25&start=' + offset, function (error, response, body) {
        console.log('error:', error); // Print the error if one occurred
        console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
        console.log('body:', body); // Print the HTML for the Google homepage.
        if (error) {
            cb(null);
        } else {
            if (response.statusCode === 200) {
                cb(body);
            } else {
                cb(null);
            }
        }
    });
};

module.exports = conSS;

