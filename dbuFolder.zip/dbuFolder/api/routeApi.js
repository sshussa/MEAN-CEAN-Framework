/**
 * Created by shuss22 on 8/2/2017.
 */


var MongoClient = require('mongodb').MongoClient
    , assert = require("assert");
var hbs = require('nodemailer-express-handlebars');



//mongodb config

var environmentVariable=process.env.EPAAS_ENV;

var url =(environmentVariable==='e1')?'mongodb://dbu_user:c0mp1expassw0rd@LPDOSPDB00394:27017/dbuniverse?authSource=admin': (environmentVariable==='e2')?'mongodb://dbu_user:c0mp1expassw0rd@LPQOSPDB00385:27017,LPQOSPDB00384:27017, LPQOSPDB00383:27017/dbuniverse?replicaSet=pqmcl141&authSource=admin':'mongodb://dbu_user:c0mp1expassw0rd@LGPOSPDB00609:27017,LGPOSPDB00607:27017, LGPOSPDB00608:27017, LPPOSPDB40269:27017/dbuniverse?replicaSet=gpmcl157&authSource=admin';


// routes
var appRouter = function (app) {

    app.get('/api/userDetails', function(req, res) {
        var ssoResponses = req.headers;
        res.send(ssoResponses); // OK!
    });

    app.get('/whoami', function (req, res) {
        res.send(req.socket.getPeerCertificate().subject.CN + ' at ' + req.connection.remoteAddress);
    });

};

module.exports = appRouter;