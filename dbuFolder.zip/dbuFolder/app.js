/**
 * Created by shuss22 on 8/2/2017.
 */

var fs = require('fs');
var https = require('https');
var session = require('cookie-session');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var morgan  = require('morgan');
var methodOverride = require('method-override');
var path = require("path");
var helmet =require('helmet');


//SSL Configuration Global

/*var port = 8443;
var ip   = '0.0.0.0';
var privateKey = fs.readFileSync('/opt/epaas/certs/key');
var certificate = fs.readFileSync('/opt/epaas/certs/cert');
var ca = fs.readFileSync('/opt/epaas/certs/ca');
var pass = fs.readFileSync('/opt/epaas/certs/pass','ascii');*/


//SSL Configuration Local

const port = 8443;
const ip   = '0.0.0.0';
const privateKey = fs.readFileSync('C:/certs/key.txt');
const certificate = fs.readFileSync('C:/certs/cert.txt');
const ca = fs.readFileSync('C:/certs/ca.txt');
const pass = fs.readFileSync('C:/certs/pass.txt','ascii');


//cross origin request headers

app.use(function (req, res, next) { //allow cross origin requests
    res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
    res.header("Access-Control-Allow-Origin", "https://dbuniverse-qa.aexp.com","https://dbuniverse-dev.aexp.com", "https://localhost:8443", "https://dbuniverse.aexp.com");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

//All environments

app.set('port',port);
// view engine setup
/*app.set('views', path.join(__dirname+ '/views'));
 app.set('view engine', 'hbs');*/
app.use(express.static(__dirname + '/assets'));  // set the static files location /public/img will be /img for users
app.use(morgan('dev'));                                         // log every request to the console
app.use(bodyParser.urlencoded({'extended':'true'}));            // parse application/x-www-form-urlencoded
app.use(bodyParser.json());                                     // parse application/json
app.use(bodyParser.json({ type: 'application/vnd.api+json' })); // parse application/vnd.api+json as json
app.use(methodOverride());
app.use(helmet());


var expiryDate = new Date(Date.now() + 60 * 60 * 500) // 30 mins
app.use(session({
    name: 'session',
    keys: ['key1', 'key2'],
    cookie: {
        secure: true,
        httpOnly: true,
        domain :'aexp.com',
        path: '/',
        expires: expiryDate
    }
}));

var options = {
    key: privateKey,
    cert: certificate,
    ca: ca,
    passphrase: pass,
    requestCert: true,
    rejectUnauthorized: false
};

options.agent = new https.Agent(options);

var routesApi = require('./api/routeApi.js')(app);

var conSS= new require('./api/confluenceSearch');

app.get('/confluenceSearch', function(req, res){
    conSS.do(req.query.pageNm, req.query.phrase, function(data){
        if(data){
            console.log('returned data ' ,data);
            res.status(200).json(data);
            // res.json(data, 200);
        }else{
            console.log('null data ' ,data);
            res.status(204).json(null);
            // res.json(null, 204); 
        }
    })
});


app.all('*', function(req, res) {
    res.sendFile(path.join(__dirname, 'assets/index.html'));
});

https.createServer(options, app).listen(port, ip, function () {
    console.log('Running on ' + ip + ':' + port);
});

