/**
 * Created by shuss22 on 7/28/2017.
 */

var gulp = require('gulp');

var srcPath = [
  '**/*',
  '!gulpfile.js',
  '!.*'
];

gulp.task('build', function () {
  return gulp.src(srcPath)
      .pipe(gulp.dest('dist/'))
});



/*var gulp = require('gulp');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var minify = require('gulp-minify-css');
var gutil=require('gulp-util');
var babel = require('gulp-babel');


gulp.task('js', function() {
  return gulp.src(['assets/source/scripts/!*.js'])
      .pipe(concat('app.js'))
      .pipe(babel({presets: ['babili']}))
      .on('error', function (err) { gutil.log(gutil.colors.red('[Error]'), err.toString()); })
      .pipe(gulp.dest('assets/destination/scripts/'));
  //.pipe(livereload());
});

gulp.task('css', function(){
  gulp.src('assets/source/styles/!*.css')
      .pipe(concat('dbuStyle.css'))
      .pipe(minify())
      .pipe(gulp.dest('assets/destination/styles/'));
});

var srcPath = [
  '**!/!*',
  '!gulpfile1.js',
  '!.*'
];

gulp.task('build', function () {
  return gulp.src(srcPath)
      .pipe(gulp.dest('dist/'))
});


gulp.task('default',['js','css'],function(){
});*/
